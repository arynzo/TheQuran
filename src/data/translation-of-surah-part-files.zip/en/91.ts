import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wash shamsi wa duhaa haa"
  },
  {
    "id": 2,
    "text": "Wal qamari izaa talaa haa"
  },
  {
    "id": 3,
    "text": "Wannahaari izaa jallaa haa"
  },
  {
    "id": 4,
    "text": "Wallaili izaa yaghshaa haa"
  },
  {
    "id": 5,
    "text": "Wassamaaa'i wa maa banaahaa"
  },
  {
    "id": 6,
    "text": "Wal ardi wa maa tahaahaa"
  },
  {
    "id": 7,
    "text": "Wa nafsinw wa maa sawwaahaa"
  },
  {
    "id": 8,
    "text": "Fa-alhamahaa fujoorahaa wa taqwaahaa"
  },
  {
    "id": 9,
    "text": "Qad aflaha man zakkaahaa"
  },
  {
    "id": 10,
    "text": "Wa qad khaaba man dassaahaa"
  },
  {
    "id": 11,
    "text": "Kazzabat Samoodu bi taghwaahaaa"
  },
  {
    "id": 12,
    "text": "Izim ba'asa ashqaahaa"
  },
  {
    "id": 13,
    "text": "Faqaala lahum Rasoolul laahi naaqatal laahi wa suqiyaahaa"
  },
  {
    "id": 14,
    "text": "Fakazzaboohu fa'aqaroohaa fadamdama 'alaihim Rabbuhum bizambihim fasaw waahaa"
  },
  {
    "id": 15,
    "text": "Wa laa yakhaafu'uqbaahaa"
  }
];

export default en;
