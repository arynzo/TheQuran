import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Ataaa amrullaahi falaa tasta'jilooh; Subhaanahoo wa Ta'aalaa 'ammaa yushrikoon"
  },
  {
    "id": 2,
    "text": "Yunazzilul malaaa 'ikata birroohi min amrihee 'alaa mai yashaaa'u min 'ibaadiheee an anzirooo annahoo laaa ilaaha illaaa ana fattaqoon"
  },
  {
    "id": 3,
    "text": "Khalaqas samaawaati wal arda bilhaqq; Ta'aalaa 'ammaa yushrikoon"
  },
  {
    "id": 4,
    "text": "Khalaqal insaana min nutfatin fa izaa huwa khaseemum mubeen"
  },
  {
    "id": 5,
    "text": "Wal an 'amaa khalaqahaa; lakum feehaa dif'unw wa manaafi'u wa minhaa taakuloon"
  },
  {
    "id": 6,
    "text": "Wa lakum feehaa jamaalun heena tureehoona wa heena tasrahoon"
  },
  {
    "id": 7,
    "text": "Wa tahmilu asqaalakum ilaa baladil lam takoonoo baaligheehi illaa bishiqqil anfus; inna Rabbakum la Ra'oofur Raheem"
  },
  {
    "id": 8,
    "text": "Walkhaila wal bighaala wal hameera litarkaboohaa wa zeenah; wa yakhluqu maa laa ta'lamoon"
  },
  {
    "id": 9,
    "text": "Wa 'alal laahi qasdus sabeeli wa minhaa jaaa'ir; wa law shaaa'a lahadaakum ajma'een"
  },
  {
    "id": 10,
    "text": "Huwal lazeee anzala minas samaaa'i maaa'al lakum minhu sharaabunw wa minhu shajarun feehi tuseemoon"
  },
  {
    "id": 11,
    "text": "Yumbitu lakum bihiz zar'a wazzaitoona wanna kheela wal-a'naaba wa min kullis samaraat, inna fee zaalika la Aayatal liqawminy yatafakkaroon"
  },
  {
    "id": 12,
    "text": "Wa sakkhkhara lakumul laila wannahaara wash shamsa walqamara wannujoomu musakhkharaatum bi amrih; inna fee zaalika la Aayaatil liqawminy ya'qiloon"
  },
  {
    "id": 13,
    "text": "Wa maa zara a lakum fil ardi mukhtalifan alwaanuh; inna fee zaalika la Aayatal liqawminy yazakkaroon"
  },
  {
    "id": 14,
    "text": "Wa Huwal lazee sakhkharal bahra litaakuloo minhu lahman tariyyanw wa tastakhrijoo minhu hilyatan talbasoonahaa wa taral fulka mawaakhira feehi wa litabtaghoo min fadlihee wa la'allakum tashkuroon"
  },
  {
    "id": 15,
    "text": "Wa alqaa fil ardi rawaasiya an tameeda bikum wa anhaaranw wa sublulal la 'allakum tahtadoon"
  },
  {
    "id": 16,
    "text": "Wa 'alaamaat; wa bin najmi hum yahtadoon"
  },
  {
    "id": 17,
    "text": "Afamany yakhluqu kamallaa yakhluq; afalaa tazak karoon"
  },
  {
    "id": 18,
    "text": "Wa in ta'uddoo ni'matal laahi laa tuhsoohaa; innal laaha la Ghafoorur Raheem"
  },
  {
    "id": 19,
    "text": "Wallaahu ya'lamu maa tusirroona wa maa tu'linoon"
  },
  {
    "id": 20,
    "text": "Wallazeena yad'oona min doonil laahi laa yakhluqoona shai'anw wa hum yukhlaqoon"
  },
  {
    "id": 21,
    "text": "Amwaatun ghairu ahyaaa'inw wa maa yash'uroona aiyaana yub'asoon"
  },
  {
    "id": 22,
    "text": "Ilahukum Ilaahunw Waahid; fallazeena laa yu'minoona bil Aakhirati quloobuhum munkiratunw wa hum mustakbiroon"
  },
  {
    "id": 23,
    "text": "Laa jarama annal laaha ya'lamu maa yusirrona wa ma yu'linoon; innahoo laa yuhibbul mustakbireen"
  },
  {
    "id": 24,
    "text": "Wa izaa qeela lahum maazaaa anzala Rabbukum qaaloo asaateerul awwaleen"
  },
  {
    "id": 25,
    "text": "Liyahmilooo awzaarahum kaamilatany Yawmal Qiyaamati wa min awzaaril lazeena yudilloonahum bighairi 'ilm; alaa saaa'a maa yaziroon"
  },
  {
    "id": 26,
    "text": "Qad makaral lazeena min qablihim fa atal laahu bunyaa nahum minal qawaa'idi fakharra 'alaihimus saqfu min fawqihim wa ataahumul 'azaabu min haisu laa yash'uroon"
  },
  {
    "id": 27,
    "text": "Summa Yawmal Qiyaamati yukhzeehim wa yaqoolu aina shurakaaa'iyal lazeena kuntum tushaaaqqoona feehim; qaalal lazeena ootul 'ilma innal khizyal Yawma wassooo'a 'alal kaafireen"
  },
  {
    "id": 28,
    "text": "Allazeena tatawaf faahu mul malaaa'ikatu zaalimeee anfusihim fa alqawus salama maa kunnaa na'malu min sooo'; balaaa innal laaha 'aleemum bimaa kuntum ta'maloon"
  },
  {
    "id": 29,
    "text": "Fadkhulooo abwaaba jahannama khaalideena feeha falabi'sa maswal mutakab bireen"
  },
  {
    "id": 30,
    "text": "Wa qeela lillazeenat taqaw maazaaa anzala Rabbukum; qaaloo khairaa; lillazeena ahsanoo fee haazihid dunyaa hasanah; wa la Daarul Aakhirati khair; wa lani'ma daarul muttaqeen"
  },
  {
    "id": 31,
    "text": "Jannaatu 'Adniny yadkhuloonahaa tajree min tahtihal anhaaru lahum feehaa maa yashaaa'oon; kazaalika yajzil laahul muttaqeen"
  },
  {
    "id": 32,
    "text": "Allazeena tatawaf faahumul malaaa'ikatu taiyibeena yaqooloona salaamun 'alai kumud khulul Jannata bimaa kuntum ta'maloon"
  },
  {
    "id": 33,
    "text": "Hal yanzuroona illaaa an taatiyahumul malaaa'ikatu aw yaatiya amru Rabbik; kazaalika fa'alal lazeena min qablihim; wa maa zalamahumul laahu wa laakin kaanoo anfusahum yazlimoon"
  },
  {
    "id": 34,
    "text": "Fa asaabahum saiyi aatu maa 'amiloo wa haaqa bihim maa kaano bihee yastahzi'oon"
  },
  {
    "id": 35,
    "text": "Wa qaalal lazeena ashrakoo law shaaa'al laahu ma 'abadnaa min doonihee min shai'in nahnu wa laaa aabaaa'unaa wa laa harramnaa min doonihee min shai'; kazaalika fa'alal lazeena min qablihim fahal 'alar Rusuli illal balaaghul mubeen"
  },
  {
    "id": 36,
    "text": "Wa laqad ba'asnaa fee kulli ummatir Rasoolan ani'budul laaha wajtanibut Taaghoota faminhum man hadal laahu wa minhum man haqqat 'alaihid dalaalah; faseeroo fil ardi fanzuroo kaifa kaana 'aaqibatul mukazzibeen"
  },
  {
    "id": 37,
    "text": "In tahris 'alaa hudaahum fa innal laaha laa yahdee mai yudillu wa maa lahum min naasireen"
  },
  {
    "id": 38,
    "text": "Wa aqsamoo billaahi jahda aimaanihim laa yab'asul laahu mai yamoot; balaa wa'dan 'alaihi haqqanw wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 39,
    "text": "Liyubaiyina lahumul lazee yakhtalifoona feehi wa liya'lamal lazeena kafarooo annahum kaanoo kaazibeen"
  },
  {
    "id": 40,
    "text": "Innamaa qawlunaa lishay'in izaa aradnaahu an naqoola lahoo kun fa yakoon"
  },
  {
    "id": 41,
    "text": "Wallazeena haajaroo fil laahi mim ba'di maa zulimoo lanubawwi' annahum fiddunyaa hasanatanw wa la ajrul Aakhirati akbar; law kaanoo ya'lamoon"
  },
  {
    "id": 42,
    "text": "Allazeena sabaroo wa 'alaa Rabbihim yatawak kaloon"
  },
  {
    "id": 43,
    "text": "Wa maaa arsalnaa min qablika illaa rijaalan nooheee ilaihim; fas'alooo ahlaz zikri in kuntum laa ta'lamoon"
  },
  {
    "id": 44,
    "text": "Bilbaiyinaati waz Zubur; wa anzalnaaa ilaikaz Zikra litubaiyina linnaasi maa nuzzila ilaihim wa la'allahum yatafakkaroon"
  },
  {
    "id": 45,
    "text": "Afa aminal lazeena makarus saiyi aati ai yakhsifal laahu bihimul arda aw yaaa tiyahumul 'azaabu min haisu laa yash'uroon"
  },
  {
    "id": 46,
    "text": "Aw yaakhuzahum fee taqallubihim famaa hum bi mu'jizeen"
  },
  {
    "id": 47,
    "text": "Aw yaakhuzahum 'alaa takhawwuf; fa inna Rabbakum la Ra'oofur Raheem"
  },
  {
    "id": 48,
    "text": "Awa lam yaraw ilaa maa khalaqal laahu min shai'iny-yatafaiya'u zilaaluhoo 'anil yameeni washshamaaa' ili sujjadal lillaahi wa hum daakhiroon"
  },
  {
    "id": 49,
    "text": "Wa lillaahi yasjudu maa fis samaawaati wa maa fil ardi min daaabbatinw walma laaa'ikatu wa hum laa yastakbiroon"
  },
  {
    "id": 50,
    "text": "Yakhaafoona Rabbahum min fawqihim wa yaf'aloona maa yu'maroon"
  },
  {
    "id": 51,
    "text": "Wa qaalal laahu laa tatta khizooo ilaahainis naini innamaa Huwa Ilaahunw Waahid; fa iyyaaya farhaboon"
  },
  {
    "id": 52,
    "text": "Wa lahoo maa fis samaawaati wal ardi wa lahud deenu waasibaa; afaghairal laahi tattaqoon"
  },
  {
    "id": 53,
    "text": "Wa maa bikum minni'matin faminal laahi summa izaa massakumud durru fa ilaihi taj'aroon"
  },
  {
    "id": 54,
    "text": "Summaa izaa kashafad durra 'ankum izaa fareequm minkum bi Rabbihim yushrikoon"
  },
  {
    "id": 55,
    "text": "Liyakfuroo bimaa aatainaahum; fatamatta'oo, fasawfa ta'lamoon"
  },
  {
    "id": 56,
    "text": "Wa yaj'aloona limaa laa ya'lamoona naseebam mimmaa razaqnaahum; tallaahi latus'alunaa 'ammaa kuntum taftaroon"
  },
  {
    "id": 57,
    "text": "Wa yaj'aloona lillaahil banaati Subhaanahoo wa lahum maa yashtahoon"
  },
  {
    "id": 58,
    "text": "Wa izaa bushshira ahaduhum bil unsaa zalla wajhuhoo muswaddanw wa huwa kazeem"
  },
  {
    "id": 59,
    "text": "Yatawaaraa minal qawmimin sooo'i maa bushshira bih; a-yumsikuhoo 'alaa hoonin am yadussuhoo fit turaab; alaa saaa'a maa yahkumoon"
  },
  {
    "id": 60,
    "text": "Lillazeena laa yu'minoona bil Aakhirati masalus saw'i wa lillaahil masalul a'laa; wa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 61,
    "text": "Wa law yu'aakhizul laahun naasa bizulminhim maa taraka 'alaihaa min daaabbatinw wa laakiny yu'akhkhiruhum ilaaa ajalim musamman fa izaa jaaa'a ajaluhum laa yastaakhiroona saa'atanw wa laa yastaqdimoon"
  },
  {
    "id": 62,
    "text": "Wa yaj'aloona lillaahi maa yakrahoona wa tasifu alsinatuhumul kaziba anna lahumul husnaa laa jarama anna lahumun Naara wa annahum mufratoon"
  },
  {
    "id": 63,
    "text": "Tallaahi laqad arsalnaaa ilaaa umamim min qablika fazayyana lahumush Shaitaanu a'maalahum fahuwa waliyyuhumul yawma wa lahum 'azaabun aleem"
  },
  {
    "id": 64,
    "text": "Wa maaa anzalnaa 'alaikal Kitaaba illaa litubaiyina lahumul lazikh talafoo feehi wa hudanw wa rahmatal liqawminy yu'minoon"
  },
  {
    "id": 65,
    "text": "Wallaahu anzala minas samaaa'i maaa'an fa ahyaa bihil arda ba'da mawtihaa; inna fee zaalika la aayatal liqaw miny yasma'oon"
  },
  {
    "id": 66,
    "text": "Wa inna lakum fil an'aami la'ibrah; nusqeekum mimmmaa fee butoonihee mim baini farsinw wa damil labanann khaalisan saaa'ighallish shaaribeen"
  },
  {
    "id": 67,
    "text": "Wa min samaraatin nakheeli wal a'naabi tattakhizoona minhu sakaranw wa rizqann hasanaa; inna fee zaalika la Aayatal liqawminy ya'qiloon"
  },
  {
    "id": 68,
    "text": "Wa awhaa Rabbuka ilan-nahli anit takhizee minal jibaali buyootanw wa minash shajari wa mimmaa ya'rishoon"
  },
  {
    "id": 69,
    "text": "Summma kulee min kullis samaraati faslukee subula Rabbiki zululaa; yakhruju mim butoonihaa sharaabum mukh talifun alwaanuhoo feehi shifaaa'ul linnaas, innna fee zaalika la Aayatal liqawminy yatafakkaroon"
  },
  {
    "id": 70,
    "text": "Wallaahu khalaqakum suma yatawaffaakum; wa minkum many-yuradu ilaaa arzalil 'umuri likai laa ya'lama ba'da 'ilmin shai'aa; innal laaha 'Aleemun Qadeer"
  },
  {
    "id": 71,
    "text": "Wallaahu faddala ba'dakum 'alaa ba'din fir rizq; famal lazeena fuddiloo biraaaddee rizqihim 'alaa maa malakat aimaanuhum fahum feehi sawaaa'; afabini'matil laahi yajhadoon"
  },
  {
    "id": 72,
    "text": "Wallaahu ja'ala lakum min anfusikum azwaajanw wa ja'ala lakum min azwaajikum baneena wa hafadatanw wa razaqakum minat taiyibaat; afabil baatili yu'minoona wa bini'matil laahi hum yakkfuroon"
  },
  {
    "id": 73,
    "text": "Wa ya'budoona min doonil laahi maa laa yamliku lahum rizqam minas samaawaati wal ardi shai'anw wa laa yastatee'oon"
  },
  {
    "id": 74,
    "text": "Falaa tadriboo lillaahil amsaal; innal laaha ya'lamu wa antum laa ta'lamoon"
  },
  {
    "id": 75,
    "text": "Darabal laahu masalan 'abdam mammlookal laa yaqdiru 'alaa shai'inw wa marrazaqnaahu mminnaa rizqan hasanan fahuwa yunfiqu minhu sirranw wa jahra; hal yasta-woon; alhamdu lillaah; bal aksaruhum laa ya'lamoon"
  },
  {
    "id": 76,
    "text": "Wa darabal laahu masalar rajulaini ahaduhumaaa abkamu laa yaqdiru 'alaa shai'inw wa huwa kallun 'alaa mawlaahu ainamaa yuwajjihhu laa yaati bikhairin hal yastawee huwa wa many-yaamuru bil'adli wa huwa 'alaa Siraatim Mustaqeem"
  },
  {
    "id": 77,
    "text": "Wa lillaahi ghaibus samaawaati wal ard; wa maaa amrus Saa'ati illaa kalamhil basari aw huwa aqrab; innal laaha 'alaaa kulli shai'in Qadeer"
  },
  {
    "id": 78,
    "text": "Wallaahu akhrajakum mim butooni ummahaatikum laa ta'lamoona shai'anw wa ja'ala lakumus sam'a wal absaara wal af'idata la'allakum tashkuroon"
  },
  {
    "id": 79,
    "text": "Alam yaraw ilat tairi musakhkharaatin fee jawwis samaaa'i maa yumsikuhunna illal laah; inna fee zaalika la Aayaatil liqawminy yu'minoon"
  },
  {
    "id": 80,
    "text": "Wallaahu ja'ala lakum mim buyootikum sakananw wa ja'ala lakum min juloodil an'aami buyootan tastakhif foonahaa yawma za'nikum wa yawma iqaamatikum wa min aswaafihaa wa awbaarihaa wa ash'aarihaaa asaasanw wa mataa'an ilaa heen"
  },
  {
    "id": 81,
    "text": "Wallaahu ja'ala lakum mimmaa khalaqa zilaalanw wa ja'ala lakum minal jibaali aknaananw wa ja'ala lakum saraabeela taqeekumul harra wa saraabeela taqeekum baasakum; kazaalika yutimmu ni'matahoo alaikum la'allakum tuslimoon"
  },
  {
    "id": 82,
    "text": "Fa in tawallaw fa innamaa 'alaikal balaaghul mubeen"
  },
  {
    "id": 83,
    "text": "Ya'rifoona ni'matal laahi summa yunkiroonahaa wa aksaruhumul kaafiroon"
  },
  {
    "id": 84,
    "text": "Wa yawma nab'asu min kulli ummatin shaheedan summa laa yu'zanu lillazeena kafaroo wa laa hum yusta'taboon"
  },
  {
    "id": 85,
    "text": "Wa izaa ra al lazeena zalamul 'azaaba falaa yukhaf fafu 'anhum wa laa hum yunzaroon"
  },
  {
    "id": 86,
    "text": "Wa izaa ra al lazeena ashrakoo shurakaaa'ahum qaaloo Rabbana haaa'ulaaa'i shurakaaa'unal lazeena kunnaa nad'oo min doonika fa alqaw ilaihimul qawla innakum lakaaziboon"
  },
  {
    "id": 87,
    "text": "Wa alqaw ilal laahi yawma'izinis salama wa dalla 'anhum maa kaanoo yaftaroon"
  },
  {
    "id": 88,
    "text": "Allazeena kafaroo wa saddoo 'an sabeelil laahi zidnaahum 'azaaban fawqal 'azaabi bimaa kaanoo yufsidoon"
  },
  {
    "id": 89,
    "text": "Wa yawma nab'asu fee kulli ummmatin shaheedan 'alaihim min anfusihim wa ji'naa bika shaheedan 'alaa haaa'ulaaa'; wa nazzalnaa 'alaikal Kitaaba tibyaanal likulli shai'inw wa hudanw wa rahmatanw wa bushraa lilmuslimeen"
  },
  {
    "id": 90,
    "text": "Innal laaha ya'muru bil 'adli wal ihsaani wa eetaaa'i zil qurbaa wa yanhaa 'anil fahshaaa'i wal munkari walbagh-i' ya'izukum la'allakum tazakkaroon"
  },
  {
    "id": 91,
    "text": "Wa awfoo bi Ahdil laahi izaa 'aahattum wa laa tanqudul aimaana ba'da tawkeedihaa wa qad ja'altumul laaha 'alaikum kafeelaa; innal laaha ya'lamu maa taf'aloon"
  },
  {
    "id": 92,
    "text": "Wa laa takoonoo kallatee naqadat ghazlahaa mim ba'di quwwatin ankaasaa; tattakhizoona aimaanakum dakhalam bainakum an takoona ummatun hiya arbaa min ummah; innnamaa yablookumul laahu bih; wa la yubaiyinanna lakum yawmal Qiyaamati maa kuntum feehi takhtalifoon"
  },
  {
    "id": 93,
    "text": "Wa law shaaa'al laahu laja'alakum ummmatanw waahidatanw wa laakiny yudillu many- yashaaa'u wa yahdee many-yashaaa'; wa latus'alunna 'ammaa kuntum ta'maloon"
  },
  {
    "id": 94,
    "text": "Wa laa tattakhizooo aimaanakum dakhalam bainakum fatazilla qadamum ba'da subootihaa wa tazooqus sooo'a bima sadattum 'an sabeelil laahi wa lakum 'azaabun 'azeem"
  },
  {
    "id": 95,
    "text": "Wa laa tashtaroo bi 'ahdil laahi samanan qaleelaa; innamaa 'indal laahi huwa khairul lakum in kuntum ta'lamoon"
  },
  {
    "id": 96,
    "text": "Maa 'indakum yanfadu wa maa 'indal laahi baaq; wa lanajziyannal lazeena sabarooo ajjrahum bi ahsani maa kaanoo ya'maloon"
  },
  {
    "id": 97,
    "text": "Man 'amila saaliham min zakarin aw unsaa wa huwa mu'minun falanuhyiyannahoo hayaatan taiiyibatanw wa lanajzi yannnahum ajrahum bi ahsani maa kaanoo ya'maloon"
  },
  {
    "id": 98,
    "text": "Fa izaa qara tal Quraana fasta'iz billaahi minashh Shai taanir rajeem"
  },
  {
    "id": 99,
    "text": "Innahoo laisa lahoo sultaanun 'alal lazeena aamanoo wa 'alaa Rabbihim yatawakkaloon"
  },
  {
    "id": 100,
    "text": "Innnamaa sultaanuhoo 'alal lazeena yatawallawnahoo wallazeena hum bihee mushrikoon"
  },
  {
    "id": 101,
    "text": "Wa izaa baddalnaaa Aayatam makaana Aayatinw wal laahu a'lamu bimaa yunazzilu qaalooo innamaa anta muftar; bal aksaruhum laa ya'lamoon"
  },
  {
    "id": 102,
    "text": "Qul nazzalahoo Roohul Qudusi mir Rabbika bilhaqqi liyusabbital lazeena aamanoo wa hudanw wa bushraa lilmuslimeen"
  },
  {
    "id": 103,
    "text": "Wa laqad na'lamu annahum yaqooloona innamaa yu'allimuhoo bashar; lisaanul lazee yulhidoona ilaihi a'ja miyyunw wa haaza lisaanun 'Arabiyyum mubeen"
  },
  {
    "id": 104,
    "text": "Innal lazeena laa yu'minoona bi Aayaatil laahi laa yahdehimul laahu wa lahum 'azaabun aleem"
  },
  {
    "id": 105,
    "text": "Innamaa yaftaril kazibal lazeena laa yu'minoona bi Aayaatil laahi wa ulaaa'ika humul kaaziboon"
  },
  {
    "id": 106,
    "text": "Man kafara billaahi mim ba'di eemaanihee illaa man ukriha wa qalbuhoo mutmma'innum bil eemaani wa laakim man sharaha bilkufri sadran fa'alaihim ghadabum minal laahi wa lahum 'azaabun 'azeem"
  },
  {
    "id": 107,
    "text": "Zaalika bi annahumus tahabbul hayaatad dunyaa 'alal Aakhirati wa annal laaha laa yahdil qawmal kaafireen"
  },
  {
    "id": 108,
    "text": "Ulaaa'ikal lazeena taba'al laahu 'alaa quloobihim wa sam'ihim wa absaarihim wa ulaaa'ika humul ghaafiloon"
  },
  {
    "id": 109,
    "text": "Laa jarama annnahum fil Aakhirati humul khasiroon"
  },
  {
    "id": 110,
    "text": "Summa inna Rabbaka lillazeena haajaroo mim ba'dimaa futinoo summma jaahadoo wa sabaroo inna Rabbaka mim ba'dihaa la Ghafoorur Raheem"
  },
  {
    "id": 111,
    "text": "Yawma taatee kullu nafsin tujaadilu 'an nafsihaa wa tuwaffaa kullu nafsim maa 'amilat wa hum laa yuzlamoon"
  },
  {
    "id": 112,
    "text": "Wa darabal laahu masalan qaryatan kaanat aaminatam mutma'innatany yaaateehaa rizquhaa raghadam min kulli makaanin fakafarat bi an'umil laahi fa azaaqahal laahu libaasal joo'i walkhawfi bimaa kaanoo yasna'oon"
  },
  {
    "id": 113,
    "text": "Wa laqad jaaa'ahum Rasoolum minhum fakazzaboohu fa akhazahumul 'azaabu wa hum zaalimoon"
  },
  {
    "id": 114,
    "text": "Fakuloo mimmaa razaqa kumul laahu halaalan taiyibanw washkuroo ni'matal laahi in kuntum iyyaahu ta'budoon"
  },
  {
    "id": 115,
    "text": "Innamaa harama 'alai kumul maitata waddama wa lahmal khinzeeri wa maaa uhilla lighairil laahi bihee famanid turra ghaira baaghinw wa laa 'aadin fa innal laaha Ghafoorur Raheem"
  },
  {
    "id": 116,
    "text": "Wa laa taqooloo limaa tasifu alsinatukumul kaziba haaza halaalunw wa haazaa haraamul litaftaroo 'alal laahil kazib; innal lazeena yaftaroona 'alal laahil kaziba laa yuflihoon"
  },
  {
    "id": 117,
    "text": "Mata'un qaleelunw wa lahum 'azaabun aleem"
  },
  {
    "id": 118,
    "text": "Wa 'alal lazeena haadoo harramnaa ma qasasnaa 'alaika min qablu wa maa zalamanaahum wa laakin kaanoo anfusahum yazlimoon"
  },
  {
    "id": 119,
    "text": "Summma inna Rabbaka lillazeena 'amilus sooo'a bijahaalatin summa taaboo mim ba'di zaaalika wa aslahoo inna Rabbaka mim ba'dihaa la Ghafoorur Raheem"
  },
  {
    "id": 120,
    "text": "Inna Ibraaheema kaana ummatan qaanital lillaahi Haneefanw wa lam yakuminal mushrikeen"
  },
  {
    "id": 121,
    "text": "Shaakiral li an'umih; ijtabaahu wa hadaahu ilaa Siraatim Muustaqeem"
  },
  {
    "id": 122,
    "text": "Wa aatainaahu fid dunyaa hasanah; wa innahoo fil Aakhirati laminas saaliheen"
  },
  {
    "id": 123,
    "text": "Summma awhainaa ilaika anit tabi' Millata Ibraaheema haneefaa; wa maa kaana minal mushrikeen"
  },
  {
    "id": 124,
    "text": "Innnamaa ju'ilas Sabtu 'alal lazeenakhtalafoo feeh; wa inna Rabbaka la yahkumu bainahum Yawmal Qiyaamati feemaa kaanoo feehi yakhtalifoon"
  },
  {
    "id": 125,
    "text": "Ud'u ilaa sabeeli Rabbika bilhikmati walmaw 'izatil hasanati wa jaadilhum billatee hiya ahsan; inna Rabbaka huwa a'almu biman dalla 'an sabeelihee wa Huwa a'lamu bilmuhtadeen"
  },
  {
    "id": 126,
    "text": "Wa in 'aaqabtum fa'aaqiboo bimisli maa 'ooqibtum bihee wa la'in sabartum lahuwa khairul lissaabireen"
  },
  {
    "id": 127,
    "text": "Wasbir wa maa sabruka illaa billaah; wa laa tahzan 'alaihim wa laa taku fee daiqim mimmaa yamkuroon"
  },
  {
    "id": 128,
    "text": "Innal laaha ma'al lazeenat taqaw wal lazeena hum muhsinoon"
  }
];

export default en;
