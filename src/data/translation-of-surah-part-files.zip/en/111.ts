import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Tabbat yadaa abee Lahabinw-wa tabb"
  },
  {
    "id": 2,
    "text": "Maa aghnaa 'anhu maaluhoo wa ma kasab"
  },
  {
    "id": 3,
    "text": "Sa-yaslaa naaran zaata lahab"
  },
  {
    "id": 4,
    "text": "Wamra-atuhoo hammaa latal-hatab"
  },
  {
    "id": 5,
    "text": "Fee jeedihaa hablum mim-masad"
  }
];

export default en;
