import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Izas samaaa'un shaqqat"
  },
  {
    "id": 2,
    "text": "Wa azinat li Rabbihaa wa huqqat"
  },
  {
    "id": 3,
    "text": "Wa izal ardu muddat"
  },
  {
    "id": 4,
    "text": "Wa alqat maa feehaa wa takhallat"
  },
  {
    "id": 5,
    "text": "Wa azinat li Rabbihaa wa huqqat"
  },
  {
    "id": 6,
    "text": "Yaaa ayyuhal insaanu innaka kaadihun ilaa Rabbika kad han famulaaqeeh"
  },
  {
    "id": 7,
    "text": "Fa ammaa man ootiya kitaabahoo biyameenih"
  },
  {
    "id": 8,
    "text": "Fasawfa yuhaasab hisaabany yaseeraa"
  },
  {
    "id": 9,
    "text": "Wa yanqalibu ilaaa ahlihee masrooraa"
  },
  {
    "id": 10,
    "text": "Wa ammaa man ootiya kitaabahoo waraaa'a zahrih"
  },
  {
    "id": 11,
    "text": "Fasawfa yad'oo thubooraa"
  },
  {
    "id": 12,
    "text": "Wa yaslaa sa'eeraa"
  },
  {
    "id": 13,
    "text": "Innahoo kaana feee ahlihee masrooraa"
  },
  {
    "id": 14,
    "text": "Innahoo zanna an lany yahoor"
  },
  {
    "id": 15,
    "text": "Balaaa inna Rabbahoo kaana bihee baseeraa"
  },
  {
    "id": 16,
    "text": "Falaaa uqsimu bishshafaq"
  },
  {
    "id": 17,
    "text": "Wallaili wa maa wasaq"
  },
  {
    "id": 18,
    "text": "Walqamari izat tasaq"
  },
  {
    "id": 19,
    "text": "Latarkabunna tabaqan 'an tabaq"
  },
  {
    "id": 20,
    "text": "Famaa lahum laa yu'minoon"
  },
  {
    "id": 21,
    "text": "Wa izaa quri'a 'alaihimul Quraanu laa yasjudoon"
  },
  {
    "id": 22,
    "text": "Balil lazeena kafaroo yukazziboon"
  },
  {
    "id": 23,
    "text": "Wallaahu a'lamu bimaa yoo'oon"
  },
  {
    "id": 24,
    "text": "Fabashshirhum bi'azaabin aleem"
  },
  {
    "id": 25,
    "text": "Illal lazeena aamanoo wa 'amilus saalihaati lahum ajrun ghairu mamnoon"
  }
];

export default en;
