import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Izaa waqa'atil waaqi'ah"
  },
  {
    "id": 2,
    "text": "Laisa liwaq'atihaa kaazibah"
  },
  {
    "id": 3,
    "text": "Khafidatur raafi'ah"
  },
  {
    "id": 4,
    "text": "Izaa rujjatil ardu rajjaa"
  },
  {
    "id": 5,
    "text": "Wa bussatil jibaalu bassaa"
  },
  {
    "id": 6,
    "text": "Fakaanat habaaa'am mumbassaa"
  },
  {
    "id": 7,
    "text": "Wa kuntum azwaajan salaasah"
  },
  {
    "id": 8,
    "text": "Fa as haabul maimanati maaa as haabul maimanah"
  },
  {
    "id": 9,
    "text": "Wa as haabul mash'amati maaa as haabul mash'amah"
  },
  {
    "id": 10,
    "text": "Wassaabiqoonas saabiqoon"
  },
  {
    "id": 11,
    "text": "Ulaaa'ikal muqarraboon"
  },
  {
    "id": 12,
    "text": "Fee Jannaatin Na'eem"
  },
  {
    "id": 13,
    "text": "Sullatum minal awwaleen"
  },
  {
    "id": 14,
    "text": "Wa qaleelum minal aa khireen"
  },
  {
    "id": 15,
    "text": "'Alaa sururim mawdoonah"
  },
  {
    "id": 16,
    "text": "Muttaki'eena 'alaihaa mutaqabileen"
  },
  {
    "id": 17,
    "text": "Yatoofu 'alaihim wildaa num mukhalladoon"
  },
  {
    "id": 18,
    "text": "Bi akwaabinw wa abaareeq, wa kaasim mim ma'een"
  },
  {
    "id": 19,
    "text": "Laa yusadda'oona 'anhaa wa laa yunzifoon"
  },
  {
    "id": 20,
    "text": "Wa faakihatim mimmaa yatakhaiyaroon"
  },
  {
    "id": 21,
    "text": "Wa lahmi tairim mimmaa yashtahoon"
  },
  {
    "id": 22,
    "text": "Wa hoorun'een"
  },
  {
    "id": 23,
    "text": "Ka amsaalil lu'lu'il maknoon"
  },
  {
    "id": 24,
    "text": "Jazaaa'am bimaa kaanoo ya'maloon"
  },
  {
    "id": 25,
    "text": "Laa yasma'oona feehaa laghwanw wa laa taaseemaa"
  },
  {
    "id": 26,
    "text": "Illaa qeelan salaaman salaamaa"
  },
  {
    "id": 27,
    "text": "Wa as haabul yameeni maaa as haabul Yameen"
  },
  {
    "id": 28,
    "text": "Fee sidrim makhdood"
  },
  {
    "id": 29,
    "text": "Wa talhim mandood"
  },
  {
    "id": 30,
    "text": "Wa zillim mamdood"
  },
  {
    "id": 31,
    "text": "Wa maaa'im maskoob"
  },
  {
    "id": 32,
    "text": "Wa faakihatin kaseerah"
  },
  {
    "id": 33,
    "text": "Laa maqtoo'atinw wa laa mamnoo'ah"
  },
  {
    "id": 34,
    "text": "Wa furushim marfoo'ah"
  },
  {
    "id": 35,
    "text": "Innaaa anshaanaahunna inshaaa'aa"
  },
  {
    "id": 36,
    "text": "Faja'alnaahunna abkaaraa"
  },
  {
    "id": 37,
    "text": "'Uruban atraabaa"
  },
  {
    "id": 38,
    "text": "Li as haabil yameen"
  },
  {
    "id": 39,
    "text": "Sullatum minal awwa leen"
  },
  {
    "id": 40,
    "text": "Wa sullatum minal aakhireen"
  },
  {
    "id": 41,
    "text": "Wa as haabush shimaali maaa as haabush shimaal"
  },
  {
    "id": 42,
    "text": "Fee samoominw wa hameem"
  },
  {
    "id": 43,
    "text": "Wa zillim miny yahmoom"
  },
  {
    "id": 44,
    "text": "Laa baaridinw wa laa kareem"
  },
  {
    "id": 45,
    "text": "Innahum kaanoo qabla zaalika mutrafeen"
  },
  {
    "id": 46,
    "text": "Wa kaanoo yusirroona 'alal hinsil 'azeem"
  },
  {
    "id": 47,
    "text": "Wa kaanoo yaqooloona a'izaa mitnaa wa kunnaa turaabanw wa izaaman'ainnaa lamab'oosoon"
  },
  {
    "id": 48,
    "text": "Awa aabaaa'unal awwaloon"
  },
  {
    "id": 49,
    "text": "Qul innal awwaleena wal aakhireen"
  },
  {
    "id": 50,
    "text": "Lamajmoo'oona ilaa meeqaati yawmim ma'loom"
  },
  {
    "id": 51,
    "text": "Summa innakum ayyuhad daaalloonal mukazziboon"
  },
  {
    "id": 52,
    "text": "La aakiloona min shaja rim min zaqqoom"
  },
  {
    "id": 53,
    "text": "Famaali'oona minhal butoon"
  },
  {
    "id": 54,
    "text": "Fashaariboona 'alaihi minal hameem"
  },
  {
    "id": 55,
    "text": "Fashaariboona shurbal heem"
  },
  {
    "id": 56,
    "text": "Haazaa nuzuluhum yawmad deen"
  },
  {
    "id": 57,
    "text": "Nahnu khalaqnaakum falaw laa tusaddiqoon"
  },
  {
    "id": 58,
    "text": "Afara'aytum maa tumnoon"
  },
  {
    "id": 59,
    "text": "'A-antum takhluqoo nahooo am nahnul khaaliqoon"
  },
  {
    "id": 60,
    "text": "Nahnu qaddarnaa baina kumul mawta wa maa nahnu bimasbooqeen"
  },
  {
    "id": 61,
    "text": "'Alaaa an nubaddila amsaalakum wa nunshi'akum fee maa laa ta'lamoon"
  },
  {
    "id": 62,
    "text": "Wa laqad 'alimtumun nash atal oolaa falaw laa tazakkaroon"
  },
  {
    "id": 63,
    "text": "Afara'aytum maa tahrusoon"
  },
  {
    "id": 64,
    "text": "'A-antum tazra'oonahooo am nahnuz zaari'ooon"
  },
  {
    "id": 65,
    "text": "Law nashaaa'u laja'al naahu hutaaman fazaltum tafakkahoon"
  },
  {
    "id": 66,
    "text": "Innaa lamughramoon"
  },
  {
    "id": 67,
    "text": "Bal nahnu mahroomoon"
  },
  {
    "id": 68,
    "text": "Afara'aytumul maaa'allazee tashraboon"
  },
  {
    "id": 69,
    "text": "'A-antum anzaltumoohu minal muzni am nahnul munziloon"
  },
  {
    "id": 70,
    "text": "Law nashaaa'u ja'alnaahu ujaajan falaw laa tashkuroon"
  },
  {
    "id": 71,
    "text": "Afara'aytumun naaral latee tooroon"
  },
  {
    "id": 72,
    "text": "'A-antum anshaatum shajaratahaaa am nahnul munshi'oon"
  },
  {
    "id": 73,
    "text": "Nahnu ja'alnaahaa tazkira tanw wa mataa'al lilmuqween"
  },
  {
    "id": 74,
    "text": "Fasabbih bismi Rabbikal 'azeem"
  },
  {
    "id": 75,
    "text": "Falaa uqsimu bimaawaa qi'innujoom"
  },
  {
    "id": 76,
    "text": "Wa innahoo laqasamul lawta'lamoona'azeem"
  },
  {
    "id": 77,
    "text": "Innahoo la quraanun kareem"
  },
  {
    "id": 78,
    "text": "Fee kitaabim maknoon"
  },
  {
    "id": 79,
    "text": "Laa yamassuhooo illal mutahharoon"
  },
  {
    "id": 80,
    "text": "Tanzeelum mir Rabbil'aalameen"
  },
  {
    "id": 81,
    "text": "Afabihaazal hadeesi antum mudhinoon"
  },
  {
    "id": 82,
    "text": "Wa taj'aloona rizqakum annakum tukazziboon"
  },
  {
    "id": 83,
    "text": "Falaw laaa izaa balaghatil hulqoom"
  },
  {
    "id": 84,
    "text": "Wa antum heena'izin tanzuroon"
  },
  {
    "id": 85,
    "text": "Wa nahnu aqrabu ilaihi minkum wa laakil laa tubsiroon"
  },
  {
    "id": 86,
    "text": "Falaw laaa in kuntum ghaira madeeneen"
  },
  {
    "id": 87,
    "text": "Tarji'oonahaaa in kuntum saadiqeen"
  },
  {
    "id": 88,
    "text": "Fa ammaaa in kaana minal muqarrabeen"
  },
  {
    "id": 89,
    "text": "Farawhunw wa raihaa nunw wa jannatu na'eem"
  },
  {
    "id": 90,
    "text": "Wa ammaaa in kaana min as haabil yameen"
  },
  {
    "id": 91,
    "text": "Fasalaamul laka min as haabil yameen"
  },
  {
    "id": 92,
    "text": "Wa ammaaa in kaana minal mukazzibeenad daaalleen"
  },
  {
    "id": 93,
    "text": "Fanuzulum min hameem"
  },
  {
    "id": 94,
    "text": "Wa tasliyatu jaheem"
  },
  {
    "id": 95,
    "text": "Inna haaza lahuwa haqqul yaqeen"
  },
  {
    "id": 96,
    "text": "Fasabbih bismi rabbikal 'azeem"
  }
];

export default en;
