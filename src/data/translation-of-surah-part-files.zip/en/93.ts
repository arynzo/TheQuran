import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wad duhaa"
  },
  {
    "id": 2,
    "text": "Wal laili iza sajaa"
  },
  {
    "id": 3,
    "text": "Ma wad da'aka rabbuka wa ma qalaa"
  },
  {
    "id": 4,
    "text": "Walal-aakhiratu khairul laka minal-oola"
  },
  {
    "id": 5,
    "text": "Wa la sawfa y'uteeka rabbuka fatarda"
  },
  {
    "id": 6,
    "text": "Alam ya jidka yateeman fa aawaa"
  },
  {
    "id": 7,
    "text": "Wa wa jadaka daal lan fahada"
  },
  {
    "id": 8,
    "text": "Wa wa jadaka 'aa-ilan fa aghnaa"
  },
  {
    "id": 9,
    "text": "Fa am mal yateema fala taqhar"
  },
  {
    "id": 10,
    "text": "Wa am mas saa-ila fala tanhar"
  },
  {
    "id": 11,
    "text": "Wa amma bi ni'mati rabbika fahad dith"
  }
];

export default en;
