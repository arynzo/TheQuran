import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Innaa anzalnaahu fee lailatil qadr"
  },
  {
    "id": 2,
    "text": "Wa maa adraaka ma lailatul qadr"
  },
  {
    "id": 3,
    "text": "Lailatul qadri khairum min alfee shahr"
  },
  {
    "id": 4,
    "text": "Tanaz zalul malaa-ikatu war roohu feeha bi izni-rab bihim min kulli amr"
  },
  {
    "id": 5,
    "text": "Salaamun hiya hattaa mat la'il fajr"
  }
];

export default en;
