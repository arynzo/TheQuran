import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Haa-Meeem"
  },
  {
    "id": 2,
    "text": "Tanzeelul Kitaabi minal laahil 'Azeezil Hakeem"
  },
  {
    "id": 3,
    "text": "Innaa fis samaawaati wal ardi la Aayaatil lilmu'mineen"
  },
  {
    "id": 4,
    "text": "Wa fee khalaqikum wa maa yabussu min daaabbatin Aayaatul liqawminy-yooqinoon"
  },
  {
    "id": 5,
    "text": "Wakhtilaafil laili wannahaari wa maaa anzalal laahu minas samaaa'i mir rizqin fa ahyaa bihil arda ba'da mawtihaa wa tasreefir riyaahi Aayaatul liqawminy ya'qiloon"
  },
  {
    "id": 6,
    "text": "Tilka Aayatul laahi natloohaa 'alaika bil haqq, fabiayyi hadeesim ba'dal laahi wa Aayaatihee yu'minoon"
  },
  {
    "id": 7,
    "text": "Wailul likulli affaakin aseem"
  },
  {
    "id": 8,
    "text": "Yasma'u Aayaatil laahi tutlaa 'alaihi summa yusirru mustakbiran ka-al lam yasma'haa fabashshirhu bi'azaabin aleem"
  },
  {
    "id": 9,
    "text": "Wa izaa 'alima min Aayaatinaa shai' 'anit takhazahaa huzuwaa; ulaaa'ika lahum 'azaabum muheen"
  },
  {
    "id": 10,
    "text": "Minw waraaa'ihim Jahannamu wa laa yughnee 'anhum maa kasaboo shai'anw wa laa mat takhazoo min doonil laahi awliyaaa; wa lahum 'azaabun 'azeem"
  },
  {
    "id": 11,
    "text": "Haazaa hudaa; wal lazeena kafaroo bi aayaati Rabbihim lahum 'azaabum mir rijzin 'aleem"
  },
  {
    "id": 12,
    "text": "Allaahul lazee sahkhara lakumul bahra litajriyal fulku feehi bi amrihee wa litabtaghoo min fadlihee wa la'allakum tashkuroon"
  },
  {
    "id": 13,
    "text": "Wa sakhkhara lakum maa fis samaawaati wa maa fil ardi jamee'am minhu; inna feezaalika la Aayaatil liqawminy yatafakkaroon"
  },
  {
    "id": 14,
    "text": "Qul lillazeena aamanoo yaghfiroo lillazeena laa yarjoona ayyaamal laahi liyajziya qawmam bimaa kaanoo yaksiboon"
  },
  {
    "id": 15,
    "text": "Man 'amila saalihan falinafsihee wa man asaaa'a fa'alaihaa summa ilaa Rabbikum turja'oon"
  },
  {
    "id": 16,
    "text": "Wa laqad aatainaa Baneee Israaa'eelal Kitaaba walhukma wan Nubuwwata wa razaqnaahum minat taiyibaati wa faddalnaahum;alal 'aalameen"
  },
  {
    "id": 17,
    "text": "Wa aatainaahum baiyinaatim minal amri famakh talafooo illaa mim ba'di maa jaaa'ahumul 'ilmu baghyam bainahum; inna Rabbaka yaqdee bainahum Yawmal Qiyaamati feemaa kaanoo feehi yakhtalifoon"
  },
  {
    "id": 18,
    "text": "Summa ja'alnaaka 'alaa sharee'atim minal amri fattabi'haa wa laa tattabi'ahwaaa'al- lazeena laa ya'lamoon"
  },
  {
    "id": 19,
    "text": "Innahum lany yughnoo 'anka minal laahi shai'aa; wa innaz zaalimeena ba'duhum awliyaaa'u ba'dinw wallaahu waliyyul muttaqeen"
  },
  {
    "id": 20,
    "text": "Haazaa basaaa'iru linnaasi wa hudanw wa rahmatul liqawminy yooqinoon"
  },
  {
    "id": 21,
    "text": "Am hasibal lazeenaj tarahus saiyiaati an naj'alahum kallazeena aamanoo wa 'amilu saalihaati sawaaa'am mahyaahum wa mamaatuhum; saaa'a maa yahkumoon"
  },
  {
    "id": 22,
    "text": "Wa khalaqal laahus samaawaati wal arda bilhaqqi wa litujzaa kullu nafsim bimaa kasabat wa hum laa yuzlamoon"
  },
  {
    "id": 23,
    "text": "Afara'ayta manit takhaza ilaahahoo hawaahu wa adal lahul laahu 'alaa 'ilminw wa khatama 'alaa sam'ihee wa qalbihee wa ja'ala 'alaa basarihee ghishaawatan famany yahdeehi mim ba'dil laah; afalaa tazakkaroon"
  },
  {
    "id": 24,
    "text": "Wa qaaloo maa hiya illaa hayaatunad dunyaa namootu wa nahyaa wa maa yuhlikunaaa illad dahr; wa maa lahum bizaalika min 'ilmin in hum illaayazunnoon"
  },
  {
    "id": 25,
    "text": "Wa izaa tutlaa 'alaihim aayaatuna baiyinaatim maa kaana hujjatahum illaaa an qaalu'too bi aabaaa'inaaa in kuntum saadiqeen"
  },
  {
    "id": 26,
    "text": "Qulil laahu yuhyeekum summa yumeetukum summa yajma'ukum ilaa Yawmil Qiyaamati laa raiba feehi wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 27,
    "text": "Wa lillaahi mulkus samaawaati wal ard; wa Yawma taqoomus Saa'atu Yawma 'iziny yakhsarul mubtiloon"
  },
  {
    "id": 28,
    "text": "Wa taraa kulla ummatin jaasiyah; kullu ummatin tud'aaa ilaa kitaabihaa al Yawma tujzawna maa kuntum ta'maloon"
  },
  {
    "id": 29,
    "text": "Haazaa kitaabunaa yantiqu 'alaikum bilhaqq; innaa kunnaa nastansikhu maa kuntum ta'maloon"
  },
  {
    "id": 30,
    "text": "Fa ammal lazeena aamaanoo wa 'amilus saalihaati fayudkhiluhum Rabbuhum fee rahmatih; zaalika huwal fawzul mubeen"
  },
  {
    "id": 31,
    "text": "Wa ammal lazeena kafarooo afalam takun Aayaatee tutlaa 'alaikum fastakbartum wa kuntum qawmam mujrimeen"
  },
  {
    "id": 32,
    "text": "Wa izaa qeela inna wa'dallaahi haqqunw was Saa'atu laa raiba feehaa qultum maa nadree mas Saa'atu in nazunnu illaa zannanw wa maa nahnu bimustaiqineen"
  },
  {
    "id": 33,
    "text": "Wa badaa lahum saiyiaatu maa 'amiloo wa haaqa bihim maa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 34,
    "text": "Wa qeelal yawma nansaakum kamaa naseetum liqaaa'a yawmikum haazaa wa maawaakumun Naaru wa maa lakum min naasireen"
  },
  {
    "id": 35,
    "text": "Zaalikum bi annakumut takhaztum aayaatil laahi huzuwanw wa gharratkumul hayaatud dunyaa; fal yawma laa yukhrajoona minhaa wa laahum yusta'taboon"
  },
  {
    "id": 36,
    "text": "Falillaahil hamdu Rabbis samaawaati wa Rabbil ardi Rabbil-'aalameen"
  },
  {
    "id": 37,
    "text": "Wa lahul kibriyaaa'u fissamaawaati wal ardi wa Huwal 'Azeezul Hakeem"
  }
];

export default en;
