import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Raa; Kitaabun anzalnaahu ilaika litukhrijan-naasa minaz zulumaati ilan noori bi-izni Rabbihim ilaa siraatil 'Azeezil Hameed"
  },
  {
    "id": 2,
    "text": "Allaahil lazee lahoo maa fis samaawaati wa maa fill ard; wa wailul lilkaafireena min 'azaabin shadeed"
  },
  {
    "id": 3,
    "text": "Allazeena yastahibboo nal hayaatad dunyaa 'alal aakhirati wa yasuddoona 'ansabeelil laahi wa yabghoonahaa 'iwajaa; ulaaa 'ika fee dalaalin ba'eed"
  },
  {
    "id": 4,
    "text": "Wa maaa arsalnaa mir Rasoolin illaa bilisaani qawmihee liyubaiyina lahum fa yudillul laahu mai yashaaa'u wa yahdee mai yashaaa'; wa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 5,
    "text": "Wa laqad arsalnaa Moosaa bi Aayaatinaa an akhrij qawmaka minaz zulumaati ilan noori wa zak kirhum bi ayyaamil laah; inna fee zaalika la aayaatil likulli sabbaarin shakoor"
  },
  {
    "id": 6,
    "text": "Wa iz qaala Moosaa liqawmihiz kuroo ni'matal laahi 'alaikum iz anjaakum min Aali Fir'awna yasoomoo nakum sooo'al 'azaabi wa yuzabbihoona abnaaa'akum wa yastahyoona nisaaa'akum; wa fee zaalikum balaaa'un mir Rabbikum 'azeem"
  },
  {
    "id": 7,
    "text": "Wa iz ta azzana Rabbukum la'in shakartum la azeedannakum wa la'in kafartum inna 'azaabee lashadeed"
  },
  {
    "id": 8,
    "text": "Wa qaala Moosaaa in takfurooo antum wa man fil ardi jamee'an fa innal laaha la Ghaniyyun Hameed"
  },
  {
    "id": 9,
    "text": "Alam ya'tikum naba'ul lazeena min qablikum qawmi Noohinw wa 'Aadinw wa Samood, wallazeena mim ba'dihim; laa ya'lamuhum illallaah; jaaa'at hum Rusuluhum bilbaiyinaati faraddooo aydiyahum feee afwaahihim wa qaalooo innaa kafarnaa bimaaa ursiltum bihee wa innaa lafee shakkim mimmaa tad'oonanaaa ilaihi mureeb"
  },
  {
    "id": 10,
    "text": "Qaalat Rusuluhum afillaahi shakkun faatiris samaawaati wal ardi yad'ookum liyaghfira lakum min zunoobikum wa yu'akhirakum ilaaa ajalin musammaa; qaaloo in antum illaa basharum mislunaa tureedoona an tasuddoonaa 'ammaa kaana ya'budu aabaaa'unaa fa'toonaa bi sultaanin mubeen"
  },
  {
    "id": 11,
    "text": "Qaalat lahum Rusuluhum in nahnu illaa basharum mislukum wa laakinnal laaha yamunnu 'alaa mai yashaaa'u min 'ibaadihee wa maa kaana lanaaa an na'tiyakum bisul taanin illaa bi iznil laah; wa 'alal laahi falyatawakkalil mu'minoon"
  },
  {
    "id": 12,
    "text": "Wa maa lanaa allaa natawakkala 'alal laahi wa qad hadaanaa subulanaa; wa lanasbiranna 'alaa maaa aazaitumoonaa; wa 'alal laahi falyatawakkalil mutawakkiloon"
  },
  {
    "id": 13,
    "text": "Wa qaalal lazeena kafaroo li Rusulihim lanukhrijanna kum min aardinaaa aw la ta'oodunna fee millatinaa fa awhaaa ilaihim Rabbuhum lanuhlikannaz zaalimeen"
  },
  {
    "id": 14,
    "text": "Wa lanuskinan nakumul arda min ba'dihim; zaalika liman khaafa maqaamee wa khaafa wa'eed"
  },
  {
    "id": 15,
    "text": "Wastaftahoo wa khaaba kullu jabbaarin 'aneed"
  },
  {
    "id": 16,
    "text": "Minw waraaa'ihee jahannamu wa yusqaa min maaa'in sadeed"
  },
  {
    "id": 17,
    "text": "Yatajarra'uhoo wa laa yakaadu yuseeghuhoo wa ya'teehil mawtu min kulli makaaninw wa maa huwa bimaiyitinw wa minw waraaa'ihee 'azaabun ghaleez"
  },
  {
    "id": 18,
    "text": "Masalul lazeena kafaroo bi Rabbihim; a'maaluhum karamaadinish taddat bihir reehu fee yawmin 'aasifin; laa yaqdiroona mimmaa kasaboo 'alaa shai'; zaalika huwad dalaalul ba'eed"
  },
  {
    "id": 19,
    "text": "Alam tara annal laaha khalaqas samaawaati wal arda bilhaqq; iny yasha yuzhibkum wa ya'ti bikhalqin jadeed"
  },
  {
    "id": 20,
    "text": "Wa maa zaalika 'alal laahi bi 'azeez"
  },
  {
    "id": 21,
    "text": "Wa barazoo lillaahi jamee'an faqaalad du'afaaa'u lil lazeenas takbarooo innaa kunnaa lakum taba'an fahal antum mughnoona 'annaa min 'azaabil laahi min shai'; qaaloo law hadaanal laahu la hadaynaakum sawaaa'un 'alainaaa ajazi'naa am sabarnaa maa lanaa min mahees"
  },
  {
    "id": 22,
    "text": "Wa qaalash Shaitaanu lammaa qudiyal amru innal laaha wa'adakum wa'dal haqqi wa wa'attukum fa akhlaftukum wa maa kaana liya 'alaikum min sultaanin illaaa an da'awtukum fastajabtum lee falaa taloomoonee wa loomooo anfusakum maaa ana bimusrikhikum wa maaa antum bimusrikhiyya innee kafartu bimaaa ashraktumooni min qabl; innaz zaalimeena lahum azaabun aleem"
  },
  {
    "id": 23,
    "text": "Wa udkhilal lazeena aamanoo wa 'amilus saalihaati Jannaatin tajree min tahtihal anhaaru khaalideena feehaa bi izni Rabbihim tahiyyatuhum feeha salaam"
  },
  {
    "id": 24,
    "text": "Alam tara kaifa darabal laahu masalan kalimatan taiyibatan kashajaratin taiyibatin asluhaa saabitunw wa far'uhaa fis samaaa'"
  },
  {
    "id": 25,
    "text": "Tu'teee ukulahaa kulla heenim bi izni Rabbihaa; wa yadribul laahul amsaala linnaasi la'allahum yatazak karoon"
  },
  {
    "id": 26,
    "text": "Wa masalu kalimatin khabeesatin kashajaratin khabee satinij tussat min fawqil ardi maa lahaa min qaraar"
  },
  {
    "id": 27,
    "text": "Yusabbitul laahul lazeena aamanoo bilqawlis saabiti fil hayaatid dunyaa wa fil Aakhirati wa yudillul laahuz zaalimeen; wa yaf'alul laahu maa yashaaa'"
  },
  {
    "id": 28,
    "text": "Alam tara ilal lazeena baddaloo ni'matal laahi kufranw wa ahalloo qawmahum daaral bawaar"
  },
  {
    "id": 29,
    "text": "Jahannama yaslawnahaa wa bi'sal qaraar"
  },
  {
    "id": 30,
    "text": "Wa ja'aloo lillaahi andaadal liyudilloo 'an sabeelih; qul tamatta'oo fa innaa maseerakum ilan Naar"
  },
  {
    "id": 31,
    "text": "Qul li'ibaadiyal lazeena aamanoo yuqeemus Salaata wa yunfiqoo mimmaa razaqnaahum sirranw wa 'alaaniyatam min qabli any yaatiya Yawmul laa bai'un feehi wa laa khilaal"
  },
  {
    "id": 32,
    "text": "Allaahul lazee khalaqas samaawaati wal arda wa anzala minas samaaa'i maaa'an faakhraja bihee minas samaraati rizqal lakum wa sakhkhara lakumul fulka litajriya fil bahri bi amrihee wa sakhkhara lakumul anhaar"
  },
  {
    "id": 33,
    "text": "Wa sakhkhara lakumush shamsa walqamara daaa'ibaini wa sakhkhara lakumul laila wannahaar"
  },
  {
    "id": 34,
    "text": "Wa aataakum min kulli maa sa altumooh; wa in ta'uddoo ni'matal laahi laa tuhsoohaa; innal insaana lazaloo mun kaffaar"
  },
  {
    "id": 35,
    "text": "Wa iz qaala Ibraaheemu Rabbij 'al haazal balada aaminanw wajnubnee wa baniyya an na'budal asnaam"
  },
  {
    "id": 36,
    "text": "Rabbi innahunna adlalna kaseeram minan naasi faman tabi'anee fa innahoo minnee wa man 'asaanee fa innaka Ghafoorur Raheem"
  },
  {
    "id": 37,
    "text": "Rabbanaaa inneee askantu min zurriyyatee biwaadin ghairi zee zar'in 'inda Baitikal Muharrami Rabbanaa liyuqeemus Salaata faj'al af'idatam minan naasi tahweee ilaihim warzuqhum minas samaraati la'allahum yashkuroon"
  },
  {
    "id": 38,
    "text": "Rabbanaaa innaka ta'lamu maa nukhfee wa maa nu'lin; wa maa yakhfaa 'alal laahi min shai'in fil ardi wa laa fis samaaa'"
  },
  {
    "id": 39,
    "text": "Alhamdu lillaahil lazee wahaba lee 'alal kibari Ismaa'eela wa Ishaaq; inna Rabbee lasamee'ud du'aaa"
  },
  {
    "id": 40,
    "text": "Rabbij 'alnee muqeemas Salaati wa min zurriyyatee Rabbanaa wa taqabbal du'aaa'"
  },
  {
    "id": 41,
    "text": "Rabbanagh fir lee wa liwaalidaiya wa lilmu'mineena Yawma yaqoomul hisaab"
  },
  {
    "id": 42,
    "text": "Wa laa tahsabannal laaha ghaafilan 'ammaa ya'maluz zaalimoon; innamaa yu'akh khiruhum li Yawmin tashkhasu feehil absaar"
  },
  {
    "id": 43,
    "text": "Muhti'eena muqni'ee ru'oosihim laa yartaddu ilaihim tarfuhum wa af'idatuhum hawaaa'"
  },
  {
    "id": 44,
    "text": "Wa anzirin naasa Yawma yaateehimul 'azaabu fa yaqoolul lazeena zalamoo Rabbanaaa akhkhirnaaa ilaaa ajalin qareebin nujib da'wataka wa nattabi 'ir Rusul; awalam takoonooo aqsamtum min qablu maa lakum min zawaal"
  },
  {
    "id": 45,
    "text": "Wa sakantum fee masaakinil lazeena zalamooo anfusahum wa tabaiyana lakum kaifa fa'alnaa bihim wa darabnaa lakumul amsaal"
  },
  {
    "id": 46,
    "text": "Wa qad makaroo makrahum wa 'indal laahi makruhum wa in kaana makruhum litazoola minhul jibaal"
  },
  {
    "id": 47,
    "text": "Falaa tahsabannal laaha mukhlifa wa'dihee Rusulah; innal laaha 'azeezun zuntiqaam"
  },
  {
    "id": 48,
    "text": "Yawma tubaddalul ardu ghairal ardi wassamaawaatu wa barazoo lillaahil Waahidil Qahhaar"
  },
  {
    "id": 49,
    "text": "Wa taral mujrimeena Yawma 'izim muqarraneena filasfaad"
  },
  {
    "id": 50,
    "text": "Saraabeeluhum min qatiraaninw wa taghshaa wujoohahumun Naar"
  },
  {
    "id": 51,
    "text": "Liyajziyal laahu kulla nafsim maa kasabat; innal laaha saree'ul hisaab"
  },
  {
    "id": 52,
    "text": "Haaza balaaghul linnaasi wa liyunzaroo bihee wa liya'lamooo annamaa Huwa Illaahunw Waahidunw wa liyaz zakkara ulul albaab"
  }
];

export default en;
