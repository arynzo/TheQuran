import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Laaa uqsimu bihaazal balad"
  },
  {
    "id": 2,
    "text": "Wa anta hillum bihaazal balad"
  },
  {
    "id": 3,
    "text": "Wa waalidinw wa maa walad"
  },
  {
    "id": 4,
    "text": "Laqad khalaqnal insaana fee kabad"
  },
  {
    "id": 5,
    "text": "Ayahsabu al-lai yaqdira 'alaihi ahad"
  },
  {
    "id": 6,
    "text": "Yaqoolu ahlaktu maalal lubadaa"
  },
  {
    "id": 7,
    "text": "Ayahsabu al lam yarahooo ahad"
  },
  {
    "id": 8,
    "text": "Alam naj'al lahoo 'aynayn"
  },
  {
    "id": 9,
    "text": "Wa lisaananw wa shafatayn"
  },
  {
    "id": 10,
    "text": "Wa hadaynaahun najdayn"
  },
  {
    "id": 11,
    "text": "Falaq tahamal-'aqabah"
  },
  {
    "id": 12,
    "text": "Wa maaa adraaka mal'aqabah"
  },
  {
    "id": 13,
    "text": "Fakku raqabah"
  },
  {
    "id": 14,
    "text": "Aw it'aamun fee yawmin zee masghabah"
  },
  {
    "id": 15,
    "text": "Yateeman zaa maqrabah"
  },
  {
    "id": 16,
    "text": "Aw miskeenan zaa matrabah"
  },
  {
    "id": 17,
    "text": "Summa kaana minal lazeena aamanoo wa tawaasaw bissabri wa tawaasaw bilmarhamah"
  },
  {
    "id": 18,
    "text": "Ulaaa'ika As-haabul maimanah"
  },
  {
    "id": 19,
    "text": "Wallazeena kafaroo bi aayaatinaa hum as-haabul Mash'amah"
  },
  {
    "id": 20,
    "text": "Alaihim naarum mu'sadah"
  }
];

export default en;
