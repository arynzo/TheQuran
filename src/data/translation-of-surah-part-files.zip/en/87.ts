import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Sabbihisma Rabbikal A'laa"
  },
  {
    "id": 2,
    "text": "Allazee khalaqa fasawwaa"
  },
  {
    "id": 3,
    "text": "Wallazee qaddara fahadaa"
  },
  {
    "id": 4,
    "text": "Wallazeee akhrajal mar'aa"
  },
  {
    "id": 5,
    "text": "Faja'alahoo ghusaaa'an ahwaa"
  },
  {
    "id": 6,
    "text": "Sanuqri'uka falaa tansaaa"
  },
  {
    "id": 7,
    "text": "Illaa maa shaaa'al laah; innahoo ya'lamul jahra wa maa yakhfaa"
  },
  {
    "id": 8,
    "text": "Wa nu-yassiruka lilyusraa"
  },
  {
    "id": 9,
    "text": "Fazakkir in nafa'atizzikraa"
  },
  {
    "id": 10,
    "text": "Sa yazzakkaru maiyakhshaa"
  },
  {
    "id": 11,
    "text": "Wa yatajannabuhal ashqaa"
  },
  {
    "id": 12,
    "text": "Allazee yaslan Naaral kubraa"
  },
  {
    "id": 13,
    "text": "Summa laa yamootu feehaa wa laa yahyaa"
  },
  {
    "id": 14,
    "text": "Qad aflaha man tazakkaa"
  },
  {
    "id": 15,
    "text": "Wa zakaras ma Rabbihee fasallaa"
  },
  {
    "id": 16,
    "text": "Bal tu'siroonal hayaatad dunyaa"
  },
  {
    "id": 17,
    "text": "Wal Aakhiratu khairunw wa abqaa"
  },
  {
    "id": 18,
    "text": "Inna haazaa lafis suhu fil oolaa"
  },
  {
    "id": 19,
    "text": "Suhufi Ibraaheema wa Moosaa"
  }
];

export default en;
