import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Iqtarabatis Saa'atu wan shaqqal qamar"
  },
  {
    "id": 2,
    "text": "Wa iny yaraw aayatany yu'ridoo wa yaqooloo sihrun mustamirr"
  },
  {
    "id": 3,
    "text": "Wa kazzaboo wattaba'ooo ahwaaa'ahum; wa kullu amrin mustaqirr"
  },
  {
    "id": 4,
    "text": "Wa laqad jaaa'ahum minal anbaaa'i maa feehi muzdajar"
  },
  {
    "id": 5,
    "text": "Hikmatun baalighatun famaa tughnin nuzur"
  },
  {
    "id": 6,
    "text": "Fatawalla 'anhum; yawma yad'ud daa'i ilaa shai 'in nukur"
  },
  {
    "id": 7,
    "text": "Khushsha'an absaaruhum yakhrujoona minal ajdaasi ka annahum jaraadum muntashir"
  },
  {
    "id": 8,
    "text": "Muhti'eena ilad daa'i yaqoolul kaafiroona haazaa yawmun 'asir"
  },
  {
    "id": 9,
    "text": "Kazzabat qablahum qawmu Noohin fakazzaboo 'abdanaa wa qaaloo majnoonunw wazdujir"
  },
  {
    "id": 10,
    "text": "Fada'aa Rabbahooo annee maghloobun fantasir"
  },
  {
    "id": 11,
    "text": "Fafatahnaaa abwaabas samaaa'i bi maaa'in munhamir"
  },
  {
    "id": 12,
    "text": "Wa fajjarnal arda 'uyoonan faltaqal maaa'u 'alaaa amrin qad qudir"
  },
  {
    "id": 13,
    "text": "Wa hamalnaahu 'alaa zaati alwaahinw wa dusur"
  },
  {
    "id": 14,
    "text": "Tajree bi a'yuninaa jazaaa'an liman kaana kufir"
  },
  {
    "id": 15,
    "text": "Wa laqat taraknaahaa aayatan fahal min muddakir"
  },
  {
    "id": 16,
    "text": "Fakaifa kaana 'azaabee wa nuzur"
  },
  {
    "id": 17,
    "text": "Wa laqad yassarnal Qur'aana liz zikri fahal min muddakir"
  },
  {
    "id": 18,
    "text": "Kazzabat 'Aadun fakaifa kaana 'azaabee wa nuzur"
  },
  {
    "id": 19,
    "text": "Innaa arsalnaa 'alaihim reehan sarsaran fee Yawmi nahsin mustamirr"
  },
  {
    "id": 20,
    "text": "Tanzi'un naasa ka annahum a'jaazu nakhlin munqa'ir"
  },
  {
    "id": 21,
    "text": "Fakaifa kaana 'azaabee wa nuzur"
  },
  {
    "id": 22,
    "text": "Wa laqad yassarnal Qur'aana liz zikri fahal min muddakir"
  },
  {
    "id": 23,
    "text": "Kazzabat Samoodu binnuzur"
  },
  {
    "id": 24,
    "text": "Faqaalooo a' basharan minnaa waahidan nattabi'uhooo innaa izal lafee dalaalinw wa su'ur"
  },
  {
    "id": 25,
    "text": "'A ulqiyaz zikru 'alaihi min baininaa bal huwa kazzaabun ashir"
  },
  {
    "id": 26,
    "text": "Sa-ya'lamoona ghadan manil kazzaabul ashir"
  },
  {
    "id": 27,
    "text": "Innaa mursilun naaqati fitnatan lahum fartaqibhum wastabir"
  },
  {
    "id": 28,
    "text": "Wa nabbi'hum annal maaa'a qismatun bainahum kullu shirbin muhtadar"
  },
  {
    "id": 29,
    "text": "Fa naadaw saahibahum fa ta'aataa fa 'aqar"
  },
  {
    "id": 30,
    "text": "Fakaifa kaana 'azaabee wa nuzur"
  },
  {
    "id": 31,
    "text": "Innaaa arsalnaa 'alaihim saihatanw waahidatan fakaanoo kahasheemil muhtazir"
  },
  {
    "id": 32,
    "text": "Wa laqad yassarnal Qur'aana liz zikri fahal min muddakir"
  },
  {
    "id": 33,
    "text": "Kazzabat qawmu lootin binnuzur"
  },
  {
    "id": 34,
    "text": "Innaa arsalnaa 'alaihim haasiban illaaa aala Lootin najjainaahum bisahar"
  },
  {
    "id": 35,
    "text": "Ni'matan min 'indinaa; kazaalika najzee man shakar"
  },
  {
    "id": 36,
    "text": "Wa laqad anzarahum batshatanaa fatamaaraw binnuzur"
  },
  {
    "id": 37,
    "text": "Wa laqad raawadoohu 'andaifeehee fatamasnaaa a'yunahum fazooqoo 'azaabee wa nuzur"
  },
  {
    "id": 38,
    "text": "Wa laqad sabbahahum bukratan 'azaabun mustaqirr"
  },
  {
    "id": 39,
    "text": "Fazooqoo 'azaabee wa nuzur"
  },
  {
    "id": 40,
    "text": "Wa laqad yassarnal Qur'aana liz zikri fahal min muddakir"
  },
  {
    "id": 41,
    "text": "Wa laqad jaaa'a Aala Fir'awnan nuzur"
  },
  {
    "id": 42,
    "text": "Kazzaboo bi Aayaatinaa kullihaa fa akhaznaahum akhza 'azeezim muqtadir"
  },
  {
    "id": 43,
    "text": "'A kuffaarukum khairun min ulaaa'ikum am lakum baraaa'atun fiz Zubur"
  },
  {
    "id": 44,
    "text": "Am yaqooloona nahnu jamee'un muntasir"
  },
  {
    "id": 45,
    "text": "Sa yuhzamul jam'u wa yuwalloonad dubur"
  },
  {
    "id": 46,
    "text": "Balis Saa'atu maw'iduhum was Saa'atu adhaa wa amarr"
  },
  {
    "id": 47,
    "text": "Innal mujrimeena fee dalaalinw wa su'ur"
  },
  {
    "id": 48,
    "text": "Yawma yus-haboona fin Naari 'alaa wujoohihim zooqoo massa saqar"
  },
  {
    "id": 49,
    "text": "Innaa kulla shai'in khalaqnaahu bi qadar"
  },
  {
    "id": 50,
    "text": "Wa maaa amrunaaa illaa waahidatun ka lamhin bil basar"
  },
  {
    "id": 51,
    "text": "Wa laqad ahlaknaaa ashyaa'akum fahal min muddakir"
  },
  {
    "id": 52,
    "text": "Wa kullu shai'in fa'aloohu fiz Zubur"
  },
  {
    "id": 53,
    "text": "Wa kullu sagheerinw wa kabeerin mustatar"
  },
  {
    "id": 54,
    "text": "Innal muttaqeena fee jannaatinw wa nahar"
  },
  {
    "id": 55,
    "text": "Fee maq'adi sidqin 'inda Maleekin Muqtadir"
  }
];

export default en;
