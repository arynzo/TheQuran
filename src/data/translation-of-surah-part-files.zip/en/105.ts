import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alam tara kaifa fa'ala rabbuka bi ashaabil feel"
  },
  {
    "id": 2,
    "text": "Alam yaj'al kai dahum fee tad leel"
  },
  {
    "id": 3,
    "text": "Wa arsala 'alaihim tairan abaabeel"
  },
  {
    "id": 4,
    "text": "Tar meehim bi hi jaaratim min sij jeel"
  },
  {
    "id": 5,
    "text": "Faja 'alahum ka'asfim m'akool"
  }
];

export default en;
