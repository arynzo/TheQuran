import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Meeem"
  },
  {
    "id": 2,
    "text": "Ahasiban naasu any yutrakooo any yaqoolooo aamannaa wa hum la yuftanoon"
  },
  {
    "id": 3,
    "text": "Wa laqad fatannal lazeena min qablihim fala ya'lamannal laahul lazeena sadaqoo wa la ya'lamannal kaazibeen"
  },
  {
    "id": 4,
    "text": "Am hasibal lazeena ya'maloonas sayyiaati any yasbiqoonaa; saaa'a maa yahkumoon"
  },
  {
    "id": 5,
    "text": "Man kaana yarjoo liqaaa 'allaahi fa inna ajalal laahi la'aat; wa Huwass Sameeul 'Aleem"
  },
  {
    "id": 6,
    "text": "Wa man jaahada fainnamaa yujaahidu linafsih; innal laaha laghaniyyun 'anil 'aalameen"
  },
  {
    "id": 7,
    "text": "Wallazeena aamanoo wa 'amilus saalihaati lanukaf firanna 'anhum saiyiaatihim wa lanajziyannahum ahsanal lazee kaanoo ya'maloon"
  },
  {
    "id": 8,
    "text": "Wa wassainal insaana biwaalidaihi husnanw wa in jaahadaaka litushrika bee maa laisa laka bihee 'ilmun falaa tuti'humaa; ilaiya marji'ukum fa unabbi'ukum bimaa kuntum ta'maloon"
  },
  {
    "id": 9,
    "text": "Wallazeena aamanoo wa'amilus saalihaati lanudkhilan nahum fis saaliheen"
  },
  {
    "id": 10,
    "text": "Wa minan naasi many yaqoolu aamannaa billaahi faizaaa ooziya fil laahi ja'ala fitnatan naasi ka'azaabil laahi wa la'in jaaa'a nasrum mir Rabbika la yaqoolunna innaa kunnaa ma'akum; awa laisal laahu bi a'lama bimaa fee sudooril 'aalameen"
  },
  {
    "id": 11,
    "text": "Wa la ya'lamannal laahul lazeena aamanoo wa la ya'lamannal munaafiqeen"
  },
  {
    "id": 12,
    "text": "Wa qaalal lazeena kafaroo lillazeena aamanut tabi'oo sabeelanaa walnahmil khataayaakum wa maa hum bihaamileena min khataa yaahum min shai'in innahum lakaaziboon"
  },
  {
    "id": 13,
    "text": "Wa la yahmilunna asqaa lahum wa asqaalam ma'a asqaalihim wa la yus'alunna Yawmal Qiyaamati 'ammaa kaanoo yaftaroon"
  },
  {
    "id": 14,
    "text": "Wa laqad arsalnaa Noohan ilaa qawmihee falabisa feehim alfa sanatin illaa khamseena 'aaman fa akhazahumut toofaanu wa hum zaalimoon"
  },
  {
    "id": 15,
    "text": "Fa anjainaahu wa as haabas safeenati wa ja'alnaahaaa Aayatal lil'aalameen"
  },
  {
    "id": 16,
    "text": "Wa Ibraheema iz qaala liqawmihi' budul laaha wattaqoohu zaalikum khayrul lakum in kuntum ta'lamoon"
  },
  {
    "id": 17,
    "text": "Innamaa ta'budoona min doonil laahi awsaananw-wa takhluqoona ifkaa; innal lazeena ta'budoona min doonil laahi laa yamlikoona lakum rizqan fabtaghoo 'indal laahir rizqa wa'budoohu washkuroo lahooo ilaihi turja'oon"
  },
  {
    "id": 18,
    "text": "Wa in tukazziboo faqad kazzaba umamum min qablikum wa maa'alar Rasooli illal balaaghul mubeen"
  },
  {
    "id": 19,
    "text": "Awa lam yaraw kaifa yubdi'ul laahul khalqa summa yu'eeduh; inna zaalika 'alal laahi yaseer"
  },
  {
    "id": 20,
    "text": "Qul seeroo fil ardi fanzuroo kaifa bada al khalqa thumm Allahu yunshi''un nash atal Aakhirah; innal laaha 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 21,
    "text": "Yu'azzibu many yashaaa'u wa yarhamu many yashaaa'; wa ilaihi tuqlaboon"
  },
  {
    "id": 22,
    "text": "Wa maaa antum bimu'jizeena fil ardi wa laa fissamaaa'i wa maa lakum min doonil laahi minw waliyyinw wa laa naseer"
  },
  {
    "id": 23,
    "text": "Wallazeena kafaroo bi Aayaatil laahi wa liqaaa'iheee ulaaa'ika ya'isoo mir rahmatee wa ulaaa'ika lahum 'azaabun aleem"
  },
  {
    "id": 24,
    "text": "Famaa kaana jawaaba qawmiheee illaaa an qaaluqtuloohu aw harriqoohu fa anjaahul laahu minan naar; inna fee zaalika la Aayaatil li qawminy yu'minoon"
  },
  {
    "id": 25,
    "text": "Wa qaala innamat takhaz tum min doonil laahi awsaanam mawaddata bainikum fil hayaatid dunyaa summa Yawmal Qiyaamati yakfuru ba'dukum biba'dinw wa yal'anu ba'dukum ba'danw wa ma'waakumun Naaru wa maa lakum min naasireen"
  },
  {
    "id": 26,
    "text": "Fa aamana lahoo Loot; wa qaala innee muhajirun ilaa Rabbee innahoo Huwal 'Azeezul Hakeem"
  },
  {
    "id": 27,
    "text": "Wa wahabnaa lahoo Ishaaqa wa Ya'Qooba wa ja'alnaa fee zurriyyatihin Nubuwwata wal Kitaaba wa aatainaahu ajrahoo fid dunyaa wa innahoo fil aakhirati laminas saaliheen"
  },
  {
    "id": 28,
    "text": "Wa Lootan iz qaala liqawmiheee innakum la ta'toonal faahishata maa sabaqakum bihaa min ahadin minal 'aalameen"
  },
  {
    "id": 29,
    "text": "A'innakum la ta'toonar rijaala wa taqta'oonas sabeela wa ta'toona fee naadeekumul munkara famaa kaana jawaaba qawmiheee illaaa an qaalu' tinaaa bi'azaabil laahi in kunta minas saadiqeen"
  },
  {
    "id": 30,
    "text": "Qaala Rabbin surnee 'alal qawmil mufsideen"
  },
  {
    "id": 31,
    "text": "Wa lammaa jaaa'at Rusulunaaa Ibraaheema bil bushraa qaalooo innaa muhlikoo ahli haazihil qaryati inna ahlahaa kaanoo zaalimeen"
  },
  {
    "id": 32,
    "text": "Qaala inna feeha Lootaa; qaaloo nahnu a'lamu biman feehaa lanunajjjiyannahoo wa ahlahooo illam ra atahoo kaanat minal ghaabireen"
  },
  {
    "id": 33,
    "text": "Wa lammaaa an jaaa'at Rusulunaa Lootan seee'a bihim wa daaqa bihim zar'anw wa qaaloo laa takhaf wa laa tahzan innaa munajjooka wa ahlaka illam ra ataka kaanat minal ghaabireen"
  },
  {
    "id": 34,
    "text": "Innaa munziloona 'alaaa ahli haazihil qaryati rijzan minas samaaa'i bimaa kaanoo yafsuqoon"
  },
  {
    "id": 35,
    "text": "Wa laqad taraknaa min haaa aayatan baiyinatan liqawminy ya'qiloon"
  },
  {
    "id": 36,
    "text": "Wa ilaa Madyana akhaahum Shu'ayban faqaala yaa qawmi'-budul laaha warjul yawmal aakhira wa laa ta'saw fil ardi mufsideen"
  },
  {
    "id": 37,
    "text": "Fakazzaboohu fa akhazat humur rajfatu fa asbahoo fee daarihim jaasimeen"
  },
  {
    "id": 38,
    "text": "Wa 'Aadanw wa Samooda wa qad tabaiyana lakum min masaakinihim wa zaiyana lahumush Shaitaanu a'maalahum fasaddahum 'anis sabeeli wa kaanoo mustabsireen"
  },
  {
    "id": 39,
    "text": "Wa Qaaroona wa Fir'awna wa haamaana wa laqad jaaa'ahum Moosa bilbaiyinaati fastakbaroo fil ardi wa maa kaanoo saabiqeen"
  },
  {
    "id": 40,
    "text": "Fakullan akhaznaa bi zanbihee faminhum man arsalnaa 'alaihi haasibaa; wa minhum man akhazat hus saihatu wa minhum man khasafnaa bihil arda wa minhum man aghraqnaa; wa maa kaanal laahu li yazlimahum wa laakin kaanoo anfusahum yazlimoon"
  },
  {
    "id": 41,
    "text": "Masalul lazeenat takhazoo min doonil laahi awliyaaa'a kamasalil 'ankaboot, ittakhazat baitaa; wa inna awhanal buyooti la baitul 'ankaboot; law kaanoo ya'lamoon"
  },
  {
    "id": 42,
    "text": "Innal laaha ya'lamu maa yad'oona min doonihee min shai'; wa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 43,
    "text": "Wa tilkal amsaalu nadribuhaa linnaasi wa maa ya'qiluhaaa illal 'aalimoon"
  },
  {
    "id": 44,
    "text": "Khalaqal laahus samaawaati wal arda bilhaqq; inna fee zaalika la aayatan lil mu'mineen"
  },
  {
    "id": 45,
    "text": "Utlu maaa oohiya ilaika minal Kitaabi wa aqimis Salaata innas Salaata tanhaa 'anil fahshaaa'i wal munkar; wa lazikrul laahi akbar; wal laahu ya'lamu maa tasna'oon"
  },
  {
    "id": 46,
    "text": "Wa laa tujaadilooo Ahlal Kitaabi illaa billatee hiya ahsanu illal lazeena zalamoo minhum wa qoolooo aamannaa billazeee unzila ilainaa wa unzila ilaikum wa illaahunna wa ilahukum waahidunw-wa nahnu lahoo muslimoon"
  },
  {
    "id": 47,
    "text": "Wa kazaalika anzalnaaa ilaikal Kitaab; fallazeena aatainaahumul kitaaba yu'minoona bihee wa min haaa'ulaaa'i many yu'minu bih; wa maa yajhadu bi'Aayaatinaa illal kaafiroon"
  },
  {
    "id": 48,
    "text": "Wa maa kunta tatloo min qablihee min kitaabinw wa laa takhuttuhoo bi yameenika izal lartaabal mubtiloon"
  },
  {
    "id": 49,
    "text": "Bal huwa aayaatum baiyinaatun fee sudooril lazeena ootul 'ilm; wa maa yajhadu bi aayaatinaa illaz zaalimoon"
  },
  {
    "id": 50,
    "text": "Wa qaaloo law laaa unzila 'alaihi aayaatum mir Rabbihee qul innamal aayaatu 'indal laahi wa innamaaa ana nazeerum mubeen"
  },
  {
    "id": 51,
    "text": "Awa lam yakfihim annaaa anzalnaa 'alaikal kitaaba yutlaa 'alaihim; inna fee zaalika larahmatanw wa zikraa liqawminy yu'minoon"
  },
  {
    "id": 52,
    "text": "Qul kafaa billaahi bainee wa bainakum shaheedaa; ya'lamu maa fis samaawaati wal ard; wallazeena aamanoo bil baatili wa kafaroo billaahi ulaaa'ika humul khaasiroon"
  },
  {
    "id": 53,
    "text": "Wa yasta'jiloonaka bil'azaab; wa law laaa ajalum musammal lajaaa'ahumul a'zaab; wa la ya'tiannahum baghta tanw wa hum laa yash'uroon"
  },
  {
    "id": 54,
    "text": "Yasta'jiloonaka bil'azaab; wa inna Jahannama la muheetatum bil kaafireen"
  },
  {
    "id": 55,
    "text": "Yawma yaghshaahumul 'azaabu min fawqihim wa min tahti arjulihim wa yaqoolu zooqoo maa kuntum ta'maloon"
  },
  {
    "id": 56,
    "text": "Yaa 'ibaadiyal lazeena aamanooo inna ardee waasi 'atun fa iyyaaya fa'budoon"
  },
  {
    "id": 57,
    "text": "Kullu nafsin zaaa'iqatul mawti summa ilainaa turja'oon"
  },
  {
    "id": 58,
    "text": "Wallazeena aamanoo wa 'amilus saalihaati la nubawwi 'annahum minal Jannati ghurafan tajree min tahtihal anhaaru khaalideena feehaa; ni'ma ajrul 'aamileen"
  },
  {
    "id": 59,
    "text": "Allazeena sabaroo wa 'alaa Rabbihim yatawakkaloon"
  },
  {
    "id": 60,
    "text": "Wa ka ayyim min daaabbatil laa tahmilu rizqahaa; al laahu yarzuquhaa wa iyyaakum; wa Huwas Samee'ul Aleem"
  },
  {
    "id": 61,
    "text": "Wa la'in sa altahum man khalaqas samaawaati wal arda wa sakhkharash shamsa wal qamara la yaqoolunnal laahu fa anna yu'fakoon"
  },
  {
    "id": 62,
    "text": "Allaahu yabsutur rizqa limany yashaaa'u min 'ibaadihee wa yaqdiru lah; innal laaha bikulli shai'in Aleem"
  },
  {
    "id": 63,
    "text": "Wa la'in sa altahum man nazzala minas samaaa'i maaa'an fa ahyaa bihil arda min ba'di mawtihaa la yaqoolunnal laah; qulil hamdu lillah; bal aksaruhum laa ya'qiloon"
  },
  {
    "id": 64,
    "text": "Wa maa haazihil hayaa tud dunyaaa illaa lahwunw-wa la'ib; wa innad Daaral Aakhirata la hiyal ha yawaan; law kaanu ya'lamoon"
  },
  {
    "id": 65,
    "text": "Fa-izaa rakiboo fil fulki da'awul laaha mukhliseena lahud deena falammaa najjaa hum ilal barri izaa hum yushrikoon"
  },
  {
    "id": 66,
    "text": "Li yakfuroo bimaaa aatainaahum wa li yatamatta'oo fasaw fa ya'lamoon"
  },
  {
    "id": 67,
    "text": "Awalam yaraw annaa ja'alnaa haraman aaminanw wa yutakhattafun naasu min haw lihim; afabil baatili yu'minoona wa bini'matil laahi yakfuroon"
  },
  {
    "id": 68,
    "text": "Wa man azlamu mimma nif taraa 'alal laahi kaziban aw kazzaba bilhaqqi lammaa jaaa'ah; alaisa fee jahannama maswal lil kaafireen"
  },
  {
    "id": 69,
    "text": "Wallazeena jaahadoo feenaa lanahdiyannahum subulana; wa innal laaha lama'al muhsineen"
  }
];

export default en;
