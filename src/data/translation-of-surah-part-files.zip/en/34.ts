import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alhamdu lillaahil lazee lahoo maa fis samaawaati wa maa fil ardi wa lahul hamdu fil aakhirah; wa Huwal Hakeemul Khabeer"
  },
  {
    "id": 2,
    "text": "Ya'lamu maa yaliju fil ardi wa maa yakhruju minhaa wa maa yanzilu minas samaaa'i wa maa ya'ruju feehaa; wa Huwar Raheemul Ghafoor"
  },
  {
    "id": 3,
    "text": "Wa qaalal lazeena kafaroo laa taateenas Saa'ah; qul balaa wa Rabbee lataatiyannakum 'Aalimul Ghaib; laa ya'zubu 'anhu misqaalu zarratin fis samaawaati wa laa fil ardi wa laaa asgharu min zaalika wa laaa akbaru illaa fee kitaabim mubeen"
  },
  {
    "id": 4,
    "text": "Liyajziyal lazeena aamanoo wa 'amilus saalihaat; ulaaa'ika lahum maghfiratunw wa rizqun kareem"
  },
  {
    "id": 5,
    "text": "Wallazeena sa'aw feee aayaatinaa mu'aajizeena ulaaa 'ika lahum 'azaabum mir rijzin aleem"
  },
  {
    "id": 6,
    "text": "Wa yaral lazeena ootul 'ilmal lazeee unzila ilaika mir Rabbika huwal haqqa wa yahdeee ilaaa siraatil 'Azeezil Hameed"
  },
  {
    "id": 7,
    "text": "Wa qaalal lazeena kafaroo hal nadullukum 'alaa rajuliny yunabbi 'ukum izaa muzziqtum kulla mumazzaqin innakum lafee khalqin jadeed"
  },
  {
    "id": 8,
    "text": "Aftaraa 'alal laahi kaziban am bihee jinnah; balil lazeena laa yu'minoona bil Aakhirati fil'azaabi wad dalaalil ba'eed"
  },
  {
    "id": 9,
    "text": "Afalam yaraw ilaa maa baina aydeehim wa maa khalfahum minas samaaa'i wal ard; in nashad nakhsif bihimul arda aw nusqit 'alaihim kisafam minas samaaa'; inna fee zaalika la Aayatal likulli 'abdim muneeb"
  },
  {
    "id": 10,
    "text": "Wa laqad aatainaa Daawooda minnaa fadlany yaa jibaalu awwibee ma'ahoo wattaira wa alannaa lahul hadeed"
  },
  {
    "id": 11,
    "text": "Ani'mal saabighaatinw wa qaddir fis sardi wa'maloo saalihan innee bimaa ta'maloona Baseer"
  },
  {
    "id": 12,
    "text": "Wa li-Sulaimaanar reeha ghuduwwuhaa shahrunw wa ra-waahuhaa shahrunw wa asalnaa lahoo 'ainal qitr; wa minal jinni mai ya'malu baina yadaihi bi izni Rabbih; wa mai yazigh minhum 'an amrinaa nuziqhu min 'azaabis sa'eer"
  },
  {
    "id": 13,
    "text": "Ya'maloona lahoo ma yashaaa'u mim mahaareeba wa tamaaseela wa jifaanin kaljawaabi wa qudoorir raasiyaat; i'maloo aala Daawooda shukraa; wa qaleelum min 'ibaadiyash shakoor"
  },
  {
    "id": 14,
    "text": "Falammaa qadainaa 'alaihil mawta ma dallahum 'alaa mawtiheee illaa daaabbatul ardi taakulu minsa atahoo falammaa kharra tabaiyanatil jinnu al law kaanoo ya'lamoonal ghaiba maa labisoo fil 'azaabil muheen"
  },
  {
    "id": 15,
    "text": "Laqad kaana li Saba-in fee maskanihim Aayatun jannataani 'any yameeninw wa shimaalin kuloo mir rizqi Rabbikum washkuroolah; baldatun taiyibatunw wa Rabbun Ghafoor"
  },
  {
    "id": 16,
    "text": "Fa a'radoo fa-arsalnaa 'alaihim Sailal 'Arimi wa baddalnaahum bijannataihim jannataini zawaatai ukulin khamtinw wa aslinw wa shai'im min sidrin qaleel"
  },
  {
    "id": 17,
    "text": "Zaalika jazainaahum bimaa kafaroo wa hal nujaazeee illal kafoor"
  },
  {
    "id": 18,
    "text": "Wa ja'alnaa bainahum wa bainal qural latee baaraknaa feehaa quran zaahiratanw wa qaddarnaa feehas sayr; seeroo feehaa la yaaliya wa aiyaaman aamineen"
  },
  {
    "id": 19,
    "text": "Faqaaloo Rabbanaa baa'id baina asfaarinaa wa zalamooo anfusahum faja'alnaahum ahaadeesa wa mazzaq naahum kulla mumazzaq; inna fee zaalika la Aayaatil likulli sabbaarin shakoor"
  },
  {
    "id": 20,
    "text": "Wa laqad saddaq 'alaihim Ibleesu zannahoo fattaba'oohu illaa fareeqam minal mu'mineen"
  },
  {
    "id": 21,
    "text": "Wa maa kaana lahoo 'alaihim min sultaanin illaa lina'lama mai yu minu bil Aakhirati mimman huwa minhaa fee shakk; wa Rabbuka 'alaa kulli shai'in Hafeez"
  },
  {
    "id": 22,
    "text": "Qulid 'ul lazeena za'amtum min doonil laahi laa yamlikoona misqaala zarratin fissamaawaati wa laa fil ardi wa maa lahum feehimaa min shirkinw wa maa lahoo minhum min zaheer"
  },
  {
    "id": 23,
    "text": "Wa laa tanfa'ush shafaa'atu 'indahooo illaa liman azina lah; hattaaa izaa fuzzi'a 'an quloobihim qaaloo maazaa qaala Rabbukum; qaalul haqq, wa Huwal 'Aliyul Kabeer"
  },
  {
    "id": 24,
    "text": "Qul mai yarzuqukum minas samaawaati wal ardi qulil laahu wa innaaa aw iyyaakum la'alaa hudan aw fee dalaalim mubeen"
  },
  {
    "id": 25,
    "text": "Qul laa tus'aloona 'ammaaa ajramnaa wa laa nus'alu 'ammaa ta'maloon"
  },
  {
    "id": 26,
    "text": "Qul yajma'u bainanaa Rabbunaa summa yaftahu bainanaa bilhaqq; wa Huwal Fattaahul 'Aleem"
  },
  {
    "id": 27,
    "text": "Qul arooniyal lazeena alhaqtum bihee shurakaaa'a kallaa; bal Huwal Laahul 'Azeezul Hakeem"
  },
  {
    "id": 28,
    "text": "Wa maaa arsalnaaka illaa kaaffatal linnaasi basheeranw wa nazeeranw wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 29,
    "text": "Wa yaqooloona mataa haazal wa'du in kuntum saadiqeen"
  },
  {
    "id": 30,
    "text": "Qul lakum mee'aadu Yawmil laa tasta'khiroona 'anhu saa'atanw wa laa tastaqdimoon"
  },
  {
    "id": 31,
    "text": "Wa qaalal lazeena kafaroo lan nu'mina bihaazal Quraani wa laa billazee baina yadayh; wa law taraaa iziz zaalimoona mawqoofoona 'inda Rabbihim yarji'u ba'duhum ilaa ba'dinil qawla yaqoolul lazeenas tud'ifoo lillazeenas takbaroo law laaa antum lakunnaa mu'mineen"
  },
  {
    "id": 32,
    "text": "Qaalal lazeenas takbaroo lillazeenas tud'ifooo anahnu sadadnaakum 'anil hudaa ba'da iz jaaa'akum bal kuntum mujrimeen"
  },
  {
    "id": 33,
    "text": "Wa qaalal lazeenastud'ifoo lillazeenas takbaroo bal makrul laili wannahaari iz ta'muroonanaaaa an nakfura billaahi wa naj'ala lahooo andaadaa; wa asarrun nadaamata lammaa ra awul 'azaab; wa ja'alnal aghlaala feee a'naaqil lazeena kafaroo; hal yujzawna illaa maa kaanoo ya'maloon"
  },
  {
    "id": 34,
    "text": "Wa maaa arsalnaa' fee qaryatin min nazeerin illaa qaala mutrafoohaa innaa bimaaa ursiltum bihee kaafiroon"
  },
  {
    "id": 35,
    "text": "Wa qaaloo nahnu aksaru amwaalanw wa awlaadanw wa maa nahnu bimu 'azzabeen"
  },
  {
    "id": 36,
    "text": "Qul inna Rabbee yabsutur rizqa limai yashaaa'u wa yaqdiru wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 37,
    "text": "Wa maaa amwaalukum wa laaa awlaadukum billatee tuqarribukum 'indanaa zulfaaa illaa man aamana wa 'amila saalihan fa ulaaa'ika lahum jazaaa'ud di'fi bimaa 'amiloo wa hum fil ghurufaati aaminoon"
  },
  {
    "id": 38,
    "text": "Wallazeena yas'awna feee Aayaatinaa mu'aajizeena ulaaa'ika fil'azaabi muhdaroon"
  },
  {
    "id": 39,
    "text": "Qul inna Rabbee yabsutur rizqa limai yashaaa'u min 'ibaadihee wa yaqdiru lah; wa maaa anfaqtum min shai'in fahuwa yukhlifuhoo wa Huwa khairur raaziqeen"
  },
  {
    "id": 40,
    "text": "Wa yawma yahshuruhum jamee'an summa yaqoolu lilmalaaa'ikati a-haaa'ulaaa'i iyyaakum kaanoo ya'budoon"
  },
  {
    "id": 41,
    "text": "Qaaloo Subhaanaka Anta waliyyunaa min doonihim bal kaanoo ya'budoonal jinna aksaruhum bihim mu'minoon"
  },
  {
    "id": 42,
    "text": "Fal Yawma laa yamliku ba'dukum liba'din naf'anw wa laa darraa; wa naqoolu lil lazeena zalamoo zooqoo 'azaaban Naaril latee kuntum bihaa tukazziboon"
  },
  {
    "id": 43,
    "text": "Wa izaa tutlaa 'alaihim Aayaatunaa baiyinaatin qaaloo maa haazaa illaa rajuluny yureedu ai-yasuddakum 'ammaa kaana ya'budu aabaaa'ukum wa qaaloo maa haazaaa illaaa ifkum muftaraa; wa qaalal lazeena kafaroo lilhaqqi lammaa jaaa'ahum in haazaaa illaa sihrum mubeen"
  },
  {
    "id": 44,
    "text": "Wa maaa aatainaahum min Kutubiny yadrusoonahaa wa maaa arsalnaaa ilaihim qablaka min nazeer"
  },
  {
    "id": 45,
    "text": "Wa kazzabal lazeena min qablihim wa maa balaghoo mi'shaara maaa aatainaahum fakazzaboo Rusulee; fakaifa kaana nakeer"
  },
  {
    "id": 46,
    "text": "Qul innamaaa a'izukum biwaahidatin an taqoomoo lillaahi masnaa wa furaadaa summa tatafakkaroo; maa bisaahibikum min jinnah; in huwa illaa nazeerul lakum baina yadai 'azaabin shadeed"
  },
  {
    "id": 47,
    "text": "Qul maa sa-altukum min ajrin fahuwa lakum in ajriya illaa 'alal laahi wa Huwa 'alaa kulli shai'in Shaheed"
  },
  {
    "id": 48,
    "text": "Qul inna Rabbee yaqzifu bilhaqq 'Allaamul Ghuyoob"
  },
  {
    "id": 49,
    "text": "Qul jaaa'al haqqu wa maa yubdi'ul baatilu wa maa yu'eed"
  },
  {
    "id": 50,
    "text": "Qul in dalaltu fainnamaaa adillu 'alaa nafsee wa inih-tadaitu fabimaa yoohee ilaiya Rabbee; innahoo Samee'un Qareeb"
  },
  {
    "id": 51,
    "text": "Wa law taraaa iz fazi'oo falaa fawta wa ukhizoo min makaanin qareeb"
  },
  {
    "id": 52,
    "text": "Wa qaaloo aamannaa bihee wa annaa lahumut tanaawushu min makaanin ba'eed"
  },
  {
    "id": 53,
    "text": "Wa qad kafaroo bihee min qablu wa yaqzifoona bilghaibi min makaanin ba'eed"
  },
  {
    "id": 54,
    "text": "Wa heela bainahum wa baina maa yashtahoona kamaa fu'ila bi-ashyaa'ihim min qabl; innahum kaanoo fee shakkin mureeb"
  }
];

export default en;
