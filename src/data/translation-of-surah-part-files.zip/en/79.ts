import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wan naazi 'aati gharqa"
  },
  {
    "id": 2,
    "text": "Wan naa shi taati nashta"
  },
  {
    "id": 3,
    "text": "Wass saabi-haati sabha"
  },
  {
    "id": 4,
    "text": "Fass saabi qaati sabqa"
  },
  {
    "id": 5,
    "text": "Fal mu dab-bi raati amra"
  },
  {
    "id": 6,
    "text": "Yawma tarjufur raajifa"
  },
  {
    "id": 7,
    "text": "Tatba'u har raadifa"
  },
  {
    "id": 8,
    "text": "Quloobuny-yau maaiziw-waaji-fa"
  },
  {
    "id": 9,
    "text": "Absaa ruhaa khashi'ah"
  },
  {
    "id": 10,
    "text": "Ya qoo loona a-inna lamar doo doona fil haafirah"
  },
  {
    "id": 11,
    "text": "Aizaa kunna 'izaa man-nakhirah"
  },
  {
    "id": 12,
    "text": "Qaalu tilka izan karratun khaasirah."
  },
  {
    "id": 13,
    "text": "Fa inna ma hiya zajratuw-waahida"
  },
  {
    "id": 14,
    "text": "Faizaa hum biss saahirah"
  },
  {
    "id": 15,
    "text": "Hal ataaka hadeethu Musaa"
  },
  {
    "id": 16,
    "text": "Iz nadaahu rabbuhu bil waadil-muqad dasi tuwa"
  },
  {
    "id": 17,
    "text": "Izhab ilaa fir'auna innahu taghaa."
  },
  {
    "id": 18,
    "text": "Faqul hal laka ilaa-an tazakka."
  },
  {
    "id": 19,
    "text": "Wa ahdi yaka ila rabbika fatakh sha"
  },
  {
    "id": 20,
    "text": "Fa araahul-aayatal kubra."
  },
  {
    "id": 21,
    "text": "Fa kazzaba wa asaa."
  },
  {
    "id": 22,
    "text": "Thumma adbara yas'aa."
  },
  {
    "id": 23,
    "text": "Fa hashara fanada."
  },
  {
    "id": 24,
    "text": "Faqala ana rabbu kumul-a'laa."
  },
  {
    "id": 25,
    "text": "Fa-akha zahul laahu nakalal aakhirati wal-oola."
  },
  {
    "id": 26,
    "text": "Inna fee zaalika la'ibratal limaiy-yaksha"
  },
  {
    "id": 27,
    "text": "A-antum a shaddu khalqan amis samaa-u banaaha."
  },
  {
    "id": 28,
    "text": "Raf'a sam kaha fasaw waaha"
  },
  {
    "id": 29,
    "text": "Wa aghtasha lailaha wa akhraja duhaaha."
  },
  {
    "id": 30,
    "text": "Wal arda b'ada zaalika dahaaha."
  },
  {
    "id": 31,
    "text": "Akhraja minha maa-aha wa mar 'aaha."
  },
  {
    "id": 32,
    "text": "Wal jibala arsaaha."
  },
  {
    "id": 33,
    "text": "Mataa'al lakum wali an 'aamikum."
  },
  {
    "id": 34,
    "text": "Fa-izaa jaaa'atit taaam matul kubraa."
  },
  {
    "id": 35,
    "text": "Yauma Yata zakkarul insaanu ma sa'aa."
  },
  {
    "id": 36,
    "text": "Wa burrizatil-jaheemu limany-yaraa."
  },
  {
    "id": 37,
    "text": "Fa ammaa man taghaa."
  },
  {
    "id": 38,
    "text": "Wa aasaral hayaatad dunyaa"
  },
  {
    "id": 39,
    "text": "Fa innal jaheema hiyal maawaa."
  },
  {
    "id": 40,
    "text": "Wa ammaa man khaafa maqaama Rabbihee wa nahan nafsa 'anil hawaa"
  },
  {
    "id": 41,
    "text": "Fa innal jannata hiyal ma'waa"
  },
  {
    "id": 42,
    "text": "Yas'aloonaka 'anis saa'ati ayyaana mursaahaa"
  },
  {
    "id": 43,
    "text": "Feema anta min zikraahaa"
  },
  {
    "id": 44,
    "text": "Ilaa Rabbika muntahaa haa"
  },
  {
    "id": 45,
    "text": "Innamaaa anta munziru maiy yakhshaahaa"
  },
  {
    "id": 46,
    "text": "Ka annahum Yawma yarawnahaa lam yalbasooo illaa 'ashiyyatan aw duhaahaa"
  }
];

export default en;
