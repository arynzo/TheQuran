import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Meeem"
  },
  {
    "id": 2,
    "text": "Ghulibatir Room"
  },
  {
    "id": 3,
    "text": "Feee adnal ardi wa hummim ba'di ghalabihim sa-yaghliboon"
  },
  {
    "id": 4,
    "text": "Fee bid'i sineen; lillaahil amru min qablu wa mim ba'd; wa yawma'iziny yafrahul mu'minoon"
  },
  {
    "id": 5,
    "text": "Binasril laa; yansuru mai yashaaa'u wa Huwal 'Azeezur Raheem"
  },
  {
    "id": 6,
    "text": "Wa'dal laahi laa yukhliful laahu wa'dahoo wa laakin na aksaran naasi laa ya'lamoon"
  },
  {
    "id": 7,
    "text": "Ya'lamoona zaahiram minal hayaatid dunya wa hum 'anil Aakhirati hum ghaafiloon"
  },
  {
    "id": 8,
    "text": "Awalam yatafakkaroo feee anfusihim; maa khalaqal laahus samaawaati wal arda wa maa bainahumaaa illaa bil haqqi wa ajalim musammaa; wa inna kaseeram minan naasi biliqaaa'i Rabbihim lakaafiroon"
  },
  {
    "id": 9,
    "text": "Awalam yaseeroo fil ardi fa-yanzuroo kaifa kaana 'aaqibatul lazeena min qablihim; kaanooo ashadda minhhum quwwatanw wa asaarul arda wa 'amaroohaaa aksara mimmaa 'amaroohaa wa jaaa'athum Rusuluhum bil baiyinaati famaa kaanal laahu liyazli mahum wa laakin kaanooo anfusahum yazlimoon"
  },
  {
    "id": 10,
    "text": "Summa kaana'aaqibatal lazeena asaaa'us sooo aaa an kazzaboo bi aayaatil laahi wa kaanoo bihaa yastahzi'oon"
  },
  {
    "id": 11,
    "text": "Allaahu yabda'ul khalqa summa yu'eeduhoo summa ilaihi turja'oon"
  },
  {
    "id": 12,
    "text": "Wa yawma taqoomus Saa'atu yublisul mujrimoon"
  },
  {
    "id": 13,
    "text": "Wa lam yakul lahum min shurakaaa'ihim shufa'aaa'u wa kaanoo bishurakaaa'ihim kaafireen"
  },
  {
    "id": 14,
    "text": "Wa Yawma taqoomus Saa'atu Yawma'iziny yatafarraqoon"
  },
  {
    "id": 15,
    "text": "Fa ammal lazeena aamanoo wa 'amilus saalihaati fahum fee rawdatiny yuhbaroon"
  },
  {
    "id": 16,
    "text": "Wa ammal lazeena kafaroo wa kazzaboo bi-Aayaatinaa wa liqaaa'il Aakhirati faulaaa'ika fil'azaabi muhdaroon"
  },
  {
    "id": 17,
    "text": "Fa Subhaanal laahi heena tumsoona wa heena tusbihoon"
  },
  {
    "id": 18,
    "text": "Wa lahul hamdu fis samaawaati wal ardi wa 'ashiyyanw wa heena tuzhiroon"
  },
  {
    "id": 19,
    "text": "Yukhrijul haiya minal maiyiti wa yukhrijul maiyita minal haiyi wa yuhyil arda ba'da mawtihaa; wa kazaalika tukhrajoon"
  },
  {
    "id": 20,
    "text": "Wa min Aayaatiheee an khalaqakum min turaabin summa izaaa antum basharun tantashiroon"
  },
  {
    "id": 21,
    "text": "Wa min Aayaatiheee an khalaqa lakum min anfusikum azwaajal litaskunooo ilaihaa wa ja'ala bainakum mawad datanw wa rahmah; inna fee zaalika la Aayaatil liqawminy yatafakkaroon"
  },
  {
    "id": 22,
    "text": "Wa min Aayaatihee khalqus samaawaati wal aardi wakhtilaafu alsinatikum wa alwaanikum; inna fee zaalika la Aayaatil lil'aalimeen"
  },
  {
    "id": 23,
    "text": "Wa min Aayaatihee manaamukum bil laili wannahaari wabtighaaa'ukum min fadlih; inna fee zaalika la Aayaatil liqawminy yasma'oon"
  },
  {
    "id": 24,
    "text": "Wa min Aayaatihee yureekumul barqa khawfanw wa tama'anw wa yunazzilu minas samaaa'i maaa'an fa yuhyee bihil arda ba'da mawtihaaa inna fee zaalika la Aayaatil liqawminy ya'qiloon"
  },
  {
    "id": 25,
    "text": "Wa min Aayaatihee an taqoomas samaaa'u wal ardu bi-amrih; summa izaa da'aakum da'watam minal ardi izaaa antum takhrujoon"
  },
  {
    "id": 26,
    "text": "Wa lahoo man fissamaawaati wal ardi kullul lahoo qaanitoon"
  },
  {
    "id": 27,
    "text": "Wa Huwal lazee yabda'ul khalqa summa yu'eeduhoo wa huwa ahwanu 'alaih; wa lahul masalul a'laa fissamaawaati wal-ard; wa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 28,
    "text": "Daraba lakum masalam min anfusikum hal lakum mimmaa malakat aymaanukum min shurakaaa'a fee maa razaqnaakum fa antum feehi sawaaa'un takhaafoonahum kakheefa tikum anfusakum; kazaalika nufassilul Aayaati liqawminy ya'qiloon"
  },
  {
    "id": 29,
    "text": "Balit taba'al lazeena zalamooo ahwaaa'ahum bighairi 'ilmin famai yahdee man adallal laahu wa maa lahum min naasireen"
  },
  {
    "id": 30,
    "text": "Fa aqim wajhaka liddeeni Haneefaa; fitratal laahil latee fataran naasa 'alaihaa; laa taabdeela likhalqil laah; zaalikad deenul qaiyimu wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 31,
    "text": "Muneebeena ilaihi wattaqoohu wa aqeemus Salaata wa laa takoonoo minal mushrikeen"
  },
  {
    "id": 32,
    "text": "Minal lazeena farraqoo deenahum wa kaanoo shiya'an kullu hizbim bimaa ladaihim farihoon"
  },
  {
    "id": 33,
    "text": "Wa izaa massan naasa durrun da'aw Rabbahum muneebeena ilaihi summa izaaa azaqahum minhu rahmatan izaa fareequm minhum be Rabbihim yushrikoon"
  },
  {
    "id": 34,
    "text": "Li yakfuroo bimaaa aatainaahum; fatamatta'oo fasawfa ta'lamoon"
  },
  {
    "id": 35,
    "text": "Am anzalnaa 'alaihim sultaanan fahuwa yatakallamu bimaa kaanoo bihee yushrikoon"
  },
  {
    "id": 36,
    "text": "Wa izaaa azaqnan naasa rahmatan farihoo bihaa wa in tusibhum sayyi'atum bimaa qaddamat aydeehim izaa hum yaqnatoon"
  },
  {
    "id": 37,
    "text": "Awalam yaraw annal laaha yabsutur rizqa limai yashaaa'u wa yaqdir; inna fee zaalika la Aayaatil liqawminy yu'minoon"
  },
  {
    "id": 38,
    "text": "Fa aati zal qurbaa haqqahoo walmiskeena wabnassabeel; zaalika khairul lil lazeena yureedoona Wajhal laahi wa ulaaa'ika humul muflihoon"
  },
  {
    "id": 39,
    "text": "Wa maaa aataitum mir ribal li yarbuwa feee amwaalin naasi falaa yarboo 'indal laahi wa maaa aataitum min zaakaatin tureedoona wajhal laahi fa ulaaa'ika humul mud'ifoon"
  },
  {
    "id": 40,
    "text": "Allaahul lazee khalaqa kum summa razaqakum summa yumeetukum summa yuhyeekum hal min shurakaaa'ikum mai yaf'alu min zaalikum min shai'; Sub haanahoo wa Ta'aalaa 'ammaa yushrikoon"
  },
  {
    "id": 41,
    "text": "Zaharal fasaadu fil barri wal bahri bimaa kasabat aydinnaasi li yuzeeqahum ba'dal lazee 'amiloo la'allahum yarji'oon"
  },
  {
    "id": 42,
    "text": "Qul seeroo fil ardi fanzuroo kaifa kaana 'aaqibatul lazeena min qabl; kaana aksaruhum mushrikeen"
  },
  {
    "id": 43,
    "text": "Fa aqim wajhaka lid deenil qaiyimi min qabli any yaatiya Yawmul laa maradda lahoo minal laahi Yawma'iziny yassadda'oon"
  },
  {
    "id": 44,
    "text": "Man kafara fa'alaihi kufruhoo wa man 'amila saalihan fali anfusihim yamhadoon"
  },
  {
    "id": 45,
    "text": "Li yajziyal lazeena aamanoo wa 'amilus saalihaati min fadlih; innahoo laa yuhibbul kaafireen"
  },
  {
    "id": 46,
    "text": "Wa min Aayaatiheee anyyursilar riyaaha mubashshi raatinw wa li yuzeeqakum mir rahmatihee wa litajriyal fulku bi amrihee wa litabtaghoo min fadlihee wa la'allakum tashkuroon"
  },
  {
    "id": 47,
    "text": "Wa laqad arsalnaa min qablika Rusulan ilaa qawmihim fajaaa'oohum bil baiyinaati fantaqamnaa minal lazeena ajramoo wa kaana haqqan 'alainaa nasrul mu'mineen"
  },
  {
    "id": 48,
    "text": "Allaahul lazee yursilur riyaaha fatuseeru sahaaban fa yabsutuhoo fis samaaa'i kaifa yashaaa'u wa yaj'aluhoo kisafan fataral wadqa yakhruju min khilaalihee fa izaaa asaaba bihee mai yashaaa'u min 'ibaadiheee izaa hum yastabshiroon"
  },
  {
    "id": 49,
    "text": "Wa in kaanoo min qabli any yunazzala 'alaihim min qablihee lamubliseen"
  },
  {
    "id": 50,
    "text": "Fanzur ilaaa aasaari rahmatil laahi kaifa yuhyil arda ba'da mawtihaa; inna zaalika lamuhyil mawtaa wa Huwa 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 51,
    "text": "Wa la'in arsalnaa reehan fara awhu musfarral lazalloo mim ba'dihee yakfuroon"
  },
  {
    "id": 52,
    "text": "Fa innaka laa tusmi'ul mawtaa wa laa tusmi'us summad du'aaa'a izaa wallaw mudbireen"
  },
  {
    "id": 53,
    "text": "Wa maa anta bihaadil 'umyi 'an dalaalatihim in tusmi'u illaa mai yuminu bi aayaatinaa fahum muslimoon"
  },
  {
    "id": 54,
    "text": "Allahul lazee khalaqa kum min du'fin summa ja'ala mim ba'di du'fin quwwatan summa ja'ala mim ba'di quwwatin du'fanw wa shaibah; yakhluqu maa yashaaa'u wa Huwal 'Aleemul Qadeer"
  },
  {
    "id": 55,
    "text": "Wa Yawma taqoomus Saa'atu yuqsimul mujrimoona maa labisoo ghaira saa'ah; kazaalika kaanoo yu'fakoon"
  },
  {
    "id": 56,
    "text": "Wa qaalal lazeena ootul 'ilma wal eemaana laqad labistum fee kitaabil laahi ilaa yawmil ba'si fahaazaa yawmul ba'si wa laakinnakum kuntum laa ta'lamoon"
  },
  {
    "id": 57,
    "text": "Fa Yawma'izil laa yanfa'ul lazeena zalamoo ma'ziratu hum wa laa hum yusta'taboon"
  },
  {
    "id": 58,
    "text": "Wa laqad darabnaa linnaasi fee haazal Quraani min kulli masal; wa la'in ji'tahum bi aayatil la yaqoolannal lazeena kafaroo in antum illaa mubtiloon"
  },
  {
    "id": 59,
    "text": "Kazaalika yatba'ul laahu 'alaa quloobil lazeena laa ya'lamoon"
  },
  {
    "id": 60,
    "text": "Fasbir inna wa'dal laahi haqqunw wa laa yastakhif fannakal lazeena laa yooqinoon"
  }
];

export default en;
