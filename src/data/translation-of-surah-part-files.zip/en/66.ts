import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yaaa ayyuhan nabiyyu lima tuharrimu maaa ahallal laahu laka tabtaghee mardaata azwaajik; wallaahu ghafoorur raheem"
  },
  {
    "id": 2,
    "text": "Qad faradal laahu lakum tahillata aymaanikum; wallaahu mawlaakum wa huwal 'aleemul hakeem"
  },
  {
    "id": 3,
    "text": "Wa iz asarran nabiyyu ilaa ba'di azwaajihee hadeesan falammaa nabba at bihee wa azharahul laahu 'alaihi 'arrafa ba'dahoo wa a'rada 'am ba'din falammaa nabba ahaa bihee qaalat man amba aka haaza qaala nabba aniyal 'aleemul khabeer"
  },
  {
    "id": 4,
    "text": "In tatoobaaa ilal laahi faqad saghat quloobukumaa wa in tazaaharaa 'alaihi fa innal laaha huwa mawlaahu wa jibreelu wa saalihul mu'mineen; wal malaaa'ikatu ba'da zaalika zaheer"
  },
  {
    "id": 5,
    "text": "'Asaa rabbuhooo in tallaqakunna anyyubdilahooo azwaajan khairam minkunna muslimaatim mu'minaatin qaanitaatin taaa'ibaatin 'aabidaatin saaa'ihaatin saiyibaatinw wa abkaaraa"
  },
  {
    "id": 6,
    "text": "Yaaa ayyuhal lazeena aamanoo qooo anfusakum wa ahleekum naaranw waqoodu han naasu wal hijaaratu 'alaihaa malaaa'ikatun ghilaazun shidaadul laa ya'soonal laaha maa amarahum wa yaf'aloona maa yu'maroon"
  },
  {
    "id": 7,
    "text": "Yaaa ayyuhal lazeena kafaroo la ta'tazirul yawma innamaa tujzawna maa kuntum ta'maloon"
  },
  {
    "id": 8,
    "text": "Yaaa ayyuhal lazeena aamanoo toobooo ilal laahi tawbatan nasoohan 'asaa rabbukum any-yukaffira 'ankum sayyi aatikum wa yudkhilakum jannaatin tajree min tahtihal anhaaru yawma laa yukhzil laahun nabiyya wallazeena aamanoo ma'ahoo nooruhum yas'aa baina aydeehim wa bi aymaanihim yaqooloona rabbanaaa atmim lanaa nooranaa waghfir lana innaka 'alaa kulli shai'in qadeer"
  },
  {
    "id": 9,
    "text": "Yaaa ayyuhan nabiyyu jaahidil kuffaara walmunaa-fiqeena waghluz 'alaihim; wa ma'waahum jahannamu wa bi'sal maseer"
  },
  {
    "id": 10,
    "text": "Darabal laahu masalal lillazeena kafarum ra ata Noohinw wamra ata Loot, kaanataa tahta 'abdaini min 'ibaadinaa saalihaini fakhaanataahumaa falam yughniyaa 'anhumaa minal laahi shai anw-wa qeelad khulan naara ma'ad Daakhileen"
  },
  {
    "id": 11,
    "text": "Wa darabal laahu masalal lil lezeena aamanumra ata Fir'awn; iz qaalat rab bibni lee 'indaka baitan fil jannati wa najjinee min Fir'awna wa 'amalihee wa najjinee minal qawmiz zaalimeen"
  },
  {
    "id": 12,
    "text": "Wa Maryamab nata 'Imraanal lateee ahsanat farjahaa fanafakhnaa feehee mir roohinaa wa saddaqat bi kalimaati Rabbihaa wa Kutubihee wakaanat minal qaaniteen (End Juz"
  }
];

export default en;
