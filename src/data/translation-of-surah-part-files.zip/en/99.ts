import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Izaa zul zilatil ardu zil zaalaha"
  },
  {
    "id": 2,
    "text": "Wa akh rajatil ardu athqaalaha"
  },
  {
    "id": 3,
    "text": "Wa qaalal insaanu ma laha"
  },
  {
    "id": 4,
    "text": "Yawmaa izin tuhaddithu akhbaaraha"
  },
  {
    "id": 5,
    "text": "Bi-anna rabbaka awhaa laha"
  },
  {
    "id": 6,
    "text": "Yawma iziny yas durun naasu ash tatal liyuraw a'maalahum"
  },
  {
    "id": 7,
    "text": "Famaiy ya'mal mithqala zarratin khai raiy-yarah"
  },
  {
    "id": 8,
    "text": "Wa maiy-y'amal mithqala zarratin sharraiy-yarah"
  }
];

export default en;
