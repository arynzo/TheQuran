import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "'Abasa wa tawallaa."
  },
  {
    "id": 2,
    "text": "An jaa-ahul 'a-maa"
  },
  {
    "id": 3,
    "text": "Wa maa yudreeka la'allahu yaz zakkaa."
  },
  {
    "id": 4,
    "text": "Aw yazzakkaru fatanfa 'ahuz zikraa."
  },
  {
    "id": 5,
    "text": "Amma manis taghnaa"
  },
  {
    "id": 6,
    "text": "Fa-anta lahu tasaddaa"
  },
  {
    "id": 7,
    "text": "Wa ma 'alaika allaa yaz zakka."
  },
  {
    "id": 8,
    "text": "Wa amma man jaa-aka yas'a"
  },
  {
    "id": 9,
    "text": "Wahuwa yakhshaa,"
  },
  {
    "id": 10,
    "text": "Fa-anta 'anhu talah haa."
  },
  {
    "id": 11,
    "text": "Kalla innaha tazkirah"
  },
  {
    "id": 12,
    "text": "Faman shaa a zakarah"
  },
  {
    "id": 13,
    "text": "Fi suhufim mukar rama,"
  },
  {
    "id": 14,
    "text": "Marfoo'atim mutah hara,"
  },
  {
    "id": 15,
    "text": "Bi'aidee safara"
  },
  {
    "id": 16,
    "text": "Kiraamim bararah."
  },
  {
    "id": 17,
    "text": "Qutilal-insanu maa akfarah."
  },
  {
    "id": 18,
    "text": "Min aiyyi shai-in Khalaq"
  },
  {
    "id": 19,
    "text": "Min nutfatin khalaqahoo faqaddarah."
  },
  {
    "id": 20,
    "text": "Thummas sabeela yas-sarah"
  },
  {
    "id": 21,
    "text": "Thumma amatahu fa-aqbarah"
  },
  {
    "id": 22,
    "text": "Thumma iza shaa-a ansharah"
  },
  {
    "id": 23,
    "text": "Kalla lamma yaqdi maa amarah."
  },
  {
    "id": 24,
    "text": "Falyanzuril insanu ilaa ta-amih"
  },
  {
    "id": 25,
    "text": "Anna sabab nalmaa-a sabba."
  },
  {
    "id": 26,
    "text": "Thumma sha qaqnal-arda shaqqa."
  },
  {
    "id": 27,
    "text": "Fa ambatna feeha habba"
  },
  {
    "id": 28,
    "text": "Wa 'inabaw-wa qadba"
  },
  {
    "id": 29,
    "text": "Wa zaitoonaw wanakh la'"
  },
  {
    "id": 30,
    "text": "Wa hadaa-iqa ghulba"
  },
  {
    "id": 31,
    "text": "Wa faki hataw-wa abba."
  },
  {
    "id": 32,
    "text": "Mata'al-lakum wa li-an'amikum."
  },
  {
    "id": 33,
    "text": "Faiza jaa-atis saakhah."
  },
  {
    "id": 34,
    "text": "Yauma yafir-rul mar-u min akheeh"
  },
  {
    "id": 35,
    "text": "Wa ummihee wa abeeh"
  },
  {
    "id": 36,
    "text": "Wa sahi batihee wa baneeh."
  },
  {
    "id": 37,
    "text": "Likul limri-im-minhum yawmaa-izin shaa nuy-yughneeh"
  },
  {
    "id": 38,
    "text": "Wujoo huny-yauma-izim-musfira;"
  },
  {
    "id": 39,
    "text": "Dahi katum mustab shirah"
  },
  {
    "id": 40,
    "text": "Wa wujoohuy yauma-izin 'alaiha ghabar a"
  },
  {
    "id": 41,
    "text": "Tarhaquha qatarah."
  },
  {
    "id": 42,
    "text": "Ulaa-ika humul-kafa ratul-fajarah."
  }
];

export default en;
