import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Haa-Meeeem"
  },
  {
    "id": 2,
    "text": "Tanzeelul Kitaabi minal laahil-'Azeezil Hakeem"
  },
  {
    "id": 3,
    "text": "Maa khalaqnas samaawaati wal arda wa maa bainahumaaa illaa bilhaqqi wa ajalim musammaa; wallazeena kafaroo 'ammaaa unziroo mu'ridoon"
  },
  {
    "id": 4,
    "text": "Qul ara'aytum maa tad'oona min doonil laahi aroonee maazaa khalaqoo minal ardi am lahum shirkun fis samaawaati eetoonee bi kitaabim min qabli haazaaa aw asaaratim min 'ilmin in kuntum saadiqeen"
  },
  {
    "id": 5,
    "text": "Wa man adallu mimmany yad'oo min doonil laahi mallaa yastajeebu lahooo ilaa Yawmil Qiyaamati wa hum'an du'aaa'ihim ghaafiloon"
  },
  {
    "id": 6,
    "text": "Wa izaa hushiran naasu kaanoo lahum a'daaa'anw wa kaanoo bi'ibaadatihim kaafireen"
  },
  {
    "id": 7,
    "text": "Wa izaa tutlaa 'alaihim Aayaatunaa baiyinaatin qaalal lazeena kafaroo lilhaqqi lammaa jaaa'ahum haazaa sihrum mubeen"
  },
  {
    "id": 8,
    "text": "Am yaqooloonaf taraahu qul inif taraituhoo falaa tamlikoona lee minal laahi shai'an Huwa a'lamu bimaa tufeedoona feehi kafaa bihee shaheedam bainee wa bainakum wa Huwal Ghafoorur Raheem"
  },
  {
    "id": 9,
    "text": "Qul maa kuntu bid'am minal Rusuli wa maaa adreee ma yuf'alu bee wa laa bikum in attabi'u illaa maa yoohaaa ilaiya wa maaa ana illaa nazeerum mubeen"
  },
  {
    "id": 10,
    "text": "Qul ara'aytum in kaana min 'indil laahi wa kafartum bihee wa shahida shaahidum mim Banee Israaa'eela 'alaa mislihee fa aamana wastak bartum innal laaha laa yahdil qawmaz zaalimeen"
  },
  {
    "id": 11,
    "text": "Wa qaalal lazeena kafaroo lillazeena aamanoo law kaana khairam maa sabaqoonaaa ilyh; wa iz lam yahtadoo bihee fasa yaqooloona haazaaa ifkun qadeem"
  },
  {
    "id": 12,
    "text": "Wa min qablihee kitaabu Moosaaa imaamanw-wa rahmah; wa haazaa Kitaabum musad diqul lisaanan 'Arabiyyal liyunziral lazeena zalamoo wa bushraa lilmuhsineen"
  },
  {
    "id": 13,
    "text": "Innal lazeena qaaloo Rabbunal laahu summas taqaamoo falaa khawfun 'alaihim wa laahum yahzanoon"
  },
  {
    "id": 14,
    "text": "Ulaaa'ika Ashabul Jannati khaalideena feehaa jazaaa'am bimaa kaano ya'maloon"
  },
  {
    "id": 15,
    "text": "Wa wassainal insaana biwaalidaihi ihsaana; hamalat hu ummuhoo kurhanw-wa wada'at hu kurhanw wa hamluhoo wa fisaaluhoo salaasoona shahraa; hattaaa izaa balagha ashuddahoo wa balagha arba'eena sanatan qaala Rabbi awzi' neee an ashkura ni'matakal lateee an'amta 'alaiya wa 'alaa waalidaiya wa an a'mala saalihan tardaahu wa aslih lee fee zurriyyatee; innee tubtu ilaika wa innee minal muslimeen"
  },
  {
    "id": 16,
    "text": "Ulaaa'ikal lazeena nata qabbalu 'anhum ahsana maa 'amiloo wa natajaawazu 'an saiyiaatihim feee Ashaabil jannati Wa'das sidqil lazee kaanoo yoo'adoon"
  },
  {
    "id": 17,
    "text": "Wallazee qaala liwaali daihi uffil lakumaaa ata'idanineee an ukhraja wa qad khalatil quroonu min qablee wa humaa yastagheesaanil laaha wailaka aamin inna wa'dal laahi haqq, fa yaqoolu maa haazaaa illaaa asaateerul awwaleen"
  },
  {
    "id": 18,
    "text": "Ulaaa'ikal lazeena haqqa 'alaihimul qawlu feee umamin qad khalat min qablihim minal jinni wal insi innahum kaanoo khaasireen"
  },
  {
    "id": 19,
    "text": "Wa likullin darajaatum mimmaa 'amiloo wa liyuwaf fiyahum a'maalahum wa hum laa yuzlamoon"
  },
  {
    "id": 20,
    "text": "Wa Yawma yu'radul lazeena kafaroo 'alan Naari azhabtum taiyibaatikum fee hayaatikumud dunyaa wastam ta'tum bihaa fal Yawma tujzawna 'azaabal hooni bimaa kuntum tastakbiroona fil ardi bighairil haqqi wa bimaa kuntum tafsuqoon"
  },
  {
    "id": 21,
    "text": "Wazkur akhaa’Aadin iz anzara qawmahoo bil Ahqaafi wa qad khalatin nuzuru mim baini yadaihi wa min khalfiheee allaa ta'budooo illal laaha inneee akhaafu 'alaikum 'azaaba Yawmin 'azeem"
  },
  {
    "id": 22,
    "text": "Qaaloo aji'tanaa li taa fikanaa 'an aalihatinaa fa'tinaa bimaa ta'idunaaa in kunta minas saadiqeen"
  },
  {
    "id": 23,
    "text": "Qaala innamal 'ilmu indal laahi wa uballighukum maaa ursiltu bihee wa laakinneee araakum qawman tajhaloon"
  },
  {
    "id": 24,
    "text": "Falammaa ra awhu 'aaridam mustaqbila awdiyatihim qaaloo haazaa 'aaridum mumtirunaa; bal huwa masta'jaltum bihee reehun feehaa 'azaabun aleem"
  },
  {
    "id": 25,
    "text": "Tudammiru kulla shai'im bi-amri Rabbihaa fa asbahoo laa yuraaa illaa masaakinuhum; kazaalika najzil qawmal mujrimeen"
  },
  {
    "id": 26,
    "text": "Wa laqad makkannaahum feemaaa im makkannaakum feehi waj'alnaa lahum sam'anw wa absaaranw wa af'idatan famaaa aghnaa 'anhum sam'uhum wa laaa absaaruhum wa laaa af'idatuhum min shai'in iz kaanoo yajhadoona bi Aayaatil laahi wa haaqa bihim maa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 27,
    "text": "Wa laqad ahlaknaa ma hawlakum minal quraa wa sarrafnal Aayaati la'allahum yarji'oon"
  },
  {
    "id": 28,
    "text": "Falaw laa nasarahumul lazeenat takhazoo min doonil laahi qurbaanan aalihatam bal dalloo 'anhum' wa zaalika ifkuhum wa maa kaanoo yaftaroon"
  },
  {
    "id": 29,
    "text": "Wa iz sarafinaaa ilaika nafaram minal jinni yastami'oonal Quraana falammaa hadaroohu qaalooo ansitoo falammaa qudiya wallaw ilaa qawmihim munzireen"
  },
  {
    "id": 30,
    "text": "Qaaloo yaa qawmanaaa innaa sami'naa Kitaaban unzila mim ba'di Moosa musaddiqal limaa baina yadaihi yahdeee ilal haqqi wa ilaa Tareeqim Mustaqeem"
  },
  {
    "id": 31,
    "text": "Yaa qawmanaaa ajeeboo daa'iyal laahi wa aaminoo bihee yaghfir lakum min zunoobikum wa yujirkum min 'azaabin aleem"
  },
  {
    "id": 32,
    "text": "Wa mal laa yujib daa'iyal laahi falaisa bimu'jizin fil ardi wa laisa lahoo min dooniheee awliyaaa'; ulaaa ika fee dalaalim mubeen"
  },
  {
    "id": 33,
    "text": "Awalam yaraw annal laahal lazee khalaqas samaawaati wal arda wa lam ya'ya bikhal qihinna biqaadirin 'alaaa aiyuhyiyal mawtaa; balaaa innahoo 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 34,
    "text": "Wa Yawma yu'radul lazeena kafaroo 'alan naari alaisa haaza bil haqq; qaaloo balaa wa Rabbinaa; qaala fazooqul 'azaaba bimaa kuntum takfuroon"
  },
  {
    "id": 35,
    "text": "Fasbir kamaa sabara ulul 'azmi minar Rusuli wa laa tasta'jil lahum; ka annahum Yawma yarawna maa yoo'adoona lam yalbasooo illaa saa'atam min nahaar; balaagh; fahal yuhlaku illal qawmul faasiqoon"
  }
];

export default en;
