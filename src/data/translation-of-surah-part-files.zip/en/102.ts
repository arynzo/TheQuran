import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Al haaku mut takathur"
  },
  {
    "id": 2,
    "text": "Hatta zurtumul-maqaabir"
  },
  {
    "id": 3,
    "text": "Kalla sawfa ta'lamoon"
  },
  {
    "id": 4,
    "text": "Thumma kalla sawfa ta'lamoon"
  },
  {
    "id": 5,
    "text": "Kalla law ta'lamoona 'ilmal yaqeen"
  },
  {
    "id": 6,
    "text": "Latara-wun nal jaheem"
  },
  {
    "id": 7,
    "text": "Thumma latara wunnaha 'ainal yaqeen"
  },
  {
    "id": 8,
    "text": "Thumma latus alunna yauma-izin 'anin na'eem"
  }
];

export default en;
