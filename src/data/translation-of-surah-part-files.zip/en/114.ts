import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Qul a'oozu birabbin naas"
  },
  {
    "id": 2,
    "text": "Malikin naas"
  },
  {
    "id": 3,
    "text": "Ilaahin naas"
  },
  {
    "id": 4,
    "text": "Min sharril waswaasil khannaas"
  },
  {
    "id": 5,
    "text": "Allazee yuwaswisu fee sudoorin naas"
  },
  {
    "id": 6,
    "text": "Minal jinnati wannaas"
  }
];

export default en;
