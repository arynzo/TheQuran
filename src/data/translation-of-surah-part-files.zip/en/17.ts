import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Subhaanal lazeee asraa bi'abdihee lailam minal Masjidil Haraami ilal Masjidil Aqsal- lazee baaraknaa haw lahoo linuriyahoo min aayaatinaa;innahoo Huwas Samee'ul- Baseer"
  },
  {
    "id": 2,
    "text": "Wa aatainaa Moosal-Kitaaba wa ja'alnaahu hudal-liBaneee Israaa'eel; allaa tat-takhizoo min doonee wakeelaa."
  },
  {
    "id": 3,
    "text": "Zurriyyata man hamalnaa ma'a Noohin innahoo kaana 'abdan shakooraa"
  },
  {
    "id": 4,
    "text": "Wa qadainaaa ilaa Baneee Israaa'eela fil Kitaabi latufsidunna fil ardi marratain; wa lata'lunna'uluwwan kabeeraa"
  },
  {
    "id": 5,
    "text": "Fa-izaa jaaa'a wa'duoolaahumaa ba'asnaaa 'alykum 'ibaadal-lanaaa ulee baasin shadeedin fajaasoo khilaalad diyaar; wa kaana wa'dam maf'oolaa"
  },
  {
    "id": 6,
    "text": "Summa radadnaa lakumul karrata 'alaihim wa amdad-naakum-bi amwaalinuw wa baneen; wa ja'alnaakum aksara nafeeraa"
  },
  {
    "id": 7,
    "text": "In ahsantum ahsantum li anfusikum wa in asaatum falahaa; fa izaa jaaa'a wa'dul aakhirati liyasooo'oo wujoo hakum wa liyadkhulul masjida kamaa dakhaloohu awwala marratinw wa liyutabbiroo maa a'law tatbeera"
  },
  {
    "id": 8,
    "text": "'Asaa rabbukum anyyarhamakum; wa in 'uttum 'udnaa; wa ja'alnaa jahannama lilkaafireena haseera"
  },
  {
    "id": 9,
    "text": "Inna haazal Quraana yahdee lillatee hiya aqwamu wa yubashshirul mu'mineenal lazeena ya'maloonas saalihaati anna lahum ajran kabeeraa"
  },
  {
    "id": 10,
    "text": "Wa annal lazeena laa yu'minoona bil aakhirati a'tadnaa lahum 'azaaban aleemaa"
  },
  {
    "id": 11,
    "text": "Wa yad'ul insaanu bishsharri du'aaa 'ahoo bilkhayr; wa kaanal insaanu 'ajoola"
  },
  {
    "id": 12,
    "text": "Wa ja'alnal laila wannahaara Aayatayni famahawnaaa Aayatal laili wa ja'alnaaa Aayatan nahaari mubsiratal litabtaghoo fadlam mir Rabbikum wa lita'lamoo 'adadas sineena walhisaab; wa kulla shai'in fassalnaahu tafseelaa"
  },
  {
    "id": 13,
    "text": "Wa kulla insaanin alzamnaahu taaa'irahoo fee 'unuqihee wa nukhriji lahoo Yawmal Qiyaamati kitaabany yalqaahu manshooraa"
  },
  {
    "id": 14,
    "text": "Iqra kitaabaka kafaa bi nafsikal Yawma 'alaika haseebaa"
  },
  {
    "id": 15,
    "text": "Manihtadaa fa innamaa yahtadee linafsihee wa man dalla fa innamaa yadillu 'alaihaa; wa laa taziru waaziratunw wizra ukhraa; wa maa kunnaa mu'azzibeena hatta nab'asa Rasoola"
  },
  {
    "id": 16,
    "text": "Wa izaaa aradnaaa an nuhlika qaryatan amarnaa mutrafeehaa fafasaqoo feehaa fahaqqa 'alaihal qawlu fadammarnaahaa tadmeeraa"
  },
  {
    "id": 17,
    "text": "Wa kam ahlaknaa minal qurooni min ba'di Nooh; wa kafaa bi Rabbika bizunoobi 'ibaadihee Khabeeram Baseeraa"
  },
  {
    "id": 18,
    "text": "Man kaana yureedul 'aajilata 'ajjalnaa lahoo feehaa maa nashaaa'u liman nureedu summa ja'alnaa lahoo Jahannama yaslaahaa mazmoomammad hooraa"
  },
  {
    "id": 19,
    "text": "Wa man araadal Aakhirata wa sa'aa lahaa sa'yahaa wa huwa mu'minun fa ulaaa'ika kaana sa'yuhum mashkooraa"
  },
  {
    "id": 20,
    "text": "Kullan numiddu haaa 'ulaaa'i wa haaa'ulaaa'i min 'ataaa'i rabbik; wa maa kaana 'ataaa'u rabbika mahzooraa"
  },
  {
    "id": 21,
    "text": "Unzur kaifa faddalnaa ba'dahum 'alaa ba'd; wa lal Aakhiratu akbaru darajaatinw wa akbaru tafdeelaa"
  },
  {
    "id": 22,
    "text": "Laa taj'al ma'al laahi ilaahan aakhara fataq'uda mazoomam makhzoolaa"
  },
  {
    "id": 23,
    "text": "Wa qadaa Rabbuka allaa ta'budooo illaaa iyyaahu wa bilwaalidaini ihsaanaa; immaa yablughanna 'indakal kibara ahaduhumaaa aw kilaahumaa falaa taqul lahumaaa uffinw wa laa tanharhumaa wa qullahumaa qawlan kareemaa"
  },
  {
    "id": 24,
    "text": "Wakhfid lahumaa janaahaz zulli minar rahmati wa qur Rabbir hamhumaa kamaa rabbayaanee sagheera"
  },
  {
    "id": 25,
    "text": "Rabbukum a'lamu bimaa fee nufoosikum; in takoonoo saaliheena fa innahoo kaana lil awwaabeena Ghafoooraa"
  },
  {
    "id": 26,
    "text": "Wa aati zal qurbaa haqqahoo walmiskeena wabnas sabeeli wa laa tubazzir tabzeeraa"
  },
  {
    "id": 27,
    "text": "Innal mubazzireena kaanoo ikhwaanash shayaateeni wa kaanash shaytaanu li Rabbihee kafooraa"
  },
  {
    "id": 28,
    "text": "Wa immaa tu'ridanna 'anhum ubtighaaa'a rahmatim mir rabbika tarjoohaa faqul lahum qawlam maisooraa"
  },
  {
    "id": 29,
    "text": "Wa laa taj'al yadaka maghloolatan ilaa 'unuqika wa laa tabsut haa kullal basti fataq'uda maloomam mahsooraa"
  },
  {
    "id": 30,
    "text": "Inna Rabbaka yabsuturrizqa limai yashaaa'u wa yaqdir; innahoo kaana bi'ibaadihee Khabeeran Baseera"
  },
  {
    "id": 31,
    "text": "Wa laa taqtulooo awlaadakum khashyata imlaaqin nahnu narzuquhum wa iyyaakum; inna qatlahum kaana khit 'an kabeeraa"
  },
  {
    "id": 32,
    "text": "Wa laa taqrabuz zinaaa innahoo kaana faahishatanw wa saaa'a sabeelaa"
  },
  {
    "id": 33,
    "text": "Wa laa taqtulun nafsal latee harramal laahu illaa bilhaqq; wa man qutila mazlooman faqad ja'alnaa liwaliyyihee sultaanan falaa yusrif fil qatli innahoo kaana mansooraa"
  },
  {
    "id": 34,
    "text": "Wa laa taqraboo maalal yateemi illaa billatee hiya ahsanu hattaa yablugha ashuddah; wa awfoo bil'ahd, innal 'ahda kaana mas'oolaa"
  },
  {
    "id": 35,
    "text": "Wa awful kaila izaa kiltum wa zinoo bilqistaasil mustaqeem; zaalika khairunw wa ahsanu ta'weelaa"
  },
  {
    "id": 36,
    "text": "Wa laa taqfu maa laisa laka bihee 'ilm; innas sam'a walbasara walfu'aada kullu ulaaa'ika kaana 'anhu mas'oolaa"
  },
  {
    "id": 37,
    "text": "Wa laa tamshi fil ardi marahan innaka lan takhriqal arda wa lan tablughal jibaala toola"
  },
  {
    "id": 38,
    "text": "Kullu zaalika kaana sayyi'uhoo inda Rabbika makroohaa"
  },
  {
    "id": 39,
    "text": "Zaalika mimmaaa awhaaa ilaika Rabbuka minal hikmah; wa laa taj'al ma'allaahi ilaahan aakhara fatulqaa fee Jahannama maloomam mad hooraa"
  },
  {
    "id": 40,
    "text": "Afa asfaakum rabbukum bilbaneena wattakhaza minal malaaa'ikati inaasaa; innakum lataqooloona qawlan 'azeema"
  },
  {
    "id": 41,
    "text": "Wa laqad sarrafnaa fee haazal Quraani liyazzakkaroo wa maa yazeeduhum illaa nufooraa"
  },
  {
    "id": 42,
    "text": "Qul law kaana ma'ahooo aalihatun kamaa yaqooloona izal labtaghaw ilaa zil 'Arshi Sabeela"
  },
  {
    "id": 43,
    "text": "Subhaanahoo wa Ta'aalaa 'ammaa yaqooloona 'uluwwan kabeeraa"
  },
  {
    "id": 44,
    "text": "Tusabbihu lahus samaawaatus sab'u wal ardu wa man feehinn; wa im min shai'in illaa yusabbihu bihamdihee wa laakil laa tafqahoona tasbeehahum; innahoo kaana Haleeman Ghafooraa"
  },
  {
    "id": 45,
    "text": "Wa izaa qara' tal Quraana ja'alnaa bainaka wa bainal lazeena laa yu'minoona bil aakhirati hijaabam mastooraa"
  },
  {
    "id": 46,
    "text": "Wa ja'alnaa 'alaa quloo bihim akinnatan any yafqahoohu wa feee aazaanihim waqraa; wa izaa zakarta Rabbaka fil Quraani wahdahoo wallaw 'alaaa adbaarihim nufooraa"
  },
  {
    "id": 47,
    "text": "Nahnu a'lamu bimaa yastami'oona biheee iz yastami'oona ilaika wa iz hum najwaaa iz yaqooluz zaalimoona in tattabi'oona illaa rajulam mas hooraa"
  },
  {
    "id": 48,
    "text": "Unzur kaifa daraboo lakal amsaala fadalloo falaa yastatee'oona sabeelaa"
  },
  {
    "id": 49,
    "text": "Wa qaalooo 'a izaa kunnaa 'izaamanw wa rufaatan 'a innaa lamab'oosoona khalqan jadeedaa"
  },
  {
    "id": 50,
    "text": "Qul koonoo hijaaratan aw hadeedaa"
  },
  {
    "id": 51,
    "text": "Aw khalqam mimmaa yakburu fee sudoorikum; fasa yaqooloona mai yu'eedunaa qulil lazee fatarakum awwala marrah; fasa yunghidoona ilaika ru'oosahum wa yaqooloona mataahoo; qul 'asaaa any yakoona qareeba"
  },
  {
    "id": 52,
    "text": "Yawma yad'ookum fatastajeeboona bihamdihee wa tazunnoona il labistum illaa qaleela"
  },
  {
    "id": 53,
    "text": "Wa qul li'ibaadee yaqoolul latee hiya ahsan; innash shaitaana yanzaghu bainahum; innash shaitaana kaana lil insaani 'aduwwam mubeenaa"
  },
  {
    "id": 54,
    "text": "Rabbukum a'lamu bikum iny yasha' yarhamkum aw iny yasha' yu'azzibkum; wa maaa arsalnaaka 'alaihim wakeelaa"
  },
  {
    "id": 55,
    "text": "Wa Rabbuka a'lamu biman fis samaawaati wal ard; wa laqad faddalnaa ba'dan Nabiyyeena 'alaa ba'dinw wa aatainaaa Daawooda Zabooraa"
  },
  {
    "id": 56,
    "text": "Qulid 'ul lazeena za'amtum min doonihee falaa yamlikoona kashfad durri'ankum wa laa tahweelaa"
  },
  {
    "id": 57,
    "text": "Ulaaa'ikal lazeena yad'oona yabtaghoona ilaa Rabbihimul waseelata ayyuhum aqrabu wa yarjoona rahmatahoo wa yakhaafoona 'azaabah; inna 'azaaba rabbika kaana mahzooraa"
  },
  {
    "id": 58,
    "text": "Wa in min qaryatin illaa Nahnu muhlikoohaa qabla Yawmil Qiyaamati aw mu'az ziboohaa 'azaaban shadeedaa; kaana zaalika fil Kitaabi mastooraa"
  },
  {
    "id": 59,
    "text": "Wa maa mana'anaaa an nursila bil aayaati illaaa an kazzaba bihal awwaloon; wa aatainaa Samoodan naaqata mubsiratan fazalamoo bihaa; wa maa nursilu bil aayaati illaa takhweefaa"
  },
  {
    "id": 60,
    "text": "Wa iz qulnaa laka inna rabbaka ahaata binnaas; wa maa ja'alnar ru'yal lateee arainaaka illaa fitnatal linnaasi washshajaratal mal'oonata fil quraan; wa nukhaw wifuhum famaa yazeeduhum illa tughyaanan kabeeraa"
  },
  {
    "id": 61,
    "text": "Wa iz qulnaa lil malaaa'ikatis judoo li Aadama fasajadooo illaaa Ibleesa qaala 'a-asjudu liman khalaqta teena"
  },
  {
    "id": 62,
    "text": "Qaala ara'aytaka haazal lazee karramta 'alaiya la'in akhartani ilaa Yawmil Qiyaamati la ahtanikanna zurriyyatahooo illaa qaleelaa"
  },
  {
    "id": 63,
    "text": "Qaalaz hab faman tabi'aka minhum fa inna Jahannama jazaaa'ukum jazaaa'am mawfooraa"
  },
  {
    "id": 64,
    "text": "Wastafziz manis tata'ta minhum bisawtika wa ajlib 'alaihim bikhailika wa rajilika wa shaarik hum fil amwaali wal awlaadi wa 'idhum; wa maa ya'iduhumush Shaitaanu illaa ghurooraa"
  },
  {
    "id": 65,
    "text": "Inna 'ibaadee laisa laka 'alaihim sultaan; wa kafaa bi Rabbika Wakeelaa"
  },
  {
    "id": 66,
    "text": "Rabbukumul lazee yuzjee lakumul fulka fil bahri litabtaghoo min fadlih; innahoo kaana bikum Raheemaa"
  },
  {
    "id": 67,
    "text": "Wa izaa massakumuddurru fil bahri dalla man tad'oona illaaa iyyaahu falammaa najjaakum ilal barri a'radtum; wa kaanal insaanu kafooraa"
  },
  {
    "id": 68,
    "text": "Afa amintum any yakhsifa bikum jaanibal barri aw yursila 'alaikum haasiban summa laa tajidoo lakum wakeelaa"
  },
  {
    "id": 69,
    "text": "Am amintum any yu'eedakum feehi taaratan ukhraa fa yursila 'alaikum qaasifam minar reehi fa yugh riqakum bimaa kafartum summa laa tajidoo lakum 'alainaa bihee tabee'aa"
  },
  {
    "id": 70,
    "text": "Wa laqad karramnaa Baneee aadama wa hamalnaahum fil barri walbahri wa razaqnaahum minat taiyibaati wa faddalnaahum 'alaa kaseerim mimman khalaqnaa tafdeelaa"
  },
  {
    "id": 71,
    "text": "Yawma nad'oo kulla unaasim bi imaamihim faman ootiya kitaabahoo bi yameenihee fa ulaaa'ika yaqra'oona kitaabahum wa laa yuzlamoona fateelaa"
  },
  {
    "id": 72,
    "text": "Wa man kaana fee haaziheee a'maa fahuwa fil aakhirati a'maa wa adallu sabeelaa"
  },
  {
    "id": 73,
    "text": "Wa in kaadoo la yaftinoonaka 'anil lazeee awhainaaa ilaika litaftariya 'alainaaa ghairahoo wa izallat takhazooka khaleelaa"
  },
  {
    "id": 74,
    "text": "Wa law laaa an sabbatnaaka laqad kitta tarkanu ilaihim shai'an qaleela"
  },
  {
    "id": 75,
    "text": "Izal la azaqnaaka di'fal hayaati wa di'fal mamaati summa laa tajidu laka 'alainaa naseeraa"
  },
  {
    "id": 76,
    "text": "Wa in kaadoo la yastafizzoonaka minal ardi liyukhri jooka minhaa wa izal laa yalbasoona khilaafaka illaa qaleelaa"
  },
  {
    "id": 77,
    "text": "Sunnata man qad arsalnaa qablakamir Rusulinaa wa laa tajidu lisunnatinaa tahweelaa"
  },
  {
    "id": 78,
    "text": "Aqimis Salaata liduloo kish shamsi ilaa ghasaqil laili wa quraanal Fajri inna quraa nal Fajri kaana mashhoodaa"
  },
  {
    "id": 79,
    "text": "Wa minal laili fatahajjad bihee naafilatal laka 'asaaa any yab'asaka Rabbuka Maqaamam Mahmoodaa"
  },
  {
    "id": 80,
    "text": "Wa qur Rabbi adkhilnee mudkhala sidqinw wa akhrijnee mukhraja sidqinw waj'al lee milladunka sultaanan naseeraa"
  },
  {
    "id": 81,
    "text": "Wa qul jaaa'al haqqu wa zahaqal baatil; innal baatila kaana zahooqaa"
  },
  {
    "id": 82,
    "text": "Wa nunazzilu minal quraani maa huwa shifaaa'unw wa rahmatullil mu'mineena wa laa yazeeduz zaalimeena illaa khasaaraa"
  },
  {
    "id": 83,
    "text": "Wa izaaa an'amnaa 'alal insaani a'rada wa na-aa bijaani bihee wa izaa massahush sharru kaana ya'oosaa"
  },
  {
    "id": 84,
    "text": "Qul kulluny ya'malu 'alaa shaakilatihee fa rabbukum a'lamu biman huwa ahdaa sabeelaa"
  },
  {
    "id": 85,
    "text": "Wa yas'aloonaka 'anirrooh; qulir roohu min amri rabbee wa maaa ooteetum minal 'ilmi illaa qaleelaa"
  },
  {
    "id": 86,
    "text": "Wa la'in shi'naa lanaz habanna billazeee awhainaaa ilaika summa laa tajidu laka bihee 'alainaa wakeelaa"
  },
  {
    "id": 87,
    "text": "Illaa rahmatam mir Rabbik; inna fadlahoo kaana 'alaika kabeeraa"
  },
  {
    "id": 88,
    "text": "Qul la'inij tama'atil insu waljinnu 'alaaa any ya'too bimisli haazal quraani laa ya'toona bimislihee wa law kaana ba'duhum liba 'din zaheeraa"
  },
  {
    "id": 89,
    "text": "Wa laqad sarrafnaa linnaasi fee haazal quraani min kulli masalin fa abaaa aksarun naasi illaa kufooraa"
  },
  {
    "id": 90,
    "text": "Wa qaaloo lan nu'mina laka hattaa tafjura lanaa minal ardi yamboo'aa"
  },
  {
    "id": 91,
    "text": "Aw takoona laka jannatum min nakheelinw wa 'inabin fatufajjiral anhaara khilaalahaa tafjeeraa"
  },
  {
    "id": 92,
    "text": "Aw tusqitas samaaa'a kamaa za'amta 'alainaa kisafan aw ta'tiya billaahi wal malaaa'ikati qabeelaa"
  },
  {
    "id": 93,
    "text": "Aw yakoona laka baitum min zukhrufin aw tarqaa fis samaaa'i wa lan nu'mina liruqiyyika hatta tunazzila 'alainaa kitaaban naqra'uh; qul Subhaana Rabbee hal kuntu illaa basharar Rasoolaa"
  },
  {
    "id": 94,
    "text": "Wa maa mana'an naasa any yu'minooo iz jaaa'ahumul hudaaa illaaa an qaalooo aba'asal laahu basharar Rasoolaa"
  },
  {
    "id": 95,
    "text": "Qul law kaana fil ardi malaaa 'ikatuny yamshoona mutma'in neena lanazzalnaa 'alaihim minas samaaa'i malakar Rasoolaa"
  },
  {
    "id": 96,
    "text": "Qul kafaa billaahi shaheedam bainee wa bainakum; innahoo kaana bi'ibaadihee Khabeeram Baseeraa"
  },
  {
    "id": 97,
    "text": "Wa mai yahdil laahu fahuwal muhtad; wa mai yudlil falan tajida lahum awliyaaa'a min doonih; wa nahshuruhum Yawmal Qiyaamati 'alaa wujoohihim umyanw wa bukmanw wa summaa; ma'waahum Jahannamu kullamaa khabat zidnaahum sa'eeraa"
  },
  {
    "id": 98,
    "text": "Zaalika jazaa'uhum bi annahum kafaroo bi aayaatinaa wa qaalooo 'a izaa kunnaa 'izaamanw wa rufaatan 'a innaa la mab'oosoona khalqan jadeedaa"
  },
  {
    "id": 99,
    "text": "Awalam yaraw annal laahal lazee khalaqas samaawaati wal arda qaadirun 'alaaa any yakhluqa mislahum wa ja'ala lahum ajalal laa raiba fee; fa abaz zaalimoona illaa kufooraa"
  },
  {
    "id": 100,
    "text": "Qul law antum tamlikoona khazaaa'ina rahmati Rabbeee izal la amsaktum khash yatal infaaq; wa kaanal insaanu qatooraa"
  },
  {
    "id": 101,
    "text": "Wa laqad aatainaa Moosaa tis'a Aayaatim baiyinaatin fas'al Baneee Israaa'eela iz jaaa'ahum faqaala lahoo Fir'awnu inee la azunnuka yaa Moosaa mas hooraa"
  },
  {
    "id": 102,
    "text": "Qaala laqad 'alimta maaa anzala haaa'ulaaa'i illaa Rabbus samaawaati wal ardi basaaa'ira wa innee la azun nuka yaa Fir'awnu masbooraa"
  },
  {
    "id": 103,
    "text": "Fa araada any yastafizzahum minal ardi fa aghraqnaahu wa mam ma'ahoo jamee'aa"
  },
  {
    "id": 104,
    "text": "Wa qulnaa min ba'dihee li Baneee Israaa'eelas kunul arda fa izaa jaaa'a wa'dul aakhirati ji'naa bikum lafeefaa"
  },
  {
    "id": 105,
    "text": "Wa bilhaqqi anzalnaahu wa bilhaqqi nazal; wa maaa arsalnaaka illaa mubash shiranw wa nazeeraa"
  },
  {
    "id": 106,
    "text": "Wa quraanan faraqnaahu litaqra ahoo 'alan naasi 'alaa muksinw wa nazzalnaahu tanzeelaa"
  },
  {
    "id": 107,
    "text": "Qul aaminoo biheee aw laa tu'minoo; innal lazeena ootul 'ilma min qabliheee izaa yutlaa 'alaihim yakhirroona lil azqaani sujjadaa"
  },
  {
    "id": 108,
    "text": "Wa yaqooloona Subhaana Rabbinaaa in kaana wa'du Rabbinaa lamaf'oolaa"
  },
  {
    "id": 109,
    "text": "Wa yakhirroona lil azqaani yabkoona wa yazeeduhum khushoo'aa"
  },
  {
    "id": 110,
    "text": "Qulid'ul laaha awid'ur Rahmaana ayyam maa tad'oo falahul asmaaa'ul Husnaa; wa laa tajhar bi Salaatika wa laa tukhaafit bihaa wabtaghi baina zaalika sabeela"
  },
  {
    "id": 111,
    "text": "Wa qulil hamdu lillaahil lazee lam yattakhiz waladanw wa lam yakul lahoo shareekun fil mulki wa lam yakul lahoo waliyyum minaz zulli wa kabbirhu takbeeraa"
  }
];

export default en;
