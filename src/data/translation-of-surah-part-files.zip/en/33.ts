import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yaa aiyuhan Nabiyyut taqil laaha wa laa tuti'il kaafireena wal munaafiqeen; innal laaha kaana 'aleeman Hakeemaa"
  },
  {
    "id": 2,
    "text": "Wattabi' maa yoohaaa ilaika mir Rabbik; innal laaha kaana bimaa ta'maloona Khabeera"
  },
  {
    "id": 3,
    "text": "Wa tawakkal 'alal laah; wa kafaa billaahi Wakeelaa"
  },
  {
    "id": 4,
    "text": "Maa ja'alal laahu lirajulim min qalbaini fee jawfih; wa maa ja'ala azwaajakumul laaa'ee tuzaahiroona minhunna ummahaatikum; wa maa ja'ala ad'iyaaa'akum abnaaa'akum; zaalikum qawlukum bi afwaa hikum wallaahu yaqoolul haqqa wa Huwa yahdis sabeel"
  },
  {
    "id": 5,
    "text": "Ud'oohum li aabaaa'ihim huwa aqsatu 'indal laah; fa illam ta'lamooo aabaaa'ahum fa ikhwaanukum fid deeni wa mawaaleekum; wa laisa 'alaikum junaahun feemaaa akhtaatum bihee wa laakim maa ta'ammadat quloobukum; wa kaanal laahu Ghafoorar Raheemaa"
  },
  {
    "id": 6,
    "text": "An-Nabiyyu awlaa bil mu'mineena min anfusihim wa azwaajuhoo ummahatuhum wa ulul arhaami ba'duhum awlaa biba'din fee Kitaabil laahi minal mu'meneena wal Muhaajireena illaaa an taf'alooo ilaaa awliyaaa'ikum ma'roofaa; kaana zaalika fil kitaabi mastooraa"
  },
  {
    "id": 7,
    "text": "Wa iz akhaznaa minan Nabiyyeena meesaaqahum wa minka wa min Noohinw wa Ibraaheema wa Moosaa wa Eesab-ni-Maryama wa akhaznaa minhum meesaaqan ghaleezaa"
  },
  {
    "id": 8,
    "text": "Liyas'alas saadiqeena 'an sidqihim; wa a'adda lilkaa fireena 'azaaban aleemaa"
  },
  {
    "id": 9,
    "text": "Yaaa aiyuhal lazeena aamanuz kuroo ni'matal laahi 'alaikum iz jaaa'atkum junoodun fa arsalnaa 'alaihim reehanw wa junoodal lam tarawhaa; wa kaanal laahu bimaa ta'maloona Baseera"
  },
  {
    "id": 10,
    "text": "Iz jaaa'ookum min fawqikum wa min asfala minkum wa iz zaaghatil absaaru wa balaghatil quloobul hanaajira wa tazunnoona billaahiz zunoonaa"
  },
  {
    "id": 11,
    "text": "Hunaalikab tuliyal mu'minoona wa zulziloo zilzaalan shadeedaa"
  },
  {
    "id": 12,
    "text": "Wa iz yaqoolul munaafiqoona wallazeena fee quloobihim maradum maa wa'adanal laahu wa Rasooluhooo illaa ghurooraa"
  },
  {
    "id": 13,
    "text": "Wa iz qaalat taaa'ifatum minhum yaaa ahla Yasriba laa muqaamaa lakum farji'oo; wa yastaazinu fareequm minhumun Nabiyya yaqooloona inna buyootanaa 'awrah; wa maa hiya bi'awratin iny yureedoona illaa firaaraa"
  },
  {
    "id": 14,
    "text": "Wa law dukhilat 'alaihim min aqtaarihaa summa su'ilul fitnata la aatawhaa wa maa talabbasoo bihaaa illaa yaseeraa"
  },
  {
    "id": 15,
    "text": "Wa laqad kaanoo 'aahadul laaha min qablu laa yuwal loonal adbaar; wa kaana 'ahdul laahi mas'oolaa"
  },
  {
    "id": 16,
    "text": "Qul lany yanfa'akumul firaaru in farartum minal mawti awil qatli wa izal laa tumatta'oona illaa qaleelaa"
  },
  {
    "id": 17,
    "text": "Qul man zal lazee ya'simukum minal laahi in araada bikum sooo'an aw araada bikum rahmah; wa laa yajidoona lahum min doonil laahi waliyyanw wa laa naseeraa"
  },
  {
    "id": 18,
    "text": "Qad ya'lamul laahul mu'awwiqeena minkum walqaaa'ileena li ikhwaanihim halumma ilainaa, wa laa yaatoonal baasa illaa qaleelaa"
  },
  {
    "id": 19,
    "text": "Ashihhatan 'alaikum faizaa jaaa'al khawfu ra aytahum yanzuroona ilaika tadooru a'yunuhum kallazee yughshaa 'alaihi minal mawti fa izaa zahabal khawfu salqookum bi alsinatin hidaadin ashihhatan 'alal khayr; ulaaa'ika lam yu'minoo fa ahbatal laahu a'maalahum; wa kaana zaalika 'alal laahi yaseeraa"
  },
  {
    "id": 20,
    "text": "Yahsaboonal Ahzaaba lam yazhaboo wa iny yaatil Ahzaabu yawaddoo law annahum baadoona fil A'raabi yasaloona 'an ambaaa'ikum wa law kaanoo feekum maa qaatalooo illaa qaleela"
  },
  {
    "id": 21,
    "text": "Laqad kaana lakum fee Rasoolil laahi uswatun hasanatul liman kaana yarjul laaha wal yawmal Aakhira wa zakaral laaha kaseeraa"
  },
  {
    "id": 22,
    "text": "Wa lammaa ra al mu'minoonal Ahzaaba qaaloo haazaa maa wa'adanal laahu wa Rasooluh; wa sadaqal laahu wa Rasooluh; wa maa zaadahum illaaa eemaananw wa tasleemaa"
  },
  {
    "id": 23,
    "text": "Minal mu'mineena rijaalun sadaqoo maa 'aahadul laaha 'alaihi faminhum man qadaa nahbahoo wa minhum mai yantaziru wa maa baddaloo tabdeelaa"
  },
  {
    "id": 24,
    "text": "Li yajziyAllahus saadiqeena bisidqihim wa yu'azzibal munaafiqeena in shaaa'a aw yatooba 'alaihim; innal laaha kaana Ghafoorar Raheemaa"
  },
  {
    "id": 25,
    "text": "Wa raddal laahul lazeena kafaroo bighaizihim lam yanaaloo khairaa; wa kafal laahul mu'mineenal qitaal; wa kaanal laahu Qawiyyan 'Azeezaa"
  },
  {
    "id": 26,
    "text": "Wa anzalal lazeena zaaha roohum min Ahlil Kitaabi min sa yaaseehim wa qazafa fee quloobihimm mur ru'ba fareeqan taqtuloona wa taasiroona fareeqaaa"
  },
  {
    "id": 27,
    "text": "Wa awrasakum ardahum wa diyaarahum wa amwaalahum wa ardal lam tata'oohaa; wa kaanal laahu 'alaa kulli shai'in Qadeeraa"
  },
  {
    "id": 28,
    "text": "Yaaa aiyuhan Nabiyyu qul li azwaajika in kuntunna turidnal hayaatad dunyaa wa zeenatahaa fata'aalaina umatti'kunna wa usarrihkunna saraahan jameela"
  },
  {
    "id": 29,
    "text": "Wa in kuntunna turidnal laaha wa Rasoolahoo wad Daaral Aakhirata fa innal laaha a'adda lil muhsinaati min kunna ajjran 'azeemaa"
  },
  {
    "id": 30,
    "text": "Yaa nisaaa'an Nabiyyi mai yaati minkunna bifaa hishatim mubaiyinatiny yudaa'af lahal 'azaabu di'fain wa kaana zaalika 'alal laahi yaseera"
  },
  {
    "id": 31,
    "text": "Wa mai yaqnut minkunna lillaahi wa Rasoolihee wa ta'mal saalihan nu'tihaaa ajrahaa marratayni wa a'tadnaa lahaa rizqan kareema"
  },
  {
    "id": 32,
    "text": "Yaa nisaaa'an Nabiyyi lastunna ka ahadim minan nisaaa'i init taqaitunna falaa takhda'na bilqawli fa yatma'al lazee fee qalbihee maradunw wa qulna qawlam ma'roofaa"
  },
  {
    "id": 33,
    "text": "Wa qarna fee bu yoo tikunna wa laa tabarrajna tabarrujal Jaahiliyyatil oolaa wa aqimnas Salaata wa aaateenaz Zakaata wa ati'nal laaha wa Rasoolah; innamaa yureedul laahu liyuzhiba 'ankumur rijsa Ahlal Bayti wa yutahhirakum tatheeraa"
  },
  {
    "id": 34,
    "text": "Wazkurna maa yutlaa fee bu yootikunna min aayaatil laahi wal Hikmah; innal laaha kaana lateefan Khabeera"
  },
  {
    "id": 35,
    "text": "Innal muslimeena wal muslimaati wal mu'mineena wal mu'minaati walqaaniteena walqaanitaati wassaadiqeena wassaadiqaati wassaabireena wassaabiraati walkhaashi'eena walkhaashi'aati walmutasaddiqeena walmutasaddiqaati wassaaa'imeena wassaaa'imaati walhaafizeena furoojahum walhaafizaati waz zaakireenal laaha kaseeranw waz zaakiraati a'addal laahu lahum maghfiratanw wa ajran 'azeemaa"
  },
  {
    "id": 36,
    "text": "Wa maa kaana limu'mininw wa laa mu'minatin izaa qadal laahu wa Rasooluhooo amran ai yakoona lahumul khiyaratu min amrihim; wa mai ya'sil laaha wa Rasoolahoo faqad dalla dalaalam mubeenaa"
  },
  {
    "id": 37,
    "text": "Wa iz taqoolu lillazeee an'amal laahu 'alaihi wa an'amta 'alaihi amsik 'alaika zawjaka wattaqil laaha wa tukhfee fee nafsika mal laahu mubdeehi wa takhshan naasa wallaahu ahaqqu an takhshaah; falammaa qadaa Zaidum minhaa wataran zawwajnaa kahaa likay laa yakoona 'alal mu'mineena harajun feee azwaaji ad'iyaaa'ihim izaa qadaw minhunna wataraa; wa kaana amrul laahi maf'oolaa"
  },
  {
    "id": 38,
    "text": "Maa kaana 'alan nabiyyyi min harajin feemaa faradal laahu lahoo sunnatal laahi fil lazeena khalaw min qabl; wa kaana amrul laahi qadaram maqdooraa"
  },
  {
    "id": 39,
    "text": "Allazeena yuballighoona Risaalaatil laahi wa yakhshaw nahoo wa laa yakkhshawna ahadan illal laah; wa kafaa billaahi Haseebaa"
  },
  {
    "id": 40,
    "text": "Maa kaana Muhammmadun abaaa ahadim mir rijaalikum wa laakir Rasoolal laahi wa Khaataman Nabiyyeen; wa kaanal laahu bikulli shai'in 'Aleema"
  },
  {
    "id": 41,
    "text": "Yaaa aiyuhal lazeena aamanuz kurul laaha zikran kaseera"
  },
  {
    "id": 42,
    "text": "Wa sabbihoohu bukratanw wa aseela"
  },
  {
    "id": 43,
    "text": "Huwal lazee yusallee 'alaikum wa malaaa'ikatuhoo liyukhrijakum minazzulumaati ilan- noor wa kaana bilmu'mineena Raheemaa"
  },
  {
    "id": 44,
    "text": "Tahiyyatuhum Yawma yalqawnahoo salaamunw wa a'adda lahum ajran kareemaa"
  },
  {
    "id": 45,
    "text": "Yaaa aiyuhan Nabiyyu innaaa arsalnaaka shaahidanw wa mubashshiranw wa nazeeraa"
  },
  {
    "id": 46,
    "text": "Wa daa'iyan ilal laahi bi iznihee wa siraajam muneeraa"
  },
  {
    "id": 47,
    "text": "Wa bashshiril mu'mineena bi annna lahum minal laahi fadlan kabeera"
  },
  {
    "id": 48,
    "text": "Wa laa tuti'il kaafireena walmunaafiqeena wa da'azaahum wa tawakkal 'alallaah; wa kafaa billaahi Wakeelaa"
  },
  {
    "id": 49,
    "text": "Yaaa aiyuhal lazeena aamanooo izaa nakahtumul mu'minaati summa tallaqtu moohunna min qabli an tamas soohunna famaa lakum 'alaihinna min 'iddatin ta'taddoonahaa famatti'oohunna wa sarri hoohunna saraahan jameelaa"
  },
  {
    "id": 50,
    "text": "Yaaa aiyuhan Nabiyyu innaaa ahlalnaa laka azwaa jakal laatee aataiyta ujoora hunna wa maa malakat yameenuka mimmaaa afaaa'al laahu 'alaika wa banaati 'ammika wa banaati 'ammaatika wa banaati khaalika wa banaati khaalaa tikal laatee haajarna ma'aka wamra' atan mu'minatan inw wahabat nafsahaa lin Nabiyyi in araadan Nabiyyu ai yastan kihahaa khaalisatan laka min doonil mu'mineen; qad 'alimnaa maa faradnaa 'alaihim feee azwaajihim wa maa malakat aimaanuhum li kailaa yakoona 'alaika haraj; wa kaanal laahu Ghafoorar Raheema"
  },
  {
    "id": 51,
    "text": "Turjee man tashaaa'u minhunna wa tu'weee ilaika man tashaaa'u wa manibta ghaita mimman 'azalta falaa junaaha 'alaik; zaalika adnaaa an taqarra a'yunuhunna wa laa yahzanna wa yardaina bimaa aataitahunna kulluhunn; wal laahu ya'lamu maa fee quloo bikum; wa kaanal laahu 'Aleeman haleemaa"
  },
  {
    "id": 52,
    "text": "Laa yahillu lakan nisaaa'u mim ba'du wa laaa an tabaddala bihinna min azwaajinw wa law ajabaka husnuhunna illaa maa malakat yameenukk; wa kaanal laahu 'alaa kulli shai'ir Raqeeba"
  },
  {
    "id": 53,
    "text": "Yaaa aiyuhal lazeena aamanoo laa tadkhuloo bu yootan Nabiyyi illaaa ai yu'zana lakum ilaa ta'aamin ghaira naazireena inaahu wa laakin izaa du'eetum fadkhuloo fa izaa ta'imtum fantashiroo wa laa mustaaniseena lihadees; inna zaalikum kaana yu'zin Nabiyya fa yastahyee minkum wallaahu laa yastahyee minal haqq; wa izaa sa altumoohunna mataa'an fas'aloohunna minw waraaa'i hijaab; zaalikum atharu liquloobikum wa quloobihinn; wa maa kaana lakum an tu'zoo Rasoolal laahi wa laaa an tankihooo azwaajahoo mim ba'diheee abadaa; inna zaalikum kaana 'indal laahi 'azeema"
  },
  {
    "id": 54,
    "text": "In tubdoo shai'an aw tukhfoohu fa innal laaha kaana bikulli shai'in 'Aleemaa"
  },
  {
    "id": 55,
    "text": "Laa junaaha 'alaihinna feee aabaaa'ihinna wa laaa abnaaa'ihinna wa laaa ikhwaanihinnna wa laaa abnaaa'i ikhwaanihinna wa laaa abnaaa'i akhawaatihinna wa laa nisaaa'i hinna wa laa Maa malakat aimaanuhunn; wattaqeenal laah; innal laaha kaana 'alaa kulli shai'in Shaheedaa"
  },
  {
    "id": 56,
    "text": "Innal laaha wa malaaa'i katahoo yusalloona 'alan Nabiyy; yaaa aiyuhal lazeena aamanoo salloo 'alaihi wa sallimoo tasleemaa"
  },
  {
    "id": 57,
    "text": "Innal lazeena yu'zoonal laaha wa Rasoolahoo la'anahumul laahu fid dunyaa wal Aakhirati wa a'adda lahum 'azaabam muheenaa"
  },
  {
    "id": 58,
    "text": "Wallazeena yu'zoonal mu'mineena wal mu'minaati bighairi mak tasaboo faqadih tamaloo buhtaananw wa ismam mubeenaa"
  },
  {
    "id": 59,
    "text": "Yaaa aiyuhan Nabiyyu qul li azwaajika wa banaatika wa nisaaa'il mu'mineena yudneena 'alaihinna min jalaabee bihinn; zaalika adnaaa ai yu'rafna falaa yu'zain; wa kaanal laahu Ghafoorar Raheemaa"
  },
  {
    "id": 60,
    "text": "La'il lam yantahil munaafiqoona wallazeena fee quloobihim maradunw walmur jifoona fil madeenati lanughri yannaka bihim summa laa yujaawiroonaka feehaaa illaa qaleela"
  },
  {
    "id": 61,
    "text": "Mal'ooneena ainamaa suqifoo ukhizoo wa quttiloo taqteelaa"
  },
  {
    "id": 62,
    "text": "Sunnatal laahi fil lazeena khalaw min qablu wa lan tajida lisunnatil laahi tabdeelaa"
  },
  {
    "id": 63,
    "text": "Yas'alukan naasu 'anis Saa'ati qul innamaa 'ilmuhaa 'indal laah; wa maa yudreeka la'allas Saa'ata takoonu qareebaa"
  },
  {
    "id": 64,
    "text": "Innal laaha la'anal kaafireena wa a'adda lahum sa'eeraa"
  },
  {
    "id": 65,
    "text": "Khaalideena feehaaa abadaa, laa yajidoona waliyyanw wa laa naseeraa"
  },
  {
    "id": 66,
    "text": "Yawma tuqallabu wujoohuhum fin Naari yaqooloona yaa laitanaaa ata'nal laaha wa ata'nar Rasoolaa"
  },
  {
    "id": 67,
    "text": "Wa qaaloo Rabbanaaa innaaa ata'naa saadatanaa wa kubaraaa'anaa fa adalloonas sabeelaa"
  },
  {
    "id": 68,
    "text": "Rabbanaaa aatihim di'fai ni minal 'azaabi wal'anhum la nan kabeera"
  },
  {
    "id": 69,
    "text": "Yaa aiyuhal lazeena aamanoo laa takoonoo kalla zeena aazaw Moosaa fa barra ahul laahu mimma qaaloo; wa kaana 'indal laahi wajeehaa"
  },
  {
    "id": 70,
    "text": "Yaaa aiyuhal lazeena aamanut taqul laaha wa qooloo qawlan sadeedaa"
  },
  {
    "id": 71,
    "text": "Yuslih lakum a'maalakum wa yaghfir lakum zunoobakum; wa mai yuti'il laaha wa Rasoolahoo faqad faaza fawzan 'azeemaa"
  },
  {
    "id": 72,
    "text": "Innaa 'aradnal amaanata 'alas samaawaati walardi wal jibaali fa abaina ai yahmil nahaa wa ashfaqna minhaa wa hamalahal insaanu innahoo kaana zalooman jahoolaa"
  },
  {
    "id": 73,
    "text": "Liyu 'azzibal laahul munaafiqeena wal munaafiqaati walmushrikeena wal mushrikaati wa yatoobal laahu 'alal mu'mineena walmu'minaat; wa kaanal laahu Ghafoorar Raheema"
  }
];

export default en;
