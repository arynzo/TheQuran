import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Lam ya kunil lazeena kafaru min ahlil kitaabi wal mushri keena mun fak keena hattaa ta- tiya humul bayyinah"
  },
  {
    "id": 2,
    "text": "Rasoolum minal laahi yatlu suhufam mutahharah"
  },
  {
    "id": 3,
    "text": "Feeha kutubun qaiyimah"
  },
  {
    "id": 4,
    "text": "Wa maa tafarraqal lazeena ootul kitaaba il-la mim b'adi ma jaa-at humul baiyyinah"
  },
  {
    "id": 5,
    "text": "Wa maa umiroo il-la liy'abu dul laaha mukhliseena lahud-deena huna faa-a wa yuqeemus salaata wa yu-tuz zakaata; wa zaalika deenul qaiyimah"
  },
  {
    "id": 6,
    "text": "Innal lazeena kafaru min ahlil kitaabi wal mushri keena fee nari jahan nama khaali deena feeha; ulaa-ika hum shar rul ba reeyah"
  },
  {
    "id": 7,
    "text": "Innal lazeena aamanu wa 'amilus saalihaati ula-ika hum khairul bareey yah"
  },
  {
    "id": 8,
    "text": "Jazaaa'uhum 'inda Rabbihim Jannaatu 'adnin tajree min tahtihal anhaaru khaalideena feehaaa abadaa; radiyal-laah 'anhum wa radoo 'anh; zaalika liman khashiya Rabbah."
  }
];

export default en;
