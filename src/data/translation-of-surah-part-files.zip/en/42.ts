import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Haa Meeem"
  },
  {
    "id": 2,
    "text": "'Ayyyn Seeen Qaaaf"
  },
  {
    "id": 3,
    "text": "Kazaalika yooheee ilaika wa ilal lazeena min qablikal laahul 'Azeezul Hakeem"
  },
  {
    "id": 4,
    "text": "Lahoo maa fis samaa waati wa maa fil ardi wa Huwal 'Aliyul 'Azeem"
  },
  {
    "id": 5,
    "text": "Takaadus samaawaatu yatafattarna min fawqihinn; walmalaaa'ikatu yusabbihoona bihamdi Rabbihim wa yastaghfiroona liman fil ard; alaaa innal laaha huwal Ghafoorur Raheem"
  },
  {
    "id": 6,
    "text": "Wallazeenat takhazoo min dooniheee awliyaaa'al laahu hafeezun 'alaihim wa maaa anta 'alaihim biwakeel"
  },
  {
    "id": 7,
    "text": "Wa kazaalika awhainaaa llaika Qur-aanan 'Arabiyyal litunzira Ummal Quraa wa man hawlahaa wa tunzira Yawmal Jam'i laa raiba feeh; fareequn fil jannati wa fareequn fissa'eer"
  },
  {
    "id": 8,
    "text": "Wa law shaaa'al laahu laja'alahum ummatanw waahi datanw walaakiny yudkhilumany yashaaa'u fee rahmatih; waz zaalimoona maa lahum minw waliyyinw wa laa naseer"
  },
  {
    "id": 9,
    "text": "Amit takhazoo min dooniheee awliyaaa'a fallaahu Huwal Waliyyu wa Huwa yuhyil mawtaa wa Huwa 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 10,
    "text": "Wa makh-talaftum feehi min shai'in fahukmuhooo ilallaah; zaalikumul laahu Rabbee 'alaihi tawakkaltu wa ilaihi uneeb"
  },
  {
    "id": 11,
    "text": "Faatirus samaawaati wal ard; ja'ala lakum min anfusikum azwaajanw wa minal an'aami azwaajai yazra'ukum feeh; laisa kamislihee shai'unw wa Huwas Samee'ul Baseer"
  },
  {
    "id": 12,
    "text": "Lahoo maqaaleedus samaawaati wal ardi yabsutur rizqa limai yashaaa'u wa yaqdir; innahoo bikulli shai'in 'Aleem"
  },
  {
    "id": 13,
    "text": "Shara'a lakum minad deeni maa wassaa bihee Noohanw wallazeee awhainaaa ilaika wa maa wassainaa biheee Ibraaheema wa Moosa wa 'Eesaaa an aqeemud deena wa laa tatafarraqoo feeh; kabura 'alal mushrikeena maa tad'oohum ilaih; Allaahu yajtabee ilaihi mai yashaaa'u wa yahdeee ilaihi mai yuneeb"
  },
  {
    "id": 14,
    "text": "Wa maa tafarraqooo illaa mim ba'di maa jaaa'ahumul 'ilmu baghyam bainahum; wa law laa Kalimatun sabaqat mir Rabbika ilaaa ajalim musammal laqudiya bainahum; wa innal lazeena oorisul Kitaaba mim ba'dihim lafee shakkim minhu mureeb"
  },
  {
    "id": 15,
    "text": "Falizaalika fad'u wastaqim kamaaa umirta wa laa tattabi' ahwaaa'ahum wa qul aamantu bimaaa anzalal laahu min Kitaab, wa umirtu li a'dila bainakum Allaahu Rabbunaa wa Rabbukum lanaaa a'maa lunaa wa lakum a'maalukum laa hujjata bainanaa wa baina kumul laahu yajma'u bainanaa wa ilaihil maseer"
  },
  {
    "id": 16,
    "text": "Wallazeena yuhaaajjoona fil laahi mim ba'di mastujeeba lahoo hujjatuhum daahidatun 'inda Rabbihim wa 'alaihim ghadabunw wa lahum 'azaabun shadeed"
  },
  {
    "id": 17,
    "text": "Allahul lazeee anzalal Kitaaba bilhaqqi wal Meezaan; wa ma yudreeka la'allas Saa'ata qareeb"
  },
  {
    "id": 18,
    "text": "Yasta'jilu bihal lazeena laa yu'minoona bihaa wallazeena aamanoo mushfiqoona minhaa wa ya'lamoona annahal haqq; alaaa innal lazeena yumaaroona fis Saa'ati lafee dalaalin ba'eed"
  },
  {
    "id": 19,
    "text": "Allahu lateefum bi'ibaadihee yarzuqu mai yashaaa'u wa Huwal Qawiyyul 'Azeez"
  },
  {
    "id": 20,
    "text": "Man kaana yureedu harsal Aakhirati nazid lahoo fee harsihee wa man kaana yureedu harsad dunyaa nu'tihee minhaa wa maa lahoo fil Aakhirati min naseeb"
  },
  {
    "id": 21,
    "text": "Am lahum shurakaaa'u shara'oo lahum minad deeni maa lam ya'zan bihil laah; wa law laa kalimatul fasli laqudiya bainahum; wa innaz zaalimeena lahum 'azaabun aleem"
  },
  {
    "id": 22,
    "text": "Taraz zaalimeena mushfiqeena mimmaa kasaboo wa huwa waaqi'um bihim; wallazeena aamanoo wa 'amilus saalihaati fee rawdaatil jannaati lahum maa yashaaa'oona 'inda Rabbihim; zaalika huwal fadlul kabeer"
  },
  {
    "id": 23,
    "text": "Zaalikal lazee yubash shirul laahu 'ibaadahul lazeena aamanoo wa 'amilus saalihaat; qul laaa as'alukum 'alaihi ajran illal mawaddata fil qurbaa; wa mai yaqtarif hasanatan nazid lahoo feehaa husnaa; innal laaha Ghafoorun Shakoor"
  },
  {
    "id": 24,
    "text": "Am yaqooloonaf tara 'alal laahi kaziban fa-iny yasha' illaahu yakhtim 'alaa qalbik; wa yamhul laahul baatila wa yuhiqqul haqqa bi Kalimaatih; innahoo 'Aleemun bizaatis sudoor"
  },
  {
    "id": 25,
    "text": "Wa Huwal lazee yaqbalut tawbata 'an 'ibaadihee wa ya'foo 'anis saiyiaati wa ya'lamu maa taf'aloon"
  },
  {
    "id": 26,
    "text": "Wa yastajeebul lazeena aamanoo wa 'amilu saalihaati wa yazeeduhum min fadlih; wal kaafiroona lahum 'azaabun shadeed"
  },
  {
    "id": 27,
    "text": "Wa law basatal laahur rizqa li'ibaadihee labaghaw fil ardi wa laakiny yunazzilu biqadarim maa yashaaa'; innahoo bi'ibaadihee Khabeerun Baseer"
  },
  {
    "id": 28,
    "text": "Wa Huwal lazee yunazzilul ghaisa min ba'di maa qanatoo wa yanshuru rahmatah; wa Huwal Waliyyul Hameed"
  },
  {
    "id": 29,
    "text": "Wa min Aayaatihee khalqus samaawaati wal ardi wa maa bassa feehimaa min daaabbah; wa Huwa 'alaa jam'ihim izaa yashaaa'u Qadeer"
  },
  {
    "id": 30,
    "text": "Wa maaa asaabakum min museebatin fabimaa kasabat aydeekum wa ya'foo 'an kaseer"
  },
  {
    "id": 31,
    "text": "Wa maaa antum bimu'jizeena fil ardi wa maa lakum min doonil laahi minw wa liyyinw wa laa naseer"
  },
  {
    "id": 32,
    "text": "Wa min Aayaatihil ja waarifil bahri kal a'lam"
  },
  {
    "id": 33,
    "text": "Iny yashaaa yuskinir reeha fa yazlalna rawaakida 'alaa zahrihi; inna fee zaalika la Aayaatil likulli sabbaarin shakoor"
  },
  {
    "id": 34,
    "text": "Aw yoobiqhunna bimaa kasaboo wa ya'fu 'an kaseer"
  },
  {
    "id": 35,
    "text": "Wa ya'lamal lazeena yujaadiloona feee Aayaatinaa maa lahum min mahees"
  },
  {
    "id": 36,
    "text": "Famaa ooteetum min shai'in famataa'ul hayaatid dunyaa wa maa 'indal laahi khairunw wa abqaa lillazeena aamanoo wa 'alaa Rabbihim yatawakkaloon"
  },
  {
    "id": 37,
    "text": "Wallazeena yajtaniboona kabaaa'iral ismi wal fawaahisha wa izaa maa ghadiboo hum yaghfiroon"
  },
  {
    "id": 38,
    "text": "Wallazeenas tajaaboo li Rabbihim wa aqaamus Salaata wa amruhum shooraa bainahum wa mimmaa razaqnaahum yunfiqoon"
  },
  {
    "id": 39,
    "text": "Wallazeena izaa asaabahumul baghyu hum yantasiroon"
  },
  {
    "id": 40,
    "text": "Wa jazaaa'u saiyi'atin saiyi'atum misluha faman 'afaa wa aslaha fa ajruhoo 'alal laah; innahoo laa yuhibbuz zaalimeen"
  },
  {
    "id": 41,
    "text": "Wa lamanin tasara ba'da zulmihee fa ulaaa'ika maa 'alaihim min sabeel"
  },
  {
    "id": 42,
    "text": "Innamas sabeelu 'alal lazeena yazlimoonan naasa wa yabghoona fil ardi bighairil haqq; ulaaa'ika lahum 'azaabun aleem"
  },
  {
    "id": 43,
    "text": "Wa laman sabara wa ghafara inna zaalika lamin 'azmil umoor"
  },
  {
    "id": 44,
    "text": "Wa mai yudli lillaahu famaa lahoo minw waliyyin min ba'dih; wa taraz zaalimeena lammaa ra awul 'azaaba yaqooloona hal ilaa maraddin min sabeel"
  },
  {
    "id": 45,
    "text": "Wa taraahum yu'radoona 'alaihaa khaashi'eena minazzulli yanzuroona min tarfin khafiyy; wa qaalal lazeena aamanooo innal khaasireenal lazeena khasirooo anfusahum wa ahleehim Yawmal Qiyaamah; alaaa innaz zaalimeena fee 'azaabin muqeem"
  },
  {
    "id": 46,
    "text": "Wa maa kaana lahum min awliyaaa'a yansuroonahum min doonil laah; wa mai yudlilil laahu famaa lahoo min sabeel"
  },
  {
    "id": 47,
    "text": "Istajeeboo li Rabbikum min qabli any yaatiya Yawmul laa maradda lahoo min Allah; maa lakum min malja' iny yawma'izinw wa maa lakum min nakeer"
  },
  {
    "id": 48,
    "text": "Fa-in a'radoo famaaa arsalnaaka 'alaihim hafeezan in 'alaika illal balaagh; wa innaaa izaaa azaqnal insaana minnaa rahmatan fariha bihaa wa in tusibhum saiyi'atun bimaa qaddamat aydeehim fa innal insaana kafoor"
  },
  {
    "id": 49,
    "text": "Lillaahi mulkus samaawaati wal ard; yakhluqu maa yashaaa'; yahabu limai yashaaa'u inaasanw wa yahabu limai yashaaa'uz zukoor"
  },
  {
    "id": 50,
    "text": "Aw yuzawwijuhum zukraananw wa inaasanw wa yaj'alu mai yashaaa'u 'aqeemaa; innahoo 'Aleemun Qadeer"
  },
  {
    "id": 51,
    "text": "Wa maa kaana libasharin any yukallimahul laahu illaa wahyan aw minw waraaa'i hijaabin aw yursila Rasoolan fa yoohiya bi iznihee maa yashaaa'; innahoo 'Aliyyun Hakeem"
  },
  {
    "id": 52,
    "text": "Wa kazaalika awhainaaa ilaika roohan min amrinaa; maa kunta tadree mal Kitaabu wa lal eemaanu wa laakin ja'alnaahu nooran nahdee bihee man nashaaa'u min 'ibaadinaa; wa innaka latahdeee ilaaa Siraatin Mustaqeem"
  },
  {
    "id": 53,
    "text": "Siraatil laahil lazee lahoo maa fis samaawaati wa maa fil ard; alaaa ilal laahi taseerul umoor"
  }
];

export default en;
