import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alam nashrah laka sadrak"
  },
  {
    "id": 2,
    "text": "Wa wa d'ana 'anka wizrak"
  },
  {
    "id": 3,
    "text": "Allazee anqada zahrak"
  },
  {
    "id": 4,
    "text": "Wa raf 'ana laka zikrak"
  },
  {
    "id": 5,
    "text": "Fa inna ma'al usri yusra"
  },
  {
    "id": 6,
    "text": "Inna ma'al 'usri yusra"
  },
  {
    "id": 7,
    "text": "Fa iza faragh ta fansab"
  },
  {
    "id": 8,
    "text": "Wa ilaa rabbika far ghab"
  }
];

export default en;
