import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Qul a'oozu bi rabbil-falaq"
  },
  {
    "id": 2,
    "text": "Min sharri maa khalaq"
  },
  {
    "id": 3,
    "text": "Wa min sharri ghaasiqin izaa waqab"
  },
  {
    "id": 4,
    "text": "Wa min sharrin-naffaa-saati fil 'uqad"
  },
  {
    "id": 5,
    "text": "Wa min sharri haasidin izaa hasad"
  }
];

export default en;
