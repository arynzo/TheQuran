import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alhamdu lillaahi faatiris samaawaati wal ardi jaa'ilil malaaa'ikati rusulan uleee ajnihatim masnaa wa sulaasa wa rubaa'; yazeedu fil khalqi maa yashaaa'; innal laaha 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 2,
    "text": "Maa yaftahil laahu linnaaasi mir rahmatin falaa mumsika lahaa wa maa yumsik falaa mursila lahoo mimba'dihi; wa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 3,
    "text": "Yaaa ayyuhan naasuzkuroo ni'matal laahi 'alaikum; hal min khaaliqin ghairul laahi yarzuqukum minas samaaa'i wal ard; laaa ilaaha illaa Huwa fa annaa tu'fakoon"
  },
  {
    "id": 4,
    "text": "Wa iny yukazzibooka faqad kuzzibat Rusulum min qablik; wa ilal laahi turja'ul umoor"
  },
  {
    "id": 5,
    "text": "Yaaa ayyuhan naasu inna wa'dal laahi haqqun falaa taghurrannakumul hayaatud dunyaa; wa laa yaghurran nakum billaahil gharoor"
  },
  {
    "id": 6,
    "text": "Innash shaitaana lakum 'aduwwun fattakhizoohu 'aduwwaa; innamaa yad'oo hizbahoo liyakoonoo min ashaabis sa'eer"
  },
  {
    "id": 7,
    "text": "Allazeena kafaroo lahum 'azaabun shadeed; wallazeena aamanoo wa 'amilus saalihaati lahum maghfiratunw wa ajrun kabeer"
  },
  {
    "id": 8,
    "text": "Afaman zuyyina lahoo sooo'u 'amalihee fara aahu hasanaa; fa innal laaha yudillu mai yashaaa'u wa yahdee mai yashaaa'u falaa tazhab nafsuka 'alaihim hasaraat; innal laaha 'aleemun bimaa yasna'oon"
  },
  {
    "id": 9,
    "text": "Wallaahul lazeee arsalar riyaaha fatuseeru sa haaban fasuqnaahu ilaa baladim maiyitin fa ahyaynaa bihil arda ba'da mawtihaa; kazaalikan nushoor"
  },
  {
    "id": 10,
    "text": "Man kaana yureedul 'izzata falillaahil 'izzatu jamee'aa; ilaihi yas'adul kalimut taiyibu wal'amalus saalihu yarfa'uh; wallazeena yamkuroonas sayyiaati lahum 'azaabun shadeed; wa makru ulaaa'ika huwa yaboor"
  },
  {
    "id": 11,
    "text": "Wallaahu khalaqakum min turaabin summa min nutfatin summa ja'alakum azwaajaa; wa maa tahmilu min unsaa wa laa tada'u illaa bi'ilmih; wa maa yu'ammaru mim mu'ammarinw wa laa yunqasu min 'umuriheee illaa fee kitaab; inna zaalika 'alal laahi yaseer"
  },
  {
    "id": 12,
    "text": "Wa maa yastawil bahraani haaza 'azbun furaatun saaa'ighun sharaabuhoo wa haazaa milhun ujaaj; wa min kullin ta'kuloona lahman tariyyanw wa tastakhrijoona hilyatan talbasoonahaa wa taral fulka feehi mawaakhira litabtaghoo min fadlihee wa la'allakum tashkuroon"
  },
  {
    "id": 13,
    "text": "Yoolijul laila fin nahaari wa yoolijun nahaara fil laili wa sakhkharash shamsa wal qamara kulluny yajree li ajalim musammaa; zaalikumul laahu Rabbukum lahul mulk; wallazeena tad'oona min doonihee maa yamlikoona min qitmeer"
  },
  {
    "id": 14,
    "text": "In tad'oohum laa yasma'oo du'aaa'akum wa law sami'oo mas tajaaboo lakum; wa Yawmal Qiyaamati Yakfuroona bishirkikum; wa laa yunabbi'uka mislu khabeer"
  },
  {
    "id": 15,
    "text": "Yaaa ayyunhan naasu antumul fuqaraaa'u ilallaahi wallaahu Huwal Ghaniyyul Hameed"
  },
  {
    "id": 16,
    "text": "Iny yasha' yuzhibkum wa ya'ti bikhalqin jadeed"
  },
  {
    "id": 17,
    "text": "Wa maa zaalika 'alal laahi bi'azeez"
  },
  {
    "id": 18,
    "text": "Wa laa taziru waaziratun wizra ukhraa; wa in tad'u musqalatun ilaa himlihaa laa yuhmal minhu shai'unw wa law kaana zaa qurbaa; innamaa tunzirul lazeena yakhshawna Rabbahum bilghaibi wa aqaamus Salaah; wa man tazakkaa fa innamaa yatazakkaa linafsih; wa ilal laahil maseer"
  },
  {
    "id": 19,
    "text": "Wa maa yastawil a'maa wal baseer"
  },
  {
    "id": 20,
    "text": "Wa laz zulumaatu wa lan noor"
  },
  {
    "id": 21,
    "text": "Wa laz zillu wa lal haroor"
  },
  {
    "id": 22,
    "text": "Wa maa yastawil ahyaaa'u wa lal amwaat; innal laaha yusmi'u mai yashaaa'u wa maaa anta bi musmi'im man fil quboor"
  },
  {
    "id": 23,
    "text": "In anta illaa nazeer"
  },
  {
    "id": 24,
    "text": "Innaa arsalnaaka bil haqqi basheeranw wa nazeeraa; wa im min ummatin illaa khalaa feehaa nazeer"
  },
  {
    "id": 25,
    "text": "Wa iny yukazzibooka faqad kazzabal lazeena min qablihim jaaa'at hum Rusuluhum bilbaiyinaati wa biz Zuburi wa bil Kitaabil Muneer"
  },
  {
    "id": 26,
    "text": "Summa akhaztul lazeena kafaroo fakaifa kaana nakeer"
  },
  {
    "id": 27,
    "text": "Alam tara annal laaha anzala minas samaaa'i maaa'an fa akhrajnaa bihee samaraatim mukhtalifan alwaanuhaa; wa minal jibaali judadum beedunw wa humrum mukhtalifun alwaanuhaa wa gharaabeebu sood"
  },
  {
    "id": 28,
    "text": "Wa minan naasi wadda waaabbi wal an'aami mukhtalifun alwaanuhoo kazalik; innamaa yakhshal laaha min 'ibaadihil 'ulamaaa'; innal laaha 'Azeezun Ghafoor"
  },
  {
    "id": 29,
    "text": "Innal lazeena yatloona Kitabbal laahi wa aqaamus Salaata wa anfaqoo mimmaa razaqnaahum sirranw wa 'alaa niyatany yarjoona tijaaratal lan taboor"
  },
  {
    "id": 30,
    "text": "Liyuwaffiyahum ujoorahum wa yazeedahum min fadlih; innahoo Ghafoorun Shakoor"
  },
  {
    "id": 31,
    "text": "Wallazeee awhainaaa ilaika minal Kitaabi huwal haqqu musaddiqal limaa baina yadayh; innal laaha bi'ibaadihee la khabeerum Baseer"
  },
  {
    "id": 32,
    "text": "Summa awrasnal Kitaaballazeenas tafainaa min 'ibaadinaa faminhum zaalimul linafsihee wa minhum muqtasidu, wa minhum saabiqum bilkhairaati bi iznil laah; zaalika huwal fadlul kabeer"
  },
  {
    "id": 33,
    "text": "Jannaatu 'adniny yad khuloonahaa yuhallawna feeha min asaawira min zahabinw wa lu'lu'anw wa libaa suhum feehaa hareer"
  },
  {
    "id": 34,
    "text": "Wa qaalul hamdu lillaahil lazeee azhaba 'annal hazan; inna Rabbanaa la Ghafoorun Shakoor"
  },
  {
    "id": 35,
    "text": "Allazeee ahallanaa daaral muqaamati min fadlihee laa yamassunaa feehaa nasabunw wa laa yamassunaa feehaa lughoob"
  },
  {
    "id": 36,
    "text": "Wallazeena kafaroo lahum naaru Jahannama laa yuqdaa 'alaihim fa yamootoo wa laa yukhaffafu 'anhum min 'azaabihaa; kazaalika najzee kulla kafoor"
  },
  {
    "id": 37,
    "text": "Wa hum yastarikhoona feehaa Rabbanaa akhrijnaa na'mal saalihan ghairal lazee kunnaa na'mal; awa lamnu 'ammirkum maa yatazak karu feehi man tazakkara wa jaaa'akumun nazeeru fazooqoo famaa lizzaalimeena min naseer"
  },
  {
    "id": 38,
    "text": "Innal laaha 'aalimu ghaibis samaawaati wal ard; innahoo 'aleemum bizaatis sudoor"
  },
  {
    "id": 39,
    "text": "Huwal lazee ja'alakum khalaaa'ifa fil ard; faman kafara fa'alaihi kufruhoo; wa laa yazeedul kaafireena kufruhum 'inda Rabbihim illaa maqtanw wa laa yazeedul kaafireena kufruhum illaa khasaaraa"
  },
  {
    "id": 40,
    "text": "Qul ara'aytum shurakaaa'a kumul lazeena tad'oona min doonil laahi; aroonee maazaa khalaqoo minal ardi am lahum shirkun fis samaawaati am aatainaahum Kitaaban fahum 'alaa baiyinatim minh; bal iny ya'iduz zaalimoona ba 'duhum ba'dan illaa ghurooraa"
  },
  {
    "id": 41,
    "text": "Innal laaha yumsikus samaawaati wal arda an tazoolaaa; wa la'in zaalataaa in amsa kahumaa min ahadim mim ba'dih; innahoo kaana Haleeman Ghafooraa"
  },
  {
    "id": 42,
    "text": "Wa aqsamoo billaahi jahda aymaanihim la'in jaaa'ahum nazeerul layakoonunna ahdaa min ihdal umami falam maa jaaa'ahum nazeerum maa zaadahum illaa nufooraa"
  },
  {
    "id": 43,
    "text": "Istikbaaran fil ardi wa makras sayyi'; wa laa yaheequl makrus sayyi'u illaa bi ahlih; fahal yanzuroona illaa sunnatal awwaleen; falan tajida lisunnatil laahi tabdeelanw wa lan tajida lisunnatil laahi tahweela"
  },
  {
    "id": 44,
    "text": "Awalam yaseeroo fil ardi fa yanzuroo kaifa kaana 'aaqibatul lazeena min Qablihim wa kaanoo ashadda minhum quwwah; wa maa kaanal laahu liyu'jizahoo min shai'in fis samaawaati wa laa fil ard; innahoo kaana 'Aleeman Qadeeraa"
  },
  {
    "id": 45,
    "text": "Wa law yu'aakhizul laahun naasa bima kasaboo maa taraka 'alaa zahrihaa min daaabbatinw wa laakiny yu'akhkhiruhum ilaaa ajalim musamman fa izaa jaaa'a ajaluhum fa innal laaha kaana bi'ibaadihee Baseeraa"
  }
];

export default en;
