import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Qaaaf; wal Qur aanil Majeed"
  },
  {
    "id": 2,
    "text": "Bal 'ajibooo an jaa'ahum munzirum minhum faqaalal kaafiroona haazaa shai'un 'ajeeb"
  },
  {
    "id": 3,
    "text": "'A-izaa mitnaa wa kunnaa turaaban zaalika raj'um ba'eed"
  },
  {
    "id": 4,
    "text": "Qad 'alimnaa maa tanqu-sul-ardu minhum wa 'indanaa Kitaabun Hafeez"
  },
  {
    "id": 5,
    "text": "Bal kazzaboo bilhaqqi lammaa jaaa'ahum fahum feee amrim mareej"
  },
  {
    "id": 6,
    "text": "Afalam yanzurooo ilas samaaa'i fawqahum kaifa banainaahaa wa zaiyannaahaa wa maa lahaa min furooj"
  },
  {
    "id": 7,
    "text": "Wal arda madadnaahaa wa alqainaa feehaa rawaasiya wa ambatnaa feehaa min kulli zawjim baheej"
  },
  {
    "id": 8,
    "text": "Tabsiratanw wa zikraa likulli 'abdim muneeb"
  },
  {
    "id": 9,
    "text": "Wa nazzalnaa minas samaaa'i maaa'am mubaarakan fa ambatnaa bihee jannaatinw wa habbal haseed"
  },
  {
    "id": 10,
    "text": "Wannakhla baasiqaatil laha tal'un nadeed"
  },
  {
    "id": 11,
    "text": "Rizqal lil'ibaad, wa ahyainaa bihee baldatam maitaa; kazaalikal khurooj"
  },
  {
    "id": 12,
    "text": "Kazzabat qablahum qawmu Noohinw wa Ashaabur Rassi wa Samood"
  },
  {
    "id": 13,
    "text": "Wa 'Aadunw wa Fir'awnu wa ikhwaanu loot"
  },
  {
    "id": 14,
    "text": "Wa Ashaabul Aykati wa qawmu Tubba'; kullun kazzabar Rusula fahaqqa wa'eed"
  },
  {
    "id": 15,
    "text": "Afa'a yeenaa bilkhalqil awwal; bal hum fee labsim min khalqin jadeed"
  },
  {
    "id": 16,
    "text": "Wa laqad khalaqnal insaana wa na'lamu maa tuwaswisu bihee nafsuhoo wa Nahnu aqrabu ilaihi min hablil wareed"
  },
  {
    "id": 17,
    "text": "'Iz yatalaqqal mutalaqqi yaani 'anil yameeni wa 'anish shimaali qa'eed"
  },
  {
    "id": 18,
    "text": "Maa yalfizu min qawlin illaa ladaihi raqeebun 'ateed"
  },
  {
    "id": 19,
    "text": "Wa jaaa'at sakratul mawti bilhaqq; zaalika maa kunta minhu taheed"
  },
  {
    "id": 20,
    "text": "Wa nufikha fis Soor; zaalika yawmul wa'eed"
  },
  {
    "id": 21,
    "text": "Wa jaaa'at kullu nafsim ma'ahaa saaa'iqunw wa shaheed"
  },
  {
    "id": 22,
    "text": "Laqad kunta fee ghaf latim min haazaa fakashafnaa 'anka ghitaaa'aka fabasarukal yawma hadeed"
  },
  {
    "id": 23,
    "text": "Wa qaala qareenuhoo haazaa maa ladaiya 'ateed"
  },
  {
    "id": 24,
    "text": "Alqiyaa fee Jahannama kulla kaffaarin 'aneed"
  },
  {
    "id": 25,
    "text": "Mannaa'il lilkhayri mu'tadim mureeb"
  },
  {
    "id": 26,
    "text": "Allazee ja'ala ma'al laahi ilaahan aakhara fa alqiyaahu fil'azaabish shadeed"
  },
  {
    "id": 27,
    "text": "Qaala qareenuhoo Rabbanaa maaa atghaituhoo wa laakin kaana fee dalaalin ba'eed"
  },
  {
    "id": 28,
    "text": "Qaala laa takhtasimoo ladaayya wa qad qaddamtu ilaikum bilwa'eed"
  },
  {
    "id": 29,
    "text": "Maa yubaddalul qawlu ladaiya wa maaa ana bizal laamil lil'abeed"
  },
  {
    "id": 30,
    "text": "Yawma naqoolu li'jahannama halim talaati wa taqoolu hal mim mazeed"
  },
  {
    "id": 31,
    "text": "Wa uzlifatil jannatu lil muttaqeena ghaira ba'eed"
  },
  {
    "id": 32,
    "text": "Haaza maa too'adoona likulli awwaabin hafeez"
  },
  {
    "id": 33,
    "text": "Man khashiyar Rahmaana bilghaibi wa jaaa'a biqalbim muneeb"
  },
  {
    "id": 34,
    "text": "Udkhuloohaa bisalaamin zaalika yawmul khulood"
  },
  {
    "id": 35,
    "text": "Lahum maa yashaaa'oona feehaa wa ladainaa mazeed"
  },
  {
    "id": 36,
    "text": "Wa kam ahlaknaa qablahum min qarnin hum ashaddu minhum batshan fanaqqaboo fil bilaad, hal mim mahees"
  },
  {
    "id": 37,
    "text": "Inna fee zaalika lazikraa liman kaana lahoo qalbun aw alqas sam'a wa huwa shaheed"
  },
  {
    "id": 38,
    "text": "Wa laqad khalaqnas samaawaati wal arda wa maa bainahumaa fee sittati ayyaamin wa maa massanaa mil lughoob"
  },
  {
    "id": 39,
    "text": "Fasbir 'alaa maa yaqooloona wa sabbih bihamdi Rabbika qabla tuloo'ish shamsi wa qablal ghuroob"
  },
  {
    "id": 40,
    "text": "Wa minal laili fasabbih hu wa adbaaras sujood"
  },
  {
    "id": 41,
    "text": "Wastami' yawma yunaa dil munaadi mim makaanin qareeb"
  },
  {
    "id": 42,
    "text": "Yawma yasmaoonas sai hata bilhaqq zaalika yawmul khurooj"
  },
  {
    "id": 43,
    "text": "Innaa Nahnu nuhyee wa numeetu wa ilainal maseer"
  },
  {
    "id": 44,
    "text": "Yawma tashaqqaqul ardu 'anhum siraa'aa; zaalika hashrun 'alainaa yaseer"
  },
  {
    "id": 45,
    "text": "Nahnu a'lamu bimaa yaqooloona wa maaa anta 'alaihim bijabbaarin fazakkir bil quraani many yakhaafu wa'eed"
  }
];

export default en;
