import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yaaa aiyuhan naasut taqoo Rabbakumul lazee khalaqakum min nafsinw waahidatinw wa khalaqa minhaa zawjahaa wa bas sa minhumaa rijaalan kaseeranw wa nisaaa'aa; wattaqul laahallazee tasaaa 'aloona bihee wal arhaam; innal laaha kaana 'alaikum Raqeeba"
  },
  {
    "id": 2,
    "text": "Wa aatul yataamaaa amwaalahum wa laa tatabad dalul khabeesa bittaiyibi wa laa ta'kulooo amwaalahum ilaaa amwaalikum; innahoo kaana hooban kabeeraa"
  },
  {
    "id": 3,
    "text": "Wa in khiftum allaa tuqsitoo fil yataamaa fankihoo maa taaba lakum minan nisaaa'i masnaa wa sulaasa wa rubaa'a fa'in khiftum allaa ta'diloo fawaahidatan aw maa malakat aimaanukum; zaalika adnaaa allaa ta'ooloo"
  },
  {
    "id": 4,
    "text": "Wa aatun nisaaa'a sadu qaatihinna nihlah; fa in tibna lakum 'an shai'im minhu nafsan fakuloohu hanee'am mareee'aa"
  },
  {
    "id": 5,
    "text": "Wa laa tu'tus sufahaaa'a amwaalakumul latee ja'alal laahu lakum qiyaamanw- warzuqoohum feehaa waksoohum wa qooloo lahum qawlam ma'roofaa"
  },
  {
    "id": 6,
    "text": "Wabtalul yataamaa hattaaa izaa balaghun nikaaha fa in aanastum minhum rushdan fad fa'ooo ilaihim amwaalahum wa laa ta' kuloohaaa israafanw wa bidaaran ai yakbaroo; wa man kaana ghaniyyan falyasta' fif wa man kaana faqeeran fal ya' kul bilma'roof; fa izaa dafa'tum ilaihim amwaalahum fa ash-hidoo 'alaihim; wa kafaa billaahi Haseeba"
  },
  {
    "id": 7,
    "text": "Lirrijaali naseebum mimmaa tarakal waalidaani wal aqraboona wa lin nisaaa'i naseebum mimmaa tarakal waalidaani wal aqraboona mimmaa qalla minhu aw kasur; naseebam mafroodaa"
  },
  {
    "id": 8,
    "text": "Wa izaa hadaral qismata ulul qurbaa walyataamaa walmasaakeenu farzuqoohum minhu wa qooloo lahum qawlam ma'roofaa"
  },
  {
    "id": 9,
    "text": "Walyakhshal lazeena law tarakoo min khalfihim zurriyyatan di'aafan khaafoo 'alaihim falyattaqul laaha walyaqooloo qawlan sadeedaa"
  },
  {
    "id": 10,
    "text": "Innal lazeena ya'kuloona amwaalal yataamaa zulman innamaa ya'kuloona fee butoonihim Naaranw-wa sayaslawna sa'eeraa"
  },
  {
    "id": 11,
    "text": "Yooseekumul laahu feee awlaadikum liz zakari mislu hazzil unsayayn; fa in kunna nisaaa'an fawqas nataini falahunna sulusaa maa taraka wa in kaanat waahidatan falahan nisf; wa li abawaihi likulli waahidim minhumas sudusu mimmma taraka in kaana lahoo walad; fa il lam yakul lahoo waladunw wa warisahooo abawaahu fali ummihis sulus; fa in kaana lahoo ikhwatun fali ummihis sudus; mim ba'di wasiyyatiny yoosee bihaaa aw dayn; aabaaa'ukum wa abnaaa'ukum laa tadroona aiyuhum aqrabu lakum naf'aa; fareedatam minallaah; innal laaha kaana 'Aleeman Hakeemaa"
  },
  {
    "id": 12,
    "text": "Wa lakum nisfu maa taraka azwaajukum il lam yakul lahunna walad; fa in kaana lahunna waladun falakumur rub'u mimmaa tarakna mim ba'di wasiyyatiny yooseena bihaaa aw dayn; wa lahunnar rubu'u mimmaa taraktum il lam yakul lakum walad; fa in kaana lakum waladun falahunnas sumunu mimmaa taraktum; mim ba'di wasiyyatin toosoona bihaaa aw dayn; wa in kaana rajuluny yoorasu kalaalatan awim ra atunw wa lahooo akhun aw ukhtun falikulli waahidim minhumas sudus; fa in kaanooo aksara min zaalika fahum shurakaaa'u fissulus; mim ba'di wasiyyatiny yoosaa bihaaa aw dainin ghaira mudaaarr; wasiyyatam minal laah; wallaahu 'Aleemun Haleem"
  },
  {
    "id": 13,
    "text": "Tilka hudoodul laah; wa mai yuti'il laaha wa Rasoolahoo yudkhilhu Jannaatin tajree min tahtihal anhaaru khaalideena feehaa; wa zaalikal fawzul 'azeem"
  },
  {
    "id": 14,
    "text": "Wa mai ya'sil laaha wa Rasoolahoo wa yata'adda hudoodahoo yudkhilhu Naaran khaalidan feehaa wa lahoo 'azaabum muheen"
  },
  {
    "id": 15,
    "text": "Wallaatee ya'teenal faahishata min nisaaa'ikum fastash-hidoo 'alaihinna arba'atam minkum fa in shahidoo fa amsikoohunna fil buyooti hatta yatawaffaa hunnal mawtu aw yaj'alal laahu lahunna sabeelaa"
  },
  {
    "id": 16,
    "text": "Wallazaani ya'tiyaanihaa minkum fa aazoohumaa fa in taabaa wa aslahaa fa a'ridoo 'anhumaaa; innal laaha kaana Tawwaabar Raheema"
  },
  {
    "id": 17,
    "text": "Innamat tawbatu 'alallaahi lillazeena ya'maloonas sooo'a bijahaalatin summa yatooboona min qareebin fa ulaa'ika yatoobul laahu 'alaihim; wa kaanal laahu 'Aleeman Hakeemaa"
  },
  {
    "id": 18,
    "text": "Wa laisatit tawbatu lillazeena ya'maloonas saiyiaati hattaaa izaa hadara ahadahumul mawtu qaala innee tubtul 'aana wa lallazeena yamootoona wa hum kuffaar; ulaaa'ika a'tadnaa lahum 'azaaban aleemaa"
  },
  {
    "id": 19,
    "text": "Yaaa aiyuhal lazeena aamanoo laa yahillu lakum an tarisun nisaaa'a karhan wa laa ta'duloohunna litazhaboo biba'di maaa aataitumoohunna illaaa ai ya'teena bifaahishatim mubaiyinah; wa 'aashiroo hunna bilma'roof; fa in karihtumoohunna fa'asaaa an takrahoo shai'anw wa yaj'alal laahu feehi khairan kaseeraa"
  },
  {
    "id": 20,
    "text": "Wa in arattumustib daala zawjim makaana zawjin wa aataitum ihdaahunna qintaaran falaa ta'khuzoo minhu shai'aa; ata'khuzoonahoo buhtaannanw wa ismam mubeenaa"
  },
  {
    "id": 21,
    "text": "Wa kaifa ta'khuzoonahoo wa qad afdaa ba'dukum ilaa ba'dinw wa akhazna minkum meesaaqan ghaleezaa"
  },
  {
    "id": 22,
    "text": "Wa laa tankihoo maa nakaha aabaaa'ukum minan nisaaa'i illaa maa qad salaf; innahoo kaana faahishatanw wa maqtanw wa saaa'a sabeelaa"
  },
  {
    "id": 23,
    "text": "Hurrimat 'alaikum umma haatukum wa banaatukum wa akhawaatukum wa 'ammaatukum wa khaalaatukum wa banaatul akhi wa banaatul ukhti wa ummahaatu kumul laateee arda' nakum wa akhawaatukum minarradaa'ati wa ummahaatu nisaaa'ikum wa rabaaa'i bukumul laatee fee hujoorikum min nisaaa'ikumul laatee dakhaltum bihinna Fa il lam takoonoo dakhaltum bihinna falaa junaaha 'alaikum wa halaaa'ilu abnaaa'ikumul lazeena min aslaabikum wa an tajma'oo bainal ukhtaini illaa maa qad salaf; innallaaha kaana Ghafoorar Raheema"
  },
  {
    "id": 24,
    "text": "Walmuhsanaatu minan nisaaa'i illaa maa malakat aimaanukum kitaabal laahi 'alaikum; wa uhilla lakum maa waraaa'a zaalikum an tabtaghoo bi'amwaalikum muhsineena ghaira musaa fiheen; famastamta'tum bihee minhunna fa aatoohunna ujoorahunna fareedah; wa laa junaaha 'alaikum feemaa taraadaitum bihee mim ba'dil fareedah; innal laaha kaana 'Aleeman Hakeemaa"
  },
  {
    "id": 25,
    "text": "Wa mal lam yastati' minkum tawlan ai yankihal muhsanaatil mu'minaati famimmaa malakat aimaanukum min fatayaatikumul mu'minaat; wallaahu a'lamu bi eemaanikum; ba'dukum mim ba'd; fankihoohunna bi izni ahlihinna wa aatoohunna ujoorahunna bilma'roofi muhsanaatin ghaira musaa fihaatinw wa laa muttakhizaati akhdaan; fa izaaa uhsinna fa in ataina bifaahi shatin fa'alaihinnna nisfu maa 'alal muhsanaati minal 'azaab; zaalika liman khashiyal 'anata minkum; wa an tasbiroo khairul lakum; wallaahu Ghafoorur Raheem"
  },
  {
    "id": 26,
    "text": "Yureedul laahu liyubai yina lakum wa yahdiyakum sunanal lazeena min qablikum wa yatooba 'alaikum; wallaahu 'Aleemun Hakeem"
  },
  {
    "id": 27,
    "text": "Wallaahu yureedu ai yatooba 'alaikum wa yureedul lazeena yattabi 'oonash shahawaati an tameeloo mailan 'azeemaa"
  },
  {
    "id": 28,
    "text": "Yureedul laahu ai yukhaffifa 'ankum; wa khuliqal insaanu da'eefaa"
  },
  {
    "id": 29,
    "text": "Yaaa aiyuhal lazeena aamanoo laa ta'kulooo amwaalakum bainakum bilbaatili 'illaaa an takoona tijaaratan 'an taraadim minkum; wa laa taqtulooo anfusakum; innal laaha kaana bikum Raheemaa"
  },
  {
    "id": 30,
    "text": "Wa mai yaf'al zaalika 'udwaananw wa zulman fasawfa nusleehi Naaraa; wa kaana zaalika 'alal laahi yaseeraa"
  },
  {
    "id": 31,
    "text": "In tajtaniboo kabaaa'ira maa tunhawna 'anhu nukaffir 'ankum saiyiaatikum wa nudkhilkum mudkhalan kareemaa"
  },
  {
    "id": 32,
    "text": "Wa laa tatamannaw maa faddalal laahu bihee ba'dakum 'alaa ba'd; lirrijaali naseebum mimmak tasaboo wa linnisaaa'i naseebum mimmak tasabn; was'alullaaha min fadlih; innal laaha kaana bikulli shai'in 'Aleemaa"
  },
  {
    "id": 33,
    "text": "Wa likullin ja'alnaa ma waaliya mimmaa tarakal waalidaani wal aqraboon; wallazeena 'aqadat aimaanukum fa aatoohum naseebahum; innal laaha kaana 'alaa kulli shai'in Shaheedaa"
  },
  {
    "id": 34,
    "text": "Arrijaalu qawwaamoona 'alan nisaaa'i bimaa fad dalallaahu ba'dahum 'alaa ba'dinw wa bimaaa anfaqoo min amwaalihim; fassaalihaatu qaanitaatun haafizaatul lil ghaibi bimaa hafizal laah; wallaatee takhaafoona nushoo zahunna fa 'izoohunna wahjuroohunna fil madaaji'i wadriboohunna fa in ata'nakum falaa tabghoo 'alaihinna sabeelaa; innallaaha kaana 'Aliyyan Kabeeraa"
  },
  {
    "id": 35,
    "text": "Wa in khiftum shiqaaqa baini himaa fab'asoo haka mam min ahlihee wa hakamam min ahlihaa; iny-yureedaaa islaah ai-yuwaffiqil laahu bainahumaa; innal laaha kaana 'Aleeman Khabeeraa"
  },
  {
    "id": 36,
    "text": "Wa'budul laaha wa laa tushrikoo bihee shai'anw wa bilwaalidaini ihsaananw wa bizil qurbaa walyataamaa walmasaakeeni waljaari zilqurbaa waljaaril junubi wassaahibi biljambi wabnis sabeeli wa maa malakat aimaanukum; innal laaha laa yuhibbu man kaana mukhtaalan fakhooraa"
  },
  {
    "id": 37,
    "text": "Allazeena yabkhaloona wa ya'muroonan naasa bilbukhli wa yaktumoona maaa aataahu mullaahu min fadlih; wa a'tadnaa lilkaafireena 'azaabam muheenaa"
  },
  {
    "id": 38,
    "text": "Wallazeena yunfiqoona amwaalahum ri'aaa'an naasi wa laa yu'minoona billaahi wa laa bil Yawmil Aakhir; wa mai yakunish shaitaanu lahoo qareenan fasaaa'a qareenaa"
  },
  {
    "id": 39,
    "text": "Wa maazaa 'alaihim law aamanoo billaahi wal Yawmil Aakhiri wa anfaqoo mimmaa razaqahumul laah; wa kaanallaahu bihim 'aleemaa"
  },
  {
    "id": 40,
    "text": "Innal laaha laa yazlimu misqaala zarratinw wa in taku hasanatany yudaa'ifhaa wa yu'ti mil ladunhu ajran 'azeemaa"
  },
  {
    "id": 41,
    "text": "Fakaifa izaa ji'naa min kulli ummatim bishaheedinw wa ji'naabika 'alaa haaa'ulaaa 'i Shaheeda"
  },
  {
    "id": 42,
    "text": "Yawma'iziny yawad dullazeena kafaroo wa'asawur Rasoola law tusawwaa bihimul ardu wa laa yaktumoonal laaha hadeesaa"
  },
  {
    "id": 43,
    "text": "Yaaa aiyuhal lazeena aamanoo laa taqrabus Salaata wa antum sukaaraa hatta ta'lamoo ma taqooloona wa laa junuban illaa 'aabiree sabeelin hatta taghtasiloo; wa in kuntum mardaaa aw 'alaa safarin aw jaaa'a ahadum minkum minal ghaaa'iti aw laamastumun nisaaa'a falam tajidoo maaa'an fatayam mamoo sa'eedan taiyiban famsahoo biwujoohikum wa aideekum; innal laaha kaana 'Afuwwan Ghafooraa"
  },
  {
    "id": 44,
    "text": "Alam tara ilal lazeena ootoo naseebam minal Kitaabi yashtaroonad dalaalata wa yureedoona an tadillus sabeel"
  },
  {
    "id": 45,
    "text": "Wallaahu a'lamu bi a'daaa'i-kum; wa kafaa billaahi waliyyanw wa kafaa billaahi naseera"
  },
  {
    "id": 46,
    "text": "Minal lazeena haadoo yuharrifoonal Kalima 'am mawaadi'ihee wa yaqooloona sami'naa wa 'asainaa wasma' ghaira musma'inw wa raa'inaa laiyam bi alsinatihim wa ta'nan fiddeen; wa law annahum qaaloo sami'naa wa ata'naa wasma' wanzurnaa lakaana khairal lahum wa aqwama wa laakil la' a'nahumul laahu bikufrihim falaa yu'minoona illaa qaleela"
  },
  {
    "id": 47,
    "text": "Yaaa aiyuha lazeena ootul Kitaaba aaminoo bimaa nazzalnaa musadiqallimaa ma'akum min qabli an natmisa wujoohan fanaruddahaa 'alaaa adbaarihaaa aw nal'anahum kamaa la'annaaa Ashaabas Sabt; wa kaana amrul laahi maf'oolaa"
  },
  {
    "id": 48,
    "text": "Innal laaha laa yaghfiru ai yushraka bihee wa yaghfiru maa doona zaalika limai yashaaa'; wa mai yushrik billaahi faqadif taraaa isman 'azeemaa"
  },
  {
    "id": 49,
    "text": "Alam tara ilal lazeena yuzakkoona anfusahum; balil laahu yuzakkee mai yashaaa'u wa laa yuzlamoona fateelaa"
  },
  {
    "id": 50,
    "text": "Unzur kaifa yaftaroona 'alal laahil kazib, wakafaa biheee ismamm mubeenaa"
  },
  {
    "id": 51,
    "text": "Alam tara ilal lazeena 'ootoo naseebam minal kitaabi yu'minoona bil Jibti wat Taaghooti wa yaqooloona lillazeena kafaroo haaa ulaaa'i ahdaa minal lazeena aamanoo sabeelaa"
  },
  {
    "id": 52,
    "text": "Ulaaa'ikal lazeena la'ana humul laahu wa mai yal'anil laahu falan tajida lahoo naseeraa"
  },
  {
    "id": 53,
    "text": "Am lahum naseebum minal mulki fa izal laa yu'toonan naasa naqeeraa"
  },
  {
    "id": 54,
    "text": "Am yahsudoonan naasa 'alaa maaa aataahumul laahu min fadlihee faqad aatainaaa Aala Ibraaheemal Kitaaba wal Hikmata wa aatainaahum mulkan 'azeemaa"
  },
  {
    "id": 55,
    "text": "Faminhum man aamana bihee wa minhum man sadda 'anh; wa kafaa bi Jahannama sa'eeraa"
  },
  {
    "id": 56,
    "text": "Innal lazeena kafaroo bi Aayaatinaa sawfa nusleehim Naaran kullamaa nadijat julooduhum baddalnaahum juloodan ghairahaa liyazooqul 'azaab; innallaaha kaana 'Azeezan Hakeemaa"
  },
  {
    "id": 57,
    "text": "Wallazeena aamanoo wa 'amilus saalihaati sanud khiluhum jannaatin tajree min tahtihal anhaaru khaalideena feehaaa abadaa, lahum feehaaa azwaajum mutahharatun wa nudkhiluhum zillan zaleelaa"
  },
  {
    "id": 58,
    "text": "Innal laaha ya'murukum an tu'addul amaanaati ilaaa ahlihaa wa izaa hakamtum bainan naasi an tahkumoo bil'adl; innal laaha ni'immaa ya'izukum bih; innal laaha kaana Samee'am Baseeraa"
  },
  {
    "id": 59,
    "text": "Yaaa aiyuhal lazeena aamanooo atee'ul laaha wa atee'ur Rasoola wa ulil amri minkum fa in tanaaza'tum fee shai'in faruddoohu ilal laahi war Rasooli in kuntum tu'minoona billaahi wal yawmil Aakhir; zaalika khairunw wa ahsanu ta'weelaa"
  },
  {
    "id": 60,
    "text": "Alam tara ilal lazeena yaz'umoona annahum amanoo bimaa unzilaa ilaika wa maaa unzila min qablika yureedoona ai yatahaakamooo ilat Taaghooti wa qad umirooo ai yakfuroo bihi, wa yureedush Shaitaanu ai yudillahum dalaalam ba'eedaa"
  },
  {
    "id": 61,
    "text": "Wa izaa qeela lahum ta'aalaw ilaa maaa anzalallaahu wa ilar Rasooli ra aital munaafiqeena yasuddoona 'anka sudoodaa"
  },
  {
    "id": 62,
    "text": "Fakaifa izaaa asaabathum museebatum bimaa qaddamat aideehim summa jaaa'ooka yahlifoona billaahi in aradnaaa illaaa ihsaananw wa tawfeeqaa"
  },
  {
    "id": 63,
    "text": "Ulaaa'ikal lazeena ya'la mullaahu maa fee quloobihim fa a'rid 'anhum wa 'izhum wa qul lahum feee anfusihim qawlam baleeghaa"
  },
  {
    "id": 64,
    "text": "Wa maa arsalnaa mir Rasoolin illaa liyutaa'a bi iznil laah; wa law annahum 'iz zalamooo anfusahum jaaa'ooka fastaghfarul laaha wastaghfara lahumur Rasoolu la wajadul laaha Tawwaabar Raheemaa"
  },
  {
    "id": 65,
    "text": "Falaa wa Rabbika laa yu'minoona hattaa yuhakkimooka fee maa shajara bainahum summa laa yajidoo feee anfusihim harajam mimmaa qadaita wa yusal limoo tasleemaa"
  },
  {
    "id": 66,
    "text": "Wa law annaa katabnaa 'alaihim aniqtulooo anfusakum aw ikhrujoo min diyaarikum maa fa'aloohu illaa qaleelum minhum wa law annahum fa'aloo maa yoo'azoona bihee lakaana khairal lahum wa ashadda tasbeetaa"
  },
  {
    "id": 67,
    "text": "Wa izal la aatainaahum mil ladunnaaa ajran 'azeemaa"
  },
  {
    "id": 68,
    "text": "Wa la Hadainaahum Siraatam mustaqeemaa"
  },
  {
    "id": 69,
    "text": "Wa many-yuti'il laaha war Rasoola fa ulaaa'ika ma'al lazeena an'amal laahu 'alaihim minan nabiyyeena wassiddeeqeena washshuhadaaa'i wassaaliheen; wa hasuna ulaaa'ika rafeeqaa"
  },
  {
    "id": 70,
    "text": "Zaalikal fadlu minal laah; wa kafaa billaahi 'Aleemaa"
  },
  {
    "id": 71,
    "text": "Yaaa aiyuhal lazeena aamanoo khuzoo hizrakum fanfiroo subaatin awin firoo jamee'aa"
  },
  {
    "id": 72,
    "text": "Wa inna minkum lamal la yubatti'anna fa in asaabatkum museebatun qaala qad an'amal laahu 'alaiya iz lam akum ma'ahum shaheeda"
  },
  {
    "id": 73,
    "text": "Wa la'in asaabakum fadlum minal laahi la yaqoolanna ka al lam takum bainakum wa bainahoo mawaddatuny yaa laitanee kuntu ma'ahum fa afooza fawzan 'azeemaa"
  },
  {
    "id": 74,
    "text": "Falyuqaatil fee sabeelil laahil lazeena yashroonal hayaatad dunyaa bil Aakhirah; wa may-yuqaatil fee sabeelil laahi fa yuqtal aw yaghlib fasawfa nu'teehi ajran 'azeemaa"
  },
  {
    "id": 75,
    "text": "Wa maa lakum laa tuqaatiloona fee sabeelil laahi walmustad'afeena minar rijaali wannisaaa'i walwildaanil lazeena yaqooloona Rabbanaaa akhrijnaa min haazihil qaryatiz zaalimi ahluhaa waj'al lanaa mil ladunka waliyanw waj'al lanaa mil ladunka naseeraa"
  },
  {
    "id": 76,
    "text": "Allazeena aamanoo yuqaatiloona fee sabeelil laahi wallazeena kafaroo yuqaatiloona fee sabeelit Taaghoot faqaatiloo awliyaaa'ash Shaitaan; inna kaidash Shaitaani kaana da'eefa"
  },
  {
    "id": 77,
    "text": "Alam tara ilal lazeena qeela lahum kuffooo aidiyakum wa aqeemus Salaata wa aaatuz Zakaata falammaa kutiba 'alaihimul qitaalu izaa fareequm minhum yakhshaw nan naasa kakhashyatil laahi aw ashadda khashyah; wa qaaloo Rabbanaa lima katabta 'alainal qitaala law laaa akhkhartanaa ilaaa ajalin qareeb; qul mataa'ud dunyaa qaleelunw wal Aakhiratu khairul limanit taqaa wa laa tuzlamoona fateelaa"
  },
  {
    "id": 78,
    "text": "Ayna maa takoonoo yudrikkumul mawtu wa law kuntum fee buroojim mushai yadah; wa in tusibhum hasanatuny yaqooloo haazihee min indil laahi wa in tusibhum saiyi'atuny yaqooloo haazihee min 'indik; qul kullum min 'indillaahi famaa lihaaa 'ulaaa'il qawmi laa yakaadoona yafqahoona hadeesaa"
  },
  {
    "id": 79,
    "text": "Maaa asaabaka min hasanatin faminal laahi wa maaa asaaabaka min saiyi'atin famin nafsik; wa arsalnaaka linnaasi Rasoolaa; wa kafaa billaahi Shaheedaa"
  },
  {
    "id": 80,
    "text": "Many yuti'ir Rasoola faqad ataa'al laaha wa man tawallaa famaaa arsalnaaka 'alaihim hafeezaa"
  },
  {
    "id": 81,
    "text": "Wa yaqooloona ta'atun fa izaa barazoo min 'indika baiyata taaa'ifatum minhum ghairal lazee taqoolu wallaahu yaktubu maa yubaiyitoona fa a'rid 'anhum wa tawakkal 'alal laah; wa kafaa billaahi Wakeelaa"
  },
  {
    "id": 82,
    "text": "Afalaa yatadabbaroonal Qur'aan; wa law kaana min 'indi ghairil laahi la wajadoo fee ikhtilaafan kaseeraa"
  },
  {
    "id": 83,
    "text": "Wa izaa jaaa'ahum amrum minal amni awil khawfi azaa'oo bihee wa law raddoohu ilar Rasooli wa ilaaa ulil amri minhum la'alimahul lazeena yastambitoonahoo minhum; wa law laa fadlul laahi 'alaikum wa rahmatuhoo lattaba'tumush Shaitaana illaa qaleelaa"
  },
  {
    "id": 84,
    "text": "Faqaatil fee sabeelil laahi laa tukallafu illa nafsaka wa harridil mu'mineen; 'asallaahu ai yakuffa ba'sallazeena kafaroo; wallaahu ashaddu ba'sanw wa ashaaddu tankeelaa"
  },
  {
    "id": 85,
    "text": "Mai yashfa' shafaa'atan hasanatay yakul lahoo naseebum minhaa wa mai yashfa' shafaa'atan saiyi'atany-yakul lahoo kiflum minhaa; wa kaanal laahu 'alaa kulli shai'im Muqeetaa"
  },
  {
    "id": 86,
    "text": "Wa izaa huyyeetum bitahiyyatin fahaiyoo bi ahsana minhaaa aw ruddoohaa; innal laaha kaana 'alaa kulli shai'in Haseeba"
  },
  {
    "id": 87,
    "text": "Allaahu laaa ilaaha illaa huwa la yajma'annakum ilaa Yawmil Qiyaamati laa raiba feeh; wa man asdaqu min allaahi hadeesaa"
  },
  {
    "id": 88,
    "text": "Famaa lakum fil munaafiqeena fi'ataini wallaahu arkasahum bimaa kasaboo; A' tureedoona an tahdoo man adallal laahu wa many yudli lillaahu falan tajida lahoo sabeelaa"
  },
  {
    "id": 89,
    "text": "Waddoo law takfuroona kamaa kafaroo fatakoonoona sawaaa'an falaa tattakhizoo minhum awliyaaa'a hattaa yuhaajiroo fee sabeelil laah; fa in tawallaw fa khuzoohum waqtuloohum haisu wajat tumoohum wa laa tattakhizoo minhum waliyyanw wa laa naseeraa"
  },
  {
    "id": 90,
    "text": "Illal lazeena yasiloona ilaa qawmim bainakum wa bainahum meesaaqun aw jaaa'ookum hasirat sudooruhum ai yuqaatilookum aw yuqaatiloo qawmahum, wa law shaaa'al laahu lasallatahum 'alaikum falaqaatalookum; fa ini' tazalookum falam yuqaatilookum wa alqaw ilaikumus salama famaa ja'alal laahu lakum 'alaihim sabeelaa"
  },
  {
    "id": 91,
    "text": "Satajidoona aakhareena yureedoona ai ya'manookum wa ya'manoo qawmahum kullamaa ruddooo ilal fitnati urkisoo feehaa; fa il lam ya'tazilookum wa yulqooo ilai kumus salama wa yakuffooo aidiyahum fakhuzoohum waqtuloohum haisu saqif tumoohum; wa ulaaa'ikum ja'alnaa lakum 'alaihim sultaanam mubeenaa"
  },
  {
    "id": 92,
    "text": "Wa maa kaana limu'minin ai yaqtula mu'minan illaa khata'aa; waman qatala mu'minan khata'an fa tahreeru raqabatim mu'minatinw wa diyatum musallamatun ilaaa ahliheee illaaa ai yassaddaqoo; fa in kaana min qawmin 'aduwwil lakum wa huwa mu'minun fa tahreeru raqabatim mu'minah; wa in kaana min qawmim bainakum wa bainahum meesaaqun fadiyatum musallamatun ilaaa ahlihee wa tahreeru raqabatim mu'minah; famal lam yajid fa Siyaamu shahraini mutataabi'aini tawbatan minal laah; wa kaanal laahu 'Aleeman hakeemaa"
  },
  {
    "id": 93,
    "text": "Wa mai yaqtul mu'minam muta'ammidan fajazaaa'uhoo Jahannamu khaalidan feehaa wa ghadibal laahu' alaihi wa la'anahoo wa a'adda lahoo 'azaaban 'azeemaa"
  },
  {
    "id": 94,
    "text": "Yaaa aiyuhal lazeena aamanoo izaa darabtum fee sabeelil laahi fatabaiyanoo wa laa taqooloo liman alqaaa ilaikumus salaama lasta mu'minan tabtaghoona 'aradal hayaatid dunyaa fa'indal laahi maghaanimu kaseerah; kazaalika kuntum min qablu famannnal laahu 'alaikum fatabaiyanoo; innallaaha kaana bimaa ta'maloona Khabeeraa"
  },
  {
    "id": 95,
    "text": "Laa yastawil qaa'idoona Minal mu'mineena ghairu uliddarari walmujaahidoona fee sabeelil laahi bi amwaalihim wa anfusihim; faddalal laahul mujaahideena bi amwaalihim wa anfusihim 'alalqaa'ideena darajah; wa kullanw wa'adal laahul husnaa; wa faddalal laahul mujaahideena 'alal qaa'ideena ajran 'azeemaa"
  },
  {
    "id": 96,
    "text": "Darajaatim minhu wa maghfiratanw wa rahmah; wa kaanal laahu Ghafoorar Raheema"
  },
  {
    "id": 97,
    "text": "Innal lazeena tawaffaa humul malaaa'ikatu zaalimeee anfusihim qaaloo feema kuntum qaaloo kunnaa mustad'afeena fil-ard; qaalooo alam takun ardul laahi waasi'atan fatuhaajiroo feehaa; fa ulaaa'ika ma'waahum Jahannamu wa saaa'at maseeraa"
  },
  {
    "id": 98,
    "text": "Illal mustad 'afeena minar rijaali wannisaaa'i walwildaani laa yastatee'oona heelatanw wa laa yahtadoona sabeela"
  },
  {
    "id": 99,
    "text": "Fa ulaaa'ika 'asal laahu ai ya'fuwa 'anhum; wa kaanal laahu 'Afuwwan Ghafooraa"
  },
  {
    "id": 100,
    "text": "Wa mai yuhaajir fee sabeelil laahi yajid fil ardi muraaghaman kaseeranw wa sa'at; wa mai yakhruj mim baitihee muhaajiran ilal laahi wa Rasoolihee summa yudrik-hul mawtu faqad waqa'a ajruhoo 'alal laah; wa kaanal laahu Ghafoorar Raheemaa"
  },
  {
    "id": 101,
    "text": "Wa izaa darabtum fil ardi falaisa 'alaikum junaahun an taqsuroo minas Salaati in khiftum ai yaftinakumul lazeena kafarooo; innal kaafireena kaanoo lakum aduwwam mubeenaa"
  },
  {
    "id": 102,
    "text": "Wa izaa kunta feehim fa aqamta lahumus Salaata faltaqum taaa'ifatum minhum ma'aka wal ya'khuzoo aslihatahum fa izaa sajadoo fal yakoonoo minw waraaa'ikum wal ta'ti taaa'ifatun ukhraa lam yusalloo falyusallo ma'aka wal ya'khuzoo hizrahum wa aslihatahum; waddal lazeena kafaroo law taghfuloona 'anaslihatikum wa amti'atikum fa yameeloona 'alaikum mailatanw waahidah; wa laa junaaha 'alaikum in kaana bikum azam mimmatarin aw kuntum mardaaa an tada'ooo aslihatakum wa khuzoo hizrakum; innal laaha a'adda lilkaafireena 'azaabam muheenaa"
  },
  {
    "id": 103,
    "text": "Fa izaa qadaitumus Salaata fazkurul laaha qiyaamanw wa qu'oodanw wa 'alaa junoobikum; fa izatma'nantum fa aqeemus Salaah; innas Salaata kaanat 'alal mu'mineena kitaabam mawqootaa"
  },
  {
    "id": 104,
    "text": "Wa laa tahinoo fibtighaaa'il qawmi in takoonoo ta'lamoona fa innahum ya'lamoona kamaa ta'lamoona wa tarjoona minal laahi maa laa yarjoon; wa kaanal laahu 'Aleeman Hakeemaa"
  },
  {
    "id": 105,
    "text": "Innaaa anzalnaaa ilaikal Kitaaba bilhaqqi litahkuma bainan naasi bimaaa araakal laah; wa laa takul lilkhaaa'ineena khaseemaa"
  },
  {
    "id": 106,
    "text": "Wastaghfiril laaha innal laaha kaana Ghafoorar Raheema"
  },
  {
    "id": 107,
    "text": "Wa laa tujaadil 'anil lazeena yakhtaanoona anfusahum; innal laaha laa yuhibbuman kaana khawwaanan aseemaa"
  },
  {
    "id": 108,
    "text": "Yastakhfoona minannaasi wa laa yastakh foona minal laahi wa huwa ma'ahum iz yubaiyitoona maa laa yardaa minal qawl; wa kaanal laahu bimaa ya'maloona muheetaa"
  },
  {
    "id": 109,
    "text": "Haaa antum haaa'ulaaa'i jaadaltum 'anhum fil hayaatid dunyaa famai yujaadilul laaha 'anhum Yawmal Qiyaamati am mai yakoonu 'alaihim wakeelaa"
  },
  {
    "id": 110,
    "text": "Wa mai ya'mal sooo'an aw yazlim nafsahoo summa yastaghfiril laaha yajidil laaha Ghafoorar Raheemaa"
  },
  {
    "id": 111,
    "text": "Wa mai yaksib isman fa innamaa yaksibuhoo 'alaa nafsih; wa kaanal laahu 'Aleeman hakeemaa"
  },
  {
    "id": 112,
    "text": "Wa mai yaksib khateee'atan aw isman summa yarmi bihee bareee'an faqadih tamala buhtaananw wa ismam mubeenaa"
  },
  {
    "id": 113,
    "text": "Wa law laa fadlul laahi 'alaika wa rahmatuhoo lahammat taaa'ifatum minhum ai yudillooka wa maa yudilloona illaaa anfusahum wa maa yadurroonaka min shai'; wa anzalal laahu 'alaikal Kitaaba wal Hikmata wa 'allamaka maa lam takun ta'lam; wa kaana fadlul laahi 'alaika 'azeemaa"
  },
  {
    "id": 114,
    "text": "Laa khaira fee kaseerim min najwaahum illaa man amara bisadaqatin aw ma'roofin aw islaahim bainan naas; wa mai yaf'al zaalikab tighaaa'a mardaatil laahi fa sawfa nu'teehi ajran 'azeemaa"
  },
  {
    "id": 115,
    "text": "Wa mai yushaaqiqir Rasoola mim ba'di maa tabaiyana lahul hudaa wa yattabi' ghaira sabeelil mu'mineena nuwallihee ma tawallaa wa nuslihee Jahannama wa saaa'at maseeraa"
  },
  {
    "id": 116,
    "text": "Innal laaha laa yaghfiru ai yushraka bihee wayaghfiru maa doona zaalika limai yashaaa'; wa mai yushrik billaahi faqad dalla dalaalam ba'eedaa"
  },
  {
    "id": 117,
    "text": "Iny yad'oona min dooniheee illaaa inaasanw wa iny yad'oona illaa Shaitaanam mareedaa"
  },
  {
    "id": 118,
    "text": "La'anahul laah; wa qaala la attakhizanna min 'ibaadika naseebam mafroodaa"
  },
  {
    "id": 119,
    "text": "Wa la udillannahum wa la umanni yannnahum wa la aamurannahum fala yubat tikunna aazaanal an'aami wa la aamurannahum fala yughai yirunna khalqal laah; wa mai yattakhizish Shaitaana waliyyam min doonil laahi faqad khasira khusraanam mubeena"
  },
  {
    "id": 120,
    "text": "Ya'iduhum wa yuman neehim wa maa ya'iduhumush Shaitaanu illaa ghurooraa"
  },
  {
    "id": 121,
    "text": "Ulaaa'ika ma'waahum Jahannamu wa laa yajidoona 'anhaa maheesaa"
  },
  {
    "id": 122,
    "text": "Wallazeena aamanoo wa 'amilus saalihaati sanud khiluhum Jannaatin tajree min tahtihal anhaaru khaalideena feehaaa abadaa; wa'dal laahi haqqaa; wa man asdaqu minal laahi qeelaa"
  },
  {
    "id": 123,
    "text": "Laisa bi amaaniyyikum wa laaa amaaniyyi Ahlil Kitaab; mai ya'mal sooo'ai yujza bihee wa laa yajid lahoo min doonil laahi waliyanw wa laa naseeraa"
  },
  {
    "id": 124,
    "text": "Wa mai ya'mal minas saalihaati min zakarin aw unsaa wa huwa mu'minun fa ulaaa'ika yadkhuloonal Jannata wa laa yuzlamoona naqeeraa"
  },
  {
    "id": 125,
    "text": "Wa man ahsanu deenam mimmman aslama wajhahoo lillaahi wa huwa muhsinunw wattaba'a Millata Ibraaheema haneefaa; wattakhazal laahu Ibraaheema khaleelaa"
  },
  {
    "id": 126,
    "text": "Wa lillaahi maa fis samaawaati wa maa fil ard; wa kaanal laahu bikulli shai'im muheetaa"
  },
  {
    "id": 127,
    "text": "Wa yastaftoonaka finnisaaa'i qulil laahu yufteekum feehinna wa maa yutlaa 'alaikum fil Kitaabi fee yataaman nisaaa'il laatee laa tu'toonahunna maa kutiba lahunnna wa targhaboona an tankihoohunna wal mustad'a feena minal wildaani wa an taqoomoo lilyataamaa bilqist; wa maa taf'aloo min khairin fa innal laaha kaana bihee 'Aleemaa"
  },
  {
    "id": 128,
    "text": "Wa inimra atun khaafat mim ba'lihaa nushoozan aw i'raadan falaa junaaha 'alaihi maaa ai yuslihaa bainahumaa sulhaa; wassulhu khair; wa uhdiratil anfusush shuhh; wa in tuhsinoo wa tattaqoo fa innal laaha kaana bimaa ta'maloona Khabeeraa"
  },
  {
    "id": 129,
    "text": "Wa lan tastatee'ooo an ta'diloo bainan nisaaa'i wa law harastum falaa tameeloo kullal maili fatazaroohaa kalmu'al laqah; wa in tuslihoo wa tattaqoo fa innal laaha kaana Ghafoorar Raheema"
  },
  {
    "id": 130,
    "text": "Wa iny-yatafarraqaa yughnil laahu kullam min sa'atih; wa kaanal laahu Waasi'an Hakeemaa"
  },
  {
    "id": 131,
    "text": "Wa lillaahi maafis samaawaati wa maa fil ard; wa laqad wassainal lazeena ootul Kitaaba min qablikum wa iyyaakum anit taqul laah; wa intakfuroo fa inna lillaahi maa fis samaawaati wa maa fil ard; wa kaanal laahu Ghaniyyan hameedaa"
  },
  {
    "id": 132,
    "text": "Wa lillaahi maa fis samaawaati wa maa fil ard; wa kafaa billaahi Wakeelaa"
  },
  {
    "id": 133,
    "text": "Iny-yasha' yuzhibkum aiyuhan naasu wa ya'ti bi aakhareen; wa kaanal laahu 'alaa zaalika Qadeeraa"
  },
  {
    "id": 134,
    "text": "Man kaana yureedu sawaabad dunyaa fa'indallaahi sawaabud dunyaa wal Aakhirah; wa kaanal laahu Samee'am Baseeraa"
  },
  {
    "id": 135,
    "text": "Yaa aiyuhal lazeena aamanoo koonoo qawwa ameena bilqisti shuhadaaa'a lillaahi wa law 'alaa anfusikum awil waalidaini wal aqrabeen iny yakun ghaniyyan aw faqeeran fallaahu awlaa bihimaa falaaa tattabi'ul hawaaa an ta'diloo; wa in talwooo aw tu'ridoo fa innal laaha kaana bimaa ta'maloona Khabeera"
  },
  {
    "id": 136,
    "text": "Yaaa aiyuhal lazeena aamanooo aaminoo billaahi wa Rasoolihee wal Kitaabil lazee nazzala 'alaa Rasoolihee wal Kitaabil lazeee anzala min qabl; wa mai yakfur billaahi wa Malaaa'ikatihee wa Kutubihee wa Rusulihee wal Yawmil Aakhiri faqad dalla dalaalam ba'eedaa"
  },
  {
    "id": 137,
    "text": "Innal lazeena aamanoo summa kafaroo summa aamanoo summa kafaroo summaz daado kufral lam yakunil laahu liyaghfira lahum wa laa liyahdiyahum sabeelaa"
  },
  {
    "id": 138,
    "text": "Bashshiril munaafiqeena bi anna lahum 'azaaban aleemaa"
  },
  {
    "id": 139,
    "text": "Allazeena yattakhizoo nal kaafireena awliyaaa'a min doonil mu'mineen; a-yabta ghoona 'indahumul 'izzata fainnnal 'izzata lillaahi jamee'aa"
  },
  {
    "id": 140,
    "text": "Wa qad nazzala 'alaikum fil Kitaabi an izaa sami'tum Aayaatil laahi yukfaru bihaa wa yustahza u bihaa falaa taq'udoo ma'ahum hattaa yakhoodoo fee hadeesin ghairih; innakum izam misluhum; innal laaha jaami'ul munaafiqeena wal kaafireena fee jahannama jamee'aa"
  },
  {
    "id": 141,
    "text": "Allazeena yatarab basoona bikum fa in kaana lakum fathum minal laahi qaalooo alam nakum ma'akum wa in kaana lilkaafireena naseebun qaalooo alam nastah wiz 'alaikum wa nammna'kum minal mu'mineen; fallaahu yahkumu bainakum Yawmal Qiyaamah; wa lai yaj'alal laahu lilkaafireena 'alal mu'mineena sabeelaa"
  },
  {
    "id": 142,
    "text": "Innal munaafiqeena yukhaadi'oonal laaha wa huwa khaadi'uhum wa izaa qaamooo ilas Salaati qaamoo kusaalaa yuraaa'oonan naasa wa laa yazkuroonal laaha illaa qaleelaa"
  },
  {
    "id": 143,
    "text": "Muzabzabeena baina zaalika laaa ilaa haaa' ulaaa'i wa laaa ilaa haaa'ulaaa'; wa mai yudli lillaahu falan tajida lahoo sabeela"
  },
  {
    "id": 144,
    "text": "Yaaa aiyuhal lazeena aamanoo laa tattakhizul kaafireena awliyaaa'a min doonil mu'mineen; aturee doona an taj'aloo lillaahi 'alaikum sultaanam mubeenaa"
  },
  {
    "id": 145,
    "text": "Innal munaafiqeena fiddarkil asfali minan Naari wa lan tajida lahum naseeraa"
  },
  {
    "id": 146,
    "text": "Illal lazeena taaboo wa aslahoo wa'tasamoo billaahi wa akhlasoo deenahum lillaahi faulaaa'ika ma'al mu'mineena wa sawfa yu'til laahul mu'mineena ajran 'azeemaa"
  },
  {
    "id": 147,
    "text": "Maa yaf'alul laahu bi 'azaabikum in shakartum wa aamantum; wa kaanal laahu Shaakiran 'Aleema"
  },
  {
    "id": 148,
    "text": "Laa yuhibbullaahul jahra bis sooo'i minal qawli illaa man zulim; wa kaanallaahu Samee'an 'Aleemaa"
  },
  {
    "id": 149,
    "text": "In tubdoo khairann aw tukhfoohu aw ta'foo 'an sooo'in fa innal laaha kaana 'afuwwan Qadeeraa"
  },
  {
    "id": 150,
    "text": "Innal lazeena yakkfuroona billaahi wa Rusulihee wa yureedoona ai yufarriqoo bainal laahi wa Rusulihee wa yaqooloona nu'minu biba'dinw wa nakfuru biba' dinw wa yureedoona ai yattakhizoo baina zaalika sabeelaa"
  },
  {
    "id": 151,
    "text": "Ulaaa'ika humul kaafiroona haqqaaw; wa a'tadnaa lilkaafireena 'azaabam muheenaa"
  },
  {
    "id": 152,
    "text": "Wallazeena aamanoo billaahi wa Rusulihee wa lam yufarriqoo baina ahadim minhum ulaaa'ika sawfa yu'teehim ujoorahum; wa kaanal laahu Ghafoorar Raheema"
  },
  {
    "id": 153,
    "text": "Yas'aluka Ahlul Kitaabi an tunazzila 'alaihim Kitaabam minas samaaa'i faqad sa aloo Moosaa akbara min zaalika faqaaloo arinal laaha jahratan fa akhazat humus saa'iqatu bizulmihim; summat takhazul 'ijla mim ba'di maa jaa'at humul baiyinaatu fa'afawnaa 'ann zaalik; wa aatainaa Moosaa sultaanam mubeenaa"
  },
  {
    "id": 154,
    "text": "Wa rafa'naa fawqahumut Toora bimeesaaqihim wa qulnaa lahumud khulul baaba sujjadanw wa qulnaa lahum laa ta'doo fis Sabti wa akhaznaa minhum meesaaqan ghaleezaa"
  },
  {
    "id": 155,
    "text": "Fabimaa naqdihim meesaaqahum wa kufrihim bi Aayaatil laahi wa qatlihimul Ambiyaaa'a bighairi haqqinw wa qawlihim quloobunaa ghulf; bal taba'al laahu 'alaihaa bikufrihim falaa yu'minoona illaa qaleelaa"
  },
  {
    "id": 156,
    "text": "Wa bikufrihim wa qawlihim 'alaa Maryama buh taanan 'azeema"
  },
  {
    "id": 157,
    "text": "Wa qawlihim innaa qatal nal maseeha 'Eesab-na-Maryama Rasoolal laahi wa maa qataloohu wa maa salaboohu wa laakin shubbiha lahum; wa innal lazeenakh talafoo feehee lafee shakkim minh; maa lahum bihee min 'ilmin illat tibaa'az zann; wa maa qataloohu yaqeenaa"
  },
  {
    "id": 158,
    "text": "Bar rafa'ahul laahu ilayh; wa kaanal laahu 'Azeezan Hakeemaa"
  },
  {
    "id": 159,
    "text": "Wa im min Ahlil Kitaabi illaa layu'minanna bihee qabla mawtihee wa Yawmal Qiyaamati yakoonu 'alaihim shaheedaa"
  },
  {
    "id": 160,
    "text": "Fabizulmin minal lazeena haadoo harramnaa 'alaihim taiyibaatin uhillat lahum wa bisadihim 'an sabeelil laahi kaseeraa"
  },
  {
    "id": 161,
    "text": "Wa akhzihimur ribaa wa qad nuhoo 'anhu wa aklihim amwaalan naasi bilbaatil; wa a'tadnaa lilkaafireena minhum 'azaaban aleema"
  },
  {
    "id": 162,
    "text": "Laakinir raasikhoona fil'ilmi minhum walmu'minoona yu'minoona bimaaa unzila ilaika wa maaa unzila min qablika walmuqeemeenas Salaata walmu'toonaz Zakaata walmu 'minoona billaahi wal yawmil Aakhir; ulaaa'ika sanu'teehim ajran 'azeemaa"
  },
  {
    "id": 163,
    "text": "Innaaa awhainaaa ilaika kamaaa awhainaaa ilaa Noohinw wan nabiyyeena mim ba'dih; wa awhainaaa ilaaa ibraaheema wa Ismaaa'eela wa Ishaaqa wa Ya'qooba wal Asbaati wa 'Eesaa wa Ayyooba wa Yoonusa wa haaroona wa Sulaimaan; wa aatainaa Daawooda Zabooraa"
  },
  {
    "id": 164,
    "text": "Wa Rusulan qad qasas naahum 'alaika min qablu wa Rusulal lam naqsushum 'alaik; wa kallamallaahu Moosaa takleemaa"
  },
  {
    "id": 165,
    "text": "Rusulam mubashshireena wa munzireena li'allaa yakoona linnaasi 'alal laahi hujjatum ba'dar Rusul; wa kaanallaahu 'Azeezan Hakeema"
  },
  {
    "id": 166,
    "text": "Laakinil laahu yashhadu bimaaa anzala ilaika anzalahoo bi'ilmihee wal malaaa'ikatu yashhadoon; wa kafaa billaahi Shaheeda"
  },
  {
    "id": 167,
    "text": "Innal lazeena kafaroo wa saddoo 'an sabeelil laahi qad dalloo dalaalam ba'eedaa"
  },
  {
    "id": 168,
    "text": "Innal lazeenakafaroo wa zalamoo lam yakunillaahu liyaghfira lahum wa laa liyahdiyahum tareeqaa"
  },
  {
    "id": 169,
    "text": "Illaa tareeqa jahannamma khaalideena feehaa abadaa; wa kaana zaalika 'alal laahi yaseeraa"
  },
  {
    "id": 170,
    "text": "Yaaa aiyuhan naasu qad jaaa'akumur Rasoolu bilhaqqi mir Rabbikum fa ammminoo khairal lakum; wa in takfuroo fainnna lillaahi maa fis samaawaati wal ard; wa kaanal laahu 'Aleemann hakeemaa"
  },
  {
    "id": 171,
    "text": "Yaaa Ahlal Kitaabi laa taghloo fee deenikum wa laa taqooloo 'alal laahi illalhaqq; innamal Maseehu 'Eesab-nu-Maryama Rasoolul laahi wa Kalimatuhooo alqaahaaa ilaa Maryama wa roohum minhum fa aaminoo billaahi wa Rusulihee wa laa taqooloo salaasah; intahoo khairallakum; innamal laahu Ilaahunw Waahid, Subhaanahooo any yakoona lahoo walad; lahoo maa fissamaawaati wa maa fil ard; wa kafaa billaahi Wakeelaa"
  },
  {
    "id": 172,
    "text": "Lay yastankifal Maseehu ai yakoona 'abdal lillaahi wa lal malaaa'ikatul muqarraboon; wa mai yastankif 'an ibaadatihee wa yastakbir fasa yahshuruhum ilaihi jamee'aa"
  },
  {
    "id": 173,
    "text": "Fa ammal lazeena aamanoo wa 'amilus saalihaati fa yuwaffeehim ujoorahum wa yazeeduhum min fadlihee wa ammal lazeenas tankafoo wastakbaroo fa yu'azzibuhum 'azaaban aleema wa laa yajidoona lahum min doonil laahi waliyyanw wa laa naseeraa"
  },
  {
    "id": 174,
    "text": "Yaa aiyuhan naasu qad jaaa'akum burhaanum mir Rabbikum wa anzalnaaa ilaikum Nooram Mubeena"
  },
  {
    "id": 175,
    "text": "Fa ammal lazeena aamanoo billaahi wa'tasamoo bihee fasa yudkhiluhum fee rahmatim minhu wa fadlinw wa yahdeehim ilaihi Siraatam Mustaqeema"
  },
  {
    "id": 176,
    "text": "Yastaftoonaka qulillaahu yufteekum fil kalaalah; inimru'un halaka laisa lahoo waladunw wa lahoo ukhtun falahaa nisfu maa tarak; wa huwa yarisuhaaa il lam yakkul lahaa walad; fa in kaanatas nataini falahumas sulusaani mimmmaa tarak; wa in kaanooo ikhwatar rijaalanw wa nisaaa'an faliz zakari mislu hazzil unsayayn; yubaiyinullaahu lakum an tadilloo; wallaahu bikulli shai'in Aleem"
  }
];

export default en;
