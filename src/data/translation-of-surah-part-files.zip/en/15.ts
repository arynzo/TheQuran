import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Raa; tilka Aayaatul Kitaabi wa Qur-aa-nim Mubeen"
  },
  {
    "id": 2,
    "text": "Rubamaa yawaddul lazeena kafaroo law kaanoo muslimeen"
  },
  {
    "id": 3,
    "text": "Zarhum yaakuloo wa yatamatta'oo wa yulhihimul amalu fasawfa ya'lamoon"
  },
  {
    "id": 4,
    "text": "Wa maaa ahlaknaa min qaryatin illaa wa lahaa kitaabum ma'loom"
  },
  {
    "id": 5,
    "text": "Maa tasbiqu min ummatin ajalahaa wa maa yastaakhiroon"
  },
  {
    "id": 6,
    "text": "Wa qaaloo yaaa aiyuhal lazee nuzzila 'alaihiz Zikru innaka lamajnoon"
  },
  {
    "id": 7,
    "text": "Law maa taateenaa bil malaaa'ikati in kunta minas saadiqeen"
  },
  {
    "id": 8,
    "text": "Maa nunazzilul malaaa'i kata illaa bilhaqqi wa maa kaanooo izam munzareen"
  },
  {
    "id": 9,
    "text": "Innaa Nahnu nazalnaz Zikra wa Innaa lahoo lahaa fizoon"
  },
  {
    "id": 10,
    "text": "Wa laqad arsalnaa min qablika fee shiya'il awwaleen"
  },
  {
    "id": 11,
    "text": "Wa maa yaateehim mir Rasoolin illaa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 12,
    "text": "Kazaalika naslukuhoo fee quloobil mujrimeen"
  },
  {
    "id": 13,
    "text": "Laa yu'minoona bihee wa qad khalat sunnatul awwaleen"
  },
  {
    "id": 14,
    "text": "Wa law fatahnaa 'alaihim baabam minas samaaa'i fazaloo feehi ya'rujoon"
  },
  {
    "id": 15,
    "text": "Laqaaloo innamaa sukkirat absaarunaa bal nahnu qawmum mashooroon"
  },
  {
    "id": 16,
    "text": "Wa laqad ja'alnaa fissamaaa'i buroojanw wa zaiyannaahaa linnaazireen"
  },
  {
    "id": 17,
    "text": "Wa hafiznaahaa min kulli Shaitaanir rajeem"
  },
  {
    "id": 18,
    "text": "Illaa manis taraqas sam'a fa atba'ahoo shihaabum mubeen"
  },
  {
    "id": 19,
    "text": "Wal arda madadnaahaa wa alqainaa feehaa rawaasiya wa ambatnaa feehaa min kulli shai'im mawzoon"
  },
  {
    "id": 20,
    "text": "Wa ja'alnaa lakum feehaa ma'aayisha wa mal lastum lahoo biraaziqeen"
  },
  {
    "id": 21,
    "text": "Wa im min shai'in illaa 'indanaa khazaaa 'inuhoo wa maa nunazziluhooo illaa biqadarim ma'loom"
  },
  {
    "id": 22,
    "text": "Wa arsalnar riyaaha la waaqiha fa anzalnaa minas samaaa'i maaa'an fa asqai naakumoohu wa maaa antum lahoo bikhaazineen"
  },
  {
    "id": 23,
    "text": "Wa innnaa la nahnu nuhyee wa numeetu wa nahnul waarisoon"
  },
  {
    "id": 24,
    "text": "Wa la qad 'alimnal mustaqdimeena minkum wa laqad 'alimnal mustaakhireen"
  },
  {
    "id": 25,
    "text": "Wa inna Rabbaka Huwa yahshuruhum; innahoo Hakeemun 'Aleem"
  },
  {
    "id": 26,
    "text": "Wa laqad khalaqnal insaana min salsaalim min hama im masnoon"
  },
  {
    "id": 27,
    "text": "Waljaaanna khalaqnaahu min qablu min naaris samoom"
  },
  {
    "id": 28,
    "text": "Wa iz qaala Rabbuka lilmalaaa' ikati innee khaaliqum basharam min salsaalim min hama im masnoon"
  },
  {
    "id": 29,
    "text": "Fa izaa sawwaituhoo wa nafakhtu feehi mir roohee faqa'oo lahoo saajideen"
  },
  {
    "id": 30,
    "text": "Fasajadal malaaa'ikatu kulluhum ajma'oon"
  },
  {
    "id": 31,
    "text": "Illaaa ibleesa abaaa ai yakoona ma'as saajideen"
  },
  {
    "id": 32,
    "text": "Qaala yaaa Ibleesu maa laka allaa takoona ma'as saajideen"
  },
  {
    "id": 33,
    "text": "Qaala lam akul li asjuda libasharin khalaqtahoo min salsaalim min hama im masnoon"
  },
  {
    "id": 34,
    "text": "Qaala fakhruj minhaa fa innaka rajeem"
  },
  {
    "id": 35,
    "text": "Wa inna 'alaikal la'nata ilaa Yawmid Deen"
  },
  {
    "id": 36,
    "text": "Qaala Rabbi fa anzirneee ilaa Yawmi yub'asoon"
  },
  {
    "id": 37,
    "text": "Qaala fa innaka minal munzareen"
  },
  {
    "id": 38,
    "text": "Ilaa Yawmil waqtil ma'loom"
  },
  {
    "id": 39,
    "text": "Qaala Rabbi bimaaa aghwaitanee la uzayyin anna lahum fil ardi wa la ughwiyan nahum ajma'een"
  },
  {
    "id": 40,
    "text": "Illaa 'ibaadaka minhumul mukhlaseen"
  },
  {
    "id": 41,
    "text": "Qaala haaza Siraatun 'alaiya Mustaqeem"
  },
  {
    "id": 42,
    "text": "Inna 'ibaadee laisa laka 'alaihim sultaanun illaa manittaba'aka minal ghaaween"
  },
  {
    "id": 43,
    "text": "Wa inna jahannama lamaw'iduhum ajma'een"
  },
  {
    "id": 44,
    "text": "Lahaa sab'atu abwaab; likulli baabim minhum juz'um maqsoom"
  },
  {
    "id": 45,
    "text": "Innal muttaqeena fee Jannaatinw wa 'uyoon"
  },
  {
    "id": 46,
    "text": "Udkhuloohaa bisalaamin aamineen"
  },
  {
    "id": 47,
    "text": "Wa naza'naa ma fee sudoorihim min ghillin ikhwaanan 'alaa sururim mutaqaabileen"
  },
  {
    "id": 48,
    "text": "Laa yamas suhum feehaa nasabunw wa maa hum minhaa bimukhrajeen"
  },
  {
    "id": 49,
    "text": "Nabbi' 'ibaadeee annneee anal Ghafoorur Raheem"
  },
  {
    "id": 50,
    "text": "Wa anna 'azaabee huwal 'azaabul aleem"
  },
  {
    "id": 51,
    "text": "Wa nabbi'hum 'an daifi Ibraaheem"
  },
  {
    "id": 52,
    "text": "Iz dakhaloo 'alaihi faqaaloo salaaman qaala innaa minkum wajiloon"
  },
  {
    "id": 53,
    "text": "Qaaloo la tawjal innaa nubashshiruka bighulaamin 'aleem"
  },
  {
    "id": 54,
    "text": "Qaala abashshartumoonee 'alaaa am massaniyal kibaru fabima tubashshiroon"
  },
  {
    "id": 55,
    "text": "Qaaloo bashsharnaaka bilhaqqi falaa takum minal qaaniteen"
  },
  {
    "id": 56,
    "text": "Qaala wa mai yaqnatu mir rahmati Rabbiheee illad daaaloon"
  },
  {
    "id": 57,
    "text": "Qaala famaa khatbukum aiyuhal mursaloon"
  },
  {
    "id": 58,
    "text": "Qaaloo innaaa ursilnaaa ilaa qawmim mujrimeen"
  },
  {
    "id": 59,
    "text": "Illaaa Aala Loot; innaa lamunajjoohum ajma'een"
  },
  {
    "id": 60,
    "text": "Illam ra atahoo qaddarnaaa innahaa laminal ghaabireen"
  },
  {
    "id": 61,
    "text": "Falamma jaaa'a Aala Lootinil mursaloon"
  },
  {
    "id": 62,
    "text": "Qaala innakum qawmum munkaroon"
  },
  {
    "id": 63,
    "text": "Qaaloo bal ji'naaka bimaa kaanoo feehi yamtaroon"
  },
  {
    "id": 64,
    "text": "Wa atainaaka bilhaqqi wa innaa lasaadiqoon"
  },
  {
    "id": 65,
    "text": "Fa asri bi ahlika biqit'im minal laili wattabi' adbaarahum wa laa yaltafit minkum ahadunw wamdoo haisu tu'maroon"
  },
  {
    "id": 66,
    "text": "Wa qadainaaa ilaihi zaalikal amra anna daabira haaa'ulaaa'i maqtoo'um musbiheen"
  },
  {
    "id": 67,
    "text": "Wa jaaa'a ahlul madeenati yastabshiroon"
  },
  {
    "id": 68,
    "text": "Qaala inna haaa'ulaaa'i daifee falaa tafdahoon"
  },
  {
    "id": 69,
    "text": "Wattaqul laaha wa laa tukhzoon"
  },
  {
    "id": 70,
    "text": "Qaalooo awalam nanhaka 'anil 'aalameen"
  },
  {
    "id": 71,
    "text": "Qaala haaa'ulaaa'i banaateee in kuntum faa'ileen"
  },
  {
    "id": 72,
    "text": "La'amruka innahum lafee sakratihim ya'mahoon"
  },
  {
    "id": 73,
    "text": "Fa akhazat humus saihatu mushriqeen"
  },
  {
    "id": 74,
    "text": "Faja'alnaa 'aaliyahaa saafilahaa wa amtarnaa 'alaihim hijaaratam min sijjeel"
  },
  {
    "id": 75,
    "text": "Inna fee zaalika la Aayaatil lilmutawassimeen"
  },
  {
    "id": 76,
    "text": "Wa innahaa labi sabeelim muqeem"
  },
  {
    "id": 77,
    "text": "Inna fee zaalika la Aayatal lilmu'mineen"
  },
  {
    "id": 78,
    "text": "Wa in kaana Ashaabul Aikati lazaalimeen"
  },
  {
    "id": 79,
    "text": "Fantaqamnaa minhum wa innahumaa labi imaamim mubeen"
  },
  {
    "id": 80,
    "text": "Wa laqad kazzaba ashaabul Hijril mursaleen"
  },
  {
    "id": 81,
    "text": "Wa aatainaahum Aayaatinaa fakaanoo 'anhaa mu'rideen"
  },
  {
    "id": 82,
    "text": "Wa kaanoo yanhitoona minal jibaali buyootan aamineen"
  },
  {
    "id": 83,
    "text": "Fa akhazat humus saihatu musbiheen"
  },
  {
    "id": 84,
    "text": "Famaaa aghnaa 'anhum maa kaanoo yaksiboon"
  },
  {
    "id": 85,
    "text": "Wa maa khalaqnas samaawaati wal arda wa maa bainahumaaa illaa bilhaqq; wa innas Saa'ata la aatiyatun fasfahis safhal jameel"
  },
  {
    "id": 86,
    "text": "Inna Rabbaka Huwal khallaaqul 'aleem"
  },
  {
    "id": 87,
    "text": "Wa laqad aatainaaka sab'am minal masaanee wal Qur-aanal 'Azeem"
  },
  {
    "id": 88,
    "text": "Laa tamuddanna 'ainaika ilaa maa matta 'naa biheee azwaajam minhum wa laa tahzan 'alaihim wakhfid janaahaka lilmu 'mineen"
  },
  {
    "id": 89,
    "text": "Wa qul inneee anan nazeerul mubeen"
  },
  {
    "id": 90,
    "text": "Kamaaa anzalnaa 'alal muqtasimeen"
  },
  {
    "id": 91,
    "text": "Allazeena ja'alul Quraana'ideen"
  },
  {
    "id": 92,
    "text": "Fawa Rabbika lanas'a lannahum ajma'een"
  },
  {
    "id": 93,
    "text": "'Ammaa kaanoo ya'maloon"
  },
  {
    "id": 94,
    "text": "Fasda' bimaa tu'maru wa a'rid anil mushrikeen"
  },
  {
    "id": 95,
    "text": "Innaa kafainaakal mustahzi'een"
  },
  {
    "id": 96,
    "text": "Allazeena yaj'aloona ma'al laahi ilaahan aakhar; fasawfa ya'lamoon"
  },
  {
    "id": 97,
    "text": "Wa laqad na'lamu annaka yadeequ sadruka bimaa yaqooloon"
  },
  {
    "id": 98,
    "text": "Fasabbih bihamdi Rabbika wa kum minas saajideen"
  },
  {
    "id": 99,
    "text": "Wa'bud Rabbaka hattaa yaatiyakal yaqeen"
  }
];

export default en;
