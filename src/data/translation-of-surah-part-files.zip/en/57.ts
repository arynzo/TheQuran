import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Sabbaha lillaahi maa fissamaawaati wal ard; wa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 2,
    "text": "Lahoo mulkus samaawaati wal ard; yuhyee wa yumeet; wa Huwa 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 3,
    "text": "Huwal Awwalu wal'Aakhiru waz Zaahiru wal Baatinu wa huwa bikulli shai'in Aleem"
  },
  {
    "id": 4,
    "text": "Huwal lazee khalaqas samaawaati wal arda fee sittati ayyaamin summas tawaa 'alal 'Arsh; ya'lamu maa yaliju filardi wa maa yakhruju minhaa wa maa yanzilu minas samaaa'i wa maa ya'ruju feeha wa Huwa ma'akum ayna maa kuntum; wallaahu bimaa ta'maloona Baseer"
  },
  {
    "id": 5,
    "text": "Lahoo mulkus samaawaati wal ard; wa ilal laahi turja'ul umoor"
  },
  {
    "id": 6,
    "text": "Yoolijul laila fin nahaari wa yoolijun nahaara fil lail; wa Huwa 'Aleemum bizaatis sudoor"
  },
  {
    "id": 7,
    "text": "Aaaminoo billaahi wa Rasoolihee wa anfiqoo mimmaa ja'alakum mustakh lafeena feehi fallazeena aamanoo minkum wa anfaqoo lahum ajrun kabeer"
  },
  {
    "id": 8,
    "text": "Wa maa lakum laa tu'minoona billaahi war Rasoolu yad'ookum li tu'minoo bi Rabbikum wa qad akhaza meesaaqakum in kuntum mu'mineen"
  },
  {
    "id": 9,
    "text": "Huwal lazee yunazzilu 'alaa 'abdiheee Aayaatim baiyinaatil liyukhrijakum minaz zulumaati ilan noor; wa innal laaha bikum la Ra'oofur Raheem"
  },
  {
    "id": 10,
    "text": "Wa maa lakum allaa tunfiqoo fee sabeelil laahi wa lillaahi meeraasus samaawaati wal- ard; laa yastawee minkum man anfaqa min qablil fat-hi wa qaatal; ulaaa'ika a'zamu darajatam minal lazeena anfaqoo min ba'du wa qaataloo; wa kullanw wa'ad allaahul husnaa; wallaahu bimaa ta'maloona Khabeer"
  },
  {
    "id": 11,
    "text": "Man zal lazee yuqridul laaha qardan hasanan fa yudaa'ifahoo lahoo wa lahooo ajrun kareem"
  },
  {
    "id": 12,
    "text": "Yawma taral mu'mineena walmu'minaati yas'aa nooruhum baina aydeehim wa bi aymaanihim bushraakumul yawma jannaatun tajree min tahtihal anhaaru khaalideena feeha; zaalika huwal fawzul 'azeem"
  },
  {
    "id": 13,
    "text": "Yawma yaqoolul munaafiqoona walmunaafiqaatu lil lazeena aamanu unzuroonaa naqtabis min noorikum qeelarji'oo waraaa'akum faltamisoo nooran faduriba bainahum bisooril lahoo baabun, baatinuhoo feehir rahmatu wa zaahiruhoo min qibalihi-'azaab"
  },
  {
    "id": 14,
    "text": "Yunaadoonahum alam nakum ma'akum qaaloo balaa wa laakinnakum fatantum anfusakum wa tarabbastum wartabtum wa gharratkumul amaaniyyu hatta jaaa'a amrul laahi wa gharrakum billaahil gharoor"
  },
  {
    "id": 15,
    "text": "Fal Yawma laa yu'khazu minkum fidyatunw wa laa minal lazeena kafaroo; ma'waakumun Naaru hiya maw laakum wa bi'sal maseer"
  },
  {
    "id": 16,
    "text": "Alam ya'ni lil lazeena aamanooo an takhsha'a quloobuhum lizikril laahi wa maa nazala minal haqqi wa laa yakoonoo kallazeena ootul Kitaaba min qablu fataala 'alaihimul amadu faqasat quloobuhum wa kaseerum minhum faasiqoon"
  },
  {
    "id": 17,
    "text": "I'lamooo annal laaha yuhyil arda ba'da mawtihaa; qad baiyannaa lakumul Aayaati la'allakum ta'qiloon"
  },
  {
    "id": 18,
    "text": "Innal mussaddiqeena wal mussaddiqaati wa aqradul laaha qardan hassanany yudaa'afu lahum wa lahum ajrun kareem"
  },
  {
    "id": 19,
    "text": "Wallazeena aamanoo billaahi wa Rusuliheee ulaaa'ika humus siddeeqoon; wash shuhadaaa'u 'inda Rabbihim lahum ajruhum wa nooruhum; wallazeena kafaroo wa kazzaboo bi aayaatinaaa ulaaa'ika As haabul jaheem"
  },
  {
    "id": 20,
    "text": "I'lamooo annamal hayaa tud dunyaa la'ibunw wa lahwunw wa zeenatunw wa tafaakhurum bainakum wa takaasurun fil amwaali wal awlaad, kamasali ghaisin a'jabal kuffaara nabaatuhoo summa yaheeju fataraahu musfarran summa yakoonu hutaamaa; wa fil aakhirati 'azaabun shadeedunw wa magh firatum minal laahi wa ridwaan; wa mal haiyaa tuddun yaaa illaa mataa'ul ghuroor"
  },
  {
    "id": 21,
    "text": "Saabiqooo ilaa maghfiratim mir Rabbikum wa jannatin 'arduhaa ka-'ardis samaaa'i wal ardi u'iddat lillazeena aamanoo billaahi wa Rusulih; zaalika fadlul laahi yu'teehi many yashaaa'; wal laahu zul fadlil 'azeem"
  },
  {
    "id": 22,
    "text": "Maaa asaaba min museebatin fil ardi wa laa feee anfusikum illaa fee kitaabim min qabli an nabra ahaa; innaa zaalika 'alal laahi yaseer"
  },
  {
    "id": 23,
    "text": "Likailaa ta'saw 'alaa maa faatakum wa laa tafrahoo bimaaa aataakum; wallaahu laa yuhibbu kulla mukhtaalin fakhoor"
  },
  {
    "id": 24,
    "text": "Allazeeena yabkhaloona wa yaamuroonan naasa bil bukhl; wa many yatawalla fa innal laaha Huwal Ghaniyyul Hameed"
  },
  {
    "id": 25,
    "text": "Laqad arsalnaa Rusulanaa bilbaiyinaati wa anzalnaa ma'ahumul Kitaaba wal Meezaana liyaqooman naasu bilqist, wa anzalnal hadeeda feehi baasun shadeedunw wa manaafi'u linnaasi wa liya'lamal laahu many yansuruhoo wa Rusulahoo bilghaib; innal laaha Qawiyyun 'Azeez"
  },
  {
    "id": 26,
    "text": "Wa laqad arsalnaa Noohanw wa Ibraaheema wa ja'alnaa fee zurriyyatihiman nubuwwata wal Kitaaba faminhum muhtad; wa kaseerum minhum faasiqoon"
  },
  {
    "id": 27,
    "text": "Summa qaffainaa 'alaa aasaarihim bi Rusulinaa wa qaffainaa bi 'Eesab ni Maryama wa aatainaahul Injeela wa ja'alnaa fee quloobil lazeenat taba'oohu ra'fatanw wa rahmatanw wa rahbaaniyyatan ibtada'ooha maa katabnaahaa 'alaihim illab tighaaa'a ridwaanil laahi famaa ra'awhaa haqqa ri'aayatihaa; fa aatainal lazeena aamanoo minhum ajrahum; wa kaseerum minhum faasiqoon"
  },
  {
    "id": 28,
    "text": "Yaaa ayyuhal lazeena aamaanut taqullaaha wa aaminoo bi Rasoolihee yu'tikum kiflaini mir rahmatihee wa yaj'al lakum nooran tamshoona bihee wa yaghfir lakum; wallaahu Ghafoorur Raheem"
  },
  {
    "id": 29,
    "text": "Li'alla ya'lama Ahlul kitaabi allaa yaqdiroona 'alaa shai'in min fadlil laahi wa annal fadla bi Yadil laahi yu'teehi many yashaaa'; wallaahu Zul fadilil 'azeem"
  }
];

export default en;
