import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wannajmi izaa hawaa"
  },
  {
    "id": 2,
    "text": "Maa dalla saahibukum wa maa ghawaa"
  },
  {
    "id": 3,
    "text": "Wa maa yyantiqu 'anilhawaaa"
  },
  {
    "id": 4,
    "text": "In huwa illaa Wahyuny yoohaa"
  },
  {
    "id": 5,
    "text": "'Allamahoo shadeedul quwaa"
  },
  {
    "id": 6,
    "text": "Zoo mirratin fastawaa"
  },
  {
    "id": 7,
    "text": "Wa huwa bil ufuqil a'laa"
  },
  {
    "id": 8,
    "text": "Summa danaa fatadalla"
  },
  {
    "id": 9,
    "text": "Fakaana qaaba qawsaini aw adnaa"
  },
  {
    "id": 10,
    "text": "Fa awhaaa ilaa 'abdihee maaa awhaa"
  },
  {
    "id": 11,
    "text": "Maa kazabal fu'aadu maa ra aa"
  },
  {
    "id": 12,
    "text": "Afatumaaroonahoo 'alaa maayaraa"
  },
  {
    "id": 13,
    "text": "Wa laqad ra aahu nazlatan ukhraa"
  },
  {
    "id": 14,
    "text": "'Inda sidratil muntaha"
  },
  {
    "id": 15,
    "text": "'Indahaa jannatul maawaa"
  },
  {
    "id": 16,
    "text": "Iz yaghshas sidrata maa yaghshaa"
  },
  {
    "id": 17,
    "text": "Maa zaaghal basaru wa maa taghaa"
  },
  {
    "id": 18,
    "text": "Laqad ra aa min aayaati Rabbihil kubraaa"
  },
  {
    "id": 19,
    "text": "Afara'aytumul laata wal 'uzzaa"
  },
  {
    "id": 20,
    "text": "Wa manaatas saalisatal ukhraa"
  },
  {
    "id": 21,
    "text": "A-lakumuz zakaru wa lahul unsaa"
  },
  {
    "id": 22,
    "text": "Tilka izan qismatun deezaa"
  },
  {
    "id": 23,
    "text": "In hiya illaaa asmaaa'un sammaitumoohaaa antum wa aabaaa'ukum maaa anzalal laahu bihaa min sultaan; inyyattabi'oona illaz zanna wa maa tahwal anfusu wa laqad jaaa'ahum mir Rabbihimul hudaa"
  },
  {
    "id": 24,
    "text": "Am lil insaani maa taman naa"
  },
  {
    "id": 25,
    "text": "Falillaahil aakhiratu wal oolaa"
  },
  {
    "id": 26,
    "text": "Wa kam mim malakin fissamaawaati laa tughnee shafaa'atuhum shai'an illaa mim ba'di anyyaazanal laahu limany yashaaa'u wa yardaa"
  },
  {
    "id": 27,
    "text": "Innal lazeena laa yu'minoona bil aakhirati la yusammoonal malaaa'ikata tasmiyatal unsaa"
  },
  {
    "id": 28,
    "text": "Wa maa lahum bihee min 'ilmin iny yattabi'oona illaz zanna wa innaz zanna laa yughnee minal haqqi shai'aa"
  },
  {
    "id": 29,
    "text": "Fa a'rid 'am man tawallaa 'an zikrinaa wa lam yurid illal hayaatad dunyaa"
  },
  {
    "id": 30,
    "text": "Zalika mablaghuhum minal 'ilm; inna rabbaka huwa a'lamu biman dalla 'an sabee lihee wa huwa a'lamu bimanih tadaa"
  },
  {
    "id": 31,
    "text": "Wa lillaahi maa fis samaawaati wa maa fil ardi liyajziyal lazeena asaaa'oo bimaa 'amiloo wa yajziyal lazeena ahsanoo bilhusnaa"
  },
  {
    "id": 32,
    "text": "Allazeena yajtaniboona kabaaa'iral ismi walfawaa hisha illal lamam; inna rabbaka waasi'ul maghfirah; huwa a'lamu bikum iz ansha akum minal ardi wa iz antum ajinnatun fee butooni umma haatikum falaa tuzakkooo anfusakum huwa a'lamu bimanit taqaa"
  },
  {
    "id": 33,
    "text": "Afara'ayatal lazee tawallaa"
  },
  {
    "id": 34,
    "text": "Wa a'taa qaleelanw wa akdaa"
  },
  {
    "id": 35,
    "text": "A'indahoo 'ilmul ghaibi fahuwa yaraa"
  },
  {
    "id": 36,
    "text": "Am lam yunabbaa bimaa fee suhuhfi Moosa"
  },
  {
    "id": 37,
    "text": "Wa Ibraaheemal lazee waffaaa"
  },
  {
    "id": 38,
    "text": "Allaa taziru waaziratunw wizra ukhraa"
  },
  {
    "id": 39,
    "text": "Wa al laisa lil insaani illaa maa sa'aa"
  },
  {
    "id": 40,
    "text": "Wa anna sa'yahoo sawfa yuraa"
  },
  {
    "id": 41,
    "text": "Summa yujzaahul jazaaa 'al awfaa"
  },
  {
    "id": 42,
    "text": "Wa anna ilaa rabbikal muntahaa"
  },
  {
    "id": 43,
    "text": "Wa annahoo huwa adhaka wa abkaa"
  },
  {
    "id": 44,
    "text": "Wa annahoo huwa amaata wa ahyaa"
  },
  {
    "id": 45,
    "text": "Wa annahoo khalaqaz zawjainiz zakara wal unsaa"
  },
  {
    "id": 46,
    "text": "Min nutfatin izaa tumnaa"
  },
  {
    "id": 47,
    "text": "Wa anna 'alaihin nash atal ukhraa"
  },
  {
    "id": 48,
    "text": "Wa annahoo huwa aghnaa wa aqnaa"
  },
  {
    "id": 49,
    "text": "Wa annahoo huwa rabbush shi'raa"
  },
  {
    "id": 50,
    "text": "Wa annahooo ahlak a 'Aadanil oolaa"
  },
  {
    "id": 51,
    "text": "Wa samooda famaaa abqaa"
  },
  {
    "id": 52,
    "text": "Wa qawma Noohim min qablu innahum kaanoo hum azlama wa atghaa"
  },
  {
    "id": 53,
    "text": "Wal mu'tafikata ahwaa"
  },
  {
    "id": 54,
    "text": "Faghashshaahaa maa ghashshaa"
  },
  {
    "id": 55,
    "text": "Fabi ayyi aalaaa'i Rabbika tatamaaraa"
  },
  {
    "id": 56,
    "text": "Haazaa nazeerum minan nuzuril oolaa"
  },
  {
    "id": 57,
    "text": "Azifatil aazifah"
  },
  {
    "id": 58,
    "text": "Laisa lahaa min doonil laahi kaashifah"
  },
  {
    "id": 59,
    "text": "Afamin hazal hadeesi ta'jaboon"
  },
  {
    "id": 60,
    "text": "Wa tadhakoona wa laa tabkoon"
  },
  {
    "id": 61,
    "text": "Wa antum saamidoon"
  },
  {
    "id": 62,
    "text": "Fasjudoo lillaahi wa'budoo"
  }
];

export default en;
