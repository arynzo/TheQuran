import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yusabbihu lilaahi maa fis samaawaati wa maa fil ardil Malikil Quddoosil 'Azeezil Hakeem"
  },
  {
    "id": 2,
    "text": "Huwal lazee ba'asa fil ummiyyeena Rasoolam min hum yatloo 'alaihim aayaatihee wa yuzakkeehim wa yu'allimuhumul Kitaaba wal Hikmata wa in kaanoo min qablu lafee dalaalim mubeen"
  },
  {
    "id": 3,
    "text": "Wa aakhareena minhum lammaa yalhaqoo bihim wa huwal 'azeezul hakeem"
  },
  {
    "id": 4,
    "text": "Zaalika fadlul laahi yu'teehi many-yashaaa; wallaahu zul fadlil 'azeem"
  },
  {
    "id": 5,
    "text": "Masalul lazeena hum milut tawraata summa lam yahmiloohaa kamasalil himaari yah milu asfaaraa; bi'sa masalul qawmil lazeena kaazzaboo bi aayaatil laah; wallaahu laa yahdil qawmazzaalimeen"
  },
  {
    "id": 6,
    "text": "Qul yaaa ayyuhal lazeena haadoo in za'amtum annakum awliyaaa'u lillaahi min doonin naasi fatamannawul mawta in kuntum saadiqeen"
  },
  {
    "id": 7,
    "text": "Wa laa yatamannaw nahooo abadam bimaa qaddamat aydeehim; wallaahu 'aleemum biz zaalimeen"
  },
  {
    "id": 8,
    "text": "Qul innal mawtal lazee tafirroona minhu fa innahoo mulaaqeekum summa turaddoona ilaa 'Aalimil Ghaibi wash shahaadati fa yunabbi'ukum bimaa kuntum ta'maloon"
  },
  {
    "id": 9,
    "text": "Yaaa ayyuhal lazeena aamanoo izaa noodiya lis-Salaati miny yawmil Jumu'ati fas'aw ilaa zikril laahi wa zarul bai'; zaalikum khayrul lakum in kuntum ta'lamoon"
  },
  {
    "id": 10,
    "text": "Fa-izaa qudiyatis Salaatu fantashiroo fil ardi wabtaghoo min fadlil laahi wazkurul laaha kaseeral la'allakum tuflihoon"
  },
  {
    "id": 11,
    "text": "Wa izaa ra'aw tijaaratan aw lahwanin faddooo ilaihaa wa tarakooka qaaa'imaa; qul maa 'indal laahi khairum minal lahwi wa minat tijaarah; wallaahu khayrur raaziqeen"
  }
];

export default en;
