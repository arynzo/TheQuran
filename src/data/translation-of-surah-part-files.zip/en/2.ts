import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Meeem"
  },
  {
    "id": 2,
    "text": "Zaalikal Kitaabu laa raiba feeh; hudal lilmuttaqeen"
  },
  {
    "id": 3,
    "text": "Allazeena yu'minoona bilghaibi wa yuqeemoonas salaata wa mimmaa razaqnaahum yunfiqoon"
  },
  {
    "id": 4,
    "text": "Wallazeena yu'minoona bimaa unzila ilaika wa maaa unzila min qablika wa bil Aakhirati hum yooqinoon"
  },
  {
    "id": 5,
    "text": "Ulaaa'ika 'alaa hudam mir rabbihim wa ulaaa'ika humul muflihoon"
  },
  {
    "id": 6,
    "text": "Innal lazeena kafaroo sawaaa'un 'alaihim 'a-anzar tahum am lam tunzirhum laa yu'minoon"
  },
  {
    "id": 7,
    "text": "Khatamal laahu 'alaa quloobihim wa 'alaa sam'i-him wa 'alaaa absaarihim ghishaa watunw wa lahum 'azaabun 'azeem"
  },
  {
    "id": 8,
    "text": "Wa minan naasi mainy yaqoolu aamannaa billaahi wa bil yawmil aakhiri wa maa hum bimu'mineen"
  },
  {
    "id": 9,
    "text": "Yukhaadi'oonal laaha wallazeena aamanoo wa maa yakhda'oona illaaa anfusahum wa maa yash'uroon"
  },
  {
    "id": 10,
    "text": "Fee quloobihim mara dun fazaadahumul laahu maradah; wa lahum 'azaabun aleemum bimaa kaanoo yakziboon"
  },
  {
    "id": 11,
    "text": "Wa izaa qeela lahum laa tufsidoo fil ardi qaalooo innamaa nahnu muslihoon"
  },
  {
    "id": 12,
    "text": "Alaaa innahum humul mufsidoona wa laakil laa yash'uroon"
  },
  {
    "id": 13,
    "text": "Wa izaa qeela lahum aaminoo kamaaa aamanan naasu qaalooo anu'minu kamaaa aamanas sufahaaa'; alaaa innahum humus sufahaaa'u wa laakil laa ya'lamoon"
  },
  {
    "id": 14,
    "text": "Wa izaa laqul lazeena aamanoo qaalooo aamannaa wa izaa khalaw ilaa shayaateenihim qaalooo innaa ma'akum innamaa nahnu mustahzi'oon"
  },
  {
    "id": 15,
    "text": "Allahu yastahzi'u bihim wa yamudduhum fee tughyaanihim ya'mahoon"
  },
  {
    "id": 16,
    "text": "Ulaaa'ikal lazeenash tara wud dalaalata bilhudaa famaa rabihat tijaaratuhum wa maa kaanoo muhtadeen"
  },
  {
    "id": 17,
    "text": "Masaluhum kamasalillazis tawqada naaran falammaaa adaaa'at maa hawlahoo zahabal laahu binoorihim wa tarakahum fee zulumaatil laa yubsiroon"
  },
  {
    "id": 18,
    "text": "Summum bukmun 'umyun fahum laa yarji'oon"
  },
  {
    "id": 19,
    "text": "Aw kasaiyibim minas samaaa'i feehi zulumaatunw wa ra'dunw wa barq, yaj'aloona asaabi'ahum feee aazaanihim minas sawaa'iqi hazaral mawt' wallaahu muheetum bilkaafireen"
  },
  {
    "id": 20,
    "text": "Yakaadul barqu yakhtafu absaarahum kullamaaa adaaa'a lahum mashaw feehi wa izaaa azlama 'alaihim qaamoo; wa law shaaa'al laahu lazahaba bisam'ihim wa absaarihim; innal laaha 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 21,
    "text": "Yaaa aiyuhan naasu'budoo Rabbakumul lazee khalaqakum wallazeena min qablikum la'allakum tattaqoon"
  },
  {
    "id": 22,
    "text": "Allazee ja'ala lakumul arda firaashanw wassamaaa'a binaaa 'anw wa anzala minassamaaa'i maaa'an fa akhraja bihee minas samaraati rizqal lakum falaa taj'aloo lillaahi andaadanw wa antum ta'lamoon"
  },
  {
    "id": 23,
    "text": "Wa in kuntum fee raibim mimmaa nazzalnaa 'alaa 'abdinaa fatoo bi Sooratim mim mislihee wad'oo shuhadaaa'akum min doonil laahi in kuntum saadiqeen"
  },
  {
    "id": 24,
    "text": "Fail lam taf'aloo wa lan taf'aloo fattaqun Naaral latee waqooduhan naasu walhijaaratu u'iddat lilkaafireen"
  },
  {
    "id": 25,
    "text": "Wa bashshiril lazeena aamanoo wa 'amilus saalihaati anna lahum jannaatin tajree min tahtihal anhaaru kullamaa ruziqoo minhaa min samaratir rizqan qaaloo haazal lazee ruziqnaa min qablu wa utoo bihee mutashaabihaa, wa lahum feehaaa azwaajum mutahhara tunw wa hum feehaa khaalidoon"
  },
  {
    "id": 26,
    "text": "Innal laaha laa yastahyeee ai yadriba masalam maa ba'oodatan famaa fawqahaa; faammal lazeena aamanoo faya'lamoona annahul haqqu mir rabbihim wa ammal lazeena kafaroo fayaqooloona maazaaa araadal laahu bihaazaa masalaa; yudillu bihee kaseeranw wa yahdee bihee kaseeraa; wa maa yudillu biheee illal faasiqeen"
  },
  {
    "id": 27,
    "text": "Allazeena yanqudoona 'ahdal laahi mim ba'di meesaaqihee wa yaqta'oona maaa amaral laahu biheee ai yoosala wa yufsidoona fil ard; ulaaa'ika humul khaasiroon"
  },
  {
    "id": 28,
    "text": "Kaifa takfuroona billaahi wa kuntum amwaatan fa ahyaakum summa yumeetukum summa yuhyeekum summaa ilaihi turja'oon"
  },
  {
    "id": 29,
    "text": "Huwal lazee khalaqa lakum maa fil ardi jamee'an summas tawaaa ilas samaaa'i fasaw waahunna sab'a samaa waat; wa Huwa bikulli shai'in Aleem"
  },
  {
    "id": 30,
    "text": "Wa iz qaala rabbuka lil malaaa'ikati innee jaa'ilun fil ardi khaleefatan qaalooo ataj'alu feehaa mai yufsidu feehaa wa yasfikud dimaaa'a wa nahnu nusabbihu bihamdika wa nuqaddisu laka qaala inneee a'lamu maa laa ta'lamoon"
  },
  {
    "id": 31,
    "text": "Wa 'allama Aadamal asmaaa'a kullahaa summa 'aradahum 'alal malaaa'ikati faqaala ambi'oonee bias maaa'i haaa'ulaaa'i in kuntum saadiqeen"
  },
  {
    "id": 32,
    "text": "Qaaloo subhaanaka laa 'ilma lanaaa illaa maa 'allamtanaaa innaka antal'aleemul hakeem"
  },
  {
    "id": 33,
    "text": "Qaala yaaa Aadamu ambi' hum biasmaaa'ihim falammaa amba ahum bi asmaaa'ihim qaala alam aqul lakum inneee a'lamu ghaibas samaawaati wal ardi wa a'lamu maa tubdoona wa maa kuntum taktumoon"
  },
  {
    "id": 34,
    "text": "Wa iz qulnaa lilmalaaa'i katis judoo liAadama fasajadooo illaaa Ibleesa abaa wastakbara wa kaana minal kaafireen"
  },
  {
    "id": 35,
    "text": "Wa qulnaa yaaa Aadamus kun anta wa zawjukal jannata wa kulaa minhaa raghadan haisu shi'tumaa wa laa taqrabaa haazihish shajarata fatakoonaa minaz zaalimeen"
  },
  {
    "id": 36,
    "text": "Fa azallahumash Shaitaanu 'anhaa fa akhrajahumaa mimmaa kaanaa fee; wa qulnah bitoo ba'dukum liba'din 'aduwwunw wa lakum fil ardi mustaqarrunw wa mataa'un ilaa heen"
  },
  {
    "id": 37,
    "text": "Fatalaqqaaa Aadamu mir Rabbihee Kalimaatin fataaba 'alaihi; innahoo Huwat Tawwaabur Raheem"
  },
  {
    "id": 38,
    "text": "Qulnah bitoo minhaa jamee 'an fa immaa ya'tiyannakum minnee hudan faman tabi'a hudaaya falaa khawfun 'alaihim wa laa hum yahza noon"
  },
  {
    "id": 39,
    "text": "Wallazeena kafaroo wa kaz zabooo bi aayaatinaa ulaaa'ika Ashaabun Naari hum feehaa khaalidoon"
  },
  {
    "id": 40,
    "text": "Yaa Baneee Israaa'eelaz kuroo ni'matiyal lateee an'amtu 'alaikum wa awfoo bi'Ahdeee oofi bi ahdikum wa iyyaaya farhaboon"
  },
  {
    "id": 41,
    "text": "Wa aaminoo bimaaa anzaltu musaddiqal limaa ma'akum wa laa takoonooo awwala kaafirim bihee wa laa tashtaroo bi Aayaatee samanan qaleelanw wa iyyaaya fattaqoon"
  },
  {
    "id": 42,
    "text": "Wa laa talbisul haqqa bilbaatili wa taktumul haqqa wa antum ta'lamoon"
  },
  {
    "id": 43,
    "text": "Wa aqeemus salaata wa aatuz zakaata warka'oo ma'ar raaki'een"
  },
  {
    "id": 44,
    "text": "Ataamuroonan naasa bilbirri wa tansawna anfusakum wa antum tatloonal Kitaab; afalaa ta'qiloon"
  },
  {
    "id": 45,
    "text": "Wasta'eenoo bissabri was Salaah; wa innahaa lakabee ratun illaa alal khaashi'een"
  },
  {
    "id": 46,
    "text": "Allazeena yazunnoona annahum mulaaqoo Rabbihim wa annahum ilaihi raaji'oon"
  },
  {
    "id": 47,
    "text": "Yaa Baneee Israaa'eelaz kuroo ni'matiyal lateee an'amtu 'alaikum wa annee faddaltukum 'alal 'aalameen"
  },
  {
    "id": 48,
    "text": "Wattaqoo Yawmal laa tajzee nafsun 'an nafsin shai'anw wa laa yuqbalu minhaa shafaa'atunw wa laa yu'khazu minhaa 'adlunw wa laa hum yunsaroon"
  },
  {
    "id": 49,
    "text": "Wa iz najjainaakum min Aali Fir'awna yasoomoonakum sooo'al azaabi yuzabbihoona abnaaa'akum wa yastahyoona nisaaa'akum; wa fee zaalikum balaaa'um mir Rabbikum 'azeem"
  },
  {
    "id": 50,
    "text": "Wa iz faraqnaa bikumul bahra fa anjainaakum wa agh-raqnaaa Aala Fir'awna wa antum tanzuroon"
  },
  {
    "id": 51,
    "text": "Wa iz waa'adnaa Moosaaa arba'eena lailatan summattakhaztumul 'ijla mim ba'dihee wa antum zaalimoon"
  },
  {
    "id": 52,
    "text": "Summa 'afawnaa 'ankum mim ba'di zaalika la'allakum tashkuroon"
  },
  {
    "id": 53,
    "text": "Wa iz aatainaa Moosal kitaaba wal Furqaana la'allakum tahtadoon"
  },
  {
    "id": 54,
    "text": "Wa iz qaala Moosaa liqawmihee yaa qawmi innakum zalamtum anfusakum bittikhaa zikumul 'ijla fatoobooo ilaa Baari'ikum faqtulooo anfusakum zaalikum khairul lakum 'inda Baari'ikum fataaba 'alaikum; innahoo Huwat Tawwaabur Raheem"
  },
  {
    "id": 55,
    "text": "Wa iz qultum yaa Moosaa lan nu'mina laka hattaa naral laaha jahratan fa akhazat kumus saa'iqatu wa antum tanzuroon"
  },
  {
    "id": 56,
    "text": "Summa ba'asnaakum mim ba'di mawtikum la'allakum tashkuroon"
  },
  {
    "id": 57,
    "text": "Wa zallalnaa 'alaikumul ghamaama wa anzalnaa 'alaikumul Manna was Salwaa kuloo min taiyibaati maa razaqnaakum wa maa zalamoonaa wa laakin kaanooo anfusahum yazlimoon"
  },
  {
    "id": 58,
    "text": "Wa iz qulnad khuloo haazihil qaryata fakuloo minhaa haisu shi'tum raghadanw wadkhulul baaba sujjadanw wa qooloo hittatun naghfir lakum khataayaakum; wa sanazeedul muhsineen"
  },
  {
    "id": 59,
    "text": "Fabaddalal lazeena zalamoo qawlan ghairal lazee qeela lahum fa anzalnaa 'alal lazeena zalamoo rijzam minas samaaa'i bimaa kaanoo yafsuqoon"
  },
  {
    "id": 60,
    "text": "Wa izis tasqaa Moosaa liqawmihee faqulnad rib bi'asaakal hajara fanfajarat minhusnataaa 'ashrata 'aynan qad 'alima kullu unaasim mash rabahum kuloo washraboo mir rizqil laahi wa laa ta'saw fil ardi mufsideen"
  },
  {
    "id": 61,
    "text": "Wa iz qultum yaa Moosaa lan nasbira 'alaa ta'aaminw waahidin fad'u lanaa rabbaka yukhrij lanaa mimmaa tumbitul ardu mimbaqlihaa wa qis saaa'ihaa wa foomihaa wa 'adasihaa wa basalihaa qaala atastabdiloonal lazee huwa adnaa billazee huwa khayr; ihbitoo misran fa inna lakum maa sa altum; wa duribat 'alaihimuz zillatu walmaskanatu wa baaa'oo bighadabim minal laah; zaalika bi annahum kaano yakfuroona bi aayaatil laahi wa yaqtuloonan Nabiyyeena bighairil haqq; zaalika bimaa 'asaw wa kaanoo ya'tadoon"
  },
  {
    "id": 62,
    "text": "Innal lazeena aamanoo wallazeena haadoo wan nasaaraa was Saabi'eena man aamana billaahi wal yawmil aakhiri wa 'amila saalihan falahum ajruhum 'inda Rabbihim wa laa khawfun 'alaihim wa laa hum yahzanoon"
  },
  {
    "id": 63,
    "text": "Wa iz akhaznaa meesaaqakum wa rafa'naa fawqakumut Toora khuzoo maaa aatainaakum biquwwatinw wazkuroo maa feehi la'allakum tattaqoon"
  },
  {
    "id": 64,
    "text": "Summa tawallaitum mim ba'di zaalika falawlaa fadlul laahi 'alaikum wa rahmatuhoo lakuntum minal khaasireen"
  },
  {
    "id": 65,
    "text": "Wa laqad 'alimtumul lazeena'-tadaw minkum fis Sabti faqulnaa lahum koonoo qiradatan khaasi'een"
  },
  {
    "id": 66,
    "text": "Faja'alnaahaa nakaalal limaa baina yadaihaa wa maa khalfahaa wa maw'izatal lilmuttaqeen"
  },
  {
    "id": 67,
    "text": "Wa iz qaala Moosaa liqawmiheee innal laaha yaamurukum an tazbahoo baqaratan qaalooo atattakhizunna huzuwan qaala a'oozu billaahi an akoona minal jaahileen"
  },
  {
    "id": 68,
    "text": "Qaalud-'u lanaa rabbaka yubaiyil lanaa maa hee; qaala innahoo yaqoolu innahaa baqaratul laa faaridunw wa laa bikrun 'awaanum baina zaalika faf'aloo maa tu'maroon"
  },
  {
    "id": 69,
    "text": "Qaalud-'u lanaa Rabbaka yubaiyil lanaa maa lawnuhaa; qaala innahoo yaqoolu innahaa baqaratun safraaa'u faaqi'ul lawnuhaa tasurrunnaazireen"
  },
  {
    "id": 70,
    "text": "Qaalud-'u lanaa Rabbaka yubaiyil lanaa maa hiya innal baqara tashaabaha 'alainaa wa innaaa in shaaa'al laahu lamuhtadoon"
  },
  {
    "id": 71,
    "text": "Qaala innahoo yaqoolu innahaa baqaratul laa zaloolun tuseerul arda wa laa tasqil harsa musallamatullaa shiyata feehaa; qaalul 'aana jita bilhaqq; fazabahoohaa wa maa kaado yaf'aloon"
  },
  {
    "id": 72,
    "text": "Wa iz qataltum nafsan faddaara'tum feehaa wallaahu mukhrijum maa kuntum taktumoon"
  },
  {
    "id": 73,
    "text": "Faqulnad riboohu biba'dihaa; kazaalika yuhyil laa hul mawtaa wa yureekum aayaatihee la'allakum ta'qiloon"
  },
  {
    "id": 74,
    "text": "Summa qasat quloobukum mim ba'di zaalika fahiya kalhijaarati aw-ashaadu qaswah; wa inna minal hijaarati lamaa yatafajjaru minhul anhaar; wa inna minhaa lamaa yash shaqqaqu fayakhruju minhul maaa'; wa inna minhaa lamaa yahbitu min khashyatil laa; wa mal laahu bighaafilin 'ammaa ta'maloon"
  },
  {
    "id": 75,
    "text": "Afatatma'oona ai yu'minoo lakum wa qad kaana fareequm minhum yasma'oona Kalaamal laahi summa yuharri foonahoo mim ba'di maa'aqaloohu wa hum ya'lamoon"
  },
  {
    "id": 76,
    "text": "Wa izaa laqul lazeena aamanoo qaalooo aamannaa wa izaakhalaa ba'duhum ilaa ba'din qaalooo atuhaddisoonahum bimaa fatahal laahu 'alaikum liyuhaajjookum bihee 'inda rabbikum; afalaa ta'qiloon"
  },
  {
    "id": 77,
    "text": "Awalaa ya'lamoona annal laaha ya'lamu maa yusirroona wa maa yu'linoon"
  },
  {
    "id": 78,
    "text": "Wa minhum ummiyyoona laa ya'lamoonal kitaaba illaaa amaaniyya wa in hum illaa yazunnoon"
  },
  {
    "id": 79,
    "text": "Fawailul lillazeena yaktuboonal kitaaba bi aidihim summa yaqooloona haazaa min 'indil laahi liyashtaroo bihee samanan qaleelan fawailul lahum mimmaa katabat aydeehim wa wailul lahum mimmaa yaksiboon"
  },
  {
    "id": 80,
    "text": "Wa qaaloo lan tamassanan Naaru illaaa ayyaamam ma'doo dah; qul attakhaztum 'indal laahi 'ahdan falai yukhlifal laahu 'ahdahooo am taqooloona 'alal laahi maa laa ta'lamoon"
  },
  {
    "id": 81,
    "text": "Balaa man kasaba sayyi'atanw wa ahaatat bihee khateee'atuhoo fa-ulaaa'ika Ashaabun Naari hum feehaa khaalidoon"
  },
  {
    "id": 82,
    "text": "Wallazeena aamanoo wa 'amilus saalihaati ulaaa'ika Ashaabul Jannati hum feeha khaalidoon"
  },
  {
    "id": 83,
    "text": "Wa iz akhaznaa meesaaqa Baneee Israaa'eela laa ta'budoona illal laaha wa bil waalidaini ihsaananw wa zil qurbaa walyataamaa walmasaakeeni wa qooloo linnaasi husnanw wa aqeemus salaata wa aatuzZakaata summa tawallaitum illaa qaleelam minkum wa antum mu'ridoon"
  },
  {
    "id": 84,
    "text": "Wa iz akhaznaa meesaa qakum laa tasfikoona dimaaa'akum wa laa tukhrijoona anfusakum min diyaarikum summa aqrartum wa antum tashhadoon"
  },
  {
    "id": 85,
    "text": "Summa antum haaa'ulaaa'i taqtuloona anfusakum wa tukhrijoona fareeqam minkum min diyaarihim tazaaharoona 'alaihim bil ismi wal'udwaani wa iny yaatookum usaaraa tufaadoohum wahuwa muharramun 'alaikum ikhraajuhum; afatu' mi-noona biba'dil Kitaabi wa takfuroona biba'd; famaa jazaaa'u mai yaf'alu zaalika minkum illaa khizyun fil hayaatid-dunyaa wa yawmal qiyaamati yuraddoona ilaaa ashaddil 'azaab; wa mal laahu bighaafilin 'ammaa ta'maloon"
  },
  {
    "id": 86,
    "text": "Ulaaa'ikal lazeenash tarawul hayaatad dunyaa bil aakhirati falaa yukhaffafu 'anhumul 'azaabu wa laa hum yunsaroon"
  },
  {
    "id": 87,
    "text": "Wa laqad aatainaa Moosal Kitaaba wa qaffainaa mim ba'dihee bir Rusuli wa aatainaa 'Eesab-na-Maryamal baiyinaati wa ayyadnaahu bi Roohil Qudus; afakullamaa jaaa'akum Rasoolum bimaa laa tahwaaa anfusukumus takbartum fafareeqan kazzabtum wa fareeqan taqtuloon"
  },
  {
    "id": 88,
    "text": "Wa qaaloo quloobunaa ghulf; bal la'anahumul laahu bikufrihim faqaleelam maa yu'minoon"
  },
  {
    "id": 89,
    "text": "Wa lammaa jaaa'ahum Kitaabum min 'indil laahi musaddiqul limaa ma'ahum wa kaanoo min qablu yastaftihoona 'alal lazeena kafaroo falammaa jaaa'ahum maa 'arafoo kafaroo bih; fala 'natul laahi 'alal kaafireen"
  },
  {
    "id": 90,
    "text": "Bi'samash taraw biheee anfusahum ai yakfuroo bimaaa anzalal laahu baghyan ai yunazzilal laahu min fadlihee 'alaa mai yashaaa'u min ibaadihee fabaaa'oo bighadabin 'alaa ghadab; wa lilkaafireena 'azaabum muheen"
  },
  {
    "id": 91,
    "text": "Wa izaa qeela lahum aaminoo bimaaa anzalal laahu qaaloo nu'minu bimaaa unzila 'alainaa wa yakfuroona bimaa waraaa'ahoo wa huwal haqqu musaddiqal limaa ma'ahum; qul falima taqtuloona Ambiyaaa'al laahi min qablu in kuntum mu'mineen"
  },
  {
    "id": 92,
    "text": "Wa laqad jaaa'akum Moosa bilbaiyinaati summat takhaztumul 'ijla mim ba'dihee wa antum zaalimoon"
  },
  {
    "id": 93,
    "text": "Wa iz akhaznaa meesaaqakum wa rafa'naa fawqa kumut Toora khuzoo maaa aatainaakum biquwwatinw wasma'oo qaaloo sami'naa wa 'asainaa wa ushriboo fee quloobihimul 'ijla bikufrihim; qul bi'samaa yaamurukum biheee eemaanukum in kuntum mu'mineen"
  },
  {
    "id": 94,
    "text": "Qul in kaanat lakumud Daarul Aakhiratu 'indal laahi khaalisatam min doonin naasi fatamannawul mawta in kuntum saadiqeen"
  },
  {
    "id": 95,
    "text": "Wa lai yatamannawhu abadam bimaa qaddamat aydeehim; wallaahu 'aleemum bizzaalimeen"
  },
  {
    "id": 96,
    "text": "Wa latajidannahum ahrasannaasi 'alaa hayaatinw wa minal lazeena ashrakoo; yawaddu ahaduhum law yu'ammaru alfa sanatinw wa maa huwa bi muzahzihihee minal 'azaabi ai yu'ammar; wallaahu baseerum bimaa ya'maloon"
  },
  {
    "id": 97,
    "text": "Qul man kaana 'aduwwal li Jibreela fainnahoo nazzalahoo 'alaa qalbika bi iznil laahi musaddiqal limaa baina yadaihi wa hudanw wa bushraa lilmu'mineen"
  },
  {
    "id": 98,
    "text": "Man kaana 'aduwwal lillaahi wa malaaa'ikatihee wa Rusulihee wa Jibreela wa Meekaala fa innal laaha 'aduwwul lilkaafireen"
  },
  {
    "id": 99,
    "text": "Wa laqad anzalnaaa ilaika Aayaatim baiyinaatinw wa maa yakfuru bihaaa illal faasiqoon"
  },
  {
    "id": 100,
    "text": "Awa kullamaa 'aahadoo ahdan nabazahoo fareequm minhum; bal aksaruhum laa yu'minoon"
  },
  {
    "id": 101,
    "text": "Wa lammaa jaaa'ahum Rasoolum min 'indil laahi musaddiqul limaa ma'ahum nabaza fareequm minal lazeena ootul Kitaaba Kitaabal laahi waraaa'a zuhoorihim ka annahum laa ya'lamoon"
  },
  {
    "id": 102,
    "text": "Wattaba'oo maa tatlush Shayaateenu 'alaa mulki Sulaimaana wa maa kafara Sulaimaanu wa laakinnash Shayatteena kafaroo yu'al limoonan naasas sihra wa maaa unzila 'alal malakaini bi Baabila Haaroota wa Maaroot; wa maa yu'allimaani min ahadin hattaa yaqoolaaa innamaa nahnu fitnatun falaa takfur fayata'al lamoona minhumaa maa yufarriqoona bihee bainal mar'i wa zawjih; wa maa hum bidaaarreena bihee min ahadin illaa bi-iznillah; wa yata'allamoona maa yadurruhum wa laa yanfa'uhum; wa laqad 'alimoo lamanish taraahu maa lahoo fil Aakhirati min khalaaq; wa labi'sa maa sharaw biheee anfusahum; law kaanoo ya'lamoon"
  },
  {
    "id": 103,
    "text": "Wa law annahum aamanoo wattaqaw lamasoobatum min 'indillaahi khairun law kaanoo ya'lamoon"
  },
  {
    "id": 104,
    "text": "Yaaa ayyuhal lazeena aamanoo laa taqooloo raa'inaa wa qoolun zurnaa wasma'oo; wa lilkaafireena 'azaabun aleem"
  },
  {
    "id": 105,
    "text": "Maa yawaddul lazeena kafaroo min ahlil kitaabi wa lal mushrikeena ai-yunazzala 'alaikum min khairim mir Rabbikum; wallaahu yakhtassu birahmatihee mai-yashaaa; wallaahu zul fadlil'azeem"
  },
  {
    "id": 106,
    "text": "Maa nansakh min aayatin aw nunsihaa na-ti bikhairim minhaaa aw mislihaaa; alam ta'lam annal laaha 'alaa kulli shai'in qadeer"
  },
  {
    "id": 107,
    "text": "Alam ta'lam annallaaha lahoo mulkus samaawaati wal ard; wa maa lakum min doonil laahi minw waliyyinw wa laa naseer"
  },
  {
    "id": 108,
    "text": "Am tureedoona an tas'aloo Rasoolakum kamaa su'ila Moosa min qabl; wa mai yatabaddalil kufra bil eemaani faqad dalla sawaaa'as sabeel"
  },
  {
    "id": 109,
    "text": "Wadda kaseerum min ahlil kitaabi law yaruddoo nakum mim ba'di eemaanikum kuffaaran hasadam min 'indi anfusihim mim ba'di maa tabaiyana lahumul haqqu fa'foo wasfahoo hattaa yaa tiyallaahu bi amrih; innal laaha 'alaa kulli shai'in qadeer"
  },
  {
    "id": 110,
    "text": "Wa aqeemus salaata wa aatuz zakaah; wa maa tuqaddimoo li anfusikum min khairin tajidoohu 'indal laah; innal laaha bimaa ta'maloona baseer"
  },
  {
    "id": 111,
    "text": "Wa qaaloo lai yadkhulal jannata illaa man kaana Hoodan aw Nasaaraa; tilka amaaniyyuhum; qul haatoo burhaa nakum in kuntum saadiqeen"
  },
  {
    "id": 112,
    "text": "Balaa man aslama wajhahoo lillaahi wa huwa muhsinun falahooo ajruhoo 'inda rabbihee wa laa khawfun 'alaihim wa laa hum yahzanoon"
  },
  {
    "id": 113,
    "text": "Wa qaalatil Yahoodu laisatin Nasaaraa 'alaa shai'inw-wa qaalatin Nasaaraaa laisatil Yahoodu 'alaa shai'inw'wa hum yatloonal Kitaab; kazaalika qaalal lazeena la ya'lamoona misla qawlihim; fallaahu yahkumu bainahum Yawmal Qiyaamati feemaa kaanoo feehi yakhtalifoon"
  },
  {
    "id": 114,
    "text": "Wa man azlamu mimmam-mana'a masaajidal laahi ai-yuzkara feehas muhoo wa sa'aa fee kharaabihaaa; ulaaa'ika maa kaana lahum ai yadkhuloohaaa illaa khaaa'ifeen; lahum fiddunyaa khizyunw wa lahum fil aakhirati 'azaabun 'azeem"
  },
  {
    "id": 115,
    "text": "Wa lillaahil mashriqu walmaghrib; fa aynamaa tuwalloo fasamma wajhullaah; innal laaha waasi'un Aleem"
  },
  {
    "id": 116,
    "text": "Wa qaalut takhazal laahu waladan subhaanahoo bal lahoo maa fis samaawaati wal ardi kullul lahoo qaanitoon"
  },
  {
    "id": 117,
    "text": "Badeee'us samaawaati wal ardi wa izaa qadaaa amran fa innamaa yaqoolu lahoo kun fayakoon"
  },
  {
    "id": 118,
    "text": "Wa qaalal lazeena laa ya'lamoona law laa yukallimunal laahu aw taateenaaa aayah; kazaalika qaalal lazeena min qablihim misla qawlihim; tashaabahat quloobuhum; qad baiyannal aayaati liqawminy yooqinoon"
  },
  {
    "id": 119,
    "text": "Innaaa arsalnaaka bilhaqqi basheeranw wa nazeeranw wa laa tus'alu 'an Ashaabil Jaheem"
  },
  {
    "id": 120,
    "text": "Wa lan tardaa 'ankal Yahoodu wa lan Nasaaraa hattaa tattabi'a millatahum; qul inna hudal laahi huwalhudaa; wa la'init taba'ta ahwaaa'ahum ba'dal lazee jaaa'aka minal 'ilmimaa laka minal laahi minw waliyyinw wa laa naseer"
  },
  {
    "id": 121,
    "text": "Allazeena aatainaahumul Kitaaba yatloonahoo haqqa tilaawatiheee ulaaa'ika yu'minoona bih; wa mai yakfur bihee fa ulaaa'ika humul khaasiroon"
  },
  {
    "id": 122,
    "text": "Yaa Baneee Israaa'eelaz-kuroo ni'matiyal lateee an'amtu 'alaikum wa annee faddaltukum 'alal 'aalameen"
  },
  {
    "id": 123,
    "text": "Wattaqoo yawmal laa tajzee nafsun 'an nafsin shai 'anw wa laa yuqbalu minhaa 'adlunw wa laa tanfa'uhaa shafaa 'atunw wa laa hum yunsaroon"
  },
  {
    "id": 124,
    "text": "Wa izib talaaa Ibraaheema Rabbuhoo bi Kalimaatin fa atammahunna qaala Innee jaa'iluka linnaasi Imaaman qaala wa min zurriyyatee qaala laa yanaalu 'ahdiz zaalimeen"
  },
  {
    "id": 125,
    "text": "Wa iz ja'alnal Baita masaabatal linnaasi wa amnanw wattakhizoo mim Maqaami Ibraaheema musallaaa; wa 'ahidnaaa ilaaa Ibraaheema wa Ismaa'eela an tahhiraa Baitiya littaaa'ifeena wal'aakifeena warrukka'is sujood"
  },
  {
    "id": 126,
    "text": "Wa iz qaala Ibraaheemu Rabbij 'al haazaa baladan aaminanw warzuq ahlahoo minas samaraati man aamana minhum billaahi wal yawmil aakhiri qaala wa man kafara faumatti'uhoo qaleelan summa adtarruhooo ilaa 'azaabin Naari wa bi'salmaseer"
  },
  {
    "id": 127,
    "text": "Wa iz yarfa'u Ibraaheemul qawaa'ida minal Baitiwa Ismaa'eelu Rabbanaa taqabbal minnaa innaka Antas Samee'ul Aleem"
  },
  {
    "id": 128,
    "text": "Rabbanaa waj'alnaa muslimaini laka wa min zurriyyatinaaa ummatam muslimatal laka wa arinaa manaasikanaa wa tub 'alainaa innaka antat Tawwaabur Raheem"
  },
  {
    "id": 129,
    "text": "Rabbanaa wab'as feehim Rasoolam minhum yatloo 'alaihim aayaatika wa yu'allimuhumul Kitaaba wal Hikmata wa yuzakkeehim; innaka Antal 'Azeezul Hakeem"
  },
  {
    "id": 130,
    "text": "Wa mai yarghabu 'am-Millati Ibraaheema illaa man safiha nafsah; wa laqadis tafainaahu fid-dunyaa wa innahoo fil aakhirati laminas saaliheen"
  },
  {
    "id": 131,
    "text": "Iz qaala lahoo Rabbuhooo aslim qaala aslamtu li Rabbil 'aalameen"
  },
  {
    "id": 132,
    "text": "Wa wassaa bihaaa Ibraaheemu baneehi wa Ya'qoob, yaa baniyya innal laahas tafaa lakumud deena falaa tamootunna illaa wa antum muslimoon"
  },
  {
    "id": 133,
    "text": "Am kuntum shuhadaaa'a iz hadara Ya'qoobal mawtu iz qaala libaneehi maa ta'budoona mim ba'dee qaaloo na'budu ilaahaka wa ilaaha aabaaa'ika Ibraaheema wa Ismaa'eela wa Ishaaqa Ilaahanw waahidanw wa nahnu lahoo muslimoon"
  },
  {
    "id": 134,
    "text": "Tilka ummatun qad khalat lahaa maa kasabat wa lakum maa kasabtum wa laa tus'aloona 'ammaa kaanoo ya'maloon"
  },
  {
    "id": 135,
    "text": "Wa qaaloo koonoo Hoodan aw Nasaaraa tahtadoo; qul bal Millata Ibraaheema Haneefanw wa maa kaana minal mushrikeen"
  },
  {
    "id": 136,
    "text": "Qoolooo aamannaa billaahi wa maaa unzila ilainaa wa maaa unzila ilaaa Ibraaheema wa Ismaa'eela wa Ishaaqa wa Ya'qooba wal Asbaati wa maaootiya Moosa wa 'Eesaa wa maaa ootiyan Nabiyyoona mir Rabbihim laa nufarriqoo baina ahadim minhum wa nahnu lahoo muslimoon"
  },
  {
    "id": 137,
    "text": "Fa in aamanoo bimisli maaa aamantum bihee faqadih tadaw wa in tawallaw fa innamaa hum fee shiqaaq; fasayakfeekahumul laah; wa Huwas Samee'ul Aleem"
  },
  {
    "id": 138,
    "text": "Sibghatal laahi wa man ahsanu minal laahi sibghatanw wa nahnu lahoo 'aabidoon"
  },
  {
    "id": 139,
    "text": "Qul atuhaaajjoonanaa fil laahi wa Huwa Rabbunaa wa Rabbukum wa lanaa a'maalunaa wa lakum a'maalukum wa nahnu lahoo mukhlisoon"
  },
  {
    "id": 140,
    "text": "Am taqooloona inna Ibraaheema wa Ismaa'eela wa Ishaaqa wa Ya'qooba wal asbaata kaanoo Hoodan aw Nasaaraa; qul 'a-antum a'lamu amil laah; wa man azlamu mimman katama shahaadatan 'indahoo minallaah; wa mallaahu bighaafilin 'ammaa ta'maloon"
  },
  {
    "id": 141,
    "text": "Tilka ummatun qad khalat lahaa maa kasabat wa lakum maa kasabtum wa laa tus'aloona 'ammaa kaano ya'maloon"
  },
  {
    "id": 142,
    "text": "Sayaqoolus sufahaaa'u minan naasi maa wallaahum 'an Qiblatihimul latee kaanoo 'alaihaa; qul lillaahil mashriqu walmaghrib; yahdee mai yashaaa'u ilaa Siraatim Mustaqeem"
  },
  {
    "id": 143,
    "text": "Wa kazaalika ja'alnaakum ummatanw wasatal litakoonoo shuhadaaa'a 'alan naasi wa yakoonar Rasoolu 'alaikum shaheedaa; wa maa ja'alnal qiblatal latee kunta 'alaihaaa illaa lina'lama mai yattabi'ur Rasoola mimmai yanqalibu 'alaa 'aqibayh; wa in kaanat lakabeeratan illaa 'alal lazeena hadal laah; wa maa kaanal laahu liyudee'a eemaanakum; innal laaha binnaasi la Ra'oofur Raheem"
  },
  {
    "id": 144,
    "text": "Qad naraa taqalluba wajhika fis samaaa'i fala nuwalliyannaka qiblatan tardaahaa; fawalli wajhaka shatral Masjidil haaram; wa haisu maa kuntum fawalloo wujoohakum shatrah; wa innal lazeena ootul Kitaaba laya'lamoona annahul haqqu mir Rabbihim; wa mal laahu bighaafilin 'ammaa ya'maloon"
  },
  {
    "id": 145,
    "text": "Wa la'in ataital lazeena ootul kitaaba bikulli aayatim maa tabi'oo Qiblatak; wa maaa anta bitaabi'in Qiblatahum; wa maa ba'duhum bitaabi''in Qiblata ba'd; wa la'init taba'ta ahwaaa'ahum mim ba'di maa jaaa'aka minal 'ilmi innaka izal laminaz zaalimeen"
  },
  {
    "id": 146,
    "text": "Allazeena aatainaahumul kitaaba ya'rifoonahoo kamaa ya'rifoona abnaaa'ahum wa inna fareeqam minhum layaktumoonal haqqa wa hum ya'lamoon"
  },
  {
    "id": 147,
    "text": "Alhaqqu mir Rabbika falaa takoonana minal mumtareen"
  },
  {
    "id": 148,
    "text": "Wa likullinw wijhatun huwa muwalleehaa fastabiqul khairaat; ayna maa takoonoo yaati bikumullaahu jamee'aa; innal laaha 'alaa kulli shai'in qadeer"
  },
  {
    "id": 149,
    "text": "Wa min haisu kharajta fawalli wajhaka shatral Masjidil Haraam; wa innahoo lalhaqqu mir Rabbik; wa mallaahu bighaafilin 'ammaa ta'maloon"
  },
  {
    "id": 150,
    "text": "Wa min haisu kharajta fawalli wajhaka shatral Masjidil Haraam; wa haisu maa kuntum fawalloo wujoohakum shatrahoo li'allaa yakoona linnaasi 'alaikum hujjatun illal lazeena zalamoo minhum falaa takhshawhum wakhshawnee wa liutimma ni'matee 'alaikum wa la'allakum tahtadoon"
  },
  {
    "id": 151,
    "text": "Kamaaa arsalnaa feekum Rasoolam minkum yatloo 'alaikum aayaatina wa yuzakkeekum wa yu'alli mukumul kitaaba wal hikmata wa yu'allimukum maa lam takoonoo ta'lamoon"
  },
  {
    "id": 152,
    "text": "Fazkurooneee azkurkum washkuroo lee wa laa takfuroon"
  },
  {
    "id": 153,
    "text": "Yaaa ayyuhal laazeena aamanus ta'eenoo bissabri was Salaah; innal laaha ma'as- saabireen"
  },
  {
    "id": 154,
    "text": "Wa laa taqooloo limai yuqtalu fee sabeelil laahi amwaat; bal ahyaaa'unw wa laakil laa tash'uroon"
  },
  {
    "id": 155,
    "text": "Wa lanablu wannakum bishai'im minal khawfi waljoo'i wa naqsim minal amwaali wal anfusi was samaraat; wa bashshiris saabireen"
  },
  {
    "id": 156,
    "text": "Allazeena izaaa asaabathum museebatun qaalooo innaa lillaahi wa innaaa ilaihi raaji'oon"
  },
  {
    "id": 157,
    "text": "Ulaaa'ika 'alaihim salawaatun mir Rabbihim wa rahma; wa ulaaa'ika humul muhtadoon"
  },
  {
    "id": 158,
    "text": "Innas Safaa wal-Marwata min sha'aaa'iril laahi faman hajjal Baita awi'tamara falaa junaaha 'alaihi ai yattawwafa bihimaa; wa man tatawwa'a khairan fa innal laaha Shaakirun'Aleem"
  },
  {
    "id": 159,
    "text": "Innal lazeena yaktumoona maaa anzalnaa minal baiyinaati walhudaa mim ba'di maa baiyannaahu linnaasi fil kitaabi ulaaa'ika yal'anuhumul laahu wa yal'anuhumul laa 'inoon"
  },
  {
    "id": 160,
    "text": "Illal lazeena taaboo wa aslahoo wa baiyanoo fa ulaaa'ika atoobu 'alaihim; wa Anat Tawwaabur Raheem"
  },
  {
    "id": 161,
    "text": "Innal lazeena kafaroo wamaa too wa hum kuffaarun ulaaa'ika 'alaihim la 'natul laahi walmalaa'ikati wannaasi ajma'een"
  },
  {
    "id": 162,
    "text": "khaalideena feeha laa yukhaffafu 'anhumul 'azaabu wa laa hum yunzaroon"
  },
  {
    "id": 163,
    "text": "Wa ilaahukum illaahunw waahid, laaa ilaaha illaa Huwar Rahmaanur Raheem"
  },
  {
    "id": 164,
    "text": "Inna fee khalqis samaawaati wal ardi wakhtilaafil laili wannahaari walfulkil latee tajree fil bahri bimaa yanfa'unnaasa wa maaa anzalal laahu minas samaaa'i mim maaa'in fa ahyaa bihil arda ba'da mawtihaa wa bas sa feehaa min kulli daaabbatinw wa tasreefir riyaahi wassahaabil musakhkhari bainas samaaa'i wal ardi la aayaatil liqawminy ya'qiloon"
  },
  {
    "id": 165,
    "text": "Wa minan naasi mai yattakhizu min doonil laahi andaadai yuhibboonahum kahubbil laahi wallazeena aamanooo ashaddu hubbal lillah; wa law yaral lazeena zalamoo iz yarawnal 'azaaba annal quwwata lillaahi jamee'anw wa annallaaha shadeedul 'azaab"
  },
  {
    "id": 166,
    "text": "Iz tabarra al lazeenat tubi'oo minal lazeenattaba'oo wa ra awul 'azaaba wa taqatta'at bihimul asbaab"
  },
  {
    "id": 167,
    "text": "Wa qaalal lazeenat taba'oo law anna lanaa karratan fanatabarra a minhum kamaa tabarra'oo minnaa; kazaalika yureehimullaahu a'maalahum hasaraatin 'alaihim wa maa hum bikhaarijeena minan Naar"
  },
  {
    "id": 168,
    "text": "Yaaa ayyuhan naasu kuloo mimmaa fil ardi halaalan taiyibanw wa laa tattabi'oo khutu waatish Shaitaan; innahoo lakum 'aduwwum mubeen"
  },
  {
    "id": 169,
    "text": "Innamaa yaamurukum bissooo'i walfahshaaa'i wa an taqooloo alal laahi maa laa ta'lamoon"
  },
  {
    "id": 170,
    "text": "Wa izaa qeela lahumuttabi'oo maaa anzalal laahu qaaloo bal nattabi'u maaa alfainaa 'alaihi aabaaa'anaaa; awalaw kaana aabaaa'uhum laa ya'qiloona shai'anw wa laa yahtadoon"
  },
  {
    "id": 171,
    "text": "Wa masalul lazeena kafaroo kamasalil lazee yan'iqu bimaa laa yasma'u illaa du'aaa'anw wa nidaaa'aa; summum bukmun 'umyun fahum laa ya'qiloon"
  },
  {
    "id": 172,
    "text": "Yaaa ayyuhal lazeena aamanoo kuloo min taiyibaati maa razaqnaakum washkuroo lillaahi in kuntum iyyaahu ta'budoon"
  },
  {
    "id": 173,
    "text": "Innamaa harrama 'alaikumul maitata waddama wa lahmal khinzeeri wa maaa uhilla bihee lighairil laahi famanid turra ghaira baaghinw wa laa 'aadin falaaa isma 'alaih; innal laaha Ghafoorur Raheem"
  },
  {
    "id": 174,
    "text": "Innal lazeena yaktumoona maaa anzalal laahu minal kitaabi wa yashtaroona bihee samanan qaleelan ulaaa'ika maa yaakuloona fee butoonihim illan Naara wa laa yukallimu humul laahu Yawmal Qiyaamati wa laa yuzakkeehim wa lahum 'azaabun aleem"
  },
  {
    "id": 175,
    "text": "Ulaaa'ikal lazeenash tarawud dalaalata bilhudaa wal'azaaba bilmaghfirah; famaaa asbarahum 'alan Naar"
  },
  {
    "id": 176,
    "text": "Zaalika bi annal laaha nazzalal kitaaba bilhaqq; wa innal lazeenakh talafoo fil kitaabi lafee shiqaaqim ba'eed"
  },
  {
    "id": 177,
    "text": "Laisal birra an tuwalloo wujoohakum qibalal mashriqi walmaghribi wa laakinnal birra man aamana billaahi wal yawmil aakhiri wal malaaa 'ikati wal kitaabi wan nabiyyeena wa aatalmaala 'alaa hubbihee zawilqurbaa walyataa maa walmasaakeena wabnas sabeeli wassaaa'ileena wa firriqaabi wa aqaamas salaata wa aataz zakaata walmoofoona bi ahdihim izaa 'aahadoo wasaabireena fil baasaaa'i waddarraaa'i wa heenal baas; ulaaa'ikal lazeena sadaqoo wa ulaaa 'ika humul muttaqoon"
  },
  {
    "id": 178,
    "text": "Yaaa ayyuhal lazeena aamanoo kutiba alaikumul qisaasu fil qatlaa alhurru bilhurri wal'abdu bil'abdi wal unsaa bil unsaa; faman 'ufiya lahoo min akheehi shai'un fattibaa'um bilma'roofi wa adaaa'un ilaihi bi ihsaan; zaalika takhfeefum mir rabikum wa rahmah; famani' tadaa ba'da zaalika falahoo 'azaabun aleem"
  },
  {
    "id": 179,
    "text": "Wa lakum fil qisaasi hayaatuny yaaa ulil albaabi la 'allakum tattaqoon"
  },
  {
    "id": 180,
    "text": "Kutiba 'alaikum izaa hadara ahadakumul mawtu in taraka khairanil wasiyyatu lilwaalidaini wal aqrabeena bilma'roofi haqqan 'alalmut taqeen"
  },
  {
    "id": 181,
    "text": "Famam baddalahoo ba'da maa sami'ahoo fa innamaaa ismuhoo 'alallazeena yubaddi loonah; innallaha Samee'un 'Aleem"
  },
  {
    "id": 182,
    "text": "Faman khaafa mim moosin janafan aw isman fa aslaha bainahum falaaa ismaa 'alayh; innal laaha Ghafoorur Raheem"
  },
  {
    "id": 183,
    "text": "Yaa ayyuhal lazeena aamanoo kutiba 'alaikumus Siyaamu kamaa kutiba 'alal lazeena min qablikum la'allakum tattaqoon"
  },
  {
    "id": 184,
    "text": "Ayyaamam ma'doodaat; faman kaana minkum mareedan aw'alaa safarin fa'iddatum min ayyaamin ukhar; wa 'alal lazeena yuteeqoonahoo fidyatun ta'aamu miskeenin faman tatawwa'a khairan fahuwa khairul lahoo wa an tasoomoo khairul lakum in kuntum ta'lamoon"
  },
  {
    "id": 185,
    "text": "Shahru Ramadaanallazeee unzila feehil Qur'aanu hudal linnaasi wa baiyinaatim minal hudaa wal furqaan; faman shahida minkumush shahra falyasumhu wa man kaana mareedan aw 'alaa safarin fa'iddatum min ayyaamin ukhar; yureedul laahu bikumul yusra wa laa yureedu bikumul 'usra wa litukmilul 'iddata wa litukabbirul laaha 'alaa maa hadaakum wa la'allakum tashkuroon"
  },
  {
    "id": 186,
    "text": "Wa izaa sa alaka 'ibaadee 'annnee fa innee qareebun ujeebu da'wataddaa'i izaa da'aani falyastajeeboo lee wal yu'minoo bee la'allahum yarshudoon"
  },
  {
    "id": 187,
    "text": "Uhilla lakum laylatas Siyaamir rafasu ilaa nisaaa'ikum; hunna libaasullakum wa antum libaasullahunn; 'alimal laahu annakum kuntum takhtaanoona anfusakum fataaba 'alaikum wa 'afaa 'ankum fal'aana baashiroo hunna wabtaghoo maa katabal laahoo lakum; wa kuloo washraboo hattaa yatabaiyana lakumul khaitul abyadu minal khaitil aswadi minal fajri summa atimmus Siyaama ilal layl; wa laa tubaashiroo hunna wa antum 'aakifoona fil masaajid; tilka hudoodul laahi falaa taqraboohaa; kazaalika yubaiyinul laahu aayaatihee linnaasi la'allahum yattaqoon"
  },
  {
    "id": 188,
    "text": "Wa laa taakuloo amwaalakum bainakum bilbaatili wa tudloo bihaaa ilal hukkaami litaakuloo fareeqam min amwaalin naasi bil ismi wa antum ta'lamoon"
  },
  {
    "id": 189,
    "text": "Yas'aloonaka 'anil ahillati qul hiya mawaaqeetu linnaasi wal Hajj; wa laisal birru bi an ta'tul buyoota min zuhoorihaa wa laakinnal birra manit taqaa; wa'tul buyoota min abwaa bihaa; wattaqullaaha la'allakum tuflihoon"
  },
  {
    "id": 190,
    "text": "Wa qaatiloo fee sabeelillaahil lazeena yuqaatiloonakum wa laa ta'tadooo; innal laaha laa yuhibbul mu'tadeen"
  },
  {
    "id": 191,
    "text": "Waqtuloohum haisu saqif tumoohum wa akhrijoohum min haisu akhrajookum; walfitnatu ashaddu minal qatl; wa laa tuqaatiloohum 'indal Masjidil Haraami hattaa yaqaatilookum feehi fa in qaatalookum faqtuloohum; kazaalika jazaaa'ul kaafireen"
  },
  {
    "id": 192,
    "text": "Fa ininn-tahaw fa innal laaha Ghafoorur Raheem"
  },
  {
    "id": 193,
    "text": "Wa qaatiloohum hatta laa takoona fitnatunw wa yakoonad deenu lillaahi fa-inin tahaw falaa 'udwaana illaa 'alaz zaalimeen"
  },
  {
    "id": 194,
    "text": "Ash Shahrul Haraamu bish Shahril Haraami wal hurumaatu qisaas; famani'tadaa 'alaikum fa'tadoo 'alaihi bimisli ma'tadaa 'alaikum; wattaqul laaha wa'lamooo annal laaha ma'al muttaqeen"
  },
  {
    "id": 195,
    "text": "Wa anfiqoo fee sabeelil laahi wa laa tulqoo bi aydeekum ilat tahlukati wa ahsinoo; innal laaha yuhibbul muhsineen"
  },
  {
    "id": 196,
    "text": "Wa atimmul Hajja wal Umarata lillaah; fain uhsirtum famas taisara minal hadyi walaa tahliqoo ru'oosakum hatta yablughal hadyu mahillah; faman kaana minkum mareedan aw biheee azam mir ra'sihee fafidyatum min Siyaamin aw sadaqatin aw nusuk; fa izaaa amintum faman tamatta'a bil 'Umrati ilal Hajji famastaisara minal hadyi; famal lam yajid fa Siyaamu salaasati ayyaamin fil Hajji wa sab'atin izaa raja'tum; tilka 'asharatun kaamilah; zaalika limal lam yakun ahluhoo haadiril Masjidil Haraam; wattaqul laaha wa'lamoo annal laaha shadeedul'iqaab"
  },
  {
    "id": 197,
    "text": "Al-Hajju ashhurum ma'-loomaat; faman farada feehinnal hajja falaa rafasa wa laa fusooqa wa laa jidaala fil Hajj; wa maa taf'aloo min khairiny ya'lamhul laah; wa tazawwadoo fa inna khairaz zaadit taqwaa; wattaqooni yaaa ulil albaab"
  },
  {
    "id": 198,
    "text": "Laisa 'alaikum junaahun an tabtaghoo fad lam mir rabbikum; fa izaaa afadtum min 'Arafaatin fazkurul laaha 'indal-Mash'aril Haraami waz kuroohu kamaa hadaakum wa in kuntum min qablihee laminad daaalleen"
  },
  {
    "id": 199,
    "text": "Summa afeedoo min haisu afaadan naasu wastagh firullaah; innal laaha Ghafoor ur- Raheem"
  },
  {
    "id": 200,
    "text": "Fa-iza qadaitum manaa sikakum fazkurul laaha kazikrikum aabaaa'akum aw ashadda zikraa; faminannaasi mai yaqoolu Rabbanaaa aatinaa fiddunyaa wa maa lahoo fil Aakhirati min khalaaq"
  },
  {
    "id": 201,
    "text": "Wa minhum mai yaqoolu rabbanaaa aatina fid dunyaa hasanatanw wa fil aakhirati hasanatanw wa qinaa azaaban Naar"
  },
  {
    "id": 202,
    "text": "Ulaaa'ika lahum naseebum mimmaa kasaboo; wal laahu saree'ul hisaab"
  },
  {
    "id": 203,
    "text": "Wazkurul laaha feee ayyaamin ma'doodaatin; faman ta'ajjala fee yawmaini falaaa ismaa 'alaihi wa man ta akhara falaaa isma 'alayhi; limanit-taqaa; wattaqul laaha wa'lamooo annakum ilaihi tuhsharoon"
  },
  {
    "id": 204,
    "text": "Wa minan naasi mai yu'jibuka qawluhoo fil hayaatid dunyaa wa yushhidul laaha 'alaa maa fee qalbihee wa huwa aladdulkhisaam"
  },
  {
    "id": 205,
    "text": "Wa izaa tawallaa sa'aa fil ardi liyufsida feeha wa yuhlikal harsa wannasl; wallaahu laa yuhibbul fasaad"
  },
  {
    "id": 206,
    "text": "Wa izaa qeela lahuttaqil laaha akhazathul izzatu bil-ism; fahasbuhoo jahannam; wa labi'sal mihaad"
  },
  {
    "id": 207,
    "text": "Wa minan naasi mai yashree nafsahub tighaaa'a mardaatil laah; wallaahu ra'oofum bil'ibaad"
  },
  {
    "id": 208,
    "text": "Yaaa ayyuhal lazeena aamanud khuloo fis silmi kaaaffatanw wa laa tattabi'oo khutuwaatish Shaitaan; innahoo lakum 'aduwwum mubeen"
  },
  {
    "id": 209,
    "text": "Fa in zalaltum minba'di maa jaaa'atkumul baiyinaatu fa'lamoo annallaaha 'Azeezun hakeem"
  },
  {
    "id": 210,
    "text": "Hal yanzuroona illaaa ai ya'tiya humul laahu fee zulalim minal ghamaami walmalaaa'ikatu wa qudiyal amr; wa ilal laahi turja'ul umoor"
  },
  {
    "id": 211,
    "text": "Sal Banee Israaa'eela kam aatainaahum min aayatim baiyinah; wa mai yubaddil ni'matal laahi mim ba'di maa jaaa'athu fa innallaaha shadeedul'iqaab"
  },
  {
    "id": 212,
    "text": "Zuyyina lillazeena kafarul hayaatud dunyaa wa yaskharoona minal lazeena aamanoo; wallazeenat taqaw fawqahum yawmal Qiyaamah; wallaahu yarzuqu mai yashaaa'u bighairi hisaab;"
  },
  {
    "id": 213,
    "text": "Kaanan naasu ummatanw waahidatan fab'asal laahun Nabiyyeena mubashshireena wa munzireena wa anzala ma'ahumul kitaaba bilhaqqi liyahkuma bainan naasi feemakh talafoo feeh; wa makh talafa feehi 'illallazeena ootoohu mim ba'di maa jaaa'athumul baiyinaatu baghyam bainahum fahadal laahul lazeena aamanoo limakh talafoo feehi minal haqqi bi iznih; wallaahu yahdee mai yashaaa'u ilaa Siraatim Mustaqeem"
  },
  {
    "id": 214,
    "text": "Am hasibtum an tadkhulul jannata wa lammaa yaa-tikum masalul lazeena khalaw min qablikum massathumul baasaaa'u waddarraaaa'u wa zulziloo hattaa yaqoolar Rasoolu wallazeena aamanoo ma'ahoo mataa nasrul laah; alaaa inna nasral laahi qareeb"
  },
  {
    "id": 215,
    "text": "Yas'aloonaka maazaa yunfiqoona qul maaa anfaqtum min khairin falil waalidaini wal aqrabeena walyataamaa wal masaakeeni wabnis sabeel; wa maa taf'aloo min khairin fa innal laaha bihee 'Aleem"
  },
  {
    "id": 216,
    "text": "Kutiba alaikumulqitaalu wa huwa kurhullakum wa 'asaaa an takrahoo shai'anw wa huwa khairullakum wa 'asaaa an tuhibbo shai'anw wa huwa sharrullakum; wallaahu ya'lamu wa antum laa ta'lamoon"
  },
  {
    "id": 217,
    "text": "Yas'aloonaka 'anish Shahril Haraami qitaalin feehi qul qitaalun feehi kabeerunw wa saddun 'an sabeelil laahi wa kufrum bihee wal Masjidil Haraami wa ikhraaju ahlihee minhu akbaru 'indal laah; walfitnatu akbaru minal qatl; wa laa yazaaloona yuqaatiloonakum hatta yaruddookum 'an deenikum inis tataa'oo; wa mai yartadid minkum 'an deenihee fayamut wahuwa kaafirun fa ulaaa'ika habitat a'maaluhum fid dunyaa wal aakhirati wa ulaaa'ika ashaabun Naari hum feehaa khaalidoon"
  },
  {
    "id": 218,
    "text": "Innal lazeena aamanoo wallazeena haajaroo wa jaahadoo fee sabeelil laahi ulaaa'ika yarjoona rahmatal laah; wallaahu Ghafoorur Raheem"
  },
  {
    "id": 219,
    "text": "Yas'aloonaka 'anilkhamri walmaisiri qul feehimaaa ismun kabeerunw wa manaafi'u linnaasi wa ismuhumaa akbaru min naf'ihimaa; wa yas'aloonaka maaza yunfiqoona qulil-'afwa; kazaalika yubaiyinul laahu lakumul-aayaati la'allakum tatafakkaroon"
  },
  {
    "id": 220,
    "text": "Fid dunyaa wal aakhirah; wa yas'aloonaka 'anil yataamaa qul islaahullahum khayr, wa in tukhaalitoohum fa ikhwaanukum; wallaahu ya'lamul mufsida minalmuslih; wa law shaaa'al laahu la-a'natakum; innal laaha 'Azeezun Hakeem"
  },
  {
    "id": 221,
    "text": "Wa laatankihul mushrikaati hattaa yu'minn; wa la amatum mu'minatun khairum mim mushrikatinw wa law a'jabatkum; wa laa tunkihul mushrikeena hattaa yu'minoo; wa la'abdummu'minun khairum mimmushrikinw wa law 'ajabakum; ulaaa'ika yad'oona ilan Naari wallaahu yad'ooo ilal Jannati walmaghfirati biiznihee wa yubaiyinu Aayaatihee linnaasi la'allahum yatazakkaroon"
  },
  {
    "id": 222,
    "text": "Wa yas'aloonaka 'anil maheedi qul huwa azan fa'tazilun nisaaa'a fil maheedi wa laa taqraboo hunna hattaa yathurna fa-izaa tatah-harrna faatoohunna min haisu amarakumul laah; innallaaha yuhibbut Tawwaabeena wa yuhibbul mutatahhireen"
  },
  {
    "id": 223,
    "text": "Nisaaa'ukum harsullakum faatoo harsakum annaa shi'tum wa qaddimoo li anfusikum; wattaqul laaha wa'lamooo annakum mulaaqooh; wa bash shirilmu 'mineen"
  },
  {
    "id": 224,
    "text": "Wa laa taj'alul laaha 'urdatal li aymaanikum an tabarroo wa tattaqoo wa tuslihoo bainan naas; wallaahu Samee'un 'Aleem"
  },
  {
    "id": 225,
    "text": "Laa yu'aakhi zukumul laahu billaghwi feee aymaa nikum wa laakiny yu'aakhi zukum bimaa kasabat quloo bukum; wallaahu Ghafoorun Haleem"
  },
  {
    "id": 226,
    "text": "Lillazeena yu'loona min nisaaa'ihim tarabbusu arba'ati ashhurin fain faaa'oo fa innal laaha Ghafoorur Raheem"
  },
  {
    "id": 227,
    "text": "Wa in 'azamut talaaqa fa innal laaha Samee'un 'Aleem"
  },
  {
    "id": 228,
    "text": "Walmutallaqaatu yatarab basna bi anfusihinna salaasata qurooo'; wa laa yahillu lahunna ai yaktumna maa khalaqal laahu feee arhaaminhinna in kunna yu'minna billaahi wal yawmil aakhir; wa bu'oola tuhunna ahaqqu biraddihinna fee zaalika in araadooo islaahaa; wa lahunna mislul lazee alaihinna bilma'roof; wa lirrijjaali 'alaihinna daraja; wallaahu 'Azeezun Hakeem"
  },
  {
    "id": 229,
    "text": "Attalaaqu marrataani fa imsaakum bima'roofin aw tasreehum bi ihsaan; wa laa yahillu lakum an taakhuzoo mimmaaa aataitumoohunna shai'an illaaa ai yakhaafaaa alla yuqeemaa hudoodallahi fa in khiftum allaa yuqeemaa hudoodal laahi falaa junaaha 'Alaihimaa feemaf tadat bihee tilka hudoodul laahi falaa ta'tadoohaa; wa mai yata'adda hudoodal laahi fa ulaaa'ika humuzzaa limoon"
  },
  {
    "id": 230,
    "text": "Fa in tallaqahaa falaa tahillu lahoo mim ba'du hattaa tankiha zawjan ghairah; fa in tallaqahaa falaa junaaha 'alaihimaaa ai yataraaja'aaa in zannaaa ai yuqeemaa hudoodal laa; wa tilka hudoodul laahi yubaiyinuhaa liqawminy ya'lamoon"
  },
  {
    "id": 231,
    "text": "Wa izaa tallaqtumun nisaaa'a fabalaghna ajala hunna fa amsikoohunna bima'roofin law sarrihoo hunna bima'roof; wa laa tumsikoo hunna diraa rallita'tadoo; wa mai yaf'al zaalika faqad zalama nafsah; wa laa tattakhizooo aayaatillaahi huzuwaa; wazkuroo ni'matal laahi 'alaikum wa maaa anzala 'alaikum minal kitaabi wal hikmati ya'izukum bih; wattaqul laaha wa'lamooo annal laaha bikulli shai'in 'Aleem"
  },
  {
    "id": 232,
    "text": "Wa izaa tallaqtumun nisaaa'a fabalaghna ajalahunna falaa ta'duloo hunna ai yankihna azwaaja hunna izaa taraadaw bainahum bilma' roof; zaalika yoo'azu bihee man kaana minkum yu'minu billaahi wal yawmil aakhir; zaalikum azkaa lakum wa at-har; wallaahu ya'lamu wa antum laa ta'lamoon"
  },
  {
    "id": 233,
    "text": "Walwaa lidaatu yurdi'na awlaada hunna hawlaini kaamilaini liman araada ai yutimmar radaa'ah; wa 'alalmawloodi lahoo rizqu hunna wa kiswatuhunna bilma'roof; laatukallafu nafsun illaa wus'ahaa; laa tudaaarra waalidatum biwaladihaa wa laa mawloodul lahoo biwaladih; wa 'alal waarisi mislu zaalik; fa in araadaa Fisaalan 'an taraadim minhumaa wa tashaawurin falaa junaaha 'alaihimaa; wa in arattum an tastardi'ooo awlaadakum falaa junaaha 'alaikum izaa sallamtum maaa aataitum bilma'roof; wattaqul laaha wa'lamooo annal laaha bimaa ta'maloona baseer"
  },
  {
    "id": 234,
    "text": "Wallazeena yutawaffawna minkum wa yazaroona azwaajai yatarabbasna bi anfusihinna arba'ata ashhurinw wa 'ashran fa izaa balaghna ajalahunna falaa junaaha 'alaikum feemaa fa'alna feee anfusihinna bilma'roof; wallaahu bimaa ta'maloona Khabeer"
  },
  {
    "id": 235,
    "text": "Wa laa junaaha 'alaikum feema 'arradtum bihee min khitbatin nisaaa'i aw aknantum feee anfusikum; 'alimal laahu annakum satazkuroonahunna wa laakil laa tuwaa'idoohunna sirran illaaa an taqooloo qawlamma'roofaa; wa laa ta'zimoo 'uqdatan nikaahi hattaa yablughal kitaabu ajalah; wa'lamooo annal laaha ya'lamumaa feee anfusikum fahzarooh; wa'lamooo annallaaha Ghafoorun Haleem"
  },
  {
    "id": 236,
    "text": "Laa junaaha 'alaikum in tallaqtumun nisaaa'a maa lam tamassoohunna aw tafridoo lahunna fareedah; wa matti'hoohunna 'alal moosi'i qadaruhoo wa 'alal muqtiri qadaruhoo matta'am bilma'roofi haqqan 'alalmuhsineen"
  },
  {
    "id": 237,
    "text": "Wa in tallaqtumoohunna min qabli an tamassoohunna wa qad farad tum lahunna fareedatan fanisfu maa faradtum illaaa ai ya'foona aw ya'fuwallazee biyadihee 'uqdatunnikaah; wa an ta'fooo aqrabu littaqwaa; wa laa tansawulfadla bainakum; innal laaha bimaa ta'maloona Baseer"
  },
  {
    "id": 238,
    "text": "Haafizoo 'alas salawaati was Salaatil Wustaa wa qoomoo lillaahi qaaniteen"
  },
  {
    "id": 239,
    "text": "Fa in khiftum farijaalan aw rukbaanan fa izaaa amintum fazkurul laaha kamaa 'allamakum maa lam takoonoo ta'lamoon"
  },
  {
    "id": 240,
    "text": "Wallazeena yutawaf fawna minkum wa yazaroona azwaajanw wasiyyatal li azwaajihim mataa'an ilal hawlighaira ikhraaj; fa in kharajna falaa junaaha 'alaikum fee maa fa'alna feee anfusihinna min ma'roof; wallaahu Azeezun Hakeem"
  },
  {
    "id": 241,
    "text": "Wa lilmutallaqaati mataa'um bilma'roofi haqqan 'alal muttaqeen"
  },
  {
    "id": 242,
    "text": "Kazaalika yubaiyinul laahu lakum aayaatihee la'allakum ta'qiloon"
  },
  {
    "id": 243,
    "text": "Alam tara ilal lazeena kharajoo min diyaarihim wa hum uloofun hazaral mawti faqaaala lahumul laahu mootoo summa ahyaahum; innal laaha lazoo fadlin 'alannaasi wa laakinna aksarannaasi laa yashkuroon"
  },
  {
    "id": 244,
    "text": "Wa qaatiloo fee sabeelil laahi wa'lamooo annal laaha Samee'un 'Aleem"
  },
  {
    "id": 245,
    "text": "Man zal lazee yuqridul laaha qardan hasanan fayudaa 'ifahoo lahoo ad'aafan kaseerah; wallaahu yaqbidu wa yabsutu wa ilaihi turja'oon"
  },
  {
    "id": 246,
    "text": "Alam tara ilal malai mim Baneee Israaa'eela mim ba'di Moosaaa iz qaaloo li Nabiyyil lahumub 'as lanaa malikan nuqaatil fee sabeelillaahi qaala hal 'asaitum in kutiba 'alaikumul qitaalu allaa tuqaatiloo qaaloo wa maa lanaaa allaa nuqaatila fee sabeelil laahi wa qad ukhrijnaa min diyaarinaa wa abnaaa'inaa falammaa kutiba 'alaihimul qitaalu tawallaw illaa qaleelam minhum; wallaahu 'aleemum bizzaalimeen"
  },
  {
    "id": 247,
    "text": "Wa qaala lahum Nabiy yuhum innal laaha qad ba'asa lakum Taaloota malikaa; qaalooo annaa yakoonu lahul mulku 'alainaa wa nahnu ahaqqu bilmulki minhu wa lam yu'ta sa'atamminal maal; qaala innallaahas tafaahu 'alaikum wa zaadahoo bastatan fil'ilmi waljismi wallaahu yu'tee mulkahoo mai yashaaa'; wallaahu Waasi'un 'Aleem"
  },
  {
    "id": 248,
    "text": "Wa qaala lahum Nabiyyuhum inna Aayata mulkiheee ai yaatiyakumut Taabootu feehi sakeenatummir Rabbikum wa baqiyyatummimmaa taraka Aalu Moosa wa Aalu Haaroona tahmiluhul malaaa'ikah; inna fee zaalika la Aayatal lakum in kuntum mu'mineen"
  },
  {
    "id": 249,
    "text": "Falammaa fasala Taalootu biljunoodi qaala innal laaha mubtaleekum binaharin faman shariba minhu falaisa minnee wa mallam yat'amhu fa innahoo minneee illaa manigh tarafa ghurfatam biyadih; fashariboo minhu illaa qaleelamminhum; falammaa jaawazahoo huwa wallazeena aamanoo ma'ahoo qaaloo laa taaqata lanal yawma bi Jaaloota wa junoodih; qaalallazeena yazunnoona annahum mulaaqul laahi kam min fi'atin qaleelatin ghalabat fi'atan kaseeratam bi iznil laah; wallaahuma'as saabireen"
  },
  {
    "id": 250,
    "text": "Wa lammaa barazoo liJaaloota wa junoodihee qaaloo Rabbanaaa afrigh 'alainaa sabranw wa sabbit aqdaamanaa wansurnaa 'alal qawmil kaafireen"
  },
  {
    "id": 251,
    "text": "Fahazamoohum bi iznillaahi wa qatala Daawoodu jaaloota wa aataahul laahulmulka Wal Hikmata wa 'allamahoo mimmaa yashaaa'; wa law laa daf'ullaahin naasa ba'dahum biba'dil lafasadatil ardu wa laakinnal laaha zoo fadlin 'alal'aalameen"
  },
  {
    "id": 252,
    "text": "Tilka Aayaatul laahi natloohaa 'alaika bilhaqq; wa innaka laminal mursaleen"
  },
  {
    "id": 253,
    "text": "Tilkar Rusulu faddalnaa ba'dahum 'alaa ba'd; minhum man kallamal laahu wa rafa'a ba'dahum darajaat; wa aatainaa 'Eesab na Maryamal baiyinaati wa ayyadnaahu bi Roohil Qudus; wa law shaaa'al laahu maqtatalal lazeena mimba'dihim mim ba'di maa jaaa'athumul baiyinaatu wa laakinikh talafoo faminhum man aamana wa minhum man kafar; wa law shaaa'al laahu maq tataloo wa laakinnallaaha yaf'alu maa yureed"
  },
  {
    "id": 254,
    "text": "Yaa ayyuhal lazeena aamanoo anfiqoo mimmaa razaqnaakum min qabli ai yaatiya yawmul laa bai'un feehee wa la khullatunw wa laa shafaa'ah; walkaa firoona humuz zaalimoon"
  },
  {
    "id": 255,
    "text": "Allahu laaa ilaaha illaa Huwal Haiyul Qaiyoom; laa taakhuzuhoo sinatunw wa laa nawm; lahoo maa fissamaawaati wa maa fil ard; man zal lazee yashfa'u indahooo illaa bi-iznih; ya'lamu maa baina aydeehim wa maa khalfahum wa laa yuheetoona bishai'im min 'ilmihee illaa bimaa shaaa'; wasi'a Kursiyyuhus samaawaati wal arda wa laa Ya'ooduhoo hifzuhumaa; wa Huwal Aliyyul 'Azeem"
  },
  {
    "id": 256,
    "text": "Laaa ikraaha fid deeni qat tabaiyanar rushdu minal ghayy; famai yakfur bit Taaghooti wa yu'mim billaahi faqadis tamsaka bil'urwatil wusqaa lan fisaama lahaa; wallaahu Samee'un 'Aleem"
  },
  {
    "id": 257,
    "text": "Allaahu waliyyul lazeena aamanoo yukhrijuhum minaz zulumaati ilan noori wallazeena kafarooo awliyaaa'uhumut Taaghootu yukhrijoonahum minan noori ilaz zulumaat; ulaaa'ika Ashaabun Naari hum feehaa khaalidoon"
  },
  {
    "id": 258,
    "text": "Alam tara ilal lazee Haaajja Ibraaheema fee Rabbiheee an aataahullaahul mulka iz qaala Ibraaheemu Rabbiyal lazee yuhyee wa yumeetu qaala ana uhyee wa umeetu qaala Ibraaheemu fa innal laaha yaatee bishshamsi minal mashriqi faati bihaa minal maghribi fabuhital lazee kafar; wallaahu laa yahdil qawmaz zaalimeen"
  },
  {
    "id": 259,
    "text": "Aw kallazee marra 'alaa qaryatinw wa hiya khaawiyatun 'alaa 'urooshihaa qaala annaa yuhyee haazihil laahu ba'da mawtihaa fa amaatahul laahu mi'ata 'aamin summa ba'asahoo qaala kam labista qaala labistu yawman aw ba'da yawmin qaala bal labista mi'ata 'aamin fanzur ilaa ta'aamika wa sharaabika lam yatasannah wanzur ilaa himaarika wa linaj'alaka Aayatal linnaasi wanzur ilal'izaami kaifa nunshizuhaa summa naksoohaa lahmaa; falammaa tabayyana lahoo qaala a'lamu annal laaha 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 260,
    "text": "Wa iz qaala Ibraaheemu Rabbi arinee kaifa tuhyil mawtaa qaala awa lam tu'min qaala balaa wa laakin liyatma'inna qalbee qaala fakhuz arba'atan minat tairi fasurhunna ilaika summaj 'al 'alaa kulli jabalin minhunna juz'an summad'uu hunna ya'teenaka sa'yaa; wa'lam annal laaha 'Azeezun Hakeem"
  },
  {
    "id": 261,
    "text": "Masalul lazeena yunfiqoona amwaalahum fee sabeelil laahi kamasali habbatin ambatat sab'a sanaabila fee kulli sumbulatim mi'atu habbah; wallaahu yudaa'ifu limai yashaaa; wallaahu Waasi'un 'Aleem"
  },
  {
    "id": 262,
    "text": "Allazeena yunfiqoona amwaalahum fee sabeelillaahi summa laa yutbi'oona maaa anfaqoo mannanw wa laaa azal lahum ajruhum 'inda Rabbihim; wa laa khawfun 'alaihim wa laa hum yahzanoon"
  },
  {
    "id": 263,
    "text": "Qawlum ma'roofunw wa maghfiratun khairum min sadaqatiny yatba'uhaaa azaa; wallaahu Ghaniyyun Haleem"
  },
  {
    "id": 264,
    "text": "Yaaa ayyuhal lazeena aamanoo laa tubtiloo sadaqaatikum bilmanni wal azaa kallazee yunfiqu maalahoo ri'aaa'an naasi wa laa yu'minu billaahi wal yawmil aakhiri famasaluhoo kamasali safwaanin 'alaihi turaabun fa asaabahoo waabilun fatara kahoo saldaa; laa yaqdiroona 'alaa shai'im mimmaa kasaboo; wallaahu laa yahdil qawmal kaafireen"
  },
  {
    "id": 265,
    "text": "Wa masalul lazeena yunfiqoona amwaalahu mubtighaaa'a mardaatil laahi wa tasbeetam min anfusihim kamasali jannatim birabwatin asaabahaa waabilun fa aatat ukulahaa di'faini fa il lam yusibhaa waabilun fatall; wallaahu bimaa ta'maloona Baseer"
  },
  {
    "id": 266,
    "text": "Ayawaddu ahadukum an takoona lahoo jannatum min nakheelinw wa a'naabin tajree min tahtihal anhaaru lahoo feehaa min kullis samaraati wa asaabahul kibaru wa lahoo zurriyyatun du'afaaa'u fa asaabahaaa i'saarun feehi naarun fahtaraqat; kazaalika yubaiyinul laahu lakumul aayaati la'allakum tatafakkaroon"
  },
  {
    "id": 267,
    "text": "Yaaa 'ayyuhal lazeena aamanooo anfiqoo min taiyibaati maa kasabtum wa mimmaaa akhrajna lakum minal ardi wa laa tayammamul khabeesa minhu tunfiqoona wa lastum bi aakhizeehi illaaa an tughmidoo feeh; wa'lamooo annal laaha Ghaniyyun Hameed"
  },
  {
    "id": 268,
    "text": "Ash Shaitaanu ya'idukumul faqra wa ya'murukum bilfahshaaa'i wallaahu ya'idukum maghfiratam minhu wa fadlaa; wallaahu Waasi'un 'Aleem"
  },
  {
    "id": 269,
    "text": "Yu'til Hikmata mai yashaaa'; wa mai yu'tal Hikmata faqad ootiya khairan kaseeraa; wa maa yazzakkaru illaaa ulul albaab"
  },
  {
    "id": 270,
    "text": "Wa maaa anfaqtum min nafaqatin aw nazartum min nazrin fa innal laaha ya'lamuh; wa maa lizzaalimeena min ansaar"
  },
  {
    "id": 271,
    "text": "In tubdus sadaqaati fani'immaa hiya wa in tukhfoohaa wa tu'toohal fuqaraaa'a fahuwa khayrul lakum; wa yukaffiru 'ankum min saiyi aatikum; wallaahu bimaa ta'maloona Khabeer"
  },
  {
    "id": 272,
    "text": "Laisa 'alaika hudaahum wa laakinnal laaha yahdee mai yashaaa'; wa maa tunfiqoo min khairin fali anfusikum; wa maa tunfiqoona illab tighaaa'a wajhil laah; wa maa tunfiqoo min khairiny yuwaffa ilaikum wa antum laa tuzlamoon"
  },
  {
    "id": 273,
    "text": "Lilfuqaraaa'il lazeena uhsiroo fee sabeelil laahi laa yastatee'oona darban fil ardi yah sabuhumul jaahilu aghniyaaa'a minat ta'affufi ta'rifuhum biseemaahum laa yas'aloonan naasa ilhaafaa; wa maa tunfiqoo min khairin fa innal laaha bihee 'Aleem"
  },
  {
    "id": 274,
    "text": "Allazeena yunfiqoona amwaalahum billaili wan nahaari sirranw wa 'alaaniyatan falahum ajruhum 'inda Rabbihim wa laa khawfun 'alaihim wa laa hum yahzanoon"
  },
  {
    "id": 275,
    "text": "Allazeena yaakuloonar ribaa laa yaqoomoona illaa kamaa yaqoomul lazee yatakhabbatuhush shaitaanu minal mass; zaalika bi annahum qaalooo innamal bai'u mislur ribaa; wa ahallal laahul bai'a wa harramar ribaa; faman jaaa'ahoo maw'izatum mir rabbihee fantahaa falahoo maa salafa wa amruhooo ilal laahi wa man 'aada fa ulaaa 'ika Ashaabun naari hum feehaa khaalidoon"
  },
  {
    "id": 276,
    "text": "Yamhaqul laahur ribaa wa yurbis sadaqaat; wallaahu laa yuhibbu kulla kaffaarin aseem"
  },
  {
    "id": 277,
    "text": "Innal lazeena aamanoo wa amilus saalihaati wa aqaamus salaata wa aatawuz zakaata lahum ajruhum 'inda rabbihim wa laa khawfun 'alaihim wa laa hum yahzanoon"
  },
  {
    "id": 278,
    "text": "Yaaa ayyuhal lazeena aamanut taqul laaha wa zaroo maa baqiya minar ribaaa in kuntum mu'mineen"
  },
  {
    "id": 279,
    "text": "Fail lam taf'aloo faazanoo biharbim minal laahi wa Rasoolihee wa in tubtum falakum ru'oosu amwaalikum laa tazlimoona wa laa tuzlamoon"
  },
  {
    "id": 280,
    "text": "Wa in kaana zoo 'usratin fanaziratun ilaa maisarah; wa an tasaddaqoo khairul lakum in kuntum ta'lamoon"
  },
  {
    "id": 281,
    "text": "Wattaqoo yawman turja'oona feehi ilal laahi summa tuwaffaa kullu nafsim maa kasabat wa hum laa yuzlamoon"
  },
  {
    "id": 282,
    "text": "Yaa ayyuhal lazeena aamanoo izaa tadaayantum bidaiynin ilaa ajalimmusamman faktubooh; walyaktub bainakum kaatibum bil'adl; wa laa yaaba kaatibun ai yaktuba kamaa 'allamahul laah; falyaktub walyumlilil lazee 'alaihil haqqu walyattaqil laaha rabbahoo wa laa yabkhas minhu shai'aa; fa in kaanal lazee 'alaihil haqqu safeehan aw da'eefan aw laa yastatee'u ai yumilla huwa falyumlil waliyyuhoo bil'adl; wastash hidoo shaheedaini mir rijaalikum fa il lam yakoonaa rajulaini farajulunw wamra ataani mimman tardawna minash shuhadaaa'i an tadilla ihdaahumaa fatuzakkira ihdaahumal ukhraa; wa laa yaabash shuhadaaa'u izaa maadu'oo; wa laa tas'amooo an taktuboohu sagheeran awkabeeran ilaaa ajalih; zaalikum aqsatu 'indal laahi wa aqwamu lishshahaadati wa adnaaa allaa tartaabooo illaaa an takoona tijaaratan haadiratan tudeeroonahaa bainakum falaisa 'alaikum junaahun allaa taktuboohan; wa ashidooo izaa tabaaya'tum; wa laa yudaaarra kaatibunw wa laa shaheed; wa in taf'aloo fa innahoo fusooqum bikum; wattaqul laaha wa yu'allimu kumul laah; wallaahu bikulli shai'in 'Aleem"
  },
  {
    "id": 283,
    "text": "Wa in kuntum 'alaa safarinw wa lam tajidoo kaatiban farihaanum maqboodatun fa in amina ba'dukum ba'dan falyu'addil lazi tumina amaa natahoo walyattaqil laaha Rabbah; wa laa taktumush shahaadah; wa mai yaktumhaa fa innahooo aasimun qalbuh; wallaahu bimaa ta'maloona 'Aleem"
  },
  {
    "id": 284,
    "text": "Lillaahi maa fissamaawaati wa maa fil ard; wa in tubdoo maa feee anfusikum aw tukhfoohu yuhaasibkum bihil laa; fayaghfiru li mai yashaaa'u wa yu'azzibu mai yashaaa'u;wallaahu 'alaa kulli shai in qadeer"
  },
  {
    "id": 285,
    "text": "Aamanar-Rasoolu bimaaa unzila ilaihi mir-Rabbihee walmu'minoon; kullun aamana billaahi wa Malaaa'ikathihee wa Kutubhihee wa Rusulihee laa nufarriqu baina ahadim- mir-Rusulih wa qaaloo sami'naa wa ata'naa ghufraanaka Rabbanaa wa ilaikal-maseer"
  },
  {
    "id": 286,
    "text": "Laa yukalliful-laahu nafsan illaa wus'ahaa; lahaa maa kasabat wa 'alaihaa maktasabat; Rabbanaa laa tu'aakhiznaaa in naseenaaa aw akhta'anaa; Rabbanaa wa laa tahmil-'alainaaa isran kamaa hamaltahoo 'alal-lazeena min qablinaa; Rabbanaa wa laa tuhammilnaa maa laa taaqata lanaa bih; wa'fu 'annaa waghfir lanaa warhamnaa; Anta mawlaanaa fansurnaa 'alal qawmil kaafireen"
  }
];

export default en;
