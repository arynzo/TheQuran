import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Sooratun anzalnaahaa wa faradnaahaa wa anzalnaa feehaaa Aayaatin baiyinaatil la'allakum tazakkaroon"
  },
  {
    "id": 2,
    "text": "Azzaaniyatu wazzaanee fajlidoo kulla waahidim minhumaa mi'ata jaldatinw wa laa taakhuzkum bihimaa raafatun fee deenil laahi in kuntum tu'minoona billaahi wal Yawmil Aakhiri wal yashhad 'azaabahumaa taaa'ifatum minal mu'mineen"
  },
  {
    "id": 3,
    "text": "Azzaanee laa yankihu illaa zaaniyatan aw mushrikatanw wazzaaniyatu laa yankihuhaaa illaa zaanin aw mushrik; wa hurrima zaalika 'alal mu'mineen"
  },
  {
    "id": 4,
    "text": "Wallazeena yarmoonal muhsanaati summa lam yaatoo bi-arba'ati shuhadaaa'a fajlidoohum samaaneena jaldatanw wa laa taqbaloo lahum shahaadatan abadaa; wa ulaaa'ika humul faasiqoon"
  },
  {
    "id": 5,
    "text": "Illal lazeena taaboo mim ba'di zaalika wa aslahoo fa innal laaha Ghafoorur Raheem"
  },
  {
    "id": 6,
    "text": "Wallazeena yarmoona azwaajahum wa lam yakul lahum shuhadaaa'u illaaa anfusuhum fashahaadatu ahadihim arba'u shahaadaatim billaahi innahoo laminas saadiqeen"
  },
  {
    "id": 7,
    "text": "Wal khaamisatu anna la'natal laahi 'alaihi in kaana minal kaazibeen"
  },
  {
    "id": 8,
    "text": "Wa yadra'u anhal 'azaaba an tashhada arba'a shahaa daatim billaahi innahoo laminal kaazibeen"
  },
  {
    "id": 9,
    "text": "Wal khaamisata anna ghadabal laahi 'alaihaaa in kaana minas saadiqeen"
  },
  {
    "id": 10,
    "text": "Wa law laa fadlul laahi 'alaikum wa rahmatuhoo wa annal laaha Tawwaabun Hakeem"
  },
  {
    "id": 11,
    "text": "Innal lazeena jaaa'oo bilifki 'usbatum minkum; laa tahsaboohu sharral lakum bal huwa khairul lakum; likul limri'im minhum mak tasaba minal-ism; wallazee tawallaa kibrahoo minhum lahoo 'azaabun 'azeem"
  },
  {
    "id": 12,
    "text": "Law laaa iz sami'tumoohu zannal mu'minoona walmu'minaatu bi anfusihim khairanw wa qaaloo haazaaa ifkum mubeen"
  },
  {
    "id": 13,
    "text": "Law laa jaaa'oo 'alaihi bi-arba'ati shuhadaaa'; fa iz lam yaatoo bishshuhadaaa'i fa ulaaa 'ika 'indal laahi humul kaaziboon"
  },
  {
    "id": 14,
    "text": "Wa law laa fadlul laahi 'alaikum wa rahmatuhoo fiddunyaa wal aakhirati lamassakum fee maaa afadtum feehi 'azaabun 'azeem"
  },
  {
    "id": 15,
    "text": "Iz talaqqawnahoo bi alsinatikum wa taqooloona bi afwaahikum maa laisa lakum bihee 'ilmunw wa tahsaboo nahoo haiyinanw wa huwa 'indal laahi 'azeem"
  },
  {
    "id": 16,
    "text": "Wa law laaa iz sami'tu moohu qultum maa yakoonu lanaaa an natakallama bihaazaa Subhaanaka haaza buhtaanun 'azeem"
  },
  {
    "id": 17,
    "text": "Ya'izukumul laahu an ta'oodoo limisliheee abadan in kuntum mu'mineen"
  },
  {
    "id": 18,
    "text": "Wa yubaiyinul laahu lakumul Aayaat; wallaahu 'Aleemun Hakeem"
  },
  {
    "id": 19,
    "text": "Innal lazeena yuhibboona an tashee'al faahishatu fil lazeena aamanoo lahum 'azaabun aleemun fid dunyaa wal Aakhirah; wallaahu ya'lamu wa antum laa ta'lamoon"
  },
  {
    "id": 20,
    "text": "Wa law laa fadlul laahi 'alaikum wa rahmatuhoo wa annal laaha Ra'oofur Raheem"
  },
  {
    "id": 21,
    "text": "Yaaa aiyuhal lazeena aamanoo laa tattabi'oo khutuwaatish Shaitaan; wa many-yattabi' khutuwaatish Shaitaani fa innahoo yaamuru bilfahshaaa'i walmunkar; wa law laa fadlul laahi 'alaikum wa rahmatuhoo maa zakaa minkum min ahadin abadanw wa laakinnal laaha yuzakkee many-yashaaa'; wallaahu Samee'un 'Aleem"
  },
  {
    "id": 22,
    "text": "Wa laa yaatali ulul fadli minkum wassa'ati ai yu'tooo ulil qurbaa walmasaakeena walmuhaajireena fee sabeelillaahi walya'foo walyasfahoo; alaa tuhibboona ai yaghfiral laahu lakum; wal laahu Ghafoorur Raheem"
  },
  {
    "id": 23,
    "text": "Innal lazeena yarmoonal muhsanaatil ghaafilaatil mu'minaati lu'inoo fid dunyaa wal Aakhirati wa lahum 'azaabun 'azeem"
  },
  {
    "id": 24,
    "text": "Yawma tashhhadu 'alaihim alsinatuhum wa aideehim wa arjuluhum bimaa kaanoo ya'maloon"
  },
  {
    "id": 25,
    "text": "Yawma'iziny yuwaf feehimul laahu deenahumul haqqa wa ya'lamoona annal laaha Huwal Haqqul Mubeen"
  },
  {
    "id": 26,
    "text": "Al khabeesaatu lil khabeeseena wal khabeesoona lil khabeesaati wat taiyibaatu lit taiyibeena wat taiyiboona lit taiyibaat; ulaaa'ika mubarra'oona mimma yaqooloona lahum maghfiratunw wa rizqun kareem"
  },
  {
    "id": 27,
    "text": "Yaaa aiyuhal lazeena aamanoo laa tadkhuloo buyootan ghaira buyootikum hatta tastaanisoo wa tusallimoo 'alaa ahlihaa; zaalikum khairul lakum la'allakum tazakkaroon"
  },
  {
    "id": 28,
    "text": "Fa il lam tajidoo feehaaa ahadan falaa tadkhuloohaa hattaa yu'zana lakum wa in qeela lakumurji'oo farji'oo huwa azkaa lakum; wallaahu bimaa ta'maloona 'Aleem"
  },
  {
    "id": 29,
    "text": "Laisa 'alaikum junaahun ann tadkhuloo buyootan ghaira maskoonatin feeha mataa'ul lakum; wallaahu ya'lamu maa tubdoona wa maa taktumoon"
  },
  {
    "id": 30,
    "text": "Qul lilmu' mineena yaghuuddoo min absaarihim wa yahfazoo furoojahum; zaalika azkaa lahum; innallaaha khabeerum bimaa yasna'oon"
  },
  {
    "id": 31,
    "text": "Wa qul lilmu'minaati yaghdudna min absaarihinna wa yahfazna furoojahunna wa laa yubdeena zeenatahunna illaa maa zahara minhaa wal yadribna bikhumurihinna 'alaa juyoobihinna wa laa yubdeena zeenatahunna illaa libu'oolatihinna aw aabaaa'i hinna aw aabaaa'i bu'oolati hinna aw abnaaa'ihinnaa aw abnaaa'i bu'oolatihinnna aw ikhwaanihinnna aw baneee ikhwaanihinna aw banee akhawaatihinna aw nisaaa'i hinna aw maa malakat aimaanuhunna awit taabi'eena ghairi ilil irbati minar rijaali awit tiflillazeena lam yazharoo 'alaa 'awraatin nisaaa'i wala yadribnna bi arjulihinna liyu'lama maa yukhfeena min zeenatihinn; wa toobooo ilallaahi jammee'an aiyuhal mu'minoona la'allakum tuflihoon"
  },
  {
    "id": 32,
    "text": "Wa ankihul ayaamaa minkum was saaliheena min 'ibaadikum wa imaa'ikum; iny- yakoonoo fuqaraaa'a yughni himul laahu min fadlih; wal laahu Waasi'un 'Aleem"
  },
  {
    "id": 33,
    "text": "Wal yasta'fifil lazeena laa yajidoona nikaahan hatta yughniyahumul laahu min fadlih; wallazeena yabtaghoonal kitaaba mimmaa malakat aimaanukum fakaatiboohum in 'alimtum feehim khairanw wa aatoohum mimmaalil laahil lazeee aataakum; wa laa tukrihoo fatayaatikum 'alal bighaaa'i in aradna tahassunal litabtaghoo 'aradal hayaatid dunyaa; wa mai yukrihhunna fa innal laaha mim ba'di ikraahihinna Ghafoorur Raheem"
  },
  {
    "id": 34,
    "text": "Wa laqad anzalnaaa ilaikum Aayaatim mubaiyinaatinw wa masalam minal lazeena khalaw min qablikum wa maw'izatal lilmuttaqeen"
  },
  {
    "id": 35,
    "text": "Allaahu noorus samaawaati wal ard; masalu noorihee kamishkaatin feehaa misbaah; almisbaahu fee zujaajatin azzujaajatu ka annahaa kawkabun durriyyuny yooqadu min shajaratim mubaarakatin zaitoonatil laa shariqiyyatinw wa laa gharbiyyatiny yakaadu zaituhaa yudeee'u wa law lam tamsashu naar; noorun 'alaa noor; yahdil laahu linoorihee mai yashaaa'; wa yadribul laahul amsaala linnaas; wallaahu bikulli shai'in Aleem"
  },
  {
    "id": 36,
    "text": "Fee buyootin azinal laahu an turfa'a wa yuzkara feehasmuhoo yusabbihu lahoo feehaa bilghuduwwi wal aasaal"
  },
  {
    "id": 37,
    "text": "Rijaalul laa tulheehim tijaaratunw wa laa bai'un 'an zikril laahi wa iqaamis Salaati wa eetaaa'iz Zakaati yakhaafoona Yawman tataqallabu feehil quloobu wal absaar"
  },
  {
    "id": 38,
    "text": "Liyajziyahumul laahu ahsana maa 'amiloo wa yazeedahum min fadlih; wal laahu yarzuqu mai yashaaa'u bighairi hisaab"
  },
  {
    "id": 39,
    "text": "Wallazeena kafarooo a'maaluhum kasaraabim biqee'atiny yahsabuhuz zamaanu maaa'an hattaaa izaa jaaa'ahoo lam yajid hu shai'anw wa wajadal laaha 'indahoo fa waffaahu hisaabah; wallaahu saree'ul hisaab"
  },
  {
    "id": 40,
    "text": "Aw kazulumaatin fee bahril lujjiyyiny yaghshaahu mawjun min fawqihee mawjun min fawqihee sahaab; zulumatun ba'duhaa fawqa ba'din izaaa akhraja yadahoo lam yakad yaraahaa wa man lam yaj'alil laahu lahoo nooran famaa lahoo min noor"
  },
  {
    "id": 41,
    "text": "Alam tara annal laaha yusabbihu lahoo man fissamaawaati wal ardi wat tairu saaaffaatim kullun qad 'alima Salaatahoo wa tasbeehah; wallaahu 'aleemum bimaa yaf'aloon"
  },
  {
    "id": 42,
    "text": "Wa lillaahi mulkus samaawaati wal ardi wa ilal laahil maseer"
  },
  {
    "id": 43,
    "text": "Alam tara annal laaha yuzjee sahaaban summa yu'allifu bainahoo summa yaj'aluhoo rukaaman fataral wadqa yakhruju min khilaalihee wa yunazzilu minas samaaa'i min jibaalin feehaa mim baradin fa yuseebu bihee mai yashaaa'u wa yasrifuhoo 'am mai yashaaa'u yakkaadu sanaa barqihee yazhabu bil absaar"
  },
  {
    "id": 44,
    "text": "Yuqallibul laahul laila wannahaar; inna fee zaalika la'ibratal li ulil absaar"
  },
  {
    "id": 45,
    "text": "Wallaahu khalaqa kulla daaabbatim mim maaa'in faminhum mai yamshee 'alaa batnihee wa minhum mai yamshee 'alaa rijlaine wa minhum mai yamshee 'alaaa arba'; yakhluqul laahu maa yashaaa'; innal laaha 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 46,
    "text": "Laqad anzalnaaa Aayaatim mubaiyinaat; wallaahu yahdee mai yashaaa'u ilaa Siraatim Mustaqeem"
  },
  {
    "id": 47,
    "text": "Wa yaqooloona aamannaa billaahi wa bir Rasooli wa ata'naa summa yatawallaa fareequm minhum mim ba'di zaalik; wa maaa ulaaa'ika bilmu'mineen"
  },
  {
    "id": 48,
    "text": "Wa izaa du'ooo ilal laahi wa Rasoolihee li yahkuma bainahum izaa fareequm minhum mu'ridoon"
  },
  {
    "id": 49,
    "text": "Wa iny-yakul lahumul haqqu yaatooo ilaihi muz'ineen"
  },
  {
    "id": 50,
    "text": "Afee quloobihim maradun amirtaabooo am yakhaafoona any yaheefallaahu 'alaihim wa Rasooluh; bal ulaaa'ika humuz zaalimoon"
  },
  {
    "id": 51,
    "text": "Innamaa kaana qawlal mu'mineena izaa du'ooo ilal laahi wa Rasoolihee li yahkuma bainahum ai yaqooloo sami'naa wa ata'naa; wa ulaaa'ika humul muflihoon"
  },
  {
    "id": 52,
    "text": "Wa mai yuti'il laaha wa Rasoolahoo wa yakhshal laaha wa yattaqhi fa ulaaa'ika humul faaa'izoon"
  },
  {
    "id": 53,
    "text": "Wa aqsamoo billaahi jahda aimaanihim la'in amartahum la yakhrujunna qul laa tuqsimoo taa'atum ma'roofah innal laaha khabeerum bimaa ta'maloon"
  },
  {
    "id": 54,
    "text": "Qul atee'ul laaha wa atee'ur Rasoola fa in tawallaw fa innamaa 'alaihi maa hummila wa 'alaikum maa hummiltum wa in tutee'oohu tahtadoo; wa maa'alar Rasooli illal balaaghul mubeen"
  },
  {
    "id": 55,
    "text": "Wa'adal laahul lazeena aamanoo minkum wa 'amilus saalihaati la yastakhlifan nahum fil ardi kamastakh lafal lazeena min qablihim wa la yumakkinanna lahum deenahumul lazir tadaa lahum wa la yubaddilannahum mim ba'di khawfihim amnaa; ya'budoonanee laayushrikoona bee shai'aa; wa man kafara ba'da zaalika fa ulaaa'ika humul faasiqoon"
  },
  {
    "id": 56,
    "text": "Wa aqeemus Salaata wa aatuz Zakaata wa atee'ur Rasoola la'allakum turhamoon"
  },
  {
    "id": 57,
    "text": "Laa tahsabannal lazeena kafaroo mu'jizeena fil ard; wa maawaahumun Naaru wa labi'sal maseer"
  },
  {
    "id": 58,
    "text": "Yaaa aiyuhal lazeena aamanoo li yasta'zinkumul lazeena malakat aimaanukum wallazeena lam yablughul huluma minkum salaasa marraat; min qabli Salaatil Fajri wa heena tada'oona siyaa bakum minaz zaheerati wa min ba'di Salaatil Ishaaa'; salaasu 'awraatil lakum; laisa 'alaikum wa laa 'alaihim junaahun ba'dahunn; tawwaafoona 'alaikum ba'dukum 'alaa ba'd; kazaalika yubaiyinul laahu lakumul aayaat; wallahu 'Aleemun Hakeem"
  },
  {
    "id": 59,
    "text": "Wa izaa balaghal atfaalu minkumul huluma fal yasta'zinoo kamas ta'zanal lazeena min qablihim; kazaalika yubaiyinul laahu lakum Aayaatih; wallaahu 'Aleemun Hakeem"
  },
  {
    "id": 60,
    "text": "Walqawaa'idu minan nisaaa'il laatee laa yarjoona nikaahan fa laisa 'alaihinna junaahun ai yada'na siyaabahunna ghaira mutabarrijaatin bi zeenah; wa ai yasta'fif na khairul lahunn; wallaahu Samee'un 'Aleem"
  },
  {
    "id": 61,
    "text": "Laisa 'alal a'maa harajunw wa laa 'alal a'raji harajunw wa laa 'alal mareedi harajun wa laa 'alaa anfusikum 'an ta'kuloo min buyootikum aw buyooti aabaaa'ikum aw buyooti ummahaatikum aw buyooti ikhwaanikum aw buyooti akhawaatikum aw buyooti a'maamikum aw buyooti 'ammaatikum aw buyooti akhwaalikum aw buyooti khaalaatikum aw maa malaktum mafaatihahooo aw sadeeqikum; laisa 'alaikum junaahun 'an ta'kuloo jamee'an aw ashtaata; fa izaa dakhaltum buyootan fa sallimoo 'alaaa anfusikum tahiyyatan min 'indil laahi mubaarakatan taiyibah; kazaalika yubai yinul laahu lakumul Aayaati la'allakum ta'qiloon"
  },
  {
    "id": 62,
    "text": "Innamal mu'minoonal lazeena aamanoo billaahi wa Rasoolihee wa izaa kaanoo ma'ahoo 'alaaa amrin jaami'il lam yazhaboo hattaa yasta'zinooh; innal lazeena yasta'zinoonaka ulaaa'ikal lazeena yu'minoona billaahi wa Rasoolih; fa izas ta'zanooka li ba'di sha'nihim fa'zal liman shi'ta minhum wastaghfir lahumul laah; innal laaha Ghafoorur Raheem"
  },
  {
    "id": 63,
    "text": "Laa taj'aloo du'aaa'ar Rasooli bainakum ka du'aaa'i ba'dikum ba'daa; qad ya'lamul laahul lazeena yatasallaloona minkum liwaazaa; fal yahzaril lazeena yukhaalifoona 'an amriheee 'an tuseebahum fitnatun aw yuseebahum 'azaabun aleem"
  },
  {
    "id": 64,
    "text": "'Alaaa inna lillaahi maa fis samaawaati wal ardi qad ya'lamu maaa antum 'alaihi wa Yawma yurja'oona ilaihi fa yunabbi'uhum bimaa 'amiloo; wallaahu bikulli shai'in 'Aleem"
  }
];

export default en;
