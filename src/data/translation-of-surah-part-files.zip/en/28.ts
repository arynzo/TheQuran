import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Taa-Seeen-Meeem"
  },
  {
    "id": 2,
    "text": "Tilka Aayaatul Kitaabil mubeen"
  },
  {
    "id": 3,
    "text": "Natloo 'alaika min naba-i Moosaa wa Fir'awna bilhaqqi liqawminy yu'miinoon"
  },
  {
    "id": 4,
    "text": "Inna Fir'awna 'alaa fil ardi wa ja'ala ahlahaa shiya'ai yastad'ifu taaa'ifatam minhum yuzabbihu abnaaa'ahum wa yastahyee nisaaa'ahum; innahoo kaana minal mufsideen"
  },
  {
    "id": 5,
    "text": "Wa nureedu an namunna 'alal lazeenas tud'ifoo fil ardi wa naj'alahum a'immatanw wa naj'alahumul waariseen"
  },
  {
    "id": 6,
    "text": "Wa numakkina lahum fil ardi wa nuriya Fir'awna wa Haamaana wa junoodahumaa minhum maa kaanoo yahzaroon"
  },
  {
    "id": 7,
    "text": "Wa awhainaaa ilaaa ummi Moosaaa an ardi'eehi faizaa khifti 'alaihi fa alqeehi filyammi wa laa takhaafee wa laa tahzaneee innaa raaaddoohu ilaiki wa jaa'iloohu minal mursaleen"
  },
  {
    "id": 8,
    "text": "Faltaqatahooo Aalu Fir'awna li yakoona lahum 'aduwwanw wa hazanaa; inna Fir'awna wa Haamaana wa junooda humaa kaanoo khaati'een"
  },
  {
    "id": 9,
    "text": "Wa qaalatim ra atu Fir'awna qurratu 'aynil lee wa lak; laa taqtuloohu 'asaaa aiyanfa'anaa aw nattakhizahoo waladanw wa hum laa yash'uroon"
  },
  {
    "id": 10,
    "text": "Wa asbaha fu'aadu ummi Moosaa faarighan in kaadat latubdee bihee law laaa arrabatnaa 'alaa qalbihaa litakoona minal mu'mineen"
  },
  {
    "id": 11,
    "text": "Wa qaalat li ukhtihee qusseehi fabasurat bihee 'an junubinw wahum laa yash'uroon"
  },
  {
    "id": 12,
    "text": "Wa harramnaa 'alaihil maraadi'a min qablu faqaalat hal adullukum 'alaaa ahli baitiny yakfuloonahoo lakum wa hum lahoo naasihoon"
  },
  {
    "id": 13,
    "text": "Faradadnaahu ilaa ummihee kai taqarra 'ainuhaa wa laa tahzana wa lita'lama anna wa'dal laahi haqqunw wa laakinna aksarahum laa ya'lamoon"
  },
  {
    "id": 14,
    "text": "Wa lammaa balagha ashuddahoo wastawaaa aatai naahu hukmanw wa 'ilmaa; wa kazaalika najzil muhsineen"
  },
  {
    "id": 15,
    "text": "Wa dakhalal madeenata 'alaa heene ghaflatim min ahlihaa fawajada feeha raju laini yaqtatilaani haazaa min shee'atihee wa haaza min 'aduwwihee fastaghaasahul lazee min shee'atihee 'alal lazee min 'aduwwihee fawakazahoo Moosaa faqadaa 'alaihi qaala haaza min 'amalish Shaitaani innahoo 'aduwwum mmudillum mubeen"
  },
  {
    "id": 16,
    "text": "Qaala Rabbi innee zalamtu nafsee faghfir lee faghafaralah; innahoo Huwal Ghafoorur Raheem"
  },
  {
    "id": 17,
    "text": "Qaala Rabbi bimaaa an'amta 'alaiya falan akoona zaheeral lilmujrimeen"
  },
  {
    "id": 18,
    "text": "Fa asbaha fil madeenati khaaa'ifany yataraqqabu fa izal lazis tansarahoo bil amsi yastasrikhuh; qaala lahoo moosaaa innaka laghawiyyum mubeen"
  },
  {
    "id": 19,
    "text": "Falammaaa an araada ai yabtisha billazee huwa 'aduwwul lahumaa qaala yaa Moosaaa atureedu an taqtulanee kamaa qatalta nafsam bil amsi in tureedu illaaa an takoona jabbaaram fil ardi wa maa tureedu an takoona minal musliheen"
  },
  {
    "id": 20,
    "text": "Wa jaaa'a rajulum min aqsal madeenati yas'aa qaala yaa Moosaaa innal mala a yaa tamiroona bika liyaqtulooka fakhruj innee laka minan naasiheen"
  },
  {
    "id": 21,
    "text": "Fakharaja minhaa khaaa 'ifany-yataraqqab; qaala Rabbi najjinee minal qawmiz zaalimeen"
  },
  {
    "id": 22,
    "text": "Wa lammaa tawajjaha tilqaaa'a Madyana qaala 'asaa Rabbeee ai yahdiyanee Sawaaa'as Sabeel"
  },
  {
    "id": 23,
    "text": "Wa lammaa warada maaa'a Madyana wajada 'alaihi ummatam minannaasi yasqoona wa wajada min doonihimum ra ataini tazoodaani qaala maa khatbukumaa qaalataa laa nasqee hatta yusdirar ri'aaa'u wa aboonaa shaikhun kabeer"
  },
  {
    "id": 24,
    "text": "Fasaqaa lahumaa summa tawallaaa ilaz zilli faqaala Rabbi innee limaaa anzalta ilaiya min khairin faqeer"
  },
  {
    "id": 25,
    "text": "Fajaaa'at hu ihdaahumaa tamshee 'alas tihyaaa'in qaalat inna abee yad'ooka li yajziyaka ajra maa saqaita lanaa; falammaa jaaa'ahoo wa qassa 'alaihil qasasa qaala laa takhaf najawta minal qawmiz zaalimeen"
  },
  {
    "id": 26,
    "text": "Qaalat ihdaahumaa yaaa abatis taajirhu inna khaira manistaajartal qawiyyul ameen"
  },
  {
    "id": 27,
    "text": "Qaala innee ureedu an unkihaka ihdab nataiya haataini 'alaaa an taajuranee samaaniya hijaj; fa in atmamta 'ashran famin 'indika wa maaa ureedu an ashuqqa 'alaik; satajiduneee in shaaa'al laahu minas saaliheen"
  },
  {
    "id": 28,
    "text": "Qaala zaalika bainee wa bainaka aiyamal ajalaini qadaitu falaa 'udwaana 'alaiya wallaahu 'alaa ma naqoolu Wakeel"
  },
  {
    "id": 29,
    "text": "Falammmaa qadaa Moosal ajala wa saara bi ahliheee aanasa min jaanibit Toori naaran qaala li ahlihim kusooo inneee aanastu naaral la 'alleee aateekum minhaa bikhabarin aw jazwatim minan naari la 'allakum tastaloon"
  },
  {
    "id": 30,
    "text": "Falammaaa ataahaa noodiya min shaati'il waadil aimani fil buq'atil muubaarakati minash shajarati ai yaa Moosaaa inneee Anal laahu Rabbul 'aalameen"
  },
  {
    "id": 31,
    "text": "Wa an alqi 'asaaka falam maa ra aahaa tahtazzu ka annnahaa jaaannunw wallaa mudbiranw wa lam yu'aqqib; yaa Moosaa aqbil wa laa takhaf innaka minal aamineen"
  },
  {
    "id": 32,
    "text": "Usluk yadaka fee jaibika takhruj baidaaa'a min ghairi sooo'inw wadmum ilaika janaahaka minar rahbi fazaanika burhaanaani mir Rabbika ilaa Fir'awna wa mala'ih; innahum kaanoo qawman faasiqeen"
  },
  {
    "id": 33,
    "text": "Qaala Rabbi innee qataltu minhum nafsan fa akhaafu ai yaqtuloon"
  },
  {
    "id": 34,
    "text": "Wa akhee Haaroonu huwa afsahu minnee lisaanan fa arsilhu ma'iya rid ai yusaddiquneee innee akhaafu ai yukazziboon"
  },
  {
    "id": 35,
    "text": "Qaala sanashuddu 'adudaka bi akheeka wa naj'alu lakumaa sultaanan falaa yasiloona ilaikumaa; bi Aayaatinaa antumaa wa manit taba'akumal ghaaliboon"
  },
  {
    "id": 36,
    "text": "Falammaa jaaa'ahum Moosaa bi Aayaatinaa baiyinaatin qaaloo maa haazaaa illaa sihrum muftaranw wa maa sami'naa bihaazaa feee aabaaa'inal awwaleen"
  },
  {
    "id": 37,
    "text": "Wa qaala Moosaa Rabbeee a'alamu biman jaaa'a bilhudaa min 'indihee wa man takoonu lahoo 'aaqibatud daari innahoo laa yuflihuz zaalimoon"
  },
  {
    "id": 38,
    "text": "Wa qaala Fir'awnu yaaa aiyuhal mala-u maa 'alimtu lakum min ilaahin ghairee fa awqid lee yaa Haamaanu 'alatteeni faj'al lee sarhal la'alleee attali'u ilaaa ilaahi Moosaa wa innee la azunnuhoo minal kaazibeen"
  },
  {
    "id": 39,
    "text": "Wastakbara huwa wa junooduhoo fil ardi bighairil haqqi wa zannooo annahum ilainaa laa yurja'oon"
  },
  {
    "id": 40,
    "text": "Fa akhaznaahu wa junoo dahoo fanabaznaahum fil yammi fanzur kaifa kaana 'aaqibatuz zaalimeen"
  },
  {
    "id": 41,
    "text": "Wa ja'alnaahum a'immatany yad'oona ilan Naari wa Yawmal Qiyaamati laa yunsaroon"
  },
  {
    "id": 42,
    "text": "Wa atba'naahum fee haazihid dunyaa la'natanw wa Yawmal Qiyaamati hum minal maqbooheen"
  },
  {
    "id": 43,
    "text": "Wa laqad aatainaa Moosal Kitaaba mim ba'di maaa ahlaknal quroonal oolaa basaaa'ira linnaasi wa hudanw wa rahmatal la'allahum yata zakkkaroon"
  },
  {
    "id": 44,
    "text": "Wa maa kunta bijaanibil gharbiyyi iz qadainaaa ilaa Moosal amra wa maa kunta minash shaahideen"
  },
  {
    "id": 45,
    "text": "Wa laakinnaa anshaanaa quroonan fatataawala 'alaihimul 'umur; wa maa kunta saawiyan feee ahli Madyana tatloo 'alaihim Aayaatinaa wa laakinnaa kunnaa mursileen"
  },
  {
    "id": 46,
    "text": "Wa maa kunta bijaanibit Toori iz naadainaa wa laakir rahmatam mir Rabbika litunzira qawmam maaa ataahum min nazeerim min qablika la'allahum yatazakkaroon"
  },
  {
    "id": 47,
    "text": "Wa law laaa an tuseebahum museebatum bimaa qaddamat aideehim fa yaqooloo Rabbanaa law laaa arsalta ilainaa Rasoolan fanattabi'a Aayaatika wa nakoona minal mu'mineen"
  },
  {
    "id": 48,
    "text": "Falammaa jaaa'ahumul haqqu min 'indinaa qaaloo law laa ootiya misla maaa ootiyaa Moosaa; awalam yakfuroo bimaaa ootiya Moosaa min qablu qaaloo sihraani tazaaharaa wa qaalooo innaa bikullin kaafiroon"
  },
  {
    "id": 49,
    "text": "Qul faatoo bi Kitaabim min 'indil laahi huwa ahdaa minhu maaa attabi'hu in kuntum saadiqeen"
  },
  {
    "id": 50,
    "text": "Fa il lam yastajeeboo laka fa'lam annamaa yattabi'oona ahwaaa'ahum; wa man adallu mimmanit taba'a hawaahu bighari hudam minal laah; innal laaha laa yahdil qawmaz zaalimeen"
  },
  {
    "id": 51,
    "text": "Wa laqad wassalnaa lahumul qawla la'allahum yatazakkaroon"
  },
  {
    "id": 52,
    "text": "Allazeena aatainaahu mul Kitaaba min qablihee hum bihee yu'minoon"
  },
  {
    "id": 53,
    "text": "Wa izaa yutlaa 'alaihim qaaloo aamannaa biheee innahul haqqu mir rabbinaaa innaa kunnaa min qablihee muslimeen"
  },
  {
    "id": 54,
    "text": "Ulaaa'ika yu'tawna ajrahum marratayni bimaa sabaroo wa yadra'oona bil hasanatis saiyi'ata wa mimmmaa razaq naahum yunfiqoon"
  },
  {
    "id": 55,
    "text": "Wa izaa sami'ul laghwa a'radoo 'anhu wa qaaloo lanaaa a'maalunaa wa lakum a'maalukum salaamun 'alaikum laa nabtaghil jaahileen"
  },
  {
    "id": 56,
    "text": "Innaka laa tahdee man ahbabta wa laakinn Allaha yahdee mai yashaaa'; wa huwa a'lamu bil muhtadeen"
  },
  {
    "id": 57,
    "text": "Wa qaalooo in nattabi'il hudaa ma'aka nutakhattaf min ardinaa; awalam numakkkil lahum haraman aaminany yujbaaa ilaihi samaraatu kulli shai'ir rizqam mil ladunnaa wa laakinna aksarahum laa ya'lamoon"
  },
  {
    "id": 58,
    "text": "Wa kam ahlaknaa min qaryatim batirat ma'eeshatahaa fatilka masaakinuhum lam tuskam mim ba'dihim illaa qaleelaa; wa kunnaa Nahnul waariseen"
  },
  {
    "id": 59,
    "text": "Wa maa kaana Rabbuka muhlikal quraa hattaa yab'asa feee ummihaa Rasoolany yatloo 'alaihim aayaatina; wa maa kunnaa muhlikil quraaa illaa wa ahluhaa zaalimoon"
  },
  {
    "id": 60,
    "text": "Wa maaa ooteetum min shai'in famataa'ul hayaatid dunyaa wa zeenatuhaa; wa maa 'indal laahi khairunw wa abqaa; afalaa ta'qiloon"
  },
  {
    "id": 61,
    "text": "Afamanw wa'adnaahu wa'dan hasanan fahuwa laaqeehi kamam matta'naahu mataa'al hayaatid dunyaa summa huwa Yawmal Qiyaamati minal muhdareen"
  },
  {
    "id": 62,
    "text": "Wa Yawma yunaadeehim fa-yaqoolu aina shurakaaa 'iyal lazeena kuntum taz'umoon"
  },
  {
    "id": 63,
    "text": "Qaalal lazeena haqqa 'alaihimul qawlu Rabbanaa haaa'ulaaa'il lazeena aghwainaa aghwainaahu kamaa ghawainaa tabarraanaaa ilaika maa kaanoo iyyaanaa ya'budoon"
  },
  {
    "id": 64,
    "text": "Wa qeelad 'oo shurakaaa'akum fada'awhum falam yastajeeboo lahum wa ra awul 'azaab; law annahum kaanoo yahtadoon"
  },
  {
    "id": 65,
    "text": "Wa Yawma yunaadeehim fa yaqoolu maazaaa ajabtumul mursaleen"
  },
  {
    "id": 66,
    "text": "Fa'amiyat 'alaihimul ambaaa'u Yawma'izin fahum laa yatasaaa'aloon"
  },
  {
    "id": 67,
    "text": "Fa ammaa man taaba wa aamana wa 'amila saalihan fa'asaaa ai yakoona minal mufliheen"
  },
  {
    "id": 68,
    "text": "Wa Rabbuka yakhuluqu maa yashaaa'u wa yakhtaar; maa kaana lahumul khiyarah; Subhannal laahi wa Ta'aalaa 'ammmaa yushrikoon"
  },
  {
    "id": 69,
    "text": "Wa Rabbuka ya'lamu maa tukinnu sudooruhum wa maa yu'linoon"
  },
  {
    "id": 70,
    "text": "Wa Huwal laahu laaa ilaaha illaa Huwa lahul hamdu fil oolaa wal Aakhirati wa lahul hukmu wa ilaihi turja'oon"
  },
  {
    "id": 71,
    "text": "Qul ara'aitum in ja'alal laahu 'alaikumul laila sarmadan ilaa Yawmil Qiyaamati man ilaahun ghairul laahi yaa teekum bidiyaaa'in afalaa tasma'oon"
  },
  {
    "id": 72,
    "text": "Qul ara'aitum in ja'alal laahu 'alaikumun nahaara sarmadan ilaa Yawmil Qiyaamati man ilaahun ghairul laahi yaateekum bilailin taskunoona feehi afalaa tubsiroon"
  },
  {
    "id": 73,
    "text": "Wa mir rahmatihee ja'ala lakumul laila wannahaara litaskunoo feehi wa litabtaghoo min fadlihee wa la'allakum tashkuroon"
  },
  {
    "id": 74,
    "text": "Wa Yawma yunaadeehim fa yaqoolu aina shurakaaa'iyal lazeena kuntum tazz'umoon"
  },
  {
    "id": 75,
    "text": "Wa naza'naa min kulli ummatin shaheedan faqulnaa haatoo burhaanakum fa'alimooo annal haqqa lillaahi wa dalla 'anhum maa kaanoo yaftaroon"
  },
  {
    "id": 76,
    "text": "Inna Qaaroona kaana min qawmi Moosaa fabaghaaa 'alaihim wa aatainaahu minal kunoozi maaa inna mafaati hahoo latanooo'u bil'usbati ulil quwwati iz qaala lahoo qawmuhoo laa tafrah innal laahaa laa yuhibbul fariheen"
  },
  {
    "id": 77,
    "text": "Wabtaghi feemaaa aataakal laahud Daaral Aakhirata wa laa tansa naseebaka minad dunyaa wa ahsin kamaaa ahsanal laahu ilaika wa laa tabghil fasaada fil ardi innal laaha laa yuhibbul mufsideen"
  },
  {
    "id": 78,
    "text": "Qaala innamaaa ootee tuhoo 'alaa 'ilmin 'indeee; awalam ya'lam annal laaha qad ahlaka min qablihee minal qurooni man huwa ashaddu minhu quwwatanw wa aksaru jam'aa; wa laa yus'alu 'an zunoobihimul mujrimoon"
  },
  {
    "id": 79,
    "text": "Fakharaja 'alaa qawmihee fee zeenatih; qaalal lazeena yureedoonal hayaatad dunyaa yaalaita lanaa misla maaa ootiya Qaaroonu innahoo lazoo hazzin 'azeem"
  },
  {
    "id": 80,
    "text": "Wa qaalal lazeena ootul 'ilma wailakum sawaabul laahi khairul liman aamana wa 'amila saalihaa; wa laa yulaq qaahaaa illas saabiroon"
  },
  {
    "id": 81,
    "text": "Fakhasafnaa bihee wa bidaarihil arda famaa kaana lahoo min fi'atiny yansuroo nahoo min doonil laahi wa maa kaana minal muntasireen"
  },
  {
    "id": 82,
    "text": "Wa asbahal lazeena tamannaw makaanahoo bil amsi yaqooloona waika annal laaha yabsutur rizqa limany ya shaaa'u min 'ibaadihee wa yaqdiru law laaa am mannal laahu 'alainaa lakhasafa binaa waika annahoo laa yuflihul kaafiroon"
  },
  {
    "id": 83,
    "text": "Tilkad Daarul Aakhiratu naj'aluhaa lillazeena laa yureedoona 'uluwwan fil ardi wa laa fasaadaa; wal 'aaqibatu lilmuttaqeen"
  },
  {
    "id": 84,
    "text": "Man jaaa'a bilhasanati falahoo khairum minhaa wa man jaaa'a bissaiyi'ati falaa yujzal lazeena 'amilus saiyiaati illaa maa kaanoo ya'maloon"
  },
  {
    "id": 85,
    "text": "Innal lazee farada 'alaikal Qur-aana laraaadduka ilaa ma'aad; qur Rabbeee a'lamu man jaaa'a bil hudaa wa man huwa fee dalaalim mubeen"
  },
  {
    "id": 86,
    "text": "Wa maa kunta tarjooo ai yulqaaa ilaikal Kitaabu illaa rahmatan mir Rabbika falaa takoonanna zaheeral lil kaafireen"
  },
  {
    "id": 87,
    "text": "Wa laa yasuddunnaka 'an Aayaatil laahi ba'da iz unzilat ilaika wad'u ilaa Rabbika wa laa takoonanna minal mushrikeen"
  },
  {
    "id": 88,
    "text": "Wa laa tad'u ma'al laahi ilaahan aakhar; laaa ilaaha illaa Hoo; kullu shai'in haalikun illaa Wajhah; lahul hukkmu wa ilaihi turja'oon"
  }
];

export default en;
