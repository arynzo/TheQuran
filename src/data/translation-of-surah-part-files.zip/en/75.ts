import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Laaa uqsimu bi yawmil qiyaamah"
  },
  {
    "id": 2,
    "text": "Wa laaa uqsimu bin nafsil lawwaamah"
  },
  {
    "id": 3,
    "text": "Ayahsabul insaanu al lan najm'a 'izaamah"
  },
  {
    "id": 4,
    "text": "Balaa qaadireena 'alaaa an nusawwiya banaanah"
  },
  {
    "id": 5,
    "text": "Bal yureedul insaanu liyafjura amaamah"
  },
  {
    "id": 6,
    "text": "Yas'alu ayyyaana yawmul qiyaamah"
  },
  {
    "id": 7,
    "text": "Fa izaa bariqal basar"
  },
  {
    "id": 8,
    "text": "Wa khasafal qamar"
  },
  {
    "id": 9,
    "text": "Wa jumi'ash shamsu wal qamar"
  },
  {
    "id": 10,
    "text": "Yaqoolul insaanu yaw ma 'izin aynal mafarr"
  },
  {
    "id": 11,
    "text": "Kallaa laa wazar"
  },
  {
    "id": 12,
    "text": "Ilaa rabbika yawma 'izinil mustaqarr"
  },
  {
    "id": 13,
    "text": "Yunabba 'ul insaanu yawma 'izim bimaa qaddama wa akhkhar"
  },
  {
    "id": 14,
    "text": "Balil insaanu 'alaa nafsihee baseerah"
  },
  {
    "id": 15,
    "text": "Wa law alqaa ma'aazeerah"
  },
  {
    "id": 16,
    "text": "Laa tuharrik bihee lisaa naka lita'jala bih"
  },
  {
    "id": 17,
    "text": "Inna 'alainaa jam'ahoo wa qur aanah"
  },
  {
    "id": 18,
    "text": "Fa izaa Qur'anahu fattabi' qur aanah"
  },
  {
    "id": 19,
    "text": "Summa inna 'alainaa bayaanah"
  },
  {
    "id": 20,
    "text": "Kallaa bal tuhibboonal 'aajilah"
  },
  {
    "id": 21,
    "text": "Wa tazaroonal Aakhirah"
  },
  {
    "id": 22,
    "text": "Wujoohuny yawma 'izin naadirah"
  },
  {
    "id": 23,
    "text": "Ilaa rabbihaa naazirah"
  },
  {
    "id": 24,
    "text": "Wa wujoohuny yawma 'izim baasirah"
  },
  {
    "id": 25,
    "text": "Tazunnu any yuf'ala bihaa faaqirah"
  },
  {
    "id": 26,
    "text": "Kallaaa izaa balaghatit taraaqee"
  },
  {
    "id": 27,
    "text": "Wa qeela man raaq"
  },
  {
    "id": 28,
    "text": "Wa zanna annahul firaaq"
  },
  {
    "id": 29,
    "text": "Waltaffatis saaqu bissaaq"
  },
  {
    "id": 30,
    "text": "Ilaa rabbika yawma'izinil masaaq"
  },
  {
    "id": 31,
    "text": "Falaa saddaqa wa laa sallaa"
  },
  {
    "id": 32,
    "text": "Wa laakin kazzaba wa tawalla"
  },
  {
    "id": 33,
    "text": "Summa zahaba ilaaa ahlihee yatamatta"
  },
  {
    "id": 34,
    "text": "Awlaa laka fa awlaa"
  },
  {
    "id": 35,
    "text": "Summa awlaa laka fa awla"
  },
  {
    "id": 36,
    "text": "Ayahsabul insaanu ai yutraka sudaa"
  },
  {
    "id": 37,
    "text": "Alam yaku nutfatam mim maniyyiny yumnaa"
  },
  {
    "id": 38,
    "text": "Summa kaana 'alaqatan fakhalaqa fasawwaa"
  },
  {
    "id": 39,
    "text": "Faja'ala minhuz zawjayniz zakara wal unsaa"
  },
  {
    "id": 40,
    "text": "Alaisa zaalika biqaadirin 'alaaa any yuhyiyal mawtaa"
  }
];

export default en;
