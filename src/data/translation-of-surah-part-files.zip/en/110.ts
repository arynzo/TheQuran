import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Iza jaaa'a nasrul-laahi walfath"
  },
  {
    "id": 2,
    "text": "Wa ra-aitan naasa yadkhuloona fee deenil laahi afwajaa"
  },
  {
    "id": 3,
    "text": "Fasabbih bihamdi rabbika wastaghfirh, innahoo kaana tawwaaba"
  }
];

export default en;
