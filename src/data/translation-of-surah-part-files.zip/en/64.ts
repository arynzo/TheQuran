import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yusabbihu lillaahi maa fis samaawaati wa maa fil ardi lahul mulku wa lahul hamd, wa Huwa 'alaa kulli shai 'in Qadeer"
  },
  {
    "id": 2,
    "text": "Huwal lazee khalaqakum faminkum kaafirunw wa min kum mu'min ; wallaahu bimaa ta'maloona Baseer"
  },
  {
    "id": 3,
    "text": "Khalaqas samaawaati wal arda bilhaqqi wa sawwarakum fa ahsana suwarakum wa ilaihil maseer"
  },
  {
    "id": 4,
    "text": "Ya'lamu maa fis samaawaati wal ardi wa ya'lamu maa tusirroona wa maa tu'linoon; wallaahu 'Aleemum bizaatis sudoor"
  },
  {
    "id": 5,
    "text": "Alam ya'tikum naba'ul lazeena kafaroo min qablu fazaaqoo wabaala amrihim wa lahum 'azaabun aleem"
  },
  {
    "id": 6,
    "text": "Zaalika bi annahoo kaanat ta'teehim Rusuluhum bilbaiyinaati faqaaloo a basharuny yahdoonanaa fakafaroo wa tawallaw; wastaghnal laah; wallaahu ghaniyyun hameed"
  },
  {
    "id": 7,
    "text": "Za'amal lazeena kafarooo al-lany yub'asoo; qul balaa wa rabbee latub'asunna summa latunabba'unna bimaa 'amiltum; wa zaalika 'alal laahi yaseer"
  },
  {
    "id": 8,
    "text": "Fa-aaminoo billaahi wa rasoolihee wannooril lazeee anzalnaa; wallaahu bima ta'maloona khabeer"
  },
  {
    "id": 9,
    "text": "Yawma yajma'ukum li yawmil jam'i zaalika yawmut taghaabun; wa many-yumim billaahi wa ya'mal saalihany yukaffir 'anhu sayyi aatihee wa yudkhilhu jannaatin tajree min tahtihal anhaaru khaalideena feehaaa abadaa; zaalikal fawzul 'azeem"
  },
  {
    "id": 10,
    "text": "Wallazeena kafaroo wa kazzaboo bi aayaaatinaaa ulaaa'ika ashaabun naari khaalideena feehaa wa bi'sal maseer"
  },
  {
    "id": 11,
    "text": "Maaa asaaba mim musee batin illaa bi-iznil laah; wa many yu'mim billaahi yahdi qalbah; wallaahu bikulli shai'in Aleem"
  },
  {
    "id": 12,
    "text": "Wa atee'ul laaha wa atee'ur Rasool; fa in tawallaitum fa innamaa 'alaa Rasoolinal balaaghul mubeen"
  },
  {
    "id": 13,
    "text": "Allaahu laaa ilaaha illaa Hoo; wa 'alal laahi falyata wakkalil mu'minoon"
  },
  {
    "id": 14,
    "text": "Yaaa ayyuhal lazeena aamanooo inna min azwaaji kum wa awlaadikum 'aduwwal lakum fahzaroohum; wa in ta'foo wa tasfahoo wa taghfiroo fa innal laaha ghafoorur Raheem"
  },
  {
    "id": 15,
    "text": "Innamaa amwaalukum wa awlaadukum fitnah; wallaahu 'indahooo ajrun 'azeem"
  },
  {
    "id": 16,
    "text": "Fattaqul laaha mastata'tum wasma'oo wa atee'oo wa anfiqoo khairal li anfusikum; wa many-yooqa shuh ha nafsihee fa-ulaaa'ika humul muflihoon"
  },
  {
    "id": 17,
    "text": "In tuqridul laaha qardan hasanany yudaaifhu lakum wa yaghfir lakum; wallaahu Shakoorun Haleem"
  },
  {
    "id": 18,
    "text": "'Aalimul-Ghaibi wash-shahaadatil 'Azeezul Hakeem"
  }
];

export default en;
