import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yaa ayyuhal lazeena aamanoo laa tattakhizoo 'aduwwee wa 'aduwaakum awliyaaa'a tulqoona ilaihim bilmawaddati wa qad kafaroo bima jaaa'akum minal haqq, yukhrijoonar Rasoola wa iyyaakum an tu'minoo billaahi rabbikum in kuntum kharajtum jihaadan fee sabeelee wabtighaaa'a mardaatee; tusirroona ilaihim bilma waddati wa ana a'alamu bimaaa akhfaitum wa maaa a'lantum; wa many yaf'alhu minkum faqad dalla sawaaa'as sabeel"
  },
  {
    "id": 2,
    "text": "Iny yasqafookum yakoonoo lakum a'daaa'anw wa yabsutooo ilaikum aydiyahum wa alsinatahum bissooo'i wa waddoo law takfuroon"
  },
  {
    "id": 3,
    "text": "Lan tanfa'akum arhaamukum wa laaa awlaadukum; yawmal qiyaamati yafsilu bainakum; wallaahu bimaa ta'maloona baseer"
  },
  {
    "id": 4,
    "text": "Qad kaanat lakum uswatun hasanatun feee Ibraaheema wallazeena ma'ahoo iz qaaloo liqawmihim innaa bura 'aaa'u minkum wa mimmaa ta'budoona min doonil laahi kafarnaa bikum wa badaa bainanaa wa bainakumul 'adaawatu wal baghdaaa'u abadan hattaa tu'minoo billaahi wahdahooo illaa qawla Ibraheema li abeehi la astaghfiranna laka wa maaa amliku laka minal laahi min shai; rabbanaa 'alaika tawakkalnaa wa ilaika anabnaa wa ilaikal maseer"
  },
  {
    "id": 5,
    "text": "Rabbana laa taj'alnaa fitnatal lillazeena kafaroo waghfir lanaa rabbanaa innaka antal azeezul hakeem"
  },
  {
    "id": 6,
    "text": "Laqad kaana lakum feehim uswatunhasanatul liman kaana yarjul laaha wal yawmal aakhir; wa many yatawalla fa innal laaha huwal ghaniyyul hameed"
  },
  {
    "id": 7,
    "text": "Asal laahu any yaj'ala bainakum wa bainal lazeena 'aadaitum minhum mawaddah; wallahu qadeer; wallahu ghafoorur raheem"
  },
  {
    "id": 8,
    "text": "Laa yanhaakumul laahu 'anil lazeena lam yuqaatilookum fid deeni wa lam yukhrijookum min diyaarikum an tabarroohum wa tuqsitooo ilaihim; innal laaha yuhibbul muqsiteen"
  },
  {
    "id": 9,
    "text": "Innamaa yanhaakumul laahu 'anil lazeena qaatalookum fid deeni wa akhrajookum min diyaarikum wa zaaharoo 'alaa ikhraajikum an tawallawhum; wa many yatawallahum fa ulaaa'ika humuz zaalimoon"
  },
  {
    "id": 10,
    "text": "Yaaa ayyuhal lazeena aamanoo izaa jaaa'akumul mu'minaatu muhaajiraatin famtahinoo hunn; Allaahu a'lamu bi eemaani hinn; fa in 'alimtumoo hunna mu'minaatin falaa tarji'oo hunna ilal kuffaar; laa hunna hillul lahum wa laa hum yahilloona lahunna wa aatoohum maa anfaqoo wa laa junaaha 'alaikum an tankihoohunna izaaa aataitumoohunna ujoorahunn; wa laa tumsikoo bi 'isamil kawaafir; was'aloo maaa anfaqtum walyas'aloo maaa anfaqoo; zaalikum hukmul laahi yahkumu bainakum; wallaahu 'aleemun hakeem"
  },
  {
    "id": 11,
    "text": "Wa in faatakum shai'un min azwaajikum ilal kuffaari fa 'aaqabtum fa aatul lazeena zahabat azwaajuhum misla maaa anfaqoo; wattaqul laahal lazeee antum bihee mu'minoon"
  },
  {
    "id": 12,
    "text": "Yaaa ayyuhan nabbiyyu izaa jaaa'akal mu'minaatu yubaayigh'naka 'alaaa allaa yushrikna billaahi shai 'anw wa laa yasriqna wa laa yazneena wa laa yaqtulna awlaadahunna wa laa ya'teena bibuhtaaniny yaftaree nahoo baina aydeehinna wa arjulihinna wa laa ya'seenaka fee ma'roofin fa baayigh' hunna wastaghfir lahunnal-laaha innal-laaha Ghafoorur Raheem"
  },
  {
    "id": 13,
    "text": "Yaaa ayyuhal lazeena amanoo laa tatawallaw qawman ghadibal laahu 'alaihim qad ya'isoo minal aakhirati kamaa ya'isal kuffaaru min as haabil quboor"
  }
];

export default en;
