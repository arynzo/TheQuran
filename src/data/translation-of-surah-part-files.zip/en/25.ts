import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Tabaarakal lazee nazzalal Furqaana 'alaa 'abdihee li yakoona lil'aalameena nazeera"
  },
  {
    "id": 2,
    "text": "Allazee lahoo mulkus samaawaati wal ardi wa lam yattakhiz waladanw wa lam yakul lahoo shareekun filmulki wa khalaqa kulla shai'in faqaddarahoo taqdeeraa"
  },
  {
    "id": 3,
    "text": "Wattakhazoo min dooniheee aalihatal laa yakhluqoona shai'anw wa hum yukhlaqoona wa laa yamlikoona li anfusihim darranw wa laa naf'anw wa laa yamlikoona mawtanw wa laa hayaatanw wa laa nushooraa"
  },
  {
    "id": 4,
    "text": "Wa qaalal lazeena kafarooo in haazaaa illaaa ifkunif taraahu wa a'aanahoo 'alaihi qawmun aakharoona faqad jaaa'oo zulmanw wa zooraa"
  },
  {
    "id": 5,
    "text": "Wa qaalooo asaateerul awwaleenak tatabahaa fahiya tumlaa 'alaihi bukratanw wa aseelaa"
  },
  {
    "id": 6,
    "text": "Qul anzalahul lazee ya'lamus sirra fis samaawaati wal-ard; innahoo kaana Ghafoorar Raheemaa"
  },
  {
    "id": 7,
    "text": "Wa qaaloo maa li haazar Rasooli ya'kulut ta'aama wa yamshee fil aswaaq; law laaa unzila ilaihi malakun fa yakoona ma'ahoo nazeeraa"
  },
  {
    "id": 8,
    "text": "Aw yulqaaa ilaihi kanzun aw takoonu lahoo jannatuny ya'kulu minhaa; wa qaalaz zaalimoona in tattabi'oona illaa rajulan mas hooraa"
  },
  {
    "id": 9,
    "text": "Unzur kaifa daraboo lakal amsaala fadalloo falaa yastatee'oona sabeelaa"
  },
  {
    "id": 10,
    "text": "Tabaarakal lazeee in shaaa'a ja'ala laka khairan min zaalika jannaatin tajree min tahtihal anhaaru wa yaj'al laka qusooraa"
  },
  {
    "id": 11,
    "text": "Bal kazzaboo bis Saa'ati wa a'tadnaa liman kazzaba bis Saa'ati sa'eeraa"
  },
  {
    "id": 12,
    "text": "Izaa ra'at hum min makaanin ba'eedin sami'oo lahaa taghaiyuzanw wa zafeeraa"
  },
  {
    "id": 13,
    "text": "Wa izaaa ulqoo minhaa makaanan daiyiqam muqar raneena da'aw hunaalika thuboora"
  },
  {
    "id": 14,
    "text": "Laa tad'ul yawma thubooranw waahidanw wad'oo thubooran kaseeraa"
  },
  {
    "id": 15,
    "text": "Qul azaalika khairun am Jannatul khuldil latee wu'idal muttaqoon; kaanat lahum jazaaa'anw wa maseeraa"
  },
  {
    "id": 16,
    "text": "Lahum feehaa maa yashaaa'oona khaalideen; kaana 'alaa Rabbika wa'dan mas'oolaa"
  },
  {
    "id": 17,
    "text": "Wa Yawma yahshuruhum wa maa ya'budoona min doonil laahi fa yaqoolu 'a-antum adlaltum 'ibaadee haaa'ulaaa'i am hum dallus sabeel"
  },
  {
    "id": 18,
    "text": "Qaaloo Subhaanaka maa kaana yanbaghee lanaaa an nattakhiza min doonika min awliyaaa'a wa laakin matta'tahum wa aabaaa'ahum hattaa nasooz zikra wa kaanoo qawman booraa"
  },
  {
    "id": 19,
    "text": "Faqad kazzabookum bimaa taqooloona famaa tastatee'oona sarfanw wa laa nasraa; wa many yazlim minkum nuziqhu 'azaaban kabeeraa"
  },
  {
    "id": 20,
    "text": "Wa maaa arsalnaa qablaka minal mursaleena illaaa innahum la ya'kuloonat ta'aama wa yamshoona fil aswaaq; wa ja'alnaa ba'dakum liba'din fitnatan atasbiroon; wa kaana Rabbuka Baseera"
  },
  {
    "id": 21,
    "text": "Wa qaalal lazeena laa yarjoona liqaaa'anaa law laaa unzila 'alainal malaaa'ikatu awnaraa Rabbanaa; laqadistakbaroo feee anfusihim wa 'ataw 'utuwwan kabeeraa"
  },
  {
    "id": 22,
    "text": "Yawma yarawnal malaaa 'ikata laa bushraa Yawmaizin lil mujrimeena wa yaqooloona hijran mahjooraa"
  },
  {
    "id": 23,
    "text": "Wa qadimnaaa ilaa maa 'amiloo min 'amalin faja'alnaahuhabaaa'an manthooraa"
  },
  {
    "id": 24,
    "text": "As haabul jannati yawma'izin khairun mustaqar ranw wa ahsanu maqeela"
  },
  {
    "id": 25,
    "text": "Wa Yawma tashaqqaqus samaaa'u bilghamaami wa nuzzilal malaaa'ikatu tanzeela"
  },
  {
    "id": 26,
    "text": "Almulku Yawma'izinil haqqu lir Rahmaan; wa kaana Yawman'alal kaafireena 'aseeraa"
  },
  {
    "id": 27,
    "text": "Wa Yawma ya'adduz zaalimu 'alaa yadaihi yaqoolu yaa laitanit takhaztu ma'ar Rasooli sabeelaa"
  },
  {
    "id": 28,
    "text": "Yaa wailataa laitanee lam attakhiz fulaanan khaleelaa"
  },
  {
    "id": 29,
    "text": "Laqad adallanee 'aniz zikri ba'da iz jaaa'anee; wa kaanash Shaitaanu lil insaani khazoolaa"
  },
  {
    "id": 30,
    "text": "Wa qaalar Rasoolu yaa Rabbi inna qawmit takhazoo haazal Qur'aana mahjooraa"
  },
  {
    "id": 31,
    "text": "Wa kazaalika ja'alnaa likulli Nabiyyin 'aduwwan minal mujrimeen; wa kafaa bi Rabbika haadiyanw wa naseeraa"
  },
  {
    "id": 32,
    "text": "Wa qaalal lazeena kafaroo law laa nuzzila 'alaihil Qur'aanu jumlatanw waahidah; kazaalika linusabbita bihee fu'aadaka wa rattalnaahu tarteelaa"
  },
  {
    "id": 33,
    "text": "Wa laa ya'toonaka bi masalin illaa ji'naaka bilhaqqi wa ahsana tafseeraa"
  },
  {
    "id": 34,
    "text": "Allazeena yuhsharoona 'alaa wujoohihim ilaa jahannama ulaaa'ika sharrun makaananw wa adallu sabeelaa"
  },
  {
    "id": 35,
    "text": "Wa laqad aatainaa Moosal Kitaaba wa ja'alnaa ma'ahooo akhaahu Haaroona wazeeraa"
  },
  {
    "id": 36,
    "text": "Faqulnaz habaaa ilal qawmil lazeena kazzaboo bi Aayaatinaa fadammarnaahum tadmeeraa"
  },
  {
    "id": 37,
    "text": "Wa qawma Noohin lammaa kazzabur Rusula aghraqnaahum wa ja'alnaahum linnaasi Aayatanw wa a'tadnaa lizzaalimeena 'azaaban aleemaa"
  },
  {
    "id": 38,
    "text": "Wa 'Aadanw wa Samooda wa As haabar Rassi wa quroonan baina zaalika katheeraa"
  },
  {
    "id": 39,
    "text": "Wa kullan darabnaa lahul amsaala wa kullan tabbarnaa tatbeera"
  },
  {
    "id": 40,
    "text": "Wa laqad ataw 'alal qaryatil lateee umtirat mataras saw'; afalam yakoonoo yarawnahaa; bal kaanoo laa yarjoona nushooraa"
  },
  {
    "id": 41,
    "text": "Wa izaa ra awka iny yattakhizoonaka illaa huzuwan ahaazal lazee ba'asal laahu Rasoolaa"
  },
  {
    "id": 42,
    "text": "In kaada la yudillunaa 'an aalihatinaa law laaa an sabarnaa 'alaihaa; wa sawfa ya'lamoona heena yarawnal 'azaaba man adallu sabeela"
  },
  {
    "id": 43,
    "text": "Ara'aita manit takhaza ilaahahoo hawaahu afa anta takoonu 'alaihi wakeelaa"
  },
  {
    "id": 44,
    "text": "Am tahsabu anna aksarahum yasma'oona aw ya'qiloon; in hum illaa kal an'aami bal hum adallu sabeelaa"
  },
  {
    "id": 45,
    "text": "Alam tara ilaa Rabbika kaifa maddaz zilla wa law shaaa'a la ja'alahoo saakinan thumma ja'alnash shamsa 'alaihi daleelaa"
  },
  {
    "id": 46,
    "text": "Thumma qabadnaahu ilainaa qabdany yaseeraa"
  },
  {
    "id": 47,
    "text": "Wa Huwal lazee ja'ala lakumul laila libaasanw wannawma subaatanw wa ja'alan nahaara nushooraa"
  },
  {
    "id": 48,
    "text": "Wa Huwal lazeee arsalar riyaaha bushran baina yadai rahmatih; wa anzalnaa minas samaaa'i maaa'an tahooraa"
  },
  {
    "id": 49,
    "text": "Linuhyiya bihee baldatan maitanw-wa nusqiyahoo mimmaa khalaqnaaa an'aamanw wa anaasiyya katheeraa"
  },
  {
    "id": 50,
    "text": "Wa laqad sarrafnaahu bainahum li yazzakkaroo fa abaaa aksarun naasi illaa kufooraa"
  },
  {
    "id": 51,
    "text": "Wa law shi'naa laba'asnaa fee kulli qaryatin nazeeraa"
  },
  {
    "id": 52,
    "text": "Falaa tuti'il kaafireena wa jaahidhum bihee jihaadan kabeeraa"
  },
  {
    "id": 53,
    "text": "Wa Huwal lazee marajal bahraini haazaa 'azbun furaatunw wa haazaa milhun ujaaj; wa ja'ala bainahumaa barzakhanw wa hijran mahjooraa"
  },
  {
    "id": 54,
    "text": "Wa Huwal lazee khalaqa minal maaa'i basharan fa ja'alahoo nasaban wa sihraa; wa kaana Rabbuka Qadeeraa"
  },
  {
    "id": 55,
    "text": "Wa ya'budoona min doonil laahi maa laa yanfa'uhum wa laa yadurruhum; wa kaanal kaafiru 'alaa Rabbihee zaheeraa"
  },
  {
    "id": 56,
    "text": "Wa maa arsalnaaka illaa mubashshiranw wa nazeeraa"
  },
  {
    "id": 57,
    "text": "Qul maaa as'alukum 'alaihi min ajrin illaa man shaaa'a ai yattakhiza ilaa Rabbihee sabeelaa"
  },
  {
    "id": 58,
    "text": "Wa tawakkal 'alal Haiyil lazee laa yamootu wa sabbih bihamdih; wa kafaa bihee bizunoobi 'ibaadihee khabeeraa"
  },
  {
    "id": 59,
    "text": "Allazee khalaqas samaawaati wal arda wa maa bainahumaa fee sittati aiyaamin thumma stawaa 'alal 'Arsh; ar Rahmaanu fas'al bihee khabeeraa"
  },
  {
    "id": 60,
    "text": "Wa izaa qeela lahumus judoo lir Rahmaani qaaloo wa mar Rahmaanu 'a nasjudu limaa ta'murunaa wa zaadahum nufooraa"
  },
  {
    "id": 61,
    "text": "Tabaarakal lazee ja'ala fis samaaa'i buroojanw wa ja'ala feehaa siraajanw wa qamaran muneeraa"
  },
  {
    "id": 62,
    "text": "Wa huwal lazee ja'alal laila wannahaara khilfatan liman araada 'any yazzakkara aw araadaa shukooraa"
  },
  {
    "id": 63,
    "text": "Wa 'ibaadur Rahmaanil lazeena yamshoona 'alal ardi hawnanw wa izaa khaata bahumul jaahiloona qaaloo salaamaa"
  },
  {
    "id": 64,
    "text": "Wallazeena yabeetoona li Rabbihim sujjadanw wa qiyaamaa"
  },
  {
    "id": 65,
    "text": "Wallazeena yaqooloona Rabbanas rif 'annaa 'azaaba Jahannama inna 'azaabahaa kaana gharaamaa"
  },
  {
    "id": 66,
    "text": "Innahaa saaa'at mustaqarranw wa muqaamaa"
  },
  {
    "id": 67,
    "text": "Wallazeena izaaa anfaqoo lam yusrifoo wa lam yaqturoo wa kaana baina zaalika qawaamaa"
  },
  {
    "id": 68,
    "text": "Wallazeena laa yad'oona ma'al laahi ilaahan aakhara wa laa yaqtuloonan nafsal latee harramal laahu illaa bilhaqqi wa laa yaznoon; wa mai yaf'al zaalika yalqa 'athaamaa"
  },
  {
    "id": 69,
    "text": "Yudaa'af lahul 'azaabu Yawmal Qiyaamati wa yakhlud feehee muhaanaa"
  },
  {
    "id": 70,
    "text": "Illaa man taaba wa 'aamana wa 'amila 'amalan saalihan fa ulaaa'ika yubad dilul laahu saiyi aatihim hasanaat; wa kaanal laahu Ghafoorar Raheemaa"
  },
  {
    "id": 71,
    "text": "Wa man taaba wa 'amila saalihan fa innahoo yatoobu ilal laahi mataabaa"
  },
  {
    "id": 72,
    "text": "Wallazeena laa yash hadoonaz zoora wa izaa marroo billaghwi marroo kiraamaa"
  },
  {
    "id": 73,
    "text": "Wallazeena izaa zukkiroo bi Aayaati Rabbihim lam yakhirroo 'alaihaa summanw wa'umyaanaa"
  },
  {
    "id": 74,
    "text": "Wallazeena yaqooloona Rabbanaa hab lanaa min azwaajinaa wa zurriyaatinaa qurrata a'yuninw waj 'alnaa lilmuttaqeena Imaamaa"
  },
  {
    "id": 75,
    "text": "Ulaaa'ika yujzawnal ghurfata bimaa sabaroo wa yulaqqawna feehaa tahiyyatanw wa salaamaa"
  },
  {
    "id": 76,
    "text": "Khaalideena feehaa; hasunat mustaqarranw wa muqaamaa"
  },
  {
    "id": 77,
    "text": "Qul maa ya'ba'u bikum Rabbee law laa du'aaa'ukum faqad kazzabtum fasawfa yakoonu lizaamaa"
  }
];

export default en;
