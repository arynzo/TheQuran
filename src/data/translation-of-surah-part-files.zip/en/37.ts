import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wassaaaffaati saffaa"
  },
  {
    "id": 2,
    "text": "Fazzaajiraati zajraa"
  },
  {
    "id": 3,
    "text": "Fattaaliyaati Zikra"
  },
  {
    "id": 4,
    "text": "Inna Illaahakum la Waahid"
  },
  {
    "id": 5,
    "text": "Rabbus samaawaati wal ardi wa maa bainahumaa wa Rabbul mashaariq"
  },
  {
    "id": 6,
    "text": "Innaa zaiyannas samaaa 'ad dunyaa bizeenatinil kawaakib"
  },
  {
    "id": 7,
    "text": "Wa hifzam min kulli Shaitaanim maarid"
  },
  {
    "id": 8,
    "text": "Laa yassamma 'oona ilal mala 'il a'alaa wa yuqzafoona min kulli jaanib"
  },
  {
    "id": 9,
    "text": "Duhooranw wa lahum 'azaabunw waasib"
  },
  {
    "id": 10,
    "text": "Illaa man khatifal khatfata fa atba'ahoo shihaabun saaqib"
  },
  {
    "id": 11,
    "text": "Fastaftihim ahum ashaddu khalqan am man khalaqnaa; innaa khalaqnaahum min teenil laazib"
  },
  {
    "id": 12,
    "text": "Bal'ajibta wa yaskharoon"
  },
  {
    "id": 13,
    "text": "Wa izaa zukkiroo laa yazkuroon"
  },
  {
    "id": 14,
    "text": "Wa izaa ra aw Aayatany yastaskhiroon"
  },
  {
    "id": 15,
    "text": "Wa qaalooo in haazaa illaa sihrum mubeen"
  },
  {
    "id": 16,
    "text": "'A-izaa mitnaa wa kunnaa turaabanw wa 'izaaman 'a innaa lamab'oosoon"
  },
  {
    "id": 17,
    "text": "Awa aabaa'unal awwaloon"
  },
  {
    "id": 18,
    "text": "Qul na'am wa antum daakhiroon"
  },
  {
    "id": 19,
    "text": "Fa innamaa hiya zajra tunw waahidatun fa izaa hum yanzuroon"
  },
  {
    "id": 20,
    "text": "Wa qaaloo yaa wailanaa haazaa Yawmud-Deen"
  },
  {
    "id": 21,
    "text": "Haazaa Yawmul Faslil lazee kuntum bihee tukaziboon"
  },
  {
    "id": 22,
    "text": "Uhshurul lazeena zalamoo wa azwaajahum wa maa kaanoo ya'budoon"
  },
  {
    "id": 23,
    "text": "Min doonil laahi fahdoohum ilaa siraatil Jaheem"
  },
  {
    "id": 24,
    "text": "Wa qifoohum innahum mas'ooloon"
  },
  {
    "id": 25,
    "text": "Maa lakum laa tanaasaroon"
  },
  {
    "id": 26,
    "text": "Bal humul Yawma mustaslimoon"
  },
  {
    "id": 27,
    "text": "Wa aqbala ba'duhum 'alaa ba'diny yatasaaa'aloon"
  },
  {
    "id": 28,
    "text": "Qaalooo innakum kuntum taatoonanaa 'anil yameen"
  },
  {
    "id": 29,
    "text": "Qaaloo bal lam takoonoo mu'mineen"
  },
  {
    "id": 30,
    "text": "Wa maa kaana lanaa 'alaikum min sultaanim bal kuntum qawman taagheen"
  },
  {
    "id": 31,
    "text": "Fahaqqa 'alainaa qawlu Rabbinaaa innaa lazaaa'iqoon"
  },
  {
    "id": 32,
    "text": "Fa aghwainaakum innaa kunnaa ghaaween"
  },
  {
    "id": 33,
    "text": "Fa innahum Yawma'izin fil'azaabi mushtarikoon"
  },
  {
    "id": 34,
    "text": "Innaa kazaalika naf'alu bil mujrimeen"
  },
  {
    "id": 35,
    "text": "Innahum kaanooo izaa qeela lahum laaa ilaaha illal laahu yastakbiroon"
  },
  {
    "id": 36,
    "text": "Wa yaqooloona a'innaa lataarikooo aalihatinaa lishaa'irim majnoon"
  },
  {
    "id": 37,
    "text": "bal jaaa'a bilhaqqi wa saddaqal mursaleen"
  },
  {
    "id": 38,
    "text": "Innakum lazaaa'iqul 'azaabil aleem"
  },
  {
    "id": 39,
    "text": "Wa maa tujzawna illaa maa kuntum ta'maloon"
  },
  {
    "id": 40,
    "text": "Illaa 'ibaadal laahil mukhlaseen"
  },
  {
    "id": 41,
    "text": "Ulaaa'ika lahum rizqum ma'loom"
  },
  {
    "id": 42,
    "text": "Fa waakihu wa hum mukramoon"
  },
  {
    "id": 43,
    "text": "Fee jannaatin Na'eem"
  },
  {
    "id": 44,
    "text": "'Alaa sururim mutaqaa bileen"
  },
  {
    "id": 45,
    "text": "Yutaafu 'alaihim bikaasim mim ma'een"
  },
  {
    "id": 46,
    "text": "Baidaaa'a laz zatil lish shaaribeen"
  },
  {
    "id": 47,
    "text": "Laa feehaa ghawlunw wa laa hum 'anhaa yunzafoon"
  },
  {
    "id": 48,
    "text": "Wa 'indahum qaasiraatut tarfi 'een"
  },
  {
    "id": 49,
    "text": "Ka annahunna baidum maknoon"
  },
  {
    "id": 50,
    "text": "Fa aqbala ba'duhum 'alaa badiny yatasaaa 'aloon"
  },
  {
    "id": 51,
    "text": "Qaala qaaa'ilum minhum innee kaana lee qareen"
  },
  {
    "id": 52,
    "text": "Yaqoolu 'a innaka laminal musaddiqeen"
  },
  {
    "id": 53,
    "text": "'A-izaa mitnaa wa kunnaa turaabanw wa 'izaaman 'a innaa lamadeenoon"
  },
  {
    "id": 54,
    "text": "Qaala hal antum muttali'oon"
  },
  {
    "id": 55,
    "text": "Fattala'a fara aahu fee sawaaa'il Jaheem"
  },
  {
    "id": 56,
    "text": "Qaala tallaahi in kitta laturdeen"
  },
  {
    "id": 57,
    "text": "Wa law laa ni'matu Rabbee lakuntu minal muhdareen"
  },
  {
    "id": 58,
    "text": "Afamaa nahnu bimaiyiteen"
  },
  {
    "id": 59,
    "text": "Illa mawtatanal oola wa maa nahnu bimu'azzabeen"
  },
  {
    "id": 60,
    "text": "Inna haazaa lahuwal fawzul 'azeem"
  },
  {
    "id": 61,
    "text": "Limisli haaza falya'ma lil 'aamiloon"
  },
  {
    "id": 62,
    "text": "Azaalika khairun nuzulan am shajaratuz Zaqqoom"
  },
  {
    "id": 63,
    "text": "Innaa ja'alnaahaa fitnatal lizzaalimeen"
  },
  {
    "id": 64,
    "text": "Innahaa shajaratun takhruju feee aslil Jaheem"
  },
  {
    "id": 65,
    "text": "Tal'uhaa ka annahoo ru'oosush Shayaateen"
  },
  {
    "id": 66,
    "text": "Fa innahum la aakiloona minhaa famaali'oona minhal butoon"
  },
  {
    "id": 67,
    "text": "Summa inna lahum 'alaihaa lashawbam min hameem"
  },
  {
    "id": 68,
    "text": "Summa inna marji'ahum la ilal Jaheem"
  },
  {
    "id": 69,
    "text": "Innahum alfaw aabaaa'ahum daaalleen"
  },
  {
    "id": 70,
    "text": "Fahum 'alaa aasaarihim yuhra'oon"
  },
  {
    "id": 71,
    "text": "Wa laqad dalla qablahum aksarul awwaleen"
  },
  {
    "id": 72,
    "text": "Wa laqad arsalnaa feehim munzireen"
  },
  {
    "id": 73,
    "text": "Fanzur kaifa kaana 'aaqibatul munzareen"
  },
  {
    "id": 74,
    "text": "Illaa 'ibaadal laahil mukhlaseen"
  },
  {
    "id": 75,
    "text": "Wa laqad naadaanaa Noohun falani'mal mujeeboon"
  },
  {
    "id": 76,
    "text": "Wa najjainaahu wa ahlahoo minal karbil 'azeem"
  },
  {
    "id": 77,
    "text": "Wa ja'alnaa zurriyyatahoo hummul baaqeen"
  },
  {
    "id": 78,
    "text": "Wa taraknaa 'alaihi fil aakhireen"
  },
  {
    "id": 79,
    "text": "Salaamun 'alaa Noohin fil 'aalameen"
  },
  {
    "id": 80,
    "text": "Innaa kazaalika najzil muhsineen"
  },
  {
    "id": 81,
    "text": "Innahoo min 'ibaadinal mu'mineen"
  },
  {
    "id": 82,
    "text": "Summa aghraqnal aakhareen"
  },
  {
    "id": 83,
    "text": "Wa inna min shee'atihee la Ibraaheem"
  },
  {
    "id": 84,
    "text": "Iz jaaa'a Rabbahoo bi qalbin saleem"
  },
  {
    "id": 85,
    "text": "Iz qaala li abeehi wa qawmihee maazaa ta'budoon"
  },
  {
    "id": 86,
    "text": "A'ifkan aalihatan doonal laahi tureedoon"
  },
  {
    "id": 87,
    "text": "Famaa zannukum bi Rabbil'aalameen"
  },
  {
    "id": 88,
    "text": "Fanazara nazratan finnujoom"
  },
  {
    "id": 89,
    "text": "Faqaala innee saqeem"
  },
  {
    "id": 90,
    "text": "Fatawallaw 'anhu mudbireen"
  },
  {
    "id": 91,
    "text": "Faraagha ilaaa aalihatihim faqaala alaa taakuloon"
  },
  {
    "id": 92,
    "text": "Maa lakum laa tantiqoon"
  },
  {
    "id": 93,
    "text": "Faraagha 'alaihim darbam bilyameen"
  },
  {
    "id": 94,
    "text": "Fa aqbalooo ilaihi yaziffoon"
  },
  {
    "id": 95,
    "text": "Qaala ata'budoona maa tanhitoon"
  },
  {
    "id": 96,
    "text": "Wallaahu khalaqakum wa maa ta'maloon"
  },
  {
    "id": 97,
    "text": "Qaalub noo lahoo bun yaanan fa alqoohu fil jaheem"
  },
  {
    "id": 98,
    "text": "Fa araadoo bihee kaidan faja 'alnaahumul asfaleen"
  },
  {
    "id": 99,
    "text": "Wa qaala innee zaahibun ilaa Rabbee sa yahdeen"
  },
  {
    "id": 100,
    "text": "Rabbi hab lee minas saaliheen"
  },
  {
    "id": 101,
    "text": "Fabashsharnaahu bighulaamin haleem"
  },
  {
    "id": 102,
    "text": "Falamma balagha ma'a hus sa'ya qaala yaa buniya inneee araa fil manaami anneee azbahuka fanzur maazaa taraa; qaala yaaa abatif 'al maa tu'maru satajidunee in shaaa'allaahu minas saabireen"
  },
  {
    "id": 103,
    "text": "Falammaaa aslamaa wa tallahoo liljabeen"
  },
  {
    "id": 104,
    "text": "Wa naadainaahu ai yaaaa Ibraheem"
  },
  {
    "id": 105,
    "text": "Qad saddaqtar ru'yaa; innaa kazaalika najzil muhsineen"
  },
  {
    "id": 106,
    "text": "Inna haazaa lahuwal balaaa'ul mubeen"
  },
  {
    "id": 107,
    "text": "Wa fadainaahu bizibhin 'azeem"
  },
  {
    "id": 108,
    "text": "Wa taraknaa 'alaihi fil aakhireen"
  },
  {
    "id": 109,
    "text": "Salaamun 'alaaa Ibraaheem"
  },
  {
    "id": 110,
    "text": "Kazaalika najzil muhsineen"
  },
  {
    "id": 111,
    "text": "Innahoo min 'ibaadinal mu'mineen"
  },
  {
    "id": 112,
    "text": "Wa bashsharnaahu bi Ishaaqa Nabiyam minas saaliheen"
  },
  {
    "id": 113,
    "text": "Wa baaraknaa 'alaihi wa 'alaaa Ishaaq; wa min zurriyya tihimaa muhsinunw wa zaalimul linafsihee mubeen"
  },
  {
    "id": 114,
    "text": "Wa laqad mananna alaa Moosaa wa Haaroon"
  },
  {
    "id": 115,
    "text": "Wa najjainaahumaa wa qawmahumaa minal karbil 'azeem"
  },
  {
    "id": 116,
    "text": "Wa nasarnaahum fakaanoo humul ghaalibeen"
  },
  {
    "id": 117,
    "text": "Wa aatainaahumal Kitaabal mustabeen"
  },
  {
    "id": 118,
    "text": "Wa hadainaahumus Siraatal Mustaqeem"
  },
  {
    "id": 119,
    "text": "Wa taraknaa 'alaihimaa fil aakhireen"
  },
  {
    "id": 120,
    "text": "Salaamun 'alaa Moosaa wa Haaroon"
  },
  {
    "id": 121,
    "text": "Innaa kazaalika najzil muhsineen"
  },
  {
    "id": 122,
    "text": "Innahumaa min 'ibaadinal mu'mineen"
  },
  {
    "id": 123,
    "text": "Wa inna Ilyaasa laminal mursaleen"
  },
  {
    "id": 124,
    "text": "Iz qaala liqawmiheee alaa tattaqoon"
  },
  {
    "id": 125,
    "text": "Atad'oona Ba'lanw wa tazaroona ahsanal khaaliqeen"
  },
  {
    "id": 126,
    "text": "Allaaha Rabbakum wa Rabba aabaaa'ikumul awwaleen"
  },
  {
    "id": 127,
    "text": "Fakazzaboohu fa inna hum lamuhdaroon"
  },
  {
    "id": 128,
    "text": "Illaa 'ibaadal laahil mukhlaseen"
  },
  {
    "id": 129,
    "text": "Wa taraknaa 'alaihi fil aakhireen"
  },
  {
    "id": 130,
    "text": "Salaamun 'alaaa Ilyaaseen"
  },
  {
    "id": 131,
    "text": "Innaa kazaalika najzil muhsineen"
  },
  {
    "id": 132,
    "text": "Innahoo min 'ibaadinal mu'mineen"
  },
  {
    "id": 133,
    "text": "Wa inna Lootal laminal mursaleen"
  },
  {
    "id": 134,
    "text": "Iz najjainaahu wa ahlahooo ajma'een"
  },
  {
    "id": 135,
    "text": "Illaa 'ajoozan fil ghaabireen"
  },
  {
    "id": 136,
    "text": "Summa dammarnal aakhareen"
  },
  {
    "id": 137,
    "text": "Wa innakum latamurroona 'alaihim musbiheen"
  },
  {
    "id": 138,
    "text": "Wa billail; afalaa ta'qiloon"
  },
  {
    "id": 139,
    "text": "Wa inna Yoonusa laminal mursaleen"
  },
  {
    "id": 140,
    "text": "Iz abaqa ilal fulkil mash hoon"
  },
  {
    "id": 141,
    "text": "Fasaahama fakaana minal mudhadeen"
  },
  {
    "id": 142,
    "text": "Faltaqamahul hootu wa huwa muleem"
  },
  {
    "id": 143,
    "text": "Falaw laaa annahoo kaana minal musabbiheen"
  },
  {
    "id": 144,
    "text": "Lalabisa fee batniheee ilaa Yawmi yub'asoon"
  },
  {
    "id": 145,
    "text": "Fanabaznaahu bil'araaa'i wa huwa saqeem"
  },
  {
    "id": 146,
    "text": "Wa ambatnaa 'alaihi shajaratam mai yaqteen"
  },
  {
    "id": 147,
    "text": "Wa arsalnaahu ilaa mi'ati alfin aw yazeedoon"
  },
  {
    "id": 148,
    "text": "Fa aamanoo famatta' naahum ilaa heen"
  },
  {
    "id": 149,
    "text": "Fastaftihim ali Rabbikal banaatu wa lahumul banoon"
  },
  {
    "id": 150,
    "text": "Am khalaqnal malaaa'i kata inaasanw wa hum shaahidoon"
  },
  {
    "id": 151,
    "text": "Alaaa innahum min ifkihim la yaqooloon"
  },
  {
    "id": 152,
    "text": "Waladal laahu wa innahum lakaaziboon"
  },
  {
    "id": 153,
    "text": "Astafal banaati 'alal baneen"
  },
  {
    "id": 154,
    "text": "Maa lakum kaifa tahkumoon"
  },
  {
    "id": 155,
    "text": "Afalaa tazakkaroon"
  },
  {
    "id": 156,
    "text": "Am lakum sultaanum mubeen"
  },
  {
    "id": 157,
    "text": "Faatoo bi Kitaabikum in kuntum saadiqeen"
  },
  {
    "id": 158,
    "text": "Wa ja'aloo bainahoo wa bainal jinnati nasabaa; wa laqad 'alimatil jinnatu innahum lamuhdaroon"
  },
  {
    "id": 159,
    "text": "Subhaanal laahi 'ammaa yasifoon"
  },
  {
    "id": 160,
    "text": "Illaa 'ibaadal laahil mukhlaseen"
  },
  {
    "id": 161,
    "text": "Fa innakum wa maa ta'budoon"
  },
  {
    "id": 162,
    "text": "Maaa antum 'alaihi bi faaatineen"
  },
  {
    "id": 163,
    "text": "Illaa man huwa saalil jaheem"
  },
  {
    "id": 164,
    "text": "Wa maa minnaaa illaa lahoo maqaamun ma'loom"
  },
  {
    "id": 165,
    "text": "Wa innaa lanah nus saaffoon"
  },
  {
    "id": 166,
    "text": "Wa innaa lanah nul musabbihoon"
  },
  {
    "id": 167,
    "text": "Wa in kaanoo la yaqooloon"
  },
  {
    "id": 168,
    "text": "Law anna 'indanaa zikram minal awwaleen"
  },
  {
    "id": 169,
    "text": "Lakunna 'ibaadal laahil mukhlaseen"
  },
  {
    "id": 170,
    "text": "Fakafaroo bihee fasawfa ya'lamoon"
  },
  {
    "id": 171,
    "text": "Wa laqad sabaqat Kalimatunaa li'ibaadinal mursa leen"
  },
  {
    "id": 172,
    "text": "Innaa hum lahumul mansooroon"
  },
  {
    "id": 173,
    "text": "Wa inna jundana lahumul ghaaliboon"
  },
  {
    "id": 174,
    "text": "Fatawalla 'anhum hatta heen"
  },
  {
    "id": 175,
    "text": "Wa absirhum fasawfa yubsiroon"
  },
  {
    "id": 176,
    "text": "Afabi'azaabinaa yasta'jiloon"
  },
  {
    "id": 177,
    "text": "Fa izaa nazala bisaahatihim fasaaa'a sabaahul munzareen"
  },
  {
    "id": 178,
    "text": "Wa tawalla 'anhum hattaa heen"
  },
  {
    "id": 179,
    "text": "Wa absir fasawfa yubsiroon"
  },
  {
    "id": 180,
    "text": "Subhaana Rabbika Rabbil 'izzati 'amma yasifoon"
  },
  {
    "id": 181,
    "text": "Wa salaamun 'alalmursaleen"
  },
  {
    "id": 182,
    "text": "Walhamdu lillaahi Rabbil 'aalameen"
  }
];

export default en;
