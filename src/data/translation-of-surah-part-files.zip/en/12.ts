import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Raa; tilka Aayaatul Kitaabil Mubeen"
  },
  {
    "id": 2,
    "text": "Innaaa anzalnaahu quraanan 'Arabiyyal la 'allakum ta'qiloon"
  },
  {
    "id": 3,
    "text": "Nahnu naqussu 'alaika ahsanal qasasi bimaaa awhainaaa ilaika haazal quraana wa in kunta min qablihee laminal ghaafileen"
  },
  {
    "id": 4,
    "text": "Iz qaala Yoosufu li abeehi yaaa abati innee ra aytu ahada 'ashara kawkabanw wash shamsa walqamara ra aytuhum lee saajideen"
  },
  {
    "id": 5,
    "text": "Qaala yaa bunaiya laa taqsus ru'yaaka 'alaaa ikhwatika fayakeedoo laka kaidaa; innash Shaitaana lil insaani 'aduwwum mubeen"
  },
  {
    "id": 6,
    "text": "Wa kazaalika yajtabeeka rabbuka wa yu'allimuka min ta'weelil ahaadeesi wa yutimmu ni'matahoo 'alaika wa 'alaaa Aali Ya'qooba kamaaa atammahaa 'alaaa abawaika min qablu Ibraaheema wa Ishaaq; inna Rabbaka 'Aleemun hakeem"
  },
  {
    "id": 7,
    "text": "Laqad kaana fee Yoosufa wa ikhwatiheee Aayaatul lissaaa'ileen"
  },
  {
    "id": 8,
    "text": "Iz qaaloo la Yoosufu wa akhoohu ahabbu ilaaa Abeenaa minnaa wa nahnu 'usbatun; inna abaanaa lafee dalaalim mubeen"
  },
  {
    "id": 9,
    "text": "Uqtuloo Yoosufa awitra hoohu ardany yakhlu lakum wajhu abeekum wa takoonoo mim ba'dihee qawman saaliheen"
  },
  {
    "id": 10,
    "text": "Qaalaa qaaa'ilum minhum laa taqtuloo Yoosufa wa alqoohu fee ghayaabatil jubbi yaltaqithu badus sai yaarati in kuntum faa 'ileen"
  },
  {
    "id": 11,
    "text": "Qaaloo yaaa abaanaa maa laka laa ta'mannaa 'alaa Yoosufa wa innaa lahoo lanaa sihoon"
  },
  {
    "id": 12,
    "text": "Arsillhu ma'anaa ghadany yarta' wa yal'ab wa innaa lahoo la haafizoon"
  },
  {
    "id": 13,
    "text": "Qaala innee la yahzununeee an tazhaboo bihee wa akhaafu any ya'kulahuz zi'bu wa antum 'anhu ghaafiloon"
  },
  {
    "id": 14,
    "text": "Qaaloo la in akalahuzzi'bu wa nahnu 'usbatun innaaa izal lakhaasiroon"
  },
  {
    "id": 15,
    "text": "Falammaa zahaboo bihee wa ajma'ooo anyyaj'aloohu fee ghayaabatil jubb; wa awhainaaa ilaihi latunabbi 'annahum bi amrihim haaza wa hum laa yash'uroon"
  },
  {
    "id": 16,
    "text": "Wa jaaa'ooo abaahum 'ishaaa 'any yabkoon"
  },
  {
    "id": 17,
    "text": "Qaaloo yaaa abaanaaa innaa zahabnaa nastabiqu wa taraknaa Yoosufa 'inda mataa'inaa fa akalahuz zi'b, wa maaa anta bimu'minil lanaa wa law kunnaa saadiqeen"
  },
  {
    "id": 18,
    "text": "Wa jaaa'oo 'alaa qameesi hee bidamin kazib qaala bal sawwalat lakum anfusukum amraa; fasabrun jameel; wallaahul musta'aanu 'alaa maatasifoon"
  },
  {
    "id": 19,
    "text": "Wa jaaa'at saiyaaratun fa-arsaloo waaridahum fa adlaa dalwah; qaala yaa bushraa haaza ghulaam; wa asarroohu bi-daa'ah; wallaahu 'aleemun bimaa ya'maloon"
  },
  {
    "id": 20,
    "text": "Wa sharawhu bisamanim bakhsin daraahima ma'doo datinw wa kaanoo feehi minaz zaahideen"
  },
  {
    "id": 21,
    "text": "Wa qaalal lazish taraahu mim Misra limra atiheee akrimee maswaahu 'asaaa any- yanfa'anaaa aw nattakhizahoo waladaa; wa kazaalika mak-kannaa li-Yoosufa fil ardi wa linu'allimahoo min ta'weelil ahaadees; wallaahu ghaalibun 'alaaa amrihee wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 22,
    "text": "Wa lammaa balagha ashuddahooo aatainaahu hukmanw wa 'ilmaa; wa kazaa lika najzil muhsineen"
  },
  {
    "id": 23,
    "text": "Wa raawadat hul latee huwa fee baitihaa 'an nafsihee wa ghallaqatil abwaaba wa qaalat haita lak; qaala ma'aazal laahi innahoo rabbeee ahsana maswaay; innahoo laa yuflihuz- zaalimoon"
  },
  {
    "id": 24,
    "text": "Wa laqad hammat bihee wa hamma bihaa law laaa ar ra-aa burhaana rabbih; kazaalika linasrifa 'anhu sooo'a walfahshaaa'; innahoo min 'ibaadi nal mukhlaseen"
  },
  {
    "id": 25,
    "text": "Wastabaqal baaba wa qaddat qameesahoo min duburinw wa alfayaa saiyidahaa ladal baab; qaalat maa jazaaa'u man araada bi ahlika sooo'an illaaa any-yusjana aw azaabun 'aleem"
  },
  {
    "id": 26,
    "text": "Qaala hiya raawadatnee 'an nafsee wa shahida shaahidum min ahlihaa in kaana qameesuhoo qudda min qubulin fasadaqat wa huwa minal kaazibeen"
  },
  {
    "id": 27,
    "text": "Wa in kaana qameesuhoo qudda min duburin fakazabat wa huwa minas saadiqeen"
  },
  {
    "id": 28,
    "text": "Falammaa ra-aa qamee sahoo qudda min duburin qaala innahoo min kaidikunna inna kaidakunna 'azeem"
  },
  {
    "id": 29,
    "text": "Yoosufu a'rid 'an haaza wastaghfiree li zanbiki innaki kunti minal khaati'een"
  },
  {
    "id": 30,
    "text": "Wa qaala niswatun fil madeenatim ra atul'Azeezi turaawidu fataahaa 'an nafsihee qad shaghafahaa hubbaa; innaa lana raahaa fee dalaalim mubeen"
  },
  {
    "id": 31,
    "text": "Falammaa sami'at bimak rihinna arsalat ilaihinna wa a'tadat lahunna muttaka anw wa aatat kulla waahidatim min hunna sikkeenanw wa qaala tikh ruj 'alaihinna falammaa ra aynahooo akbarnahoo wa qatta'na aydiyahunna wa qulna haasha lillaahi maa haaza basharaa; in haazaaa illaa malakun kareem"
  },
  {
    "id": 32,
    "text": "Qaalat fazaalikunnal lazee lumtunnanee feeh; wa laqad raawattuhoo 'an nafsihee fasta'sam; wa la'il lam yaf'al maaa aamuruhoo la yusjananna wa la yakoonan minas saaghireen"
  },
  {
    "id": 33,
    "text": "Qaala rabbis sijnu ahabbu ilaiya mimma yad'oo naneee 'ilaihi wa illaa tasrif 'annee kaidahunna asbu ilaihinna wa akum minal jaahileen"
  },
  {
    "id": 34,
    "text": "Fastajaaba lahoo rabbuhoo fasarafa 'anhu kaidahunn; innahoo huwas Samee'ul 'Aleem"
  },
  {
    "id": 35,
    "text": "Summa badaa lahum min ba'di maa ra-awul Aayaati layasjununnahoo hatta heen"
  },
  {
    "id": 36,
    "text": "Wa dakhala ma'a hussijna fata-yaan; qaala ahaduhumaaa inneee araaneee a'siru khamranw wa qaalal aakharu inneee araaneee ahmilu fawqa ra'see khubzan ta'kulut tairu minhu; nabbi'naa bi ta'weelih; innaa naraaka minal muhsineen"
  },
  {
    "id": 37,
    "text": "Qaala laa ya'teekumaa ta'aamun turzaqaaniheee illaa nabba'tukumaa bi ta'weelihee; qabla any ya'ti yakumaa; zaalikumaa mimmaa 'allamanee rabbee; innee taraktu millata qawmil laa yu'minoona billaahi wahum bil aakhirati hum kaafiroon"
  },
  {
    "id": 38,
    "text": "Wattaba'tu millata aabaaa'eee Ibraaheema wa Ishaaqa wa Ya'qoob; maa kaana lanaaa an nushrika billaahi min shai'; zaalikamin fadlil laahi 'alainaa wa 'alan naasi wa laakinna aksaran naasi laa yashkuroon"
  },
  {
    "id": 39,
    "text": "Yaa saahibayis sijni 'a-arbaabum mutafarriqoona khayrun amil laahul waahidul qahhaar"
  },
  {
    "id": 40,
    "text": "Maa ta'budoona min doonihee illaaa asmaaa'an sam maitumoohaaa antum wa aabaaa'ukum maaa anzalal laahu bihaa min sultan; inilhukmu illaa lillaah; amara allaa ta'budooo illaaa iyyaah; zaalikad deenul qaiyimu wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 41,
    "text": "Yaa saahibayis sijni ammaaa ahadukumaa fa yasqee rabbahoo khamranw wa ammal aakharu fa yuslabu fata'kulut tairu mir ra'sih; qudiyal amrul lazee feehi tastaftiyaan"
  },
  {
    "id": 42,
    "text": "Wa qaala lillazee zanna annahoo najim minhumaz kurnee 'inda rabbika fa-ansaahush Shaitaanu zikra Rabbihee falabisa fis sijni bid'a sineen"
  },
  {
    "id": 43,
    "text": "Wa qaalal maliku inneee araa sab'a baqaraatin simaaniny ya'kuluhunna sab'un 'ijaafunw wa sab'a sumbulaatin khudrinw wa ukhara yaabisaat; yaaa ayuhal mala-u aftoonee fee ru'yaaya in kuntum lirru'yaa ta'buroon"
  },
  {
    "id": 44,
    "text": "Qaalooo adghaasu ahlaa minw wa maa nahnu bi ta'weelil ahlaami bi'aalimeen"
  },
  {
    "id": 45,
    "text": "Wa qaalal lazee najaa minhumaa waddakara ba'da ummatin ana unabbi'ukum bi ta'weelihee fa-arsiloon"
  },
  {
    "id": 46,
    "text": "Yoosufu ayyuhas siddeequ aftinaa fee sab'i baqaraatin simaaniny ya'kuluhunna sab'un 'ijaafunw wa sabi'i sumbulaatin khudrinw wa ukhara yaabisaatil la'alleee arji'u ilan naasi la'allahum ya'lamoon"
  },
  {
    "id": 47,
    "text": "Qaala tazra'oona sab'a sineena da aban famaa hasattum fazaroohu fee sumbu liheee illaa qaleelam mimmaa ta'kuloon"
  },
  {
    "id": 48,
    "text": "Thumma ya'tee mim ba'di zaalika sab'un shidaaduny ya'kulna maa qaddamtum lahunna illaa qaleelam mimma tuhsinoon"
  },
  {
    "id": 49,
    "text": "Thumma ya'tee mim ba'di zalika 'aamun feehi yughaa sun naasu wa feehi ya'siroon"
  },
  {
    "id": 50,
    "text": "Wa qaalal maliku'toonee bihee falammaa jaaa'ahur rasoolu qaalar-ji ilaa rabbika fas'alhu maa baalun niswatil laatee qatta'na aydiyahunn; inna Rabbee bikaidihinna 'Aleem"
  },
  {
    "id": 51,
    "text": "Qaala maa khatbukunna iz raawattunna Yoosufa 'annafsih; qulna haasha lillaahi maa 'alimnaa 'alaihi min sooo'; qaalatim ra atul 'Azeezil 'aana hashasal haqq, ana raawat tuhoo 'an nafsihee wa innahoo laminas saadiqeen"
  },
  {
    "id": 52,
    "text": "Zaalika liya'lama annee lam akhunhu bilghaibi wa annal laaha laa yahdee kaidal khaaa'ineen"
  },
  {
    "id": 53,
    "text": "Wa maa ubarri'u nafsee; innan nafsa la ammaaratum bissooo'i illaa maa rahima Rabbee; inna Rabbee Ghafoorur Raheem"
  },
  {
    "id": 54,
    "text": "Wa qaalal maliku' toonee biheee astakhlishu linafsee falammaa kallamahoo qaala innakal yawma ladainaa makeenun ameen"
  },
  {
    "id": 55,
    "text": "Qaalaj 'alnee 'alaa khazaaa'inil ardi innee hafeezun 'aleem"
  },
  {
    "id": 56,
    "text": "Wa kazaalika makkannaa li Yoosufa fil ardi yatabawwa'u minhaa haisu yashaaaa'; nuseebu birahmatinaa man nashaaa'u wa laa nudee'u ajral muhsineen"
  },
  {
    "id": 57,
    "text": "Wa la ajrul Aakhirati khairul lillazeena aamanoo wa kaanoo yattaqoon"
  },
  {
    "id": 58,
    "text": "Wa jaaa'a ikhwatu Yoosufa fadakhaloo 'alaihi fa'arafahum wa hum lahoo munkiroon"
  },
  {
    "id": 59,
    "text": "Wa lammaa jahhazahum bijahaazihim qaala' toonee bi akhil lakum min abeekum; alaa tarawna anneee oofil kaila wa ana khairul munzileen"
  },
  {
    "id": 60,
    "text": "Fa il lam taatoonee bihee falaa kaila lakum 'indee wa laa taqraboon"
  },
  {
    "id": 61,
    "text": "Qaaloo sanuraawidu 'anhu abaahu wa innaa lafaa'iloon"
  },
  {
    "id": 62,
    "text": "Wa qaala lifityaanihij 'aloo bidaa'atahum fee rihaalihim la'allahum ya'rifoonahaaa izan qalabooo ilaaa ahlihim la'allahum yarji'oon"
  },
  {
    "id": 63,
    "text": "Falammaa raja'ooo ilaaa abeehim qaaloo yaaa abaanaa muni'a minnal kailu fa arsil ma'anaaa akhaanaa naktal wa innaa lahoo lahaafizoon"
  },
  {
    "id": 64,
    "text": "Qaala hal aamanukum 'alaihi illaa kamaa amintukum 'alaaa akheehi min qabl; fal laahu khairun haafizanw wa Huwa arhamur Raahimeen"
  },
  {
    "id": 65,
    "text": "Wa lammaa fatahoo mataa 'ahum wajadoo bidaa'atahum ruddat ilaihim qaaloo yaaa abaanaa maa nabghee; haazihee bida 'atunaa ruddat ilainaa wa nameeru ahlanaa wa nahfazu akhaanaa wa nazdaadu kaila ba'eer; zaalika kailuny yaseer"
  },
  {
    "id": 66,
    "text": "Qaala lan ursilahoo ma'akum hattaa tu'tooni mawsiqam minal laahee lataa tunnanee biheee illaaa ai yuhaata bikum falammaaa aatawhu mawsiqahum qaalal laahu 'alaa maa naqoolu Wakeel"
  },
  {
    "id": 67,
    "text": "Wa qaala yaa baniyya laa tadkhuloo mim baabinw waa hidinw wadkhuloo min abwaabim mutafarriqah; wa maaa ughnee 'ankum minal laahi min shai'in; inil hukmu illaa lillaahi 'alaihi tawakkaltu wa 'alaihi fal yatawakkalil Mutawakkiloon"
  },
  {
    "id": 68,
    "text": "Wa lammaa dakhaloo min haisu amarahum aboohum maa kaana yughnee 'anhum minal laahi min shai'in illaa haajatan fee nafsi Ya'qooba qadaahaa; wa innahoo lazoo 'ilmil limaa 'allamnaahu wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 69,
    "text": "Wa lammaa dakhaloo 'alaa Yoosufa aawaaa ilaihi akhaahu qaala inneee ana akhooka falaa tabta'is bimaa kaanoo ya'maloon"
  },
  {
    "id": 70,
    "text": "Falammaa jahhazahum bijahaazihim ja'alas siqaayata fee rahli akheehi summa azzana mu'azzinun ayyatuhal'eeru innakum lasaariqoon"
  },
  {
    "id": 71,
    "text": "Qaaloo wa aqbaloo 'alaihim maazaa tafqidoon"
  },
  {
    "id": 72,
    "text": "Qaaloo nafqidu suwaa'al maliki wa liman jaaa'a bihee himlu ba'eerinw wa ana bihee za'eem"
  },
  {
    "id": 73,
    "text": "Qaaloo tallaahi laqad 'alimtum maa ji'na linufsida fil ardi wa maa kunnaa saariqeen"
  },
  {
    "id": 74,
    "text": "Qaaloo famaa jazaaa'u hooo in kuntum kaazibeen"
  },
  {
    "id": 75,
    "text": "Qaaloo jazaaa'uhoo manw wujida fee rahlihee fahuwa jazaaa'uh; kazaalika najziz zaalimeen"
  },
  {
    "id": 76,
    "text": "Fabada-a bi-aw'iyatihim qabla wi'aaa'i akheehi summas takhrajahaa minw wi 'aaa'i akheeh; kazaalika kidnaa li Yoosuf; maa kaana liyaakhuza akhaahu fee deenil maliki illaaa any yashaaa'al laah; narfa'u darajaatim man nashaaa'; wa fawqa kulli zee 'ilmin 'Aleem"
  },
  {
    "id": 77,
    "text": "Qaaloo iny yasriq faqad saraqa akhul lahoo min qabl; fa asarrahaa Yoosufu fee nafsihee wa lam yubdihaa lahum; qaala antum sharrum makaananw wallaahu a'lamu bimaa tasifoon"
  },
  {
    "id": 78,
    "text": "Qaaloo yaaa ayyuhal 'Azeezu inna lahooo aban shaikhan kabeeran fakhuz ahadanaa makaanahoo innaa naraaka minal muhsineen"
  },
  {
    "id": 79,
    "text": "Qaala ma'aazal laahi an naakhuza illaa manw wajadnaa mataa'anaa 'indahoo innaaa izal lazaalimoon"
  },
  {
    "id": 80,
    "text": "Falammas tay'asoo minhu khalasoo najiyyan qaala kabeeruhum alam ta'lamoo anna abaakum qad akhaza 'alaikum mawthiqam min Allahi wa min qablu maa farrattum fee Yoosufa falan abrahal arda hattaa ya'zana leee abeee aw yahkumal laahu lee wa huwa khairul haakimeen"
  },
  {
    "id": 81,
    "text": "Irji'ooo ilaaa abeekum faqooloo yaaa abaanaaa innab naka saraq; wa maa shahidnaaa illaa bimaa 'alimnaa wa maa kunnaa lilghaibi haafizeen"
  },
  {
    "id": 82,
    "text": "Was'alil qaryatal latee kunnaa feehaa wal'eeral lateee aqbalnaa feehaa wa innaa lasaadiqoon"
  },
  {
    "id": 83,
    "text": "Qaala bal sawwalat lakum anfusukum amran fasabrun jameelun 'asal laahu any yaa tiyanee bihim jamee'aa; innahoo Huwal 'Aleemul Hakeem"
  },
  {
    "id": 84,
    "text": "Wa tawallaa 'anhum wa qaala yaaa asafaa 'alaa Yoosufa wabyaddat 'aynaahu minal huzni fahuwa kazeem"
  },
  {
    "id": 85,
    "text": "Qaaloo tallaahi tafta'u tazkuru Yoosufa hattaa takoona haradan aw takoona minal haalikeen"
  },
  {
    "id": 86,
    "text": "Qaala innamaaa ashkoo bassee wa huzneee ilal laahi wa a'lamu minal laahi maa laa ta'lamoon"
  },
  {
    "id": 87,
    "text": "Yaa baniyyaz haboo fatahassasoo miny Yoosufa wa akheehi wa laa tai'asoo mir rawhil laahi innahoo laa yai'asu mir rawhil laahi illal qawmul kaafiroon"
  },
  {
    "id": 88,
    "text": "Falammaa dakhaloo 'alaihi qaaloo yaaa ayyuhal 'Azeezu massanaa wa ahlanad durru wa ji'naa bi bidaa 'im muzjaatin fa awfi lanal kaila wa tasaddaq 'alainaa innal laaha yajzil mutasaddiqeen"
  },
  {
    "id": 89,
    "text": "Qaala hal 'alimtum maa fa'altum bi Yoosufa wa akheehi iz antum jaahiloon"
  },
  {
    "id": 90,
    "text": "Qaaloo 'a innaka la anta Yoosufu qaala ana Yoosufu wa haazaaa akhee qad mannal laahu 'alainaa innahoo mai yattaqi wa yasbir fa innal laaha laa yudee'u ajral muhsineen"
  },
  {
    "id": 91,
    "text": "Qaaloo tallaahi laqad aatharakal laahu 'alainaa wa in kunnaa lakhaati'een"
  },
  {
    "id": 92,
    "text": "Qaala laa tathreeba 'alaikumul yawma yaghfirul laahu lakum wa Huwa arhamur raahimeen"
  },
  {
    "id": 93,
    "text": "Izhaboo biqameesee haazaa fa alqoohu 'alaa wajhi abee ya'ti baseeranw wa'toonee bi ahlikum ajma'een"
  },
  {
    "id": 94,
    "text": "Wa lammaa fasalatil 'eeru qaala aboohum innee la ajidu reeha Yoosufa law laaa an tufannidoon"
  },
  {
    "id": 95,
    "text": "Qaaloo tallaahi innaka lafee dalaalikal qadeem"
  },
  {
    "id": 96,
    "text": "Falammaaa an jaaa'albasheeru alqaahu 'alaa wajhihee fartadda baseeran qaala alam aqul lakum inneee a'lamu minal laahi maa laa ta'lamoon"
  },
  {
    "id": 97,
    "text": "Qaaloo yaaa abaanas taghfir lanaa zunoobanaa innaa kunnaa khaati'een"
  },
  {
    "id": 98,
    "text": "Qaala sawfa astaghfiru lakum Rabbeee innahoo Huwal Ghafoorur Raheem"
  },
  {
    "id": 99,
    "text": "Falammaa dakhaloo 'alaa Yoosufa aawaaa ilaihi abawaiyhi wa qaalad khuloo Misra inshaaa'al laahu aamineen"
  },
  {
    "id": 100,
    "text": "Wa raf'a abawaihi 'alal 'arshi wa kharroo lahoo sujjadaa; wa qaala yaaa abati haaza taaweelu ru'yaaya min qablu qad ja'alahaa Rabbee haqqaa; wa qad ahsana beee iz akhrajanee minas sijni wa jaaa'a bikum minal badwi mim ba'di an nazaghash Shaitaanu bainee wa baina ikhwatee; inna Rabbee lateeful limaa yashaaa'; innahoo Huwal 'Aleemul Hakeem"
  },
  {
    "id": 101,
    "text": "Rabbi qad aataitanee minal mulki wa 'allamtanee min taaweelil ahaadees; faati ras samaawaati wal ardi Anta waliyyee fid dunyaa wal Aakhirati tawaffanee muslimanw wa alhiqnee bissaaliheen"
  },
  {
    "id": 102,
    "text": "Zaalika min ambaaa'il ghaibi nooheehi ilaika wa maa kunta ladaihim iz ajma'ooo amrahum wa hum yamkuroon"
  },
  {
    "id": 103,
    "text": "Wa maa aksarun naasi wa law harasta bimu'mineen"
  },
  {
    "id": 104,
    "text": "Wa maa tas'aluhum 'alaihi min ajr; in huwa illaa zikrul lil'aalameen"
  },
  {
    "id": 105,
    "text": "Wa ka ayyim min Aayatin fis samaawaati wal ardi yamurroona 'alaihaa wa hum 'anhaa mu'ridoon"
  },
  {
    "id": 106,
    "text": "Wa maa yu'minu aksaru hum billaahi illaa wa hum mushrikoon"
  },
  {
    "id": 107,
    "text": "Afa aminooo an taatiya hum ghaashiyatum min 'azaabil laahi aw taatiyahumus Saa'atu baghtatanw wa hum laa yash'uroon"
  },
  {
    "id": 108,
    "text": "Qul haazihee sabeeleee ad'ooo ilal laah; 'alaa baseera tin ana wa manit taba'anee wa Subhaanal laahi wa maaa ana minal mushrikeen"
  },
  {
    "id": 109,
    "text": "Wa maaa arsalnaa min qablika illaa rijaalan nooheee ilaihim min ahlil quraa; afalam yaseeroo fil ardi fa yanzuroo kaifa kaana 'aaqibatul lazeena min qablihim; wa la Daarul Aakhirati Khairul lillazeenat taqaw; afalaa ta'qiloon"
  },
  {
    "id": 110,
    "text": "Hattaaa izas tai'asar Rusulu wa zannooo annahum qad kuziboo jaaa'ahum nas runaa fanujjiya man nashaaa'u wa laa yuraddu ba'suna 'anil qawmil mujrimeen"
  },
  {
    "id": 111,
    "text": "Laqad kaana fee qasasihim 'ibratul li ulil albaab; maa kaana hadeethany yuftaraa wa laakin tasdeeqal lazee baina yadaihi wa tafseela kulli shai'inw wa hudanw wa rahmatal liqawminy yu'minoon"
  }
];

export default en;
