import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Innaaa arsalnaa Noohan ilaa qawmihee an anzir qawmaka min qabli any yaatiyahum 'azaabun aleem"
  },
  {
    "id": 2,
    "text": "Qaala yaa qawmi innee lakum nazeerum mubeen"
  },
  {
    "id": 3,
    "text": "Ani'-budul laaha watta qoohu wa atee'oon"
  },
  {
    "id": 4,
    "text": "Yaghfir lakum min zunoobikum wa yu'akhkhirkum ilaaa ajalim musammaa; innaa ajalal laahi izaa jaaa'a laa yu'akhkhar; law kuntum ta'lamoon"
  },
  {
    "id": 5,
    "text": "Qaala rabbi innee da'awtu qawmee lailanw wa naharaa"
  },
  {
    "id": 6,
    "text": "Falam yazid hum du'aaa 'eee illaa firaaraa"
  },
  {
    "id": 7,
    "text": "Wa inee kullamaa da'awtuhum litaghfira lahum ja'alooo asaabi'ahum fee aazaanihim wastaghshaw siyaabahum wa asaarroo wastakbarus tikbaaraa"
  },
  {
    "id": 8,
    "text": "Summa innee da'aw tuhum jihaara"
  },
  {
    "id": 9,
    "text": "Summaa inneee a'lantu lahum wa asrartu lahum israaraa"
  },
  {
    "id": 10,
    "text": "Faqultus taghfiroo Rabbakum innahoo kaana Ghaffaaraa"
  },
  {
    "id": 11,
    "text": "Yursilis samaaa'a 'alaikum midraaraa"
  },
  {
    "id": 12,
    "text": "Wa yumdidkum bi am waalinw wa baneena wa yaj'al lakum Jannaatinw wa yaj'al lakum anhaaraa"
  },
  {
    "id": 13,
    "text": "Maa lakum laa tarjoona lillaahi waqaaraa"
  },
  {
    "id": 14,
    "text": "Wa qad khalaqakum at waaraa"
  },
  {
    "id": 15,
    "text": "Alam taraw kaifa khalaqal laahu sab'a samaawaatin tibaaqaa"
  },
  {
    "id": 16,
    "text": "Wa ja'alal qamara feehinna nooranw wa ja'alash shamsa siraajaa"
  },
  {
    "id": 17,
    "text": "Wallaahu ambatakum minal ardi nabaataa"
  },
  {
    "id": 18,
    "text": "Summa yu'eedukum feehaa wa yukhrijukum ikhraajaa"
  },
  {
    "id": 19,
    "text": "Wallaahu ja'ala lakumul arda bisaataa"
  },
  {
    "id": 20,
    "text": "Litaslukoo minhaa subulan fijaajaa"
  },
  {
    "id": 21,
    "text": "Qaala Noohur Rabbi innahum 'asawnee wattaba'oo mal lam yazid hu maaluhoo wa waladuhooo illaa khasaara"
  },
  {
    "id": 22,
    "text": "Wa makaroo makran kubbaaraa"
  },
  {
    "id": 23,
    "text": "Wa qaaloo laa tazarunna aalihatakum wa laa tazarunna Waddanw wa laa Suwaa'anw wa laa Yaghoosa wa Ya'ooqa wa Nasraa"
  },
  {
    "id": 24,
    "text": "Wa qad adalloo kaseera; wa laa tazidiz zaalimeena illaa dalaalaa"
  },
  {
    "id": 25,
    "text": "Mimmaa khateee' aatihim ughriqoo fa udkhiloo Naaran falam yajidoo lahum min doonil laahi ansaaraa"
  },
  {
    "id": 26,
    "text": "Wa qaala Noohur Rabbi laa tazar 'alal ardi minal kaafireena daiyaaraa"
  },
  {
    "id": 27,
    "text": "Innaka in tazarhum yudil loo 'ibaadaka wa laa yalidooo illaa faajiran kaffaaraa"
  },
  {
    "id": 28,
    "text": "Rabbigh fir lee wa liwaa lidaiya wa liman dakhala baitiya mu'minanw wa lil mu'mineena wal mu'minaati wa laa tazidiz zaalimeena illaa tabaaraa"
  }
];

export default en;
