import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Izash shamsu kuwwirat"
  },
  {
    "id": 2,
    "text": "Wa izan nujoomun kadarat"
  },
  {
    "id": 3,
    "text": "Wa izal jibaalu suyyirat"
  },
  {
    "id": 4,
    "text": "Wa izal 'ishaaru 'uttilat"
  },
  {
    "id": 5,
    "text": "Wa izal wuhooshu hushirat"
  },
  {
    "id": 6,
    "text": "Wa izal bihaaru sujjirat"
  },
  {
    "id": 7,
    "text": "Wa izan nufoosu zuwwijat"
  },
  {
    "id": 8,
    "text": "Wa izal maw'oodatu su'ilat"
  },
  {
    "id": 9,
    "text": "Bi ayyi zambin qutilat"
  },
  {
    "id": 10,
    "text": "Wa izas suhufu nushirat"
  },
  {
    "id": 11,
    "text": "Wa izas samaaa'u kushitat"
  },
  {
    "id": 12,
    "text": "Wa izal jaheemu su'-'irat"
  },
  {
    "id": 13,
    "text": "Wa izal jannatu uzlifat"
  },
  {
    "id": 14,
    "text": "'Alimat nafsum maaa ahdarat"
  },
  {
    "id": 15,
    "text": "Falaaa uqsimu bil khunnas"
  },
  {
    "id": 16,
    "text": "Al jawaaril kunnas"
  },
  {
    "id": 17,
    "text": "Wallaili izaa 'as'as"
  },
  {
    "id": 18,
    "text": "Wassubhi izaa tanaffas"
  },
  {
    "id": 19,
    "text": "Innahoo laqawlu rasoolin kareem"
  },
  {
    "id": 20,
    "text": "Zee quwwatin 'inda zil 'arshi makeen"
  },
  {
    "id": 21,
    "text": "Mutaa'in samma ameen"
  },
  {
    "id": 22,
    "text": "Wa maa saahibukum bimajnoon"
  },
  {
    "id": 23,
    "text": "Wa laqad ra aahu bilufuqil mubeen"
  },
  {
    "id": 24,
    "text": "Wa maa huwa 'alal ghaibi bidaneen"
  },
  {
    "id": 25,
    "text": "Wa maa huwa biqawli shaitaanir rajeem"
  },
  {
    "id": 26,
    "text": "Fa ayna tazhaboon"
  },
  {
    "id": 27,
    "text": "In huwa illaa zikrul lil'aalameen"
  },
  {
    "id": 28,
    "text": "Liman shaaa'a minkum ai yastaqeem"
  },
  {
    "id": 29,
    "text": "Wa maa tashaaa'oona illaaa ai yashaaa 'al laahu Rabbul 'Aalameen"
  }
];

export default en;
