import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yaa ayyuhal lazeena aamanoo la tuqaddimoo baina yada yil laahi wa Rasoolihee wattaqul laah; innal laaha samee'un 'Aleem"
  },
  {
    "id": 2,
    "text": "Yaa ayyuhal lazeena aamanoo laa tarfa'ooo aswaatakum fawqa sawtin Nabiyi wa laa tajharoo lahoo bilqawli kajahri ba'dikum liba 'din an tahbata a 'maalukum wa antum laa tash'uroon"
  },
  {
    "id": 3,
    "text": "Innal lazeena yaghud doona aswaatahum 'inda Rasoolil laahi ulaaa'ikal lazeenam tah anal laahu quloobahum littaqwaa; lahum maghfiratunw wa'ajrun 'azeem"
  },
  {
    "id": 4,
    "text": "Innal lazeena yunaadoo naka minw waraaa'il hujuraati aksaruhum laa ya'qiloon"
  },
  {
    "id": 5,
    "text": "Wa law annahum sabaroo hatta takhruja ilaihim lakaana khairal lahum; wallaahu Ghafoorur Raheem"
  },
  {
    "id": 6,
    "text": "Yaaa ayyuhal lazeena aamanoo in jaaa'akum faasiqum binaba in fatabaiyanooo an tuseeboo qawmam bijahalatin fatusbihoo 'alaa maa fa'altum naadimeen"
  },
  {
    "id": 7,
    "text": "Wa'lamooo anna feekum Rasoolal laah; law yutee'ukum fee kaseerim minal amrila'anittum wa laakinnal laaha habbaba ilaikumul eemaana wa zaiyanahoo fee quloobikum wa karraha ilaikumul kufra walfusooqa wal'isyaan; ulaaaika humur raashidoon"
  },
  {
    "id": 8,
    "text": "Fadlam minal laahi wa ni'mah; wallaahu 'Aleemun Hakeem"
  },
  {
    "id": 9,
    "text": "Wa in taaa'ifataani minal mu'mineena naqtataloo fa aslihoo bainahumaa; fa-im baghat ihdaahumaa 'alal ukhraa faqaatilul latee tabghee hattaa tafeee'a ilaaa amril laah; fa-in faaa'at fa aslihoo bainahumaa bil'adli wa aqsitoo, innal laaha yuhibbul muqsiteen"
  },
  {
    "id": 10,
    "text": "Innamal mu'minoona ikhwatun fa aslihoo baina akhawaykum wattaqul laaha la'allakum turhamoon"
  },
  {
    "id": 11,
    "text": "Yaaa ayyuhal lazeena aamanoo laa yaskhar qawmum min qawmin 'asaaa anyyakoonoo khairam minhum wa laa nisaaa'um min nisaaa'in 'Asaaa ay yakunna khairam minhunna wa laa talmizooo anfusakum wa laa tanaabazoo bil alqaab; bi'sal ismul fusooqu ba'dal eemaan; wa mal-lam yatub fa-ulaaa'ika humuz zaalimoon"
  },
  {
    "id": 12,
    "text": "Yaaa ayyuhal lazeena aamanuj taniboo kaseeram minaz zanni inna ba'daz zanniismunw wa laa tajassasoo wa la yaghtab ba'dukum ba'daa; a yuhibbu ahadukum any yaakula lahma akheehi maitan fakarih tumooh; wattaqul laa; innal laaha tawwaabur Raheem"
  },
  {
    "id": 13,
    "text": "Yaaa ayyuhan naasu innaa khalaqnaakum min zakarinw wa unsaa wa ja'alnaakum shu'oobanw wa qabaaa'ila lita'aarafoo inna akramakum 'indal laahi atqaakum innal laaha 'Aleemun khabeer"
  },
  {
    "id": 14,
    "text": "Qaalatil-A 'raabu aamannaa qul lam tu'minoo wa laakin qoolooo aslamnaa wa lamma yadkhulil eemaanu fee quloobikum wa in tutee'ul laaha wa Rasoolahoo laa yalitkum min a'maalikum shai'aa; innal laaha Ghafoorur Raheem"
  },
  {
    "id": 15,
    "text": "Innamal muu'minoonal lazeena aamanoo billaahi wa Rasoolihee summa lam yartaaboo wa jaahadoo biamwaalihim wa anfusihim fee sabeelil laah; ulaaaika humus saadiqoon"
  },
  {
    "id": 16,
    "text": "Qul atu'allimoonal laaha bideenikum wallaahu ya'lamu maa fis samaawaati wa maa fil ard; wallaahu bikulli shai'in 'Aleem"
  },
  {
    "id": 17,
    "text": "Yamunnoona 'alaika an aslamoo qul laa tamunnoo 'alaiya Islaamakum balillaahu yamunnu 'alaikum an hadaakum lil eemaani in kuntum saadiqeen"
  },
  {
    "id": 18,
    "text": "Innal laaha ya'lamu ghaibas samaawaati wal ard; wallaahu baseerum bimaa ta'maloon"
  }
];

export default en;
