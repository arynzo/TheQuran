import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Ara 'aytal lazee yukazzibu biddeen"
  },
  {
    "id": 2,
    "text": "Fazaalikal lazee yadu'ul-yateem"
  },
  {
    "id": 3,
    "text": "Wa la yahuddu 'alaa ta'aamil miskeen"
  },
  {
    "id": 4,
    "text": "Fa wailul-lil musalleen"
  },
  {
    "id": 5,
    "text": "Allazeena hum 'an salaatihim saahoon"
  },
  {
    "id": 6,
    "text": "Allazeena hum yuraaa'oon"
  },
  {
    "id": 7,
    "text": "Wa yamna'oonal maa'oon"
  }
];

export default en;
