import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Ya aiyuhal muzzammil"
  },
  {
    "id": 2,
    "text": "Qumil laila illaa qaleelaa"
  },
  {
    "id": 3,
    "text": "Nisfahooo awinqus minhu qaleelaa"
  },
  {
    "id": 4,
    "text": "Aw zid 'alaihi wa rattilil Qur'aana tarteela"
  },
  {
    "id": 5,
    "text": "Innaa sanulqee 'alaika qawlan saqeelaa"
  },
  {
    "id": 6,
    "text": "Inna naashi'atal laili hiya ashadddu wat anw wa aqwamu qeelaa"
  },
  {
    "id": 7,
    "text": "Inna laka fin nahaari sabhan taweelaa"
  },
  {
    "id": 8,
    "text": "Wazkuris ma rabbika wa tabattal ilaihi tabteelaa"
  },
  {
    "id": 9,
    "text": "Rabbul mashriqi wal maghriibi laaa ilaaha illaa Huwa fattakhizhu wakeelaa"
  },
  {
    "id": 10,
    "text": "Wasbir 'alaa maa yaqoo loona wahjurhum hajran jameelaa"
  },
  {
    "id": 11,
    "text": "Wa zarnee walmukaz zibeena ulin na'mati wa mahhilhum qaleelaa"
  },
  {
    "id": 12,
    "text": "Inna ladainaaa ankaalanw wa jaheemaa"
  },
  {
    "id": 13,
    "text": "Wa ta'aaman zaa ghussa tinw wa'azaaban aleemaa"
  },
  {
    "id": 14,
    "text": "Yawma tarjuful ardu waljibaalu wa kaanatil jibaalu kaseebam maheelaa"
  },
  {
    "id": 15,
    "text": "Innaa arsalnaaa ilaikum rasoolan shaahidan 'aleykum kamaaa arsalnaaa ilaa Fir'awna rasoolaa"
  },
  {
    "id": 16,
    "text": "Fa'asaa Fir'awnur Rasoola fa akhaznaahu akhzanw wabeelaa"
  },
  {
    "id": 17,
    "text": "Fakaifa tattaqoona in kafartum yawmany yaj'alul wildaana sheeba"
  },
  {
    "id": 18,
    "text": "Assamaaa'u munfatirum bih; kaana wa'duhoo maf'oola"
  },
  {
    "id": 19,
    "text": "Inna haazihee tazkira; fa man shaaa'at takhaza ilaa Rabbihee sabeelaa"
  },
  {
    "id": 20,
    "text": "Inna Rabbaka ya'lamu annaka taqoomu adnaa min sulusa yil laili wa nisfahoo wa sulusahoo wa taaa'ifatum minal lazeena ma'ak; wal laahu yuqaddirul laila wanna haar; 'alima al lan tuhsoohu fataaba 'alaikum faqra'oo maa tayassara minal quraan; 'alima an sa yakoonu minkum mardaa wa aakharoona yadriboona fil ardi yabtaghoona min fadlil laahi wa aakharoona yuqaatiloona fee sabeelil laahi faqra'oo ma tayassara minhu wa aqeemus salaata wa aatuz zakaata wa aqridul laaha qardan hasanaa; wa maa tuqaddimoo li anfusikum min khairin tajidoohu 'indal laahi huwa khayranw wa a'zama ajraa; wastaghfirul laahaa innal laaha ghafoorur raheem."
  }
];

export default en;
