import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wat teeni waz zaitoon"
  },
  {
    "id": 2,
    "text": "Wa toori sineen"
  },
  {
    "id": 3,
    "text": "Wa haazal balad-il ameen"
  },
  {
    "id": 4,
    "text": "Laqad khalaqnal insaana fee ahsani taqweem"
  },
  {
    "id": 5,
    "text": "Thumma ra dad naahu asfala saafileen"
  },
  {
    "id": 6,
    "text": "Ill-lal lazeena aamanoo wa 'amilus saalihaati; falahum ajrun ghairu mamnoon"
  },
  {
    "id": 7,
    "text": "Fama yu kaz zibuka b'adu bid deen"
  },
  {
    "id": 8,
    "text": "Alai sal laahu bi-ahkamil haakimeen"
  }
];

export default en;
