import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "'Amma Yatasaa-aloon"
  },
  {
    "id": 2,
    "text": "'Anin-nabaa-il 'azeem"
  },
  {
    "id": 3,
    "text": "Allazi hum feehi mukh talifoon"
  },
  {
    "id": 4,
    "text": "Kallaa sa y'alamoon"
  },
  {
    "id": 5,
    "text": "Thumma kallaa sa y'alamoon"
  },
  {
    "id": 6,
    "text": "Alam naj'alil arda mihaa da"
  },
  {
    "id": 7,
    "text": "Wal jibaala au taada"
  },
  {
    "id": 8,
    "text": "Wa khalaq naakum azwaaja"
  },
  {
    "id": 9,
    "text": "Waja'alna naumakum subata"
  },
  {
    "id": 10,
    "text": "Waja'alnal laila libasa"
  },
  {
    "id": 11,
    "text": "Waja'alnan nahara ma 'aasha"
  },
  {
    "id": 12,
    "text": "Wa banaina fauqakum sab 'an shi daada"
  },
  {
    "id": 13,
    "text": "Waja'alna siraajaw wah haaja"
  },
  {
    "id": 14,
    "text": "Wa anzalna minal m'usiraati maa-an thaj-jaaja"
  },
  {
    "id": 15,
    "text": "Linukh rija bihee habbaw wana baata"
  },
  {
    "id": 16,
    "text": "Wa jan naatin alfafa"
  },
  {
    "id": 17,
    "text": "Inna yaumal-fasli kana meeqaata"
  },
  {
    "id": 18,
    "text": "Yauma yun fakhu fis-soori fataa' toona afwaaja"
  },
  {
    "id": 19,
    "text": "Wa futiha tis samaa-u fakaanat abwaaba"
  },
  {
    "id": 20,
    "text": "Wa suyyi raatil jibaalu fa kaanat saraaba"
  },
  {
    "id": 21,
    "text": "Inna jahan nama kaanat mirsaada"
  },
  {
    "id": 22,
    "text": "Lit taa gheena ma aaba"
  },
  {
    "id": 23,
    "text": "Laa bitheena feehaa ahqaaba"
  },
  {
    "id": 24,
    "text": "Laa ya zooqoona feeha bar daw walaa sharaaba"
  },
  {
    "id": 25,
    "text": "Illa hamee maw-wa ghas saaqa"
  },
  {
    "id": 26,
    "text": "Jazaa-aw wi faaqa"
  },
  {
    "id": 27,
    "text": "Innahum kaanu laa yarjoona hisaaba"
  },
  {
    "id": 28,
    "text": "Wa kazzabu bi aayaa tina kizzaba"
  },
  {
    "id": 29,
    "text": "Wa kulla shai-in ahsai naahu kitaa ba"
  },
  {
    "id": 30,
    "text": "Fa zooqoo falan-nazee dakum ill-laa azaaba"
  },
  {
    "id": 31,
    "text": "Inna lil mutta qeena mafaaza"
  },
  {
    "id": 32,
    "text": "Hadaa-iqa wa a'anaa ba"
  },
  {
    "id": 33,
    "text": "Wa kaawa 'iba at raaba"
  },
  {
    "id": 34,
    "text": "Wa ka'san di haaqa"
  },
  {
    "id": 35,
    "text": "Laa yasma'oona fiha lagh waw walaa kizzaba"
  },
  {
    "id": 36,
    "text": "Jazaa-am mir-rabbika ataa-an hisaaba"
  },
  {
    "id": 37,
    "text": "Rabbis samaa waati wal ardi wa maa baina humar rahmaani laa yam likoona minhu khitaaba"
  },
  {
    "id": 38,
    "text": "Yauma yaqoo mur roohu wal malaa-ikatu saf-fal laa yatakallamoona ill-laa man azina lahur rahmaanu wa qaala sawaaba"
  },
  {
    "id": 39,
    "text": "Zaalikal yaumul haqqu faman shaa-at ta khaaza ill-laa rabbihi ma-aaba"
  },
  {
    "id": 40,
    "text": "In naa anzar naakum azaaban qareebaiy-yauma yan zurul marr-u maa qaddamat yadaahu wa ya qoolul-kaafiru yaa lai tanee kuntu turaaba"
  }
];

export default en;
