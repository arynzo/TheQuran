import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Kaaaf-Haa-Yaa-'Ayyyn-Saaad"
  },
  {
    "id": 2,
    "text": "Zikru rahmati Rabbika 'abdahoo Zakariyya"
  },
  {
    "id": 3,
    "text": "Iz naadaa Rabbahoo nidaaa'an khafiyyaa"
  },
  {
    "id": 4,
    "text": "Qaala Rabbi innee wahanal 'azmu minnee washta 'alar ra'su shaibanw wa lam akum bidu'aaa'ika Rabbi shaqiyyaa"
  },
  {
    "id": 5,
    "text": "Wa innee khiftul mawaaliya minw waraaa'ee wa kaanat imra atee 'aqiran fa hablee mil ladunka waliyyaa"
  },
  {
    "id": 6,
    "text": "Yarisunee wa yarisu min aali Ya'qoob, waj'alhu Rabbi radiyya"
  },
  {
    "id": 7,
    "text": "Yaa Zakariyyaaa innaa nubashshiruka bi ghulaamin ismuhoo Yahyaa lam naj'al lahoo min qablu samiyyaa"
  },
  {
    "id": 8,
    "text": "Qaala Rabbi annaa yakoonu lee ghulaamunw wakaanat imra atee 'aaqiranw wa qad balaghtu minal kibari 'itiyyaa"
  },
  {
    "id": 9,
    "text": "Qaala kazaalika qaala Rabbuka huwa 'alaiya haiyinunw wa qad khalaqtuka min qablu wa lam taku shai'aa"
  },
  {
    "id": 10,
    "text": "Qaala Rabbij 'al leee Aayah; qaala Aayatuka allaa tukalliman naasa salaasa layaalin sawiyyaa"
  },
  {
    "id": 11,
    "text": "Fakharaja 'alaa qawmihee minal mihraabi fa-awhaaa ilaihim an sabbihoo bukratanw wa 'ashiyyaa"
  },
  {
    "id": 12,
    "text": "Yaa Yahyaa khuzil Kitaaba biquwwatinw wa aatainaahul hukma sabiyyaa"
  },
  {
    "id": 13,
    "text": "Wa hanaanam mil ladunnaa wa zakaatanw wa kaana taqiyyaa"
  },
  {
    "id": 14,
    "text": "Wa barram biwaalidayhi wa lam yakum jabbaaran 'asiyyaa"
  },
  {
    "id": 15,
    "text": "Wa salaamun 'alaihi yawma wulida wa yawma yamootu wa yawma yub'asu haiyyaa"
  },
  {
    "id": 16,
    "text": "Wazkur fil Kitaabi Maryama; izin tabazat min ahlihaa makaanan sharqiyyaa"
  },
  {
    "id": 17,
    "text": "Fattakhazat min doonihim hijaaban fa arsalnaaa ilaihaa roohanaa fatamassala lahaa basharan sawiyyaa"
  },
  {
    "id": 18,
    "text": "Qaalat inneee a'oozu bir Rahmaani minka in kunta taqiyyaa"
  },
  {
    "id": 19,
    "text": "Qaala innamaa ana rasoolu Rabbiki li ahaba laki ghulaaman zakiyyaa"
  },
  {
    "id": 20,
    "text": "Qaalat anna yakoonu lee ghulaamunw wa lam yamsasnee bashrunw wa lam aku baghiyyaa"
  },
  {
    "id": 21,
    "text": "Qaala kazaaliki qaala Rabbuki huwa 'alaiya haiyinuwn wa linaj 'alahooo Aayatal linnaasi wa rahmatam minnaa; wa kaana amram maqdiyyaa"
  },
  {
    "id": 22,
    "text": "Fahamalat hu fantabazat bihee makaanan qasiyyaa"
  },
  {
    "id": 23,
    "text": "Fa ajaaa 'ahal makhaadu ilaa jiz'in nakhlati qaalat yaa laitanee mittu qabla haazaa wa kuntu nasyam mansiyyaa"
  },
  {
    "id": 24,
    "text": "Fanaadaahaa min tahtihaaa allaa tahzanee qad ja'ala Rabbuki tahtaki sariyyaa"
  },
  {
    "id": 25,
    "text": "Wa huzzeee ilaiki bijiz 'in nakhlati tusaaqit 'alaiki rutaban janiyyaa"
  },
  {
    "id": 26,
    "text": "Fakulee washrabee wa qarree 'ainaa; fa immaa tarayinnna minal bashari ahadan faqooleee innee nazartu lir Rahmaani sawman falan ukallimal yawma insiyyaa"
  },
  {
    "id": 27,
    "text": "Fa atat bihee qawmahaa tahmiluhoo qaaloo yaa Maryamoo laqad ji'ti shai'an fariyyaa"
  },
  {
    "id": 28,
    "text": "Yaaa ukhta Haaroona maa kaana abookimra'a saw'inw wa maa kaanat ummuki baghiyyaa"
  },
  {
    "id": 29,
    "text": "Fa ashaarat ilaih; qaaloo kaifa nukallimu man kaana fil mahdi sabiyyaa"
  },
  {
    "id": 30,
    "text": "Qaala innee 'abdullaahi aataaniyal Kitaaba wa ja'alanee Nabiyyaa"
  },
  {
    "id": 31,
    "text": "Wa ja'alanee mubaarakan aina maa kuntu wa awsaanee bis Salaati waz Zakaati maa dumtu haiyaa"
  },
  {
    "id": 32,
    "text": "Wa barram biwaalidatee wa lam yaj'alnee jabbaaran shaqiyyaa"
  },
  {
    "id": 33,
    "text": "Wassalaamu 'alaiya yawma wulidtu wa yawma amootu wa yawma ub'asu haiyaa"
  },
  {
    "id": 34,
    "text": "Zaalika 'Eesab-nu Maryama; qawlal haqqil lazee feehi yamtaroon"
  },
  {
    "id": 35,
    "text": "Maa kaana lillaahi ai yattakhiza minw waladin Subhaanah; izaa qadaaa amran fa innamaa yaqoolu lahoo kun fa yakoon"
  },
  {
    "id": 36,
    "text": "Wa innal laaha Rabbee wa Rabbukum fa'budooh; haazaa Siraatum Mustaqeem"
  },
  {
    "id": 37,
    "text": "Fakhtalafal ahzaabu min bainihim fawailul lillazeena kafaroo min mashhadi Yawmin 'azeem"
  },
  {
    "id": 38,
    "text": "Asmi' bihim wa absir Yawma ya'toonanaa laakiniz zaalimoonal yawma fee dalaalin mubeen"
  },
  {
    "id": 39,
    "text": "Wa anzirhum Yawmal hasrati iz qudiyal amr; wa hum fee ghaflatinw wa hum laa yu'minoon"
  },
  {
    "id": 40,
    "text": "Innaa nahnu narisul arda wa man 'alaihaa wa ilainaa yurja'oon"
  },
  {
    "id": 41,
    "text": "Wazkur fil Kitaabi Ibraaheem; innahoo kaana siddeeqan Nabiyyaa"
  },
  {
    "id": 42,
    "text": "Iz qaala li abeehi yaaa abati lima ta'budu maa laa yasma'u wa laa yubsiru wa laa yughnee 'anka shai'aa"
  },
  {
    "id": 43,
    "text": "Yaaa abati innee qad jaaa'anee minal 'ilmi maa lam ya'tika fattabi'neee ahdika siraatan Sawiyyaa"
  },
  {
    "id": 44,
    "text": "Yaaa abati laa ta'budish Shaitaan; innash Shaitaana kaana lir Rahmaani 'asiyyaa"
  },
  {
    "id": 45,
    "text": "Yaaa abati innee akhaafu ai yamassaka 'azaabum minar Rahmaani fatakoona lish Shaitaani waliyyaa"
  },
  {
    "id": 46,
    "text": "Qaala araaghibun anta 'an aalihatee yaaa Ibraaheemu la 'il lam tantahi la arjumannaka wahjurnee maliyyaa"
  },
  {
    "id": 47,
    "text": "Qaala salaamun 'alaika sa astaghfiru laka Rabbeee innahoo kaana bee hafiyyaa"
  },
  {
    "id": 48,
    "text": "Wa a'tazilukum wa maa tad'oona min doonil laahi wa ad'oo Rabbee 'asaaa allaaa akoona bidu'aaa'i Rabbee shaqiyyaa"
  },
  {
    "id": 49,
    "text": "Fa lam ma'tazalahum wa maa ya'budoona min doonil laahi wahabnaa lahoo is-haaqa wa ya'qoob; wa kullan ja'alnaa Nabiyyaa"
  },
  {
    "id": 50,
    "text": "Wa wahabnaa lahum mirrahmatinaa wa ja'alnaa lahum lisaana sidqin 'aliyyaa"
  },
  {
    "id": 51,
    "text": "Wazkur fil Kitaabi Moosaaa; innahoo kaana mukhlasanw wa kaana Rasoolan Nabiyyaa"
  },
  {
    "id": 52,
    "text": "Wa naadainaahu min jaanibit Tooril aimani wa qarrabnaahu najiyyaa"
  },
  {
    "id": 53,
    "text": "Wa wahabnaa lahoo mir rahmatinaaa akhaahu Haaroona Nabiyyaa"
  },
  {
    "id": 54,
    "text": "Wazkur fil Kitaabi ismaa'eel; innahoo kaana saadiqal wa'di wa kaana Rasoolan Nabiyyaa"
  },
  {
    "id": 55,
    "text": "Wa kaana ya'muru ahlahoo bis Salaati waz zakaati wa kaana 'inda Rabbihee mardiyyaa"
  },
  {
    "id": 56,
    "text": "Wazkur fil Kitaabi Idrees; innahoo kaana siddeeqan Nabiyyaa"
  },
  {
    "id": 57,
    "text": "Wa rafa'naahu makaanan 'aliyyaa"
  },
  {
    "id": 58,
    "text": "Ulaaa'ikal lazeena an'amal laahu 'alaihim minan Nabiyyeena min zurriyyati Aadama wa mimman hamalnaa ma'a Noohinw wa min zurriyyati Ibraaheema wa Israaa'eela wa mimman hadainaa wajta bainaaa; izaa tutlaa 'alaihim Aayaatur Rahmaani kharroo sujjadanw wa bukiyyaa"
  },
  {
    "id": 59,
    "text": "Fakhalafa min ba'dihim khalfun adaa'us Salaata wattaba'ush shahawaati fasawfa yalqawna ghaiyyaa"
  },
  {
    "id": 60,
    "text": "Illaa man taaba wa aamana wa 'amila saalihan fa ulaaa'ika yadkhuloonal jannata wa laa yuzlamoona shai'aa"
  },
  {
    "id": 61,
    "text": "Jannaati 'adninil latee wa'adar Rahmaanu ibaadahoo bilghaib; innahoo kaana wa'duhoo ma'tiyyaa"
  },
  {
    "id": 62,
    "text": "Laa yasma'oona feehaa laghwan illaa salaamaa; wa lahum rizquhum feehaa bukratanw wa 'ashiyyaa"
  },
  {
    "id": 63,
    "text": "Tilkal jannatul latee noorisu min 'ibaadinaa man kaana taqiyyaa"
  },
  {
    "id": 64,
    "text": "Wa maa natanazzalu illaa bi amri Rabbika lahoo maa baina aideenaa wa maa khalfanaa wa maa baina zaalik; wa maa kaana Rabbuka nasiyyaa"
  },
  {
    "id": 65,
    "text": "Rabbus samaawaati wal ardi wa maa bainahumaa fa'bud hu wastabir li'ibaadatih; hal ta'lamu lahoo samiyyaa"
  },
  {
    "id": 66,
    "text": "Wa yaqoolul insaanu 'a izaa maa mittu lasawfa ukhraju haiyaa"
  },
  {
    "id": 67,
    "text": "'A wa laa yazkurul insaanu annaa khalaqnaahu min qablu wa lam yaku shai'aa"
  },
  {
    "id": 68,
    "text": "Fawa Rabbika lanahshu rannahum wash shayaateena summa lanuhdirannahum hawla jahannama jisiyyaa"
  },
  {
    "id": 69,
    "text": "Summa lanan zi'anna min kulli shee'atin aiyuhum ashaddu 'alar Rahmaani 'itiyyaa"
  },
  {
    "id": 70,
    "text": "Summa lanahnu a'lamu billazeena hum awlaa bihaa siliyyaa"
  },
  {
    "id": 71,
    "text": "Wa in minkum illaa waariduhaa; kaana 'alaa Rabbika hatmam maqdiyyaa"
  },
  {
    "id": 72,
    "text": "Summa nunajjil lazeenat taqaw wa nazaruz zaalimeena feehaa jisiyyaa"
  },
  {
    "id": 73,
    "text": "Wa izaa tutlaa 'alaihim Aayaatunaa baiyinaatin qaalal lazeena kafaroo lillazeena aamanooo aiyul fareeqaini khairum maqaamanw wa ahsanu nadiyyaa"
  },
  {
    "id": 74,
    "text": "Wa kam ahlaknaa qablahum min qarnin hum ahsanu asaasanw wa ri'yaa"
  },
  {
    "id": 75,
    "text": "Qul man kaana fidda laalati falyamdud lahur Rahmaanu maddaa; hattaaa izaa ra aw maa yoo'adoona immal 'azaaba wa immas Saa'ata fasa ya'lamoona man huwa sharrum makaananw wa ad'afu jundaa"
  },
  {
    "id": 76,
    "text": "Wa yazeedul laahul lazeenah tadaw hudaa; wal baaqiyaatus saalihaatu khairun 'inda Rabbika sawaabanw wa khairum maraddaa"
  },
  {
    "id": 77,
    "text": "Afara'aytal lazee kafara bi Aayaatinaa wa qaala la oota yanna maalanw wa waladaa"
  },
  {
    "id": 78,
    "text": "'At tala'al ghaiba 'amit takhaza 'indar Rahmaani 'ahdaa"
  },
  {
    "id": 79,
    "text": "Kallaa; sanaktubu maa yaqoolu wa namuddu lahoo minal 'azaabi maddaa"
  },
  {
    "id": 80,
    "text": "Wa narisuhoo maa yaqoolu wa ya'teenaa fardaa"
  },
  {
    "id": 81,
    "text": "Wattakhazoo min doonil laahi aalihatal liyakoonoo lahum 'izzaa"
  },
  {
    "id": 82,
    "text": "Kallaa; sa yakfuroona bi'ibaadatihim wa yakoonoona 'alaihim diddaa"
  },
  {
    "id": 83,
    "text": "Alam tara annaaa arsalnash Shayaateena 'alal kaafireena ta'uzzuhum azzaa"
  },
  {
    "id": 84,
    "text": "Falaa ta'jal alaihim innamaa na 'uddu lahum 'addaa"
  },
  {
    "id": 85,
    "text": "Yawma nahshurul muttaqeena ilar Rahmaani wafdaa"
  },
  {
    "id": 86,
    "text": "Wa nasooqul mujrimeena ilaa Jahannama wirdaa"
  },
  {
    "id": 87,
    "text": "Laa yamlikoonash shafaa'ata illaa manittakhaza 'indar Rahmaani 'ahdaa"
  },
  {
    "id": 88,
    "text": "Wa qaalut takhazar Rahmaanu waladaa"
  },
  {
    "id": 89,
    "text": "Laqad ji'tum shai'an iddaa"
  },
  {
    "id": 90,
    "text": "Takaadus samaawaatu yatafattarna minhu wa tanshaq qul ardu wa takhirrul jibaalu haddaa"
  },
  {
    "id": 91,
    "text": "An da'aw lir Rahmaani waladaa"
  },
  {
    "id": 92,
    "text": "Wa maa yambaghee lir Rahmaani ai yattakhiza waladaa"
  },
  {
    "id": 93,
    "text": "In kullu man fis samaawaati wal ardi illaaa aatir Rahmaani 'abdaa"
  },
  {
    "id": 94,
    "text": "Laqad ahsaahum wa addahum 'addaa"
  },
  {
    "id": 95,
    "text": "Wa kulluhum aateehi Yawmal Qiyaamati fardaa"
  },
  {
    "id": 96,
    "text": "Innal lazeena aamanoo wa 'amilus saalihaati sa yaj'alu lahumur Rahmaanu wuddaa"
  },
  {
    "id": 97,
    "text": "Fa innamaa yassarnaahu bilisaanika litubashshira bihil muttaqeena wa tunzira bihee qawmal luddaa"
  },
  {
    "id": 98,
    "text": "Wa kam ahlaknaa qabla hum min qarnin hal tuhissu minhum min ahadin aw tasma'u lahum rikzaa"
  }
];

export default en;
