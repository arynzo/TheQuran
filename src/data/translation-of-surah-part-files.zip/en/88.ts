import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Hal ataaka hadeesul ghaashiyah"
  },
  {
    "id": 2,
    "text": "Wujoohuny yawma 'izin khaashi'ah"
  },
  {
    "id": 3,
    "text": "'Aamilatun naasibah"
  },
  {
    "id": 4,
    "text": "Taslaa naaran haamiyah"
  },
  {
    "id": 5,
    "text": "Tusqaa min 'aynin aaniyah"
  },
  {
    "id": 6,
    "text": "Laisa lahum ta'aamun illaa min daree'"
  },
  {
    "id": 7,
    "text": "Laa yusminu wa laa yughnee min joo'"
  },
  {
    "id": 8,
    "text": "Wujoohuny yawma 'izin naa'imah"
  },
  {
    "id": 9,
    "text": "Lisa'yihaa raadiyah"
  },
  {
    "id": 10,
    "text": "Fee jannatin 'aaliyah"
  },
  {
    "id": 11,
    "text": "Laa tasma'u feehaa laaghiyah"
  },
  {
    "id": 12,
    "text": "Feehaa 'aynun jaariyah"
  },
  {
    "id": 13,
    "text": "Feehaa sururum marfoo'ah"
  },
  {
    "id": 14,
    "text": "Wa akwaabum mawdoo'ah"
  },
  {
    "id": 15,
    "text": "Wa namaariqu masfoofah"
  },
  {
    "id": 16,
    "text": "Wa zaraabiyyu mabsoosah"
  },
  {
    "id": 17,
    "text": "Afalaa yanzuroona ilalibili kaifa khuliqat"
  },
  {
    "id": 18,
    "text": "Wa ilas samaaa'i kaifa rufi'at"
  },
  {
    "id": 19,
    "text": "Wa ilal jibaali kaifa nusibat"
  },
  {
    "id": 20,
    "text": "Wa ilal ardi kaifa sutihat"
  },
  {
    "id": 21,
    "text": "Fazakkir innama anta Muzakkir"
  },
  {
    "id": 22,
    "text": "Lasta 'alaihim bimusaitir"
  },
  {
    "id": 23,
    "text": "Illaa man tawallaa wa kafar"
  },
  {
    "id": 24,
    "text": "Fa yu'azzibuhul laahul 'azaabal akbar"
  },
  {
    "id": 25,
    "text": "Innaa ilainaaa iyaabahum"
  },
  {
    "id": 26,
    "text": "Summa inna 'alainaa hisaabahum"
  }
];

export default en;
