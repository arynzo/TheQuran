import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alhamdu lillaahil lazeee anzala 'alaa 'abdihil kitaaba wa lam yaj'al lahoo 'iwajaa"
  },
  {
    "id": 2,
    "text": "Qaiyimal liyunzira ba'asan shadeedam mil ladunhu wa yubashshiral mu'mineenal lazeena ya'maloonas saalihaati anna lahum ajran hasanaa"
  },
  {
    "id": 3,
    "text": "Maakiseena feehi abadaa"
  },
  {
    "id": 4,
    "text": "Wa yunziral lazeena qaalut takhazal laahu waladaa"
  },
  {
    "id": 5,
    "text": "Maa lahum bihee min 'ilminw wa laa li aabaaa'ihim; kaburat kalimatan takhruju min afwaahihim; iny yaqooloona illaa kazibaa"
  },
  {
    "id": 6,
    "text": "Fala'allaka baakhi'un nafsaka 'alaaa aasaarihim illam yu'minoo bihaazal hadeesi asafaa"
  },
  {
    "id": 7,
    "text": "Innaa ja'alnaa ma 'alal ardi zeenatal lahaa linabluwahum ayyuhum ahsanu 'amalaa"
  },
  {
    "id": 8,
    "text": "Wa innaa la jaa'iloona maa 'alaihaa sa'eedan juruzaa"
  },
  {
    "id": 9,
    "text": "Am hasibta anna Ashaabal Kahfi war Raqeemi kaanoo min Aayaatinaa 'ajabaa"
  },
  {
    "id": 10,
    "text": "Iz awal fityatu ilal Kahfi faqaaloo Rabbanaaa aatinaa mil ladunka rahmatanw wa haiyi' lanaa min amrinaa rashadaa"
  },
  {
    "id": 11,
    "text": "Fadarabnaa 'alaaa aazaanihim fil Kahfi seneena 'adadaa"
  },
  {
    "id": 12,
    "text": "Summa ba'asnaahum lina'lama ayyul hizbaini ahsaa limaa labisooo amadaa"
  },
  {
    "id": 13,
    "text": "Nahnu naqussu 'alaika naba ahum bilhaqq; innahum fityatun aamanoo bi Rabbihim wa zidnaahum hudaa"
  },
  {
    "id": 14,
    "text": "Wa rabatnaa 'alaa quloo bihim iz qaamoo faqaaloo Rabbunaa Rabbus samaawaati wal ardi lan nad'uwa min dooniheee ilaahal laqad qulnaaa izan shatataa"
  },
  {
    "id": 15,
    "text": "Haaa'ulaaa'i qawmunat takhazoo min dooniheee aalihatal law laa yaatoona 'alaihim bisultaanim baiyin; faman azlamu mimmaniftaraa 'alal laahi kazibaa"
  },
  {
    "id": 16,
    "text": "Wa izi'tazal tumoohum wa maa ya'budoona illal laaha faawooo ilal kahfi yanshur lakum Rabbukum mir rahmatihee wa yuhaiyi' lakum min amrikum mirfaqa"
  },
  {
    "id": 17,
    "text": "Wa tarash shamsa izaa tala'at tazaawaru 'an kahfihim zaatal yameeni wa izaa gharabat taqriduhum zaatash shimaali wa hum fee fajwatim minh; zaalika min Aayaatillaah; mai yahdil laahu fahuwal muhtad, wa mai yudlil falan tajida lahoo waliyyam murshidaa"
  },
  {
    "id": 18,
    "text": "Wa tahsabuhum ayqaazanw wa hum ruqood; wa nuqallibuhum zaatal yameeni wa zaatash shimaali wa kalbuhum baasitun ziraa'ayhi bilwaseed; lawit tala'ta 'alaihim la wallaita minhum firaaranw wa lamuli'ta minhum ru'ba"
  },
  {
    "id": 19,
    "text": "Wa kazaalika ba'asnaahum liyatasaaa'aloo bainahum; qaala qaaa'ilum minhum kam labistum qaaloo labisnaa yawman aw ba'da yawm; qaaloo Rabbukum a'lamu bimaa labistum fab'asooo ahadakum biwariqikum haazihee ilal madeenati falyanzur ayyuhaaa azkaa ta'aaman falyaatikum birizqim minhu walyatalattaf wa laa yush'iranna bikum ahadaa"
  },
  {
    "id": 20,
    "text": "Innahum iny yazharoo 'alaikum yarjumookum aw yu'eedookum fee millatihim wa lan tuflihooo izan abadaa"
  },
  {
    "id": 21,
    "text": "Wa kazaalika a'sarnaa 'alaihim liya'lamooo anna wa'dal laahi haqqunw wa annas Saa'ata laa raiba feehaa iz yatanaaza'oona bainahum amrahum faqaalub noo 'alaihim bunyaanaa; Rabbuhum a'lamu bihim; qaalal lazeena ghalaboo 'alaaa amrihim lanat takhizanna 'alaihim masjidaa"
  },
  {
    "id": 22,
    "text": "Sa yaqooloona salaasatur raabi'uhum kalbuhum wa yaqooloona khamsatun saadisuhum kalbuhum rajmam bilghaib; wa yaqooloona sab'atunw wa saaminuhum kalbuhum; qur Rabbeee a'lamu bi'iddatihim maa ya'lamuhum illaa qaleel; falaa tumaari feehim illaa miraaa'an zaahiranw wa laa tastafti feehim minhum ahadaa"
  },
  {
    "id": 23,
    "text": "Wa laa taqoolanna lishai'in innee faa'ilun zaalika ghadaa"
  },
  {
    "id": 24,
    "text": "Illaaa any yashaaa'al laah; wazkur Rabbaka izaa naseeta wa qul 'asaaa any yahdiyani Rabbee li aqraba min haazaa rashadaa"
  },
  {
    "id": 25,
    "text": "Wa labisoo fee kahfihim salaasa mi'atin sineena wazdaadoo tis'aa"
  },
  {
    "id": 26,
    "text": "Qulil laahu a'lamu bimaa labisoo lahoo ghaibus samaawaati wal ardi absir bihee wa asmi'; maa lahum min doonihee minw waliyyinw wa laa yushriku fee hukmihee ahadaa"
  },
  {
    "id": 27,
    "text": "Watlu maaa oohiya ilaika min Kitaabi Rabbika laa mubaddila li Kalimaatihee wa lan tajida min doonihee multahadaa"
  },
  {
    "id": 28,
    "text": "Wasbir nafsaka ma'al lazeena yad'oona Rabbahum bilghadaati wal'ashiyyi yureedoona Wajhahoo wa laa ta'du 'aynaaka 'anhum tureedu zeenatal hayaatid dunyaa wa laa tuti' man aghfalnaa qalbahoo 'an zikrinaa wattaba'a hawaahu wa kaana amruhoo furutaa"
  },
  {
    "id": 29,
    "text": "Wa qulil haqqu mir Rabbikum faman shaaa'a falyu'minw wa man shaaa'a falyakfur; innaaa a'tadnaa lizzaalimeena Naaran ahaata bihim suraadiquhaa; wa iny yastagheesoo yughaasoo bimaaa'in kalmuhli yashwil wujooh' bi'sash-sharaab; wa saaa'at murtafaqaa"
  },
  {
    "id": 30,
    "text": "Innal lazeena aamanoo wa 'amilus saalihaati innaa laa nudee'u ajra man ahsana 'amalaa"
  },
  {
    "id": 31,
    "text": "Ulaaa'ika lahum Jannaatu 'Adnin tajree min tahtihimul anhaaru yuhallawna feehaa min asaawira min zahabinw wa yalbasoona siyaaban khudram min sundusinw wa istabraqim muttaki'eena feehaa 'alal araaa'ik; ni'mas sawaab; wa hasunat murtafaqaa"
  },
  {
    "id": 32,
    "text": "Wadrib lahum masalar rajulaini ja'alnaa li ahadihimaa jannataini min a'naabinw wa hafafnaahumaa binakhilinw wa ja'alnaa bainahumaa zar'aa"
  },
  {
    "id": 33,
    "text": "Kiltal jannataini aatat ukulahaa wa lam tazlim minhu shai'anw wa fajjarnaa khi laalahumaa naharaa"
  },
  {
    "id": 34,
    "text": "Wa kaana lahoo samarun faqaala lisaahibihee wa huwa yuhaawiruhoo ana aksaru minka maalanw wa a'azzu nafaraa"
  },
  {
    "id": 35,
    "text": "Wa dakhala jannatahoo wa huwa zaalimul linafsihee qaala maaa azunnu an tabeeda haaziheee abadaa"
  },
  {
    "id": 36,
    "text": "Wa maaa azunnus Saa'ata qaaa'imatanw wa la'ir rudittu ilaa Rabbee la ajidanna khairam minhaa munqalabaa"
  },
  {
    "id": 37,
    "text": "Qaala lahoo saahibuhoo wa huwa yuhaawiruhooo akafarta billazee khalaqaka min turaabin summa min nutfatin summa sawwaaka rajulaa"
  },
  {
    "id": 38,
    "text": "Laakinaa Huwal laahu Rabbee wa laa ushriku bi Rabbeee ahadaa"
  },
  {
    "id": 39,
    "text": "Wa law laaa iz dakhalta jannataka qulta maa shaaa'al laahu laa quwwata illaa billaah; in tarani ana aqalla minka maalanw wa waladaa"
  },
  {
    "id": 40,
    "text": "Fa'asaa Rabeee any yu'tiyani khairam min jannatika wa yursila 'alaihaa husbaanam minas samaaa'i fatusbiha sa'eedan zalaqaa"
  },
  {
    "id": 41,
    "text": "Aw yusbiha maaa'uhaaa ghawran falan tastatee'a lahoo talabaa"
  },
  {
    "id": 42,
    "text": "Wa uheeta bisamarihee faasbaha yuqallibu kaffaihi 'alaa maaa anfaqa feehaa wa hiya khaawiyatun 'alaa 'urooshihaa wa yaqoolu yaalaitanee lam ushrik bi Rabbeee ahadaa"
  },
  {
    "id": 43,
    "text": "Wa lam takul lahoo fi'atuny yansuroonahoo min doonil laahi wa maa kaana muntasiraa"
  },
  {
    "id": 44,
    "text": "Hunaalikal walaayatu lillaahil haqq; huwa khairun sawaabanw wa khairun 'uqbaa"
  },
  {
    "id": 45,
    "text": "Wadrib lahum masalal hayaatid dunyaa kamaaa'in anzalnaahu minas samaaa'i fakhtalata bihee nabaatul ardi fa asbaha hasheeman tazroo hur riyaah; wa kaanal laahu 'alaa kulli shai'im muqtadiraa"
  },
  {
    "id": 46,
    "text": "Almaalu walbanoona zeenatul hayaatid dunya wal baaqiyaatus saalihaatu khairun 'inda Rabbika sawaabanw wa khairun amalaa"
  },
  {
    "id": 47,
    "text": "Wa yawma nusaiyirul jibaala wa taral arda baariza tanw wa hasharnaahum falam nughaadir minhum ahadaa"
  },
  {
    "id": 48,
    "text": "Wa 'uridoo 'alaa Rabbika saffaa, laqad ji'tumoonaa kamaa khalaqnaakum awala marrah; bal za'amtum allannaj'ala lakum maw'idaa"
  },
  {
    "id": 49,
    "text": "Wa wudi'al kitaabu fataral mujrimeena mushfiqeena mimmaa feehi wa yaqooloona yaa wailatanaa maa lihaazal kitaabi laa yughaadiru saghee ratanw wa laa kabeeratan illaaa ahsaahaa; wa wajadoo maa 'amiloo haadiraa; wa laa yazlimu Rabbuka ahadaa"
  },
  {
    "id": 50,
    "text": "Wa iz qulnaa lil malaaa'ikatis judoo li Aadama fasajadooo illaaa Ibleesa kaana minal jinni fafasaqa 'an amri Rabbih; afatattakhizoonahoo wa zurriyatahooo awliyaaa'a min doonee wa hum lakum 'aduww; bi'sa lizzaalimeena badalaa"
  },
  {
    "id": 51,
    "text": "Maaa ash hattuhum khalqas samaawaati wal ardi wa laa khalqa anfusihim wa maa kuntu muttakhizal mudilleena 'adudaa"
  },
  {
    "id": 52,
    "text": "Wa Yawma yaqoolu naadoo shurakaaa'i yal lazeena za'amtum fada'awhum falam yastajeeboo lahum wa ja'alnaa bainahum maw biqaa"
  },
  {
    "id": 53,
    "text": "Wa ra al mujrimoonan Naara fazannooo annahum muwaaqi'oohaa wa lam yajidoo 'anhaa masrifaa"
  },
  {
    "id": 54,
    "text": "Wa laqad sarrafnaa fee haazal quraani linnaasi min kulli masal; wa kaanal insaanu aksara shai'in jadalaa"
  },
  {
    "id": 55,
    "text": "Wa maa mana'an naasa any yu'minooo iz jaaa'ahumul hudaa wa yastaghfiroo Rabbahum illaaa an taatiyahum sunnatul awwaleena aw yaatiyahumul 'azaabu qubulaa"
  },
  {
    "id": 56,
    "text": "Wa maa nursilul mursaleena illaa mubashshireena wa munzireen; wa yujaadilul lazeena kafaroo bilbaatili liyudhidoo bihil haqqa wattakhazooo Aayaatee wa maaa unziroo huzuwaa"
  },
  {
    "id": 57,
    "text": "Wa man azlamu mimman zukkira bi ayaati Rabbihee fa-a'rada 'anhaa wa nasiya maa qaddamat yadaah; innaa ja'alnaa 'alaa quloobihim akinnatan any yafqahoohu wa feee aazaanihim waqraa; wa in tad'uhum ilal hudaa falany yahtadooo izan abadaa"
  },
  {
    "id": 58,
    "text": "Wa Rabbukal Ghafooru zur rahmati law yu'aakhi zuhum bimaa kasaboo la 'ajjala lahumul 'azaab; bal lahum maw'idul lany yajidoo min doonihee maw'ilaa"
  },
  {
    "id": 59,
    "text": "Wa tilkal quraaa ahlak nahum lammaa zalamoo wa ja'alnaa limahlikihim maw'idaa"
  },
  {
    "id": 60,
    "text": "Wa iz qaalaa Moosaa lifataahu laaa abrahu hattaaa ablugha majma'al bahrayni aw amdiya huqubaa"
  },
  {
    "id": 61,
    "text": "Falammaa balaghaa majma'a bainihimaa nasiyaa hootahumaa fattakhaza sabeelahoo fil bahri sarabaa"
  },
  {
    "id": 62,
    "text": "Falammaa jaawazaa qaala lifataahu aatinaa ghadaaa'anaa laqad laqeena min safarinaa haazaa nasabaa"
  },
  {
    "id": 63,
    "text": "Qaala ara'ayta iz awainaaa ilas sakhrati fa innee naseetul hoota wa maaa ansaaneehu illash Shaitaanu an azkurah; wattakhaza sabeelahoo fil bahri'ajabaa"
  },
  {
    "id": 64,
    "text": "Qaala zaalika maa kunnaa nabghi; fartaddaa 'alaa aasaari him maa qasasaa"
  },
  {
    "id": 65,
    "text": "Fa wajadaa 'abdam min 'ibaadinaaa aatainaahu Rahmatam min 'indinaa wa 'allamnaahu mil ladunnaa 'ilmaa"
  },
  {
    "id": 66,
    "text": "Qaala lahoo Moosaa hal attabi'uka 'alaaa an tu'allimani mimmaa 'ullimta rushdaa"
  },
  {
    "id": 67,
    "text": "Qaalaa innaka lan tastatee'a ma'iya sabraa"
  },
  {
    "id": 68,
    "text": "Wa kaifa tasbiru 'alaa maa lam tuhit bihee khubraa"
  },
  {
    "id": 69,
    "text": "Qaala satajiduneee in shaa 'al laahu saabiranw wa laaa a'see laka amraa"
  },
  {
    "id": 70,
    "text": "Qaala fa init taba'tanee falaa tas'alnee 'an shai'in hattaaa uhdisa laka minhu zikraa"
  },
  {
    "id": 71,
    "text": "Fantalaqaa hattaaa izaa rakibaa fis safeenati kharaqahaa qaala akharaqtahaa litughriqa ahlahaa laqad ji'ta shai'an imraa"
  },
  {
    "id": 72,
    "text": "Qaala alam aqul innaka lan tastatee'a ma'iya sabraa"
  },
  {
    "id": 73,
    "text": "Qaala laa tu'aakhiznee bimaa naseetu wa laa turhiqnee min amree 'usraa"
  },
  {
    "id": 74,
    "text": "Fantalaqaa hattaa izaa laqiyaa ghulaaman faqatalahoo qaala aqatalta nafsan zakiy yatam bighairi nafs; laqad ji'ta shai'an nukraa"
  },
  {
    "id": 75,
    "text": "Qaala alam aqul laka innaka lan tastatee'a ma'iya sabraa"
  },
  {
    "id": 76,
    "text": "Qaala in sa altuka 'an shai'im ba'dahaa falaa tusaahibnee qad balaghta mil ladunnee 'uzraa"
  },
  {
    "id": 77,
    "text": "Fantalaqaa hattaaa izaaa atayaaa ahla qaryatinis tat'amaaa ahlahaa fa abaw any yudaiyifoohumaa fawajadaa feehaa jidaarany yureedu any yanqadda fa aqaamah; qaala law shi'ta lattakhazta 'alaihi ajraa"
  },
  {
    "id": 78,
    "text": "Qaala haazaa firaaqu bainee wa bainik; sa unabbi'uka bi ta'weeli maa lam tastati' 'alaihi sabraa"
  },
  {
    "id": 79,
    "text": "Ammas safeenatu fakaanat limasaakeena ya'maloona fil bahri fa arattu an a'eebahaa wa kaana waraaa' ahum malikuny yaakhuzu kulla safeenatin ghasbaa"
  },
  {
    "id": 80,
    "text": "Wa aammal ghulaamu fakaana abawaahu mu'minaini fakhasheenaaa any yurhiqa humaa tughyaananw wa kufraa"
  },
  {
    "id": 81,
    "text": "Faradnaa any yubdila humaa Rabbuhumaa khairam minhu zakaatanw wa aqraba ruhmaa"
  },
  {
    "id": 82,
    "text": "Wa ammal jidaaru fakaana lighulaamaini yateemaini fil madeenati wa kaana tahtahoo kanzul lahumaa wa kaana aboohumaa saalihan fa araada Rabbuka any yablughaaa ashuddahumaa wa yastakhrijaa kanzahumaa rahmatam mir Rabbik; wa maa fa'altuhoo 'an amree; zaalika taaweelu maa lam tasti' 'alaihi sabra"
  },
  {
    "id": 83,
    "text": "Wa yas'aloonaka 'an Zil Qarnaini qul sa atloo 'alaikum minhu zikraa"
  },
  {
    "id": 84,
    "text": "Innaa makkannaa lahoo fil ardi wa aatainaahu min kulli shai'in sababaa"
  },
  {
    "id": 85,
    "text": "Fa atba'a sababaa"
  },
  {
    "id": 86,
    "text": "Hattaaa izaa balagha maghribash shamsi wajadahaaa taghrubu fee 'aynin hami'a tinw wa wajada 'indahaa qawmaa; qulnaa yaa Zal Qarnaini immaaa an tu'az ziba wa immaaa an tattakhiza feehim husnaa"
  },
  {
    "id": 87,
    "text": "Qaala amma man zalama fasawfa nu'azzibuhoo summa yuraddu ilaa Rabbihee fa yu 'azzibuhoo azaaban nukraa"
  },
  {
    "id": 88,
    "text": "Wa ammaa man aamana wa 'amila saalihan falahoo jazaaa'anil husnaa wa sanaqoolu lahoo min amrinaa yusraa"
  },
  {
    "id": 89,
    "text": "Summa atba'a sababaa"
  },
  {
    "id": 90,
    "text": "Hattaaa izaa balagha matli'ash shamsi wajdahaa tatlu'u alaa qawmil lam naj'al lahum min doonihaa sitraa"
  },
  {
    "id": 91,
    "text": "Kazaalika wa qad ahatnaa bimaa ladaihi khubraa"
  },
  {
    "id": 92,
    "text": "Summa atba'a sababaa"
  },
  {
    "id": 93,
    "text": "Hattaaa izaa balagha bainas saddaini wajada min doonihimaa qawmal laa yakaa doona yafqahoona qawlaa"
  },
  {
    "id": 94,
    "text": "Qaaloo yaa Zal qarnaini inna Ya'jooja wa Ma'jooja mufsidoona fil ardi fahal naj'alu laka kharjan 'alaaa an taj'ala bainanaa wa bainahum saddaa"
  },
  {
    "id": 95,
    "text": "Qaala maa makkannee feehi Rabbee khairun fa-a'eenoonee biquwwatin aj'al bainakum wa bainahum radmaa"
  },
  {
    "id": 96,
    "text": "Aatoonee zubaral hadeed, hattaaa izaa saawaa bainas sadafaini qaalan fukhoo hattaaa izaa ja'alahoo naaran qaala aatooneee ufrigh 'alaihi qitraa"
  },
  {
    "id": 97,
    "text": "Famas taa'ooo any yazharoohu wa mastataa'oo lahoo naqbaa"
  },
  {
    "id": 98,
    "text": "Qaala haaza rahmatun mir Rabbee fa izaa jaaa'a wa'du Rabbee ja'alahoo dakkaaa'a; wa kana wa'du Rabbee haqqaa"
  },
  {
    "id": 99,
    "text": "Wa taraknaa ba'dahum Yawma'iziny yamooju fee ba'dinw wa nufikha fis Soori fajama'naahum jam'aa"
  },
  {
    "id": 100,
    "text": "Wa 'aradnaa jahannama Yawma'izil lilkaafireena 'ardaa"
  },
  {
    "id": 101,
    "text": "Allazeena kaanat a'yunuhum fee ghitaaa'in 'an zikree wa kaanoo laa yastatee'oona sam'aa"
  },
  {
    "id": 102,
    "text": "Afahasibal lazeena kafarooo any yattakhizoo 'ibaadee min dooneee awliyaaa'; innaaa a'tadnaa jahannama lil kaafireena nuzulaa"
  },
  {
    "id": 103,
    "text": "Qul hal nunabbi'ukum bilakhsareena a'maalaa"
  },
  {
    "id": 104,
    "text": "Allazeena dalla sa'yuhum fil hayaatid dunyaa wa hum yahsaboona annahum yuhsinoona sun'aa"
  },
  {
    "id": 105,
    "text": "Ulaaa'ikal lazeena kafaroo bi aayaati Rabbihim wa liqaaa'ihee fahabitat a'maaluhum falaa nuqeemu lahum Yawmal Qiyaamati waznaa"
  },
  {
    "id": 106,
    "text": "Zaalika jazaaa'uhum jahannamu bimaa kafaroo wattakhazooo Aayaatee wa Rusulee huzuwaa"
  },
  {
    "id": 107,
    "text": "Innal lazeena aamanoo wa 'amilus saalihaati kaanat lahum Jannaatul Firdawsi nuzulaa"
  },
  {
    "id": 108,
    "text": "Khaalideena feeha laa yabghoona 'anhaa hiwalaa"
  },
  {
    "id": 109,
    "text": "Qul law kaanal bahru midaadal li kalimaati Rabbee lanafidal bahru qabla an tanfada Kalimaatu Rabbee wa law ji'naa bimislihee madadaa"
  },
  {
    "id": 110,
    "text": "Qul innamaaa ana basharum mislukum yoohaaa ilaiya annamaa ilaahukum Ilaahunw Waahid; faman kaana yarjoo liqaaa'a Rabbihee falya'mal 'amalan saalihanw wa laa yushrik bi'ibaadati Rabbiheee ahadaa"
  }
];

export default en;
