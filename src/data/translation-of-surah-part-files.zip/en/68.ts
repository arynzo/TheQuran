import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Noon; walqalami wa maa yasturoon"
  },
  {
    "id": 2,
    "text": "Maa anta bini'mati Rabbika bimajnoon"
  },
  {
    "id": 3,
    "text": "Wa inna laka la ajran ghaira mamnoon"
  },
  {
    "id": 4,
    "text": "Wa innaka la'alaa khuluqin 'azeem"
  },
  {
    "id": 5,
    "text": "Fasatubsiru wa yubsiroon"
  },
  {
    "id": 6,
    "text": "Bi ayyikumul maftoon"
  },
  {
    "id": 7,
    "text": "Innaa Rabbaka Huwa a'lamu biman dalla 'an sabeelihee wa Huwa a'lamu bilmuhtadeen"
  },
  {
    "id": 8,
    "text": "Falaa tuti'il mukazzibeen"
  },
  {
    "id": 9,
    "text": "Waddoo law tudhinu fa-yudhinoon"
  },
  {
    "id": 10,
    "text": "Wa laa tuti' kulla hallaa fim maheen"
  },
  {
    "id": 11,
    "text": "Hammaazim mash shaaa'im binameem"
  },
  {
    "id": 12,
    "text": "Mannaa'il lilkhairi mu'tadin aseem"
  },
  {
    "id": 13,
    "text": "'Utullim ba'da zaalika zaneem"
  },
  {
    "id": 14,
    "text": "An kaana zaa maalinw-wa baneen"
  },
  {
    "id": 15,
    "text": "Izaa tutlaa 'alaihi aayaatunaa qaala asaateerul awwaleen"
  },
  {
    "id": 16,
    "text": "Sanasimuhoo 'alal khurtoom"
  },
  {
    "id": 17,
    "text": "Innaa balawnaahum kamaa balawnaaa As-haabal jannati iz 'aqsamoo la-yasri munnahaa musbiheen"
  },
  {
    "id": 18,
    "text": "Wa laa yastasnoon"
  },
  {
    "id": 19,
    "text": "Fataafa 'alaihaa taaa'i fum mir rabbika wa hum naaa'imoon"
  },
  {
    "id": 20,
    "text": "Fa asbahat kassareem"
  },
  {
    "id": 21,
    "text": "Fatanaadaw musbiheen"
  },
  {
    "id": 22,
    "text": "Anighdoo 'alaa harsikum in kuntum saarimeen"
  },
  {
    "id": 23,
    "text": "Fantalaqoo wa hum yatakhaafatoon"
  },
  {
    "id": 24,
    "text": "Al laa yadkhulannahal yawma 'alaikum miskeen"
  },
  {
    "id": 25,
    "text": "Wa ghadaw 'alaa hardin qaadireen"
  },
  {
    "id": 26,
    "text": "Falammaa ra awhaa qaalooo innaa ladaaalloon"
  },
  {
    "id": 27,
    "text": "Bal nahnu mahroomoon"
  },
  {
    "id": 28,
    "text": "Qaala awsatuhum alam aqul lakum law laa tusabbihoon"
  },
  {
    "id": 29,
    "text": "Qaaloo subhaana rabbinaaa innaa kunnaa zaalimeen"
  },
  {
    "id": 30,
    "text": "Fa aqbala ba'duhum 'alaa ba'diny yatalaawamoon"
  },
  {
    "id": 31,
    "text": "Qaaloo yaa wailanaaa innaa kunnaa taagheen"
  },
  {
    "id": 32,
    "text": "'Asaa rabbunaaa any yubdilanaa khairam minhaaa innaaa ilaa rabbinaa raaghiboon"
  },
  {
    "id": 33,
    "text": "Kazaalikal azaab, wa la'azaabul aakhirati akbar; law kaanoo ya'lamoon"
  },
  {
    "id": 34,
    "text": "Inna lilmuttaqeena 'inda rabbihim jannaatin na'eem"
  },
  {
    "id": 35,
    "text": "Afanaj'alul muslimeena kalmujrimeen"
  },
  {
    "id": 36,
    "text": "Maa lakum kaifa tahkumoon"
  },
  {
    "id": 37,
    "text": "Am lakum kitaabun feehi tadrusoon"
  },
  {
    "id": 38,
    "text": "Inna lakum feehi lamaa takhaiyaroon"
  },
  {
    "id": 39,
    "text": "Am lakum aymaanun 'alainaa baalighatun ilaa yawmil qiyaamati inna lakum lamaa tahkumoon"
  },
  {
    "id": 40,
    "text": "Salhum ayyuhum bizaa lika za'eem"
  },
  {
    "id": 41,
    "text": "Am lahum shurakaaa'u fal ya'too bishurakaaa 'ihim in kaanoo saadiqeen"
  },
  {
    "id": 42,
    "text": "Yawma yukshafu 'an saaqinw wa yud'awna ilas sujoodi falaa yastatee'oon"
  },
  {
    "id": 43,
    "text": "Khaashi'atan absaaruhum tarhaquhum zillatunw wa qad kaanoo yud'awna ilassujoodi wa hum saalimoon"
  },
  {
    "id": 44,
    "text": "Fazarnee wa many yukazzibu bihaazal hadeesi sanastad rijuhum min haisu laa ya'lamoon"
  },
  {
    "id": 45,
    "text": "Wa umlee lahum; inna kaidee mateen"
  },
  {
    "id": 46,
    "text": "Am tas'aluhum ajran fahum min maghramin musqaloon"
  },
  {
    "id": 47,
    "text": "Am 'indahumul ghaibu fahum yaktuboon"
  },
  {
    "id": 48,
    "text": "Fasbir lihukmi rabbika wa laa takun kasaahibil hoot; iz naadaa wa huwa makzoom"
  },
  {
    "id": 49,
    "text": "Law laaa an tadaara kahoo ni'matum mir rabbihee lanubiza bil'araaa'i wa huwa mazmoom"
  },
  {
    "id": 50,
    "text": "Fajtabaahu rabbuhoo faja'alahoo minas saaliheen"
  },
  {
    "id": 51,
    "text": "Wa iny-yakaadul lazeena kafaroo la-yuzliqoonaka biabsaarihim lammaa sami'uz-Zikra wa yaqooloona innahoo lamajnoon"
  },
  {
    "id": 52,
    "text": "Wa maa huwa illaa zikrul lil'aalameen"
  }
];

export default en;
