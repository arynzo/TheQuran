import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Bismillaahir Rahmaanir Raheem"
  },
  {
    "id": 2,
    "text": "Alhamdu lillaahi Rabbil 'aalameen"
  },
  {
    "id": 3,
    "text": "Ar-Rahmaanir-Raheem"
  },
  {
    "id": 4,
    "text": "Maaliki Yawmid-Deen"
  },
  {
    "id": 5,
    "text": "Iyyaaka na'budu wa lyyaaka nasta'een"
  },
  {
    "id": 6,
    "text": "Ihdinas-Siraatal-Mustaqeem"
  },
  {
    "id": 7,
    "text": "Siraatal-lazeena an'amta 'alaihim ghayril-maghdoobi 'alaihim wa lad-daaalleen"
  }
];

export default en;
