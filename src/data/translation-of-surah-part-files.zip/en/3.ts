import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laam-Meeem"
  },
  {
    "id": 2,
    "text": "Allaahu laaa ilaaha illaa Huwal Haiyul Qaiyoom"
  },
  {
    "id": 3,
    "text": "Nazzala 'alaikal Kitaaba bilhaqqi musaddiqal limaa baina yadaihi wa anzalat Tawraata wal Injeel"
  },
  {
    "id": 4,
    "text": "Min qablu hudal linnaasi wa anzalal Furqaan; innallazeena kafaroo bi Aayaatil laahi lahum 'azaabun shadeed; wallaahu 'azeezun zun tiqaam"
  },
  {
    "id": 5,
    "text": "Innal laaha laa yakhfaa 'alaihi shai'un fil ardi wa laa fis samaaa'"
  },
  {
    "id": 6,
    "text": "Huwal lazee yusawwirukum fil arhaami kaifa yashaaa'; laa ilaaha illaa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 7,
    "text": "Huwal lazeee anzala 'alaikal Kitaaba minhu Aayaatum Muh kamaatun hunna Ummul Kitaabi wa ukharu Mutashaabihaatun fa'ammal lazeena fee quloobihim zaiyghun fa yattabi'oona ma tashaabaha minhubtighaaa 'alfitnati wabtighaaa'a taaweelih; wa maa ya'lamu taaweelahooo illal laah; warraasikhoona fil 'ilmi yaqooloona aamannaa bihee kullum min 'indi Rabbinaa; wa maa yazzakkaru illaaa ulul albaab"
  },
  {
    "id": 8,
    "text": "Rabbanaa laa tuzigh quloobanaa ba'da iz hadaitanaa wa hab lanaa mil ladunka rahmah; innaka antal Wahhaab"
  },
  {
    "id": 9,
    "text": "Rabbanaaa innaka jaami 'un-naasi li Yawmin laa raiba feeh; innal laaha laa yukhliful mee'aad"
  },
  {
    "id": 10,
    "text": "Innal lazeena kafaroo lan tughniya 'anhum amwaaluhum wa laaa awlaaduhum minal laahi shai'anw wa ulaaa'ika hum waqoodun Naar"
  },
  {
    "id": 11,
    "text": "Kadaabi Aali Fir'awna wallazeena min qablihim; kazzaboo bi Aayaatinaa fa akhazahumul laahu bizunoo bihim; wallaahu shadeedul 'iqaab"
  },
  {
    "id": 12,
    "text": "Qul lillazeena kafaroosatughlaboona wa tuhsharoona ilaa jahannam; wa bi'sal mihaad"
  },
  {
    "id": 13,
    "text": "Qad kaana lakum Aayatun fee fi'atainil taqataa fi'atun tuqaatilu fee sabeelil laahi wa ukhraa kaafiratuny yarawnahum mislaihim ra' yal 'ayn; wallaahu yu'ayyidu bi nasrihee mai yashaaa'; innaa fee zaalika la 'ibratal li ulil absaar"
  },
  {
    "id": 14,
    "text": "Zuyyina linnaasi hubbush shahawaati minannisaaa'i wal baneena walqanaateeril muqantarati minaz zahabi walfiddati walkhailil musawwamati wal an'aami walhars; zaalika mataa'ul hayaatid dunyaa wallaahu 'indahoo husnul ma-aab"
  },
  {
    "id": 15,
    "text": "Qul a'unabbi 'ukum bikhairim min zaalikum; lillazeenat taqaw 'inda Rabbihim jannaatun tajree min tahtihal anhaaru khaalideena feehaa wa azwaajum mutahharatunw wa ridwaanum minal laah; wallaahu baseerum bil'ibaad"
  },
  {
    "id": 16,
    "text": "Allazeena yaqooloona Rabbanaaa innanaaa aamannaa faghfir lanaa zunoobanaa wa qinaa 'azaaban Naar"
  },
  {
    "id": 17,
    "text": "Assaabireena wassaa diqeena walqaaniteena walmunfiqeena walmus taghfireena bil as- har"
  },
  {
    "id": 18,
    "text": "Shahidal laahu annahoo laa ilaaha illaa Huwa walmalaaa'ikatu wa ulul 'ilmi qaaa'imam bilqist; laaa ilaaha illaa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 19,
    "text": "Innad deena 'indal laahil Islaam; wa makhtalafal lazeena ootul Kitaaba illaa mim ba'di maa jaaa'ahumul 'ilmu baghyam bainahum; wa mai yakfur bi Aayaatil laahi fa innal laaha saree'ul hisaab"
  },
  {
    "id": 20,
    "text": "Fa in haaajjooka faqul aslamtu wajhiya lillaahi wa manit taba'an; wa qul lillazeena ootul Kitaaba wal ummiyyeena 'a-aslamtum; fa in aslamoo faqadih tadaw wa in tawallaw fa innamaa 'alaikal balaagh; wallaahu baseerum bil 'ibaad"
  },
  {
    "id": 21,
    "text": "Innal lazeena yakfuroona bi Aayaatil laahi wa yaqtuloonan Nabiyyeena bighairi haqqinw wa yaqtuloonal lazeena ya'muroona bilqisti minannaasi fabashirhum bi'azaabin aleem"
  },
  {
    "id": 22,
    "text": "Ulaaa'ikal lazeena habitat a'maaluhum fid dunyaa wal Aaakhirati wa maa lahum min naasireen"
  },
  {
    "id": 23,
    "text": "Alam tara ilal lazeena ootoo naseebam minal Kitaabi yud'awna ilaa Kitaabil laahi liyahkuma bainahum summa yatawallaa fareequm minhum wa hum mu'ridoon"
  },
  {
    "id": 24,
    "text": "Zaalika bi annahum qaaloo lan tamassanan naaru illaaa ayyaamam ma'doodaatinw wa gharrahum fee deenihim maa kaanoo yaftaroon"
  },
  {
    "id": 25,
    "text": "Fakaifa izaa jama'naahum li Yawmil laa raiba fee wa wuffiyat kullu nafsim maa kasabat wa hum laa yuzlamoon"
  },
  {
    "id": 26,
    "text": "Qulil laahumma Maalikal Mulki tu'til mulka man tashaaa'u wa tanzi'ul mulka mimman tashhaaa'u wa tu'izzu man tashaaa'u wa tuzillu man tashaaa'u biyadikal khairu innaka 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 27,
    "text": "Toolijul laila fin nahaari wa toolijun nahaara fil laili wa tukhrijul haiya minalmaiyiti wa tukhrijul maiyita minal haiyi wa tarzuqu man tashaaa'u bighari hisaab"
  },
  {
    "id": 28,
    "text": "Laa yattakhizil mu'minoonal kaafireena awliyaaa'a min doonil mu'mineena wa mai yaf'al zaalika falaisa minal laahi fee shai'in illaaa an tattaqoo minhum tuqaah; wa yuhazzirukumul laahu nafsah; wa ilal laahil maseer"
  },
  {
    "id": 29,
    "text": "Qul in tukhfoo maa fee sudoorikum aw tubdoohu ya'lamhul laah; wa ya'lamu maa fis samaawaati wa maa fil ard; wallaahu 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 30,
    "text": "Yawma tajidu kullu nafsim maa'amilat min khairim muhdaranw wa maa 'amilat min sooo'in tawaddu law anna bainahaa wa bainahooo amadam ba'eedaa; wa yuhazzirukumul laahu nafsah; wallaahu ra'oofum bil'ibaad"
  },
  {
    "id": 31,
    "text": "Qul in kuntum tuhibboonal laaha fattabi' oonee yuhbibkumul laahu wa yaghfir lakum zunoobakum; wallaahu Ghafoorur Raheem"
  },
  {
    "id": 32,
    "text": "Qul atee'ul laaha war Rasoola fa in tawallaw fa innal laaha laa yuhibbul kaafireen"
  },
  {
    "id": 33,
    "text": "Innal laahas tafaaa Aadama wa Noohanw wa Aala Ibraaheema wa Aala Imraana 'alal 'aalameen"
  },
  {
    "id": 34,
    "text": "Zurriyyatam ba'duhaa mim ba'd; wallaahu Samee'un 'Aleem"
  },
  {
    "id": 35,
    "text": "Iz qaalatim ra atu 'Imraana Rabbi innee nazartu laka maa fee batnee muharraran fataqabbal minnee innaka Antas Samee'ul 'Aleem"
  },
  {
    "id": 36,
    "text": "Falammaa wada'at haa qaalat Rabbi innee wada'tuhaaa unsaa wallaahu a'lamu bimaa wada'at wa laisaz zakaru kalunsaa wa innee sammaituhaa Maryama wa innee u'eezuhaa bika wa zurriyyatahaa minash Shaitaanir Rajeem"
  },
  {
    "id": 37,
    "text": "Fataqabba lahaa Rabbuhaa biqaboolin hasaninw wa ambatahaa nabaatan hasananw wa kaffalahaa Zakariyyaa kullamaa dakhala 'alaihaa Zakariyyal Mihraaba wajada 'indahaa rizqan qaala yaa Maryamu annaa laki haazaa qaalat huwa min 'indil laahi innal laaha yarzuqu mai yashaaa'u bighairi hisaab"
  },
  {
    "id": 38,
    "text": "Hunaaalika da'aa Zakariyyaa Rabbahoo qaala Rabbi hab lee mil ladunka zurriyyatan taiyibatan innaka samee'ud du'aaa'"
  },
  {
    "id": 39,
    "text": "Fanaadat hul malaaa'ikatu wa huwa qaaa'imuny yusallee fil Mihraabi annal laaha yubashshiruka bi Yahyaa musaddiqam bi Kalimatim minal laahi wa saiyidanw wa hasooranw wa Nabiyyam minas saaliheen"
  },
  {
    "id": 40,
    "text": "Qaala Rabbi annaa yakoonu lee ghulaamunw wa qad balaghaniyal kibaru wamraatee 'aaqirun qaala kazaalikal laahu yaf'alu maa yashaaa'"
  },
  {
    "id": 41,
    "text": "Qaala Rabbij 'al leee Aayatan qaala Aaayatuka allaa tukalliman naasa salaasata ayyaamin illa ramzaa; wazkur Rabbaka kaseeranw wa sabbih bil'ashiyyi wal ibkaar"
  },
  {
    "id": 42,
    "text": "Wa iz qaalatil malaaa'ikatu yaa Maryamu innal laahas tafaaki wa tahharaki wastafaaki 'alaa nisaaa'il 'aalameen"
  },
  {
    "id": 43,
    "text": "Yaa Maryamu uqnutee li Rabbiki wasjudee warka'ee ma'ar raaki'een"
  },
  {
    "id": 44,
    "text": "Zaalika min ambaaa'il ghaibi nooheehi ilaik; wa maa kunta ladaihim iz yulqoona aqlaamahum ayyuhum yakfulu Maryama wa maa kunta ladaihim iz yakhtasimoon"
  },
  {
    "id": 45,
    "text": "Iz qaalatil malaaa'ikatu yaa Maryamu innal laaha yubashshiruki bi Kalimatim minhus muhul Maseehu 'Eesab nu Maryama wajeehan fid dunyaa wal Aakhirati wa minal muqarrabeen"
  },
  {
    "id": 46,
    "text": "Wa yukallimun naasa filmahdi wa kahlanw wa minassaaliheen"
  },
  {
    "id": 47,
    "text": "Qaalat Rabbi annaa yakoonu lee waladunw wa lam yamsasnee basharun qaala kazaalikil laahu yakhluqu maa yashaaa'; izaa qadaaa amran fa innamaa yaqoolu lahoo kun fayakoon"
  },
  {
    "id": 48,
    "text": "Wa yu'allimuhul Kitaaba wal Hikmata wat Tawraata wal Injeel"
  },
  {
    "id": 49,
    "text": "Wa Rasoolan ilaa Baneee Israaa'eela annee qad ji'tukum bi Aayatim mir Rabbikum annee akhluqu lakum minatteeni kahai 'atittairi fa anfukhu feehi fayakoonu tairam bi iznil laahi wa ubri'ul akmaha wal abrasa wa uhyil mawtaa bi iznil laahi wa unabbi'ukum bimaa taakuloona wa maa taddakhiroona fee buyootikum; inna fee zaalika la Aayatal lakum in kuntum mu'mineen"
  },
  {
    "id": 50,
    "text": "Wa musaddiqal limaa baina yadaiya minat Tawraati wa liuhilla lakum ba'dal lazee hurrima 'alaikum; wa ji'tukum bi Aayatim mir Rabbikum fattaqul laaha wa atee'oon"
  },
  {
    "id": 51,
    "text": "Innal laaha Rabbee wa Rabbukum fa'budooh; haazaa Siraatum Mustaqeem"
  },
  {
    "id": 52,
    "text": "Falammaaa ahassa 'Eesaa minhumul kufra qaala man ansaaree ilal laahi qaalal Hawaariyyoona nahnu ansaarul laahi aamannaa billaahi washhad bi annaa muslimoon"
  },
  {
    "id": 53,
    "text": "Rabbanaaa aamannaa bimaaa anzalta wattaba'nar Rasoola faktubnaa ma'ash shaahideen"
  },
  {
    "id": 54,
    "text": "Wa makaroo wa makaral laahu wallaahu khairul maakireen"
  },
  {
    "id": 55,
    "text": "Iz qaalal laahu yaa 'Eesaaa innee mutawaffeeka wa raafi'uka ilaiya wa mutah hiruka minal lazeena kafaroo wa jaa'ilul lazeenattaba ooka fawqal lazeena kafarooo ilaa Yawmil Qiyaamati summa ilaiya marji'ukum fa ahkumu bainakum feemaa kuntum feehi takhtaliifoon"
  },
  {
    "id": 56,
    "text": "Fa ammal lazeena kafaroo fa u'az zibuhum 'azaaban shadeedan fiddunyaa wal Aakhirati wa maa lahum min naasireen"
  },
  {
    "id": 57,
    "text": "Wa ammal lazeena aamanoo wa 'amilus saalihaati fa yuwaffeehim ujoorahum; wallaahu laa yuhibbuz zaalimeen"
  },
  {
    "id": 58,
    "text": "Zaalika natloohu 'alaika minal Aayaati wa Zikril Hakeem"
  },
  {
    "id": 59,
    "text": "Inna masala 'Eesaa 'indal laahi kamasali Aadama khalaqahoo min turaabin summa qaala lahoo kun fayakoon"
  },
  {
    "id": 60,
    "text": "Alhaqqu mir Rabbika falaa takum minal mumtareen"
  },
  {
    "id": 61,
    "text": "Faman haaajjaka feehi mim ba'di maa jaaa'aka minal 'ilmi faqul ta'aalaw nad'u abnaaa'anaa wa abnaaa'akum wa nisaaa'anaa wa nisaaa'akum wa anfusanaa wa anfusakum summa nabtahil fanaj'al la'natal laahi 'alal kaazibeen"
  },
  {
    "id": 62,
    "text": "Innaa haazaa lahuwal qasasul haqq; wa maa min ilaahin illal laah; wa innal laahaa la Huwal 'Azeezul Hakeem"
  },
  {
    "id": 63,
    "text": "Fa in tawallaw fa innal laaha'aleemun bil mufsideen"
  },
  {
    "id": 64,
    "text": "Qul yaa Ahlal Kitaabi ta'aalaw ilaa Kalimatin sawaaa'im bainanaa wa bainakum allaa na'buda illal laaha wa laa nushrika bihee shai'anw wa laa yattakhiza ba'dunaa ba'dan arbaabam min doonil laah; fa in tawallaw faqoolush hadoo bi annaa muslimoon"
  },
  {
    "id": 65,
    "text": "Yaaa Ahlal Kitaabi limaa tuhaaajjoona feee Ibraaheema wa maaa unzilatit Tawraatu wal Injeelu illaa mim ba'dih; afala ta'qiloon"
  },
  {
    "id": 66,
    "text": "Haaa antum haaa'ulaaa'i haajajtum feemaa lakum bihee 'ilmun falima tuhaaajjoonaa feemaa laisa lakum bihee 'ilm; wallaahu ya'lamu wa antum laa ta'lamoon"
  },
  {
    "id": 67,
    "text": "Maa kaana Ibraaheemu Yahoodiyyanw wa laa Nasraa niyyanw wa laakin kaana Haneefam Muslimanw wa maa kaana minal mushrikeen"
  },
  {
    "id": 68,
    "text": "Innaa awlan naasi bi Ibraaheema lallazeenat taba 'oohu wa haazan nabiyyu wallazeena aamanoo; wallaahu waliyyul mu'mineen"
  },
  {
    "id": 69,
    "text": "Waddat taaa'ifatum min Ahlil Kitaabi law yudil loonakum wa maa yudilloona illaaa anfusahum wa maa yash'uroon"
  },
  {
    "id": 70,
    "text": "Yaaa Ahlal Kitaabi lima takfuroona bi Aayaatil laahi wa antum tash hadoon"
  },
  {
    "id": 71,
    "text": "Yaaa Ahalal Kitaabi lima talbisoonal haqqa bilbaatili wa taktumoonal haqqa wa antum ta'lamoon"
  },
  {
    "id": 72,
    "text": "Wa qaalat taaa'ifatum min Ahlil Kitaabi aaminoo billazeee unzila 'alal lazeena aamanoo wajhan nahaari wakfurooo aakhirahoo la'alla hum yarji'oon"
  },
  {
    "id": 73,
    "text": "Wa laa tu'minooo illaa liman tabi'a deenakum qul innal hudaa hudal laahi ai yu'taaa ahadum misla maaa ooteetum aw yuhaaajjookum 'inda Rabbikum, qul innal fadla biyadil laah; yu'teehi mai yashaaa'; wallaahu Waasi'un 'Aleem"
  },
  {
    "id": 74,
    "text": "Yakhtassu birahmatihee mai yashaaa'; wallaahu zulfadlil 'azeem"
  },
  {
    "id": 75,
    "text": "Wa min Ahlil Kitaabi man in ta'manhu biqintaariny yu'addihee ilaika wa minhum man in ta'manhu bi deenaarin laa yu'addiheee ilaika illaa maa dumta 'alaihi qaaa' imaa; zaalika biannahum qaaloo laisa 'alainaa fil ummiyyeena sabeelunw wa yaqooloona 'alal laahil kaziba wa hum ya'lamoon"
  },
  {
    "id": 76,
    "text": "Balaa man awfaa bi'ahdihee wattaqaa fainnal laaha yuhibbul muttaqeen"
  },
  {
    "id": 77,
    "text": "Innal lazeena yashtaroona bi'ahdil laahi wa aymaanihim samanan qaleelan ulaaa'ika laa khalaaqa lahum fil Aakhirati wa laa yukallimuhumul laahu wa laa yanzuru ilaihim Yawmal Qiyaamati wa laa yuzakkeehim wa lahum 'azabun 'aleem"
  },
  {
    "id": 78,
    "text": "Wa inna minhum lafaree qany yalwoona alsinatahum bil Kitaabi litahsaboohu minal Kitaab, wa maa huwa minal Kitaabi wa yaqooloona huwa min 'indillaahi wa maa huwa min 'indillaahi wa yaqooloona 'alal laahil kaziba wa hum ya'lamoon"
  },
  {
    "id": 79,
    "text": "Maa kaana libasharin ai yu'tiyahul laahul Kitaaba walhukma wan Nubuwwata summa yaqoola linnaasi koonoo 'ibaadal lee min doonil laahi wa laakin koonoo rabbaaniy yeena bimaa kuntum tu'allimoonal Kitaaba wa bimaa kuntum tadrusoon"
  },
  {
    "id": 80,
    "text": "Wa laa yaamurakum an tattakhizul malaaa 'ikata wan Nabiyyeena arbaabaa; a yaamurukum bilkufri ba'da iz antum muslimoon"
  },
  {
    "id": 81,
    "text": "Wa iz akhazal laahu meesaaqan Nabiyyeena lamaaa aataitukum min Kitaabinw wa Hikmatin summa jaaa'akum Rasoolum musaddiqul limaa ma'akum latu'minunna bihee wa latansurunnah; qaala a'aqrartum wa akhaztum alaa zaalikum isree qaalooo aqrarnaa; qaala fashhadoo wa ana ma'akum minash shaahideen"
  },
  {
    "id": 82,
    "text": "Faman tawallaa ba'da zaalika fa ulaaa'ika humul faasiqoon"
  },
  {
    "id": 83,
    "text": "Afaghaira deenil laahi yabghoona wa lahooo aslama man fis samaawaati wal ardi taw'anw wa karhanw wa ilaihi yurja'oon"
  },
  {
    "id": 84,
    "text": "Qul aamannaa billaahi wa maaa unzila 'alainaa wa maaa unzila 'alaaa Ibraaheema wa Ismaa'eela wa Ishaaqa wa Ya'qooba wal Asbaati wa maaa ootiya Moosaa wa 'Eesaa wan Nabiyyoona mir Rabbihim laa nufarriqu baina ahadim minhum wa nahnu lahoo muslimoon"
  },
  {
    "id": 85,
    "text": "Wa mai yabtaghi ghairal Islaami deenan falany yuqbala minhu wa huwa fil Aakhirati minal khaasireen"
  },
  {
    "id": 86,
    "text": "Kaifa yahdil laahu qawman kafaroo ba'da eemaanihim wa shahidooo annar Rasoola haqqunw wa jaaa'ahumul baiyinaat; wallaahu laa yahdil qawmaz zaalimeen"
  },
  {
    "id": 87,
    "text": "Ulaaa'ika jazaaa'uhum anna 'alaihim la'natal laahi walmalaaa'ikati wannaasi ajma'een"
  },
  {
    "id": 88,
    "text": "Khaalideena feehaa laa yukhaffafu 'anhumul 'azaabu wa laa hum yunzaroon"
  },
  {
    "id": 89,
    "text": "Illal lazeena taaboo mim ba'di zaalika wa aslahoo fa innal laaha Ghafoorur Raheem"
  },
  {
    "id": 90,
    "text": "Innal lazeena kafaroo ba'da eemaanihim summaz daadoo kufral lan tuqbala tawbatuhum wa ulaaa'ika humud daaalloon"
  },
  {
    "id": 91,
    "text": "Innal lazeena kafaroo wa maatoo wa hum kuffaarun falany yuqbala min ahadihim mil'ul ardi zahabanw wa lawiftadaa bih; ulaaa 'ika lahum 'azaabun aleemunw wa maa lahum min naasireen"
  },
  {
    "id": 92,
    "text": "Lan tanaalul birra hattaa tunfiqoo mimmaa tuhibboon; wa maa tunfiqoo min shai'in fa innal laaha bihee 'Aleem"
  },
  {
    "id": 93,
    "text": "Kullut ta'aami kaana hillal li Baneee Israaa'eela illaa maa harrama Israaa'eelu 'alaa nafsihee min qabli an tunazzalat Tawraah; qul faatoo bit Tawraati fatloohaaa in kuntum saadiqeen"
  },
  {
    "id": 94,
    "text": "Famanif taraa 'alal laahilkaziba mim ba'di zaalika fa ulaaa'ika humuz zaalimoon"
  },
  {
    "id": 95,
    "text": "Qul sadaqal laah; fattabi'oo Millata Ibraaheema Haneefanw wa maa kaana minal mush rikeen"
  },
  {
    "id": 96,
    "text": "Inna awwala Baitinw wudi'a linnaasi lallazee bi Bakkata mubaarakanw wa hudal lil 'aalameen"
  },
  {
    "id": 97,
    "text": "Feehi Aayaatum baiyinaatum Maqaamu Ibraaheema wa man dakhalahoo kaana aaminaa; wa lillaahi 'alan naasi Hijjul Baiti manis tataa'a ilaihi sabeelaa; wa man kafara fa innal laaha ghaniyyun 'anil 'aalameen"
  },
  {
    "id": 98,
    "text": "Qul yaaa Ahlal Kitaabi lima takfuroona bi Aayaatillaahi wallaahu shaheedun 'alaa maa ta'maloon"
  },
  {
    "id": 99,
    "text": "Qul yaaa Ahlal Kitaabi lima tasuddoona 'an sabeelil laahi man aamana tabghoonahaa 'iwajanw wa antum shuhadaaa'; wa mallaahu bighaafilin 'ammaa ta'maloon"
  },
  {
    "id": 100,
    "text": "Yaaa ayyuhal lazeena aamanoo in tutee'oo fareeqam minal lazeena ootul Kitaaba yaruddookum ba'da eemaanikum kaafireen"
  },
  {
    "id": 101,
    "text": "Wa kaifa takfuroona wa antum tutlaa 'alaikum Aayaatul laahi wa feekum Rasooluh; wa mai ya'tasim billaahi faqad hudiya ilaa Siraatim Mustaqeem"
  },
  {
    "id": 102,
    "text": "Yaaa ayyuhal lazeena aamanut taqul laaha haqqa tuqaatihee wa laa tamootunna illaa wa antum muslimoon"
  },
  {
    "id": 103,
    "text": "Wa'tasimoo bi Hablil laahi jamee'anw wa laa tafarraqoo; wazkuroo ni'matal laahi alaikum iz kuntum a'daaa'an fa allafa baina quloobikum fa asbah tum bini'matiheee ikhwaananw wa kuntum 'alaa shafaa hufratim minan Naari fa anqazakum minhaa; kazaalika yubaiyinul laahu lakum aayaatihee la'allakum tahtadoon"
  },
  {
    "id": 104,
    "text": "Waltakum minkum ummatuny yad'oona ilal khairi wa ya'muroona bil ma'roofi wa yanhawna 'anil munkar; wa ulaaa'ika humul muflihoon"
  },
  {
    "id": 105,
    "text": "Wa laa takoonoo kallazeena tafarraqoo wakhtalafoo mim ba'di maa jaaa'ahumul baiyinaat; wa ulaaa'ika lahum 'azaabun 'azeem"
  },
  {
    "id": 106,
    "text": "Yawma tabi yaddu wujoohunw wa taswaddu wujooh; fa-ammal lazeenas waddat wujoo hum akafartum ba'da eemaanikum fazooqul 'azaaba bimaa kuntum takfuroon"
  },
  {
    "id": 107,
    "text": "Wa ammal lazeena bi yaddat wujoohuhum fafee rahmatil laahi hum feehaa khaalidoon"
  },
  {
    "id": 108,
    "text": "Tilka Aayaatul laahi natloohaa 'alaika bilhaqq; wa mal laahu yureedu zulmallil 'aalameen"
  },
  {
    "id": 109,
    "text": "Wa lillaahi maa fissamaawaati wa maa fil ard; wa ilal laahi turja'ul umoor"
  },
  {
    "id": 110,
    "text": "Kuntum khaira ummatin ukhrijat linnaasi ta'muroona bilma'roofi wa tanhawna 'anil munkari wa tu'minoona billaah; wa law aamana Ahlul Kitaabi lakaana khairal lahum minhumul mu'minoona wa aksaruhumul faasiqoon"
  },
  {
    "id": 111,
    "text": "Lai yadurrookum 'illaaa azanw wa ai yuqaatilookum yuwallookumul adbaara summa laa yunsaroon"
  },
  {
    "id": 112,
    "text": "Duribat 'alaihimuz zillatu aina maa suqifooo illaa bihablim minal laahi wa hablim minan naasi wa baaa'oo bighadabim minallaahi wa duribat 'alaihimul maskanah; zaalika bi- annahum kaanoo yakfuroona bi Aayaatil laahi wa yaqtuloonal Ambiyaaa'a bighairi haqq; zaalika bimaa 'asaw wa kaanoo ya'tadoon"
  },
  {
    "id": 113,
    "text": "Laisoo sawaaa'a; min Ahlil Kitaabi ummatun qaaa'imatuny yatloona Aayaatil laahi aanaaa'al laili wa hum yasjudoon"
  },
  {
    "id": 114,
    "text": "Yu'minoona billaahi wal Yawmil Aakhiri wa ya'muroona bilma'roofi wa yanhawna 'anil munkari wa yusaari'oona fil khairaati wa ulaaa'ika minas saaliheen"
  },
  {
    "id": 115,
    "text": "Wa maa yaf'aloo min khairin falai yukfarooh; wallaahu 'aleemun bilmuttaqeen"
  },
  {
    "id": 116,
    "text": "Innal lazeena kafaroo lan tughniya 'anhum amwaaluhum wa laaa awlaaduhum minal laahi shai'anw wa ulaaa'ika Ashaabun Naar; hum feehaa khaalidoon"
  },
  {
    "id": 117,
    "text": "Masalu maa yunfiqoona fee haazihil hayaatid dunyaa kamasali reehin feehaa sirrun asaabat harsa qawmin zalamooo anfusahum fa ahlakath; wa maa zalamahumul laahu wa laakin anfusahum yazlimoon"
  },
  {
    "id": 118,
    "text": "Yaaa ayyuhal lazeena aamanoo laa tattakhizoo bitaanatam min doonikum laa ya'loonakum khabaalanw waddoo maa 'anittum qad badatil baghdaaa'u min afwaahihim; wa maa tukhfee sudooruhum akbar; qad baiyannaa lakumul Aayaati in kuntum ta'qiloon"
  },
  {
    "id": 119,
    "text": "Haaa antum ulaaa'i tuhibboonahum wa laa yuhibboonakum wa tu'minoona bil kitaabi kullihee wa izaa laqookum qaalooo aamannaa wa izaa khalaw 'addoo 'alaikumul anaamila minal ghaiz; qul mootoo bighai zikum; innal laaha 'aleemum bizaatis sudoor"
  },
  {
    "id": 120,
    "text": "In tamsaskum hasanatun tasu'hum wa in tusibkum saiyi'atuny yafrahoo bihaa wa in tasbiroo wa tattaqoo laa yad urrukum kaiduhum shai'aa; innal laaha bimaa ya'maloona muheet"
  },
  {
    "id": 121,
    "text": "Wa iz ghadawta min ahlika tubawwi'ul mu'mineena maqaa'ida lilqitaal; wallaahu samee'un 'aleem"
  },
  {
    "id": 122,
    "text": "Iz hammat taaa'ifataani minkum an tafshalaa wallaahu waliyyuhumaa; wa 'alal laahi falyatawakkalil mu'minoon"
  },
  {
    "id": 123,
    "text": "Wa laqad nasarakumul laahu bi-Badrinw wa antum azillatun fattaqul laaha la'allakum tashkuroon"
  },
  {
    "id": 124,
    "text": "Iz taqoolu lilmu'mineena alai yakfiyakum ai-yumiddakum Rabbukum bisalaasati aalaafim minal malaaa'ikati munzaleen"
  },
  {
    "id": 125,
    "text": "Balaaa; in tasbiroo wa tattaqoo wa ya'tookum min fawrihim haazaa yumdidkum Rabbukum bikhamsati aalaafim minal malaaa'ikati musawwimeen"
  },
  {
    "id": 126,
    "text": "Wa maa ja'alahul laahu illaa bushraa lakum wa litatma'inna quloobukum bih' wa man- nasru illaa min 'indilllaahil 'Azeezil Hakeem"
  },
  {
    "id": 127,
    "text": "Laiyaqta'a tarafam minal lazeena kafarooo aw yakbitahum fayanqaliboo khaaa'ibeen"
  },
  {
    "id": 128,
    "text": "Laisa laka minal amrishai'un aw yatooba 'alaihim aw yu'az zi bahum fa innahum zaalimoon"
  },
  {
    "id": 129,
    "text": "Wa lillahi maa fissamaawaati wa maa fil-ard; yaghfiru limai-yashaaa'u wa yu'azzibu mai- yashaaa'; wallaahu Ghafoorur Raheem"
  },
  {
    "id": 130,
    "text": "Yaaa ayyuhal lazeena aamanoo la takulu ribaaa ad'aafam mudaa'afatanw wattaqul laaha la'allakum tuflihoon"
  },
  {
    "id": 131,
    "text": "Wattaqun Naaral lateee u'iddat lilkaafireen"
  },
  {
    "id": 132,
    "text": "Wa atee'ul laaha war Rasoola la'allakum turhamoon"
  },
  {
    "id": 133,
    "text": "Wa saari'ooo ilaa maghfiratim mir Rabbikum wa Jannatin arduhassamaawaatu wal ardu u'iddat lilmuttaqeen"
  },
  {
    "id": 134,
    "text": "Allazeena yunfiqoona fissarraaa'i waddarraaa'i wal kaazimeenal ghaiza wal aafeena 'anin-naas; wallaahu yuhibbul muhsineen"
  },
  {
    "id": 135,
    "text": "Wallazeena izaa fa'aloo faahishatan aw zalamooo anfusahum zakarul laaha fastaghfaroo lizunoobihim; wa mai yaghfiruz zunooba illal laahu wa lam yusirroo 'alaa maa fa'aloo wa hum ya'lamoon"
  },
  {
    "id": 136,
    "text": "Ulaaa'ika jazaaa'uhum maghfiratum mir Rabbihim wa Jannaatun tajree min tahtihal anhaaru khaalideena feeha; wa ni'ma ajrul 'aamileen"
  },
  {
    "id": 137,
    "text": "Qad khalat min qablikum sunanum faseeroo fil ardi fanzuroo kaifa kaana 'aaqiba tul mukazzibeen"
  },
  {
    "id": 138,
    "text": "Haazaa bayaanul linnaasi wa hudanw wa maw'izatul lilmuttaqeen"
  },
  {
    "id": 139,
    "text": "Wa laa tahinoo wa laa tahzanoo wa antumul a'lawna in kuntum mu'mineen"
  },
  {
    "id": 140,
    "text": "Iny-yamsaskum qarhum faqad massal qawma qarhum misluh; wa tilkal ayyaamu nudaawiluhaa bainan naasi wa liya'lamal laahul lazeena aamanoo wa yattakhiza minkum shuhadaaa'; wallaahu laa yuh ibbuz zaalimeen"
  },
  {
    "id": 141,
    "text": "Wa liyumahhisal laahul lazeena aamanoo wa yamhaqal kaafireen"
  },
  {
    "id": 142,
    "text": "Am hasibtum an tadkhulul Jannnata wa lammaa ya'lamil laahul lazeena jaahadoo minkum wa ya'lamas saabireen"
  },
  {
    "id": 143,
    "text": "Wa laqad kuntum tamannnawnal mawta min qabli an talqawhu faqad ra aitumoohu wa antum tanzuroon"
  },
  {
    "id": 144,
    "text": "Wa maa Muhammadun illaa Rasoolun qad khalat min qablihir Rusul; afa'im maata aw qutilan qalabtum 'alaaa a'qaabikum; wa mai yanqalib 'alaa aqibaihi falai yadurral laaha shai'aa; wa sayajzil laahush shaakireen"
  },
  {
    "id": 145,
    "text": "Wa maa kaana linafsin an tamoota illaa bi iznillaahi kitaabam mu'ajjalaa; wa mai yurid sawaabad dunyaa nu'tihee minhaa wa mai yurid sawaabal Aakhirati nu'tihee minhaa; wa sanajzish shaakireen"
  },
  {
    "id": 146,
    "text": "Wa ka aiyim min Nabiyyin qaatala ma'ahoo ribbiyyoona kaseerun famaa wahanoo limaaa Asaabahum fee sabeelil laahi wa maa da'ufoo wa mas takaanoo; wallaahu yuhibbus saabireen"
  },
  {
    "id": 147,
    "text": "Wa maa kaana qawlahum illaa an qaaloo Rabbanagh fir lanaa zunoobanaa wa israafanaa feee amrinaa wa sabbit aqdaamanaa wansurnaa 'alal qawmil kaafireen"
  },
  {
    "id": 148,
    "text": "Fa aataahumul laahu sawaabad dunyaa wa husna sawaabil Aakhirah; wallaahu yuhibbul muhsineen"
  },
  {
    "id": 149,
    "text": "Yaaa 'aiyuhal lazeena aamanoo in tutee'ullazeena kafaroo yaruddookum 'alaaa a'qaabikum fatanqaliboo khaasireen"
  },
  {
    "id": 150,
    "text": "Balil laahu mawlaakum wa Huwa khairun naasireen"
  },
  {
    "id": 151,
    "text": "Sanulqee fee quloobil lazeena kafarur ru'ba bimaaa ashrakoo billaahi maa lam yunazzil bihee sultaana wa ma'wahumun Naar; wa bi'sa maswaz zaalimeen"
  },
  {
    "id": 152,
    "text": "Wa laqad sadaqakumul laahu wa'dahooo iz tahussoo nahum bi iznihee hattaaa izaa fashiltum wa tanaaza'tum fil amri wa 'asaitum mim ba'di maaa araakum maa tuhibboon; minkum mai yureedud dunyaa wa minkum mai yureedul Aakhirah; summa sarafakum 'anhum liyabtaliyakum wa laqad 'afaa 'ankum; wallaahu zoo fadlin 'alal mu'mineen"
  },
  {
    "id": 153,
    "text": "Iz tus'idoona wa laa talwoona 'alaaa ahadinw war Rasoolu yad'ookum feee ukhraakum fa asaabakum ghammam bighammil likailaa tahzanoo 'alaa maa faatakum wa laa maaa asaabakum; wallaahu khabeerum bimaa ta'maloon"
  },
  {
    "id": 154,
    "text": "Summa anzala 'alaikum mim ba'dil ghammi amanatan nu'aasai yaghshaa taaa' ifatam minkum wa taaa'ifatun qad ahammat-hum anfusuhum yazunnoona billaahi ghairal haqqi zannal jaahiliyyati yaqooloona hal lanaa minal amri min shai'; qul innal amra kullahoo lillaah; yukhfoona fee anfusihim maa laa yubdoona laka yaqooloona law kaana lanaa minal amri shai'ummaa qutilnaa haahunaa; qul law kuntum fee buyootikum labarazal lazeena kutiba 'alaihimul qatlu ilaa madaaji'ihim wa liyabtaliyal laahu maa fee sudoorikum wa liyumah hisa maa fee quloobikum; wallaahu 'aleemum bizaatis sudoor"
  },
  {
    "id": 155,
    "text": "Innal lazeena tawallaw minkum yawmal taqal jam'aani innamas tazallahumush Shaitaanu biba'di maa kasaboo wa laqad 'afal laahu 'anhum; innnal laaha Ghafoorun Haleem"
  },
  {
    "id": 156,
    "text": "Yaaa ayyuhal lazeena aamanoo laa takoonoo kallazeena kafaroo wa qaaloo li ikhwaanihim izaa daraboo fil ardi aw kaanoo ghuzzal law kaanoo 'indanaa maa maatoo wa maa qutiloo liyaj'alal laahu zaalika hasratan fee quloobihim; wallaahu yuhyee wa yumeet; wallaahu bimaa ta'maloona Baseer"
  },
  {
    "id": 157,
    "text": "Wa la'in qutiltum fee sabeelil laahi aw muttum lamaghfiratum minal laahi wa rahmatun khairum mimmaa yajma'oon"
  },
  {
    "id": 158,
    "text": "Wa la'im muttum 'aw qutiltum la il allahi tuhsharoon"
  },
  {
    "id": 159,
    "text": "Fabimaa rahmatim minal laahi linta lahum wa law kunta fazzan ghaleezal qalbi lanfaddoo min hawlika fa'afu 'anhum wastaghfir lahum wa shaawirhum fil amri fa izaa 'azamta fatawakkal 'alal laah; innallaaha yuhibbul mutawak kileen"
  },
  {
    "id": 160,
    "text": "Iny-yansurkumul laahu falaa ghaaliba lakum wa iny-yakhzulkum faman zal lazee yansurukum min ba'dih; wa 'alal laahi falyatawakkalil mu'minoon"
  },
  {
    "id": 161,
    "text": "Wa maa kaana li Nabiyyin ai yaghull; wa mai yaghlul ya'tibimaa ghalla Yawmal Qiyaamah; summa tuwaffaa kullu nafsim maa kasabat wa hum laa yuzlamoon"
  },
  {
    "id": 162,
    "text": "Afamanit taba'a Ridwaanal laahi kamam baaa'a bisakhatim minal laahi wa ma'waahu Jahannam; wa bi'sal maseer"
  },
  {
    "id": 163,
    "text": "Hum darajaatun 'indal laah; wallaahu baseerum bimaa ya'maloon"
  },
  {
    "id": 164,
    "text": "Laqad mannal laahu 'alal mu'mineena iz ba'asa feehim Rasoolam min anfusihim yatloo 'alaihim Aayaatihee wa yuzakkeehim wa yu'allimu humul Kitaaba wal Hikmata wa in kaanoo min qablu lafee dalaalim mubeen"
  },
  {
    "id": 165,
    "text": "Awa lammaaa asaabatkum museebatun qad asabtum mislaihaa qultum annaa haazaa qul huwa min 'indi anfusikum; innal laaha 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 166,
    "text": "Wa maa asaabakum yawmal taqal jam'aani fabi iznil laahi wa liya'lamal mu'mineen"
  },
  {
    "id": 167,
    "text": "Wa liya'lamal lazeena naafaqoo; wa qeela lahum ta'aalaw qaatiloo fee sabeelil laahi awid fa'oo qaaloo law na'lamu qitaalallat taba'naakum; hum lilkufri yawma'izin aqrabu minhum lil eemaan; yaqooloona bi afwaahihim maa laisa fee quloobihim; wallaahu a'lamu bimaa yaktumoon"
  },
  {
    "id": 168,
    "text": "Allazeena qaaloo li ikhwaanihim wa qa'adoo law ataa'oonaa maa qutiloo; qul fadra'oo'an anfusikumul mawta in kuntum saadiqeen"
  },
  {
    "id": 169,
    "text": "Wa laa tahsabannal lazeena qutiloo fee sabeelillaahi amwaata; bal ahyaaa'un 'inda Rabbihim yurzaqoon"
  },
  {
    "id": 170,
    "text": "Fariheena bimaaa aataa humul laahu min fadlihee wa yastabshiroona billazeena lam yalhaqoo bihim min khalfihim allaa khawfun 'alaihim wa laa hum yahzanoon"
  },
  {
    "id": 171,
    "text": "Yastabshiroona bini'matim minal laahi wa fad linw wa annal laaha laa yudee'u ajral mu'mineen"
  },
  {
    "id": 172,
    "text": "Allazeenas tajaaboo lil laahi war Rasooli mim ba'di maaa asaabahumulqarh; lillazeena ahsanoo minhum wattaqaw ajrun 'azeem"
  },
  {
    "id": 173,
    "text": "Allazeena qaala lahumun naasu innan naasa qad jama'oo lakum fakhshawhum fazaadahum emaananw wa qaaloo hasbunal laahu wa ni'malwakeel"
  },
  {
    "id": 174,
    "text": "Fanqalaboo bini'matim minal laahi wa fadlil lam yamsashum sooo'unw wattaba'oo ridwaanal laah; wallaahu zoo fadlin 'azeem"
  },
  {
    "id": 175,
    "text": "Innamaa zaalikumush Shaitaanu yukhawwifu awliyaaa'ahoo falaa takhaafoohum wa khaafooni in kuntum mu'mineen"
  },
  {
    "id": 176,
    "text": "Wa laa yahzunkal lazeena yusaari'oona fil Kufr; innahum lai yadurrul laaha shai'aa; yureedul laahu allaa yaj'ala lahum hazzan fil Aakhirati wa lahum 'azaabun 'azeem"
  },
  {
    "id": 177,
    "text": "Innal lazeenash tarawul kufra bil eemaani lai yadurrul laaha shai'anw wa lahum 'azaabun aleem"
  },
  {
    "id": 178,
    "text": "Wa laa yahsabannal lazeena kafarooo annamaa numlee lahum khairulli anfusihim; innamaa numlee lahum liyazdaadooo ismaa wa lahum 'azaabum muheen"
  },
  {
    "id": 179,
    "text": "Maa kaanal laahu liyazaral mu'mineena 'alaa maaa antum 'alaihi hattaa yameezal khabeesa minat taiyib; wa maa kaanal laahu liyutli'akum 'alal ghaibi wa laakinnal laaha yajtabee mir rusulihee mai yashaaa'; fa aaminoo billaahi wa Rusulih; wa in tu 'minoo wa tattaqoo falakum ajrun 'azeem"
  },
  {
    "id": 180,
    "text": "Wa laa yahsabannal lazeena yabkhaloona bimaa aataahumul laahu min fadilhee huwa khairal lahum bal huwa sharrul lahum sayutaw waqoona maa bakhiloo bihee Yawmal Qiyaamah; wa lillaahi meeraatus samaawaati wal ard; wallaahu bimaa ta'maloona Khabeer"
  },
  {
    "id": 181,
    "text": "Laqad sami'al laahu qawlal lazeena qaalooo innal laaha faqeerunw wa nahnu aghniyaaa'; sanaktubu maa qaaloo wa qatlahumul Ambiyaa'a bighairi haqqinw wa naqoolu zooqoo 'azaabal Hareeq"
  },
  {
    "id": 182,
    "text": "Zaalika bimaa qaddamat aideekum wa annal laaha laisa bizallaamil lil'abeed"
  },
  {
    "id": 183,
    "text": "Allazeena qaalooo innal laaha 'ahida ilainaaa allaa nu'mina liRasoolin hatta ya'tiyanaa biqurbaanin ta kuluhun naar; qul qad jaaa'akum Rusulum min qablee bilbaiyinaati wa billazee qultum falima qataltumoohum in kuntum saadiqeen"
  },
  {
    "id": 184,
    "text": "Fa in kaz zabooka faqad kuz ziba Rusulum min qablika jaaa'oo bilbaiyinaati waz Zuburi wal Kitaabil Muneer"
  },
  {
    "id": 185,
    "text": "Kullu nafsin zaaa'iqatul mawt; wa innamaa tuwaffawna ujoorakum Yawmal Qiyaamati faman zuhziha 'anin Naari wa udkhilal Jannata faqad faaz; wa mal hayaatud dunyaaa illaa mataa'ul ghuroor"
  },
  {
    "id": 186,
    "text": "Latublawunna feee amwaalikum wa anfusikum wa latasma'unna minal lazeena ootul Kitaaba min qablikum wa minal lazeena ashrakooo azan kaseeraa; wa in tasbiroo wa tattaqoo fa inna zaalika min 'azmil umoor"
  },
  {
    "id": 187,
    "text": "Wa iz akhazal laahu meesaaqal lazeena ootul Kitaaba latubaiyinunnahoo linnaasi wa laa taktumoona hoo fanabazoohu waraaa'a zuhoorihim washtaraw bihee samanan qaleelan fabi'sa maa yashtaroon"
  },
  {
    "id": 188,
    "text": "Laa tahsabannal lazeena yafrahoona bimaaa ataw wa yuhibbona ai yuhmadoo bimaa lam yaf'aloo falaa tahsabannahum bimafaazatim minal 'azaabi wa lahum 'azaabun aleem"
  },
  {
    "id": 189,
    "text": "Wa lillaahi mulkus samaawaati wal ard; wallaahu 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 190,
    "text": "Inna fee khalqis samaawaati wal ardi wakhtilaafil laili wannahaari la Aayaatil liulil albaab"
  },
  {
    "id": 191,
    "text": "Allazeena yazkuroonal laaha qiyaamanw-wa qu'oodanw-wa 'alaa juno obihim wa yatafakkaroona fee khalqis samaawaati wal ardi Rabbanaa maa khalaqta haaza baatilan Subhaanaka faqinaa 'azaaban Naar"
  },
  {
    "id": 192,
    "text": "Rabbanaaa innaka man tudkhilin Naara faqad akhzai tahoo wa maa lizzaalimeena min ansaar"
  },
  {
    "id": 193,
    "text": "Rabbanaaa innanaa sami'naa munaadiyai yunaadee lil eemaani an aaminoo bi Rabbikum fa aamannaa; Rabbanaa faghfir lanaa zunoobanaa wa kaffir 'annaa saiyi aatina wa tawaffanaa ma'al abraar"
  },
  {
    "id": 194,
    "text": "Rabbanaa wa aatinaa maa wa'attanaa 'alaa Rusulika wa laa tukhzinaa Yawmal Qiyaamah; innaka laa tukhliful mee'aad"
  },
  {
    "id": 195,
    "text": "Fastajaaba lahum Rabbuhum annee laaa Udee'u 'amala 'aamilim minkum min zakarin aw unsaa ba'dukum min ba'din fal lazeena haajaroo wa ukhrijoo min diyaarihim wa oozoo fee sabeelee wa qaataloo wa qutiloo la ukaffiranna 'anhum saiyi aatihim wa la udkhilanna hum Jannnatin tajree min tahtihal anhaaru sawaabam min 'indil laah; wallaahu 'indahoo husnus sawaab"
  },
  {
    "id": 196,
    "text": "Laa yaghurrannaka taqal lubul lazeena kafaroo fil bilaad"
  },
  {
    "id": 197,
    "text": "Mataa'un qaleelun summa ma'waahum Jahannam; wa bi'sal mihaad"
  },
  {
    "id": 198,
    "text": "Laakinil lazeenat taqaw Rabbahum lahum Jannnaatun tajree min tahtihal anhaaru khaalideena feehaa nuzulammin 'indil laah; wa maa 'indal laahi khairul lil abraar"
  },
  {
    "id": 199,
    "text": "Wa inna min Ahlil Kitaabi lamai yu'minu billaahi wa maaa unzila ilaikum wa maaa unzila ilaihim khaashi 'eena lillaahi laa yashtaroona bi Aayaatil laahi samanan qaleelaa; ulaaa'ika lahum ajruhum 'inda Rabbihim; innal laaha saree'ul hisaab"
  },
  {
    "id": 200,
    "text": "Yaaa aiyuhal lazeena aamanus biroo wa saabiroo wa raabitoo wattaqul laaha la'allakum tuflihoon"
  }
];

export default en;
