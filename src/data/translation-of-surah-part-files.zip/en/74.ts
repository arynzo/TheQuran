import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yaaa ayyuhal muddassir"
  },
  {
    "id": 2,
    "text": "Qum fa anzir"
  },
  {
    "id": 3,
    "text": "Wa rabbaka fakabbir"
  },
  {
    "id": 4,
    "text": "Wa siyaabaka fatahhir"
  },
  {
    "id": 5,
    "text": "Warrujza fahjur"
  },
  {
    "id": 6,
    "text": "Wa laa tamnun tastaksir"
  },
  {
    "id": 7,
    "text": "Wa li Rabbika fasbir"
  },
  {
    "id": 8,
    "text": "Fa izaa nuqira fin naaqoor"
  },
  {
    "id": 9,
    "text": "Fazaalika yawma 'iziny yawmun 'aseer"
  },
  {
    "id": 10,
    "text": "'Alal kaafireena ghairu yaseer"
  },
  {
    "id": 11,
    "text": "Zarnee wa man khalaqtu waheedaa"
  },
  {
    "id": 12,
    "text": "Wa ja'altu lahoo maalam mamdoodaa"
  },
  {
    "id": 13,
    "text": "Wa baneena shuhoodaa"
  },
  {
    "id": 14,
    "text": "Wa mahhattu lahoo tamheeda"
  },
  {
    "id": 15,
    "text": "Summa yat ma'u an azeed"
  },
  {
    "id": 16,
    "text": "Kallaaa innahoo kaana li Aayaatinaa 'aneedaa"
  },
  {
    "id": 17,
    "text": "Sa urhiquhoo sa'oodaa"
  },
  {
    "id": 18,
    "text": "Innahoo fakkara wa qaddar"
  },
  {
    "id": 19,
    "text": "Faqutila kayfa qaddar"
  },
  {
    "id": 20,
    "text": "Summa qutila kaifa qaddar"
  },
  {
    "id": 21,
    "text": "Summa nazar"
  },
  {
    "id": 22,
    "text": "Summa 'abasa wa basar"
  },
  {
    "id": 23,
    "text": "Summaa adbara wastakbar"
  },
  {
    "id": 24,
    "text": "Faqaala in haazaaa illaa sihruny yu'sar"
  },
  {
    "id": 25,
    "text": "In haazaaa illaa qawlul bashar"
  },
  {
    "id": 26,
    "text": "Sa usleehi saqar"
  },
  {
    "id": 27,
    "text": "Wa maaa adraaka maa saqar"
  },
  {
    "id": 28,
    "text": "Laa tubqee wa laa tazar"
  },
  {
    "id": 29,
    "text": "Lawwaahatul lilbashar"
  },
  {
    "id": 30,
    "text": "'Alaihaa tis'ata 'ashar"
  },
  {
    "id": 31,
    "text": "Wa maaja'alnaaa As-haaban naari illaa malaaa 'ikatanw wa maa ja'alnaa 'iddatahum illaa fitnatal lillazeena kafaroo liyastaiqinal lazeena ootul kitaaba wa yazdaadal lazeena aamanooo eemaananw wa laa yartaabal lazeena ootul kitaaba walmu'minoona wa liyaqoolal lazeena fee quloo bihim maradunw walkaafiroona maazaaa araadal laahu bihaazaa masalaa; kazaalika yudillul laahu mai yashaaa'u wa yahdee mai yashaaa'; wa maa ya'lamu junooda rabbika illaa hoo; wa maa hiya illaa zikraa lil bashar"
  },
  {
    "id": 32,
    "text": "Kallaa walqamar"
  },
  {
    "id": 33,
    "text": "Wallaili id adbar"
  },
  {
    "id": 34,
    "text": "Wassub hi izaaa asfar"
  },
  {
    "id": 35,
    "text": "Innahaa la ihdal kubar"
  },
  {
    "id": 36,
    "text": "Nazeeral lilbashar"
  },
  {
    "id": 37,
    "text": "Liman shaaa'a minkum any yataqaddama aw yata akhkhar"
  },
  {
    "id": 38,
    "text": "Kullu nafsim bima kasabat raheenah"
  },
  {
    "id": 39,
    "text": "Illaaa as haabal yameen"
  },
  {
    "id": 40,
    "text": "Fee jannaatiny yata saaa'aloon"
  },
  {
    "id": 41,
    "text": "'Anil mujrimeen"
  },
  {
    "id": 42,
    "text": "Maa salakakum fee saqar"
  },
  {
    "id": 43,
    "text": "Qaaloo lam naku minal musalleen"
  },
  {
    "id": 44,
    "text": "Wa lam naku nut'imul miskeen"
  },
  {
    "id": 45,
    "text": "Wa kunnaa nakhoodu ma'al khaaa'ideen"
  },
  {
    "id": 46,
    "text": "Wa kunnaa nukazzibu bi yawmid Deen"
  },
  {
    "id": 47,
    "text": "Hattaaa ataanal yaqeen"
  },
  {
    "id": 48,
    "text": "Famaa tanfa'uhum shafaa'atush shaafi'een"
  },
  {
    "id": 49,
    "text": "Famaa lahum 'anittazkirati mu'rideen"
  },
  {
    "id": 50,
    "text": "Ka annahum humurum mustanfirah"
  },
  {
    "id": 51,
    "text": "Farrat min qaswarah"
  },
  {
    "id": 52,
    "text": "Bal yureedu kullum ri'im minhum any yu'taa suhufam munashsharah"
  },
  {
    "id": 53,
    "text": "Kallaa bal laa yakhaafoonal aakhirah"
  },
  {
    "id": 54,
    "text": "Kallaaa innahoo tazkirah"
  },
  {
    "id": 55,
    "text": "Fa man shaaa'a zakarah"
  },
  {
    "id": 56,
    "text": "Wa maa yazkuroona illaaa any yashaaa'al laah; Huwa ahlut taqwaa wa ahlul maghfirah"
  }
];

export default en;
