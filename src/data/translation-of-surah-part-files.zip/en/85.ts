import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wassamaaa'i zaatil burooj"
  },
  {
    "id": 2,
    "text": "Wal yawmil maw'ood"
  },
  {
    "id": 3,
    "text": "Wa shaahidinw wa mashhood"
  },
  {
    "id": 4,
    "text": "Qutila as haabul ukhdood"
  },
  {
    "id": 5,
    "text": "Annaari zaatil waqood"
  },
  {
    "id": 6,
    "text": "Iz hum 'alaihaa qu'ood"
  },
  {
    "id": 7,
    "text": "Wa hum 'alaa maa yaf'aloona bilmu 'mineena shuhood"
  },
  {
    "id": 8,
    "text": "Wa maa naqamoo minhum illaaa aiyu'minoo billaahil 'azeezil Hameed"
  },
  {
    "id": 9,
    "text": "Allazee lahoo mulkus samaawaati wal ard; wallaahu 'alaa kulli shai 'in Shaheed"
  },
  {
    "id": 10,
    "text": "Innal lazeena fatanul mu'mineena wal mu'minaati summa lam yatooboo falahum 'azaabu Jahannama wa lahum 'azaabul hareeq"
  },
  {
    "id": 11,
    "text": "Innal lazeena aamanoo wa 'amilus saalihaati lahum Jannaatun tajree min tahtihal anhaar; zaalikal fawzul kabeer"
  },
  {
    "id": 12,
    "text": "Inna batsha Rabbika lashadeed"
  },
  {
    "id": 13,
    "text": "Innahoo Huwa yubdi'u wa yu'eed"
  },
  {
    "id": 14,
    "text": "Wa Huwal Ghafoorul Wadood"
  },
  {
    "id": 15,
    "text": "Zul 'Arshil Majeed"
  },
  {
    "id": 16,
    "text": "Fa' 'aalul limaa yureed"
  },
  {
    "id": 17,
    "text": "Hal ataaka hadeesul junood"
  },
  {
    "id": 18,
    "text": "Fir'awna wa Samood"
  },
  {
    "id": 19,
    "text": "Balil lazeena kafaroo fee takzeeb"
  },
  {
    "id": 20,
    "text": "Wallaahu minw waraaa'ihim muheet"
  },
  {
    "id": 21,
    "text": "Bal huwa Quraanum Majeed"
  },
  {
    "id": 22,
    "text": "Fee Lawhim Mahfooz"
  }
];

export default en;
