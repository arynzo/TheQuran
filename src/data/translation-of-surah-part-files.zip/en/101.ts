import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Al qaari'ah"
  },
  {
    "id": 2,
    "text": "Mal qaariah"
  },
  {
    "id": 3,
    "text": "Wa maa adraaka mal qaari'ah"
  },
  {
    "id": 4,
    "text": "Yauma ya koonun naasu kal farashil mabthooth"
  },
  {
    "id": 5,
    "text": "Wa ta koonul jibalu kal 'ihnil manfoosh"
  },
  {
    "id": 6,
    "text": "Fa-amma man thaqulat mawa zeenuh"
  },
  {
    "id": 7,
    "text": "Fahuwa fee 'ishatir raadiyah"
  },
  {
    "id": 8,
    "text": "Wa amma man khaffat mawa zeenuh"
  },
  {
    "id": 9,
    "text": "Fa-ummuhu haawiyah"
  },
  {
    "id": 10,
    "text": "Wa maa adraaka maa hiyah"
  },
  {
    "id": 11,
    "text": "Naarun hamiyah"
  }
];

export default en;
