import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Meeem"
  },
  {
    "id": 2,
    "text": "Tilka Aayaatul Kitaabil Hakeem"
  },
  {
    "id": 3,
    "text": "Hudanw wa rahmatal lilmuhsineen"
  },
  {
    "id": 4,
    "text": "Allazeena yuqeemoonas Salaata wa yu'toonaz Zakaata wa hum bil Aakhirati hum yooqinoon"
  },
  {
    "id": 5,
    "text": "Ulaaa'ika 'alaa hudam mir Rabbihim wa ulaaa'ika humul muflihoon"
  },
  {
    "id": 6,
    "text": "Wa minan naasi mai-yashtaree lahwal haddesi li yudilla 'an sabeelil laahi bighairi 'ilminw wa yattakhizahaa huzuwaa; ulaaa'ika lahum 'azaabum muheen"
  },
  {
    "id": 7,
    "text": "Wa izaa tutlaa 'alayhi Aayaatunaa wallaa mustakbiran ka al lam yasma'haa ka anna feee uzunaihi waqran fabashshiru bi'azaabin aleem"
  },
  {
    "id": 8,
    "text": "Innal lazeena aamanoo wa 'amilus saalihaati lahum Janaatun Na'eem"
  },
  {
    "id": 9,
    "text": "Khaalideena feeha wa'dal laahi haqqaa; wa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 10,
    "text": "Khalaqas samaawaati bi ghairi 'amadin tarawnahaa wa alqaa fil ardi rawaasiya an tameeda bikum wa bassa feehaa min kulli daaabbah; wa anzalnaa minas samaaa'i maaa'an fa ambatnaa feeha min kulli zawjin kareem"
  },
  {
    "id": 11,
    "text": "Haazaa khalqul laahi fa aroonee maazaa khalaqal lazeena min doonih; baliz zaalimoona fee dalalim Mubeen"
  },
  {
    "id": 12,
    "text": "Wa laqad aatainaa Luqmaanal hikmata anishkur lillaah; wa many yashkur fa innamaa yashkuru linafsihee wa man kafara fa innal laaha Ghaniyyun Hameed"
  },
  {
    "id": 13,
    "text": "Wa iz qaala luqmaanu libnihee wa huwa ya'izuhoo ya bunaiya laa tushrik billaah; innash shirka lazulmun 'azeem"
  },
  {
    "id": 14,
    "text": "Wa wassainal insaana bi waalidaihi hamalat hu ummuhoo wahnan 'alaa wahninw wa fisaaluhoo fee 'aamaini anishkur lee wa liwaalidaika ilaiyal maseer"
  },
  {
    "id": 15,
    "text": "Wa in jaahadaaka 'alaaa an tushrika bee maa laisa laka bihee 'ilmun falaa tuti'humaa wa saahib humaa fid dunyaa ma'roofanw wattabi' sabeela man anaaba ilayy; summa ilaiya marji'ukum fa unabbi'ukum bimaa kuntum ta'maloon"
  },
  {
    "id": 16,
    "text": "Ya bunaiya innahaaa in taku misqaala habbatim min khardalin fatakun fee sakhratin aw fis samaawaati aw fil ardi yaati bi Allah; innal laaha lateefun Khabeer"
  },
  {
    "id": 17,
    "text": "Yaa bunaiya aqimis-Salaata waamur bilma'roofi wanha 'anil munkari wasbir 'alaa maaa asaabaka inna zaalika min 'azmil umoor"
  },
  {
    "id": 18,
    "text": "Wa laa tusa'-'ir khaddaka linnaasi wa laa tamshi fil ardi maarahan innal laaha laa yuhibbu kulla mukhtaalin fakhoor"
  },
  {
    "id": 19,
    "text": "Waqsid fee mashyika waghdud min sawtik; inna ankaral aswaati lasawtul hameer"
  },
  {
    "id": 20,
    "text": "Alam taraw annal laaha sakhkhara lakum maa fis sa maawaati wa maa fil ardi wa asbagha 'alaikum ni'amahoo zaahiratanw wa baatinah; wa minan naasi many yujaadilu fil laahi bighayri 'ilminw wa laa hudanw wa laa Kitaabim muneer"
  },
  {
    "id": 21,
    "text": "Wa izaa qeela lahumut-tabi'oo maaa anzalal laahu qaaloo bal nattabi'u maa wajadnaa 'alaihi aabaaa'anaa; awalaw kaanash Shaitaanu yad'oohum ilaa 'azaabis sa'eer"
  },
  {
    "id": 22,
    "text": "Wa many yuslim wajha hooo ilal laahi wa huwa muhsinun faqadistamsaka bil'ur watil wusqaa; wa ilal laahi 'aaqibatul umoor"
  },
  {
    "id": 23,
    "text": "Wa man kafara falaa yahzunka kufruh; ilainaa marji'uhum fanunabbi'uhum bimaa 'amiloo; innal laaha 'aleemum bizaatis sudoor"
  },
  {
    "id": 24,
    "text": "Numatti'uhum qaleelan summa nadtarruhum ilaa 'azaabin ghaleez"
  },
  {
    "id": 25,
    "text": "Wa la'in sa altahum man khalaqas samaawaati wal arda la yaqoolunnal laah; qulil hamdu lillaah; bal aksaruhum laa ya'lamoon"
  },
  {
    "id": 26,
    "text": "Lillahi ma fis samaa waati wal ard; innal laaha Huwal Ghaniyyul Hameed"
  },
  {
    "id": 27,
    "text": "Wa law annamaa fil ardi min shajaratin aqlaamunw wal bahru yamudduhoo mim ba'dihee sab'atu abhurim maa nafidat Kalimaatul laah; innal laaha 'azeezun Hakeem"
  },
  {
    "id": 28,
    "text": "Maa khalqukum wa laa ba'sukum illaa kanafsinw-waa hidah; innal laaha Samee'um Baseer"
  },
  {
    "id": 29,
    "text": "Alam tara annal laaha yoolijul laila fin nahaari wa yoolijun nahaara fil laili wa sakhkharash shamsa wal qamara kulluny yajreee ilaaa ajalim musammanw wa annal laaha bimaa ta'maloona Khabeer"
  },
  {
    "id": 30,
    "text": "Zaalika bi annal laaha Huwal Haqqu wa anna maa yad'oona min doonihil baatilu wa annal laaha Huwal 'Aliyyul Kabeer"
  },
  {
    "id": 31,
    "text": "Alam tara annal fulka tajree fil bahri bini'matil laahi li yuriyakum min Aayaatih; inna fee zaalika la Aayaatil likulli sabbaarin shakoor"
  },
  {
    "id": 32,
    "text": "Wa izaa ghashiyahum mawjun kazzulali da'a-wul laaha mukhliseena lahud deena fa lammaa najjaahum ilal barri faminhum muqtasid; wa maa yajhadu bi Aayaatinaa illaa kullu khattaarin kafoor"
  },
  {
    "id": 33,
    "text": "Yaaa ayyuhan naasuttaqoo Rabbakum wakhshaw Yawmal laa yajzee waalidun 'anw waladihee wa laa mawloodun huwa jaazin 'anw waalidihee shai'aa; innaa wa'dal laahi haqqun falaa taghurran nakumul hayaatud dunyaa wa laa yaghur rannakum billaahil gharoor"
  },
  {
    "id": 34,
    "text": "Innal laaha 'indahoo 'ilmus saa'ati wa yunazzilul ghaisa wa ya'lamu maa fil arhaami wa maa tadree nafsum maazaa taksibu ghadaa; wa maa tadree nafsum bi ayyi ardin tamoot; innal laaha 'Aleemun Khabeer"
  }
];

export default en;
