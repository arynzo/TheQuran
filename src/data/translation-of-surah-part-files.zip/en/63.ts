import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Izaa jaaa'akal munaafiqoona qaaloo nashhadu innaka la rasoolul laah; wallaahu ya'lamu innaka la rasooluhoo wallaahu yashhadu innal munaafiqeena lakaaziboon"
  },
  {
    "id": 2,
    "text": "Ittakhazoo aymaanahum junnatan fasaddoo 'an sabeelil laah; innahum saaa'a maa kaanoo ya'maloon"
  },
  {
    "id": 3,
    "text": "Zaalika bi annahum aamanoo summa kafaroo fatubi'a 'alaa quloobihim fahum laa yafqahoon"
  },
  {
    "id": 4,
    "text": "Wa izaa ra aytahum tu'jibuka ajsaamuhum wa iny yaqooloo tasma' liqawlihim ka'annahum khushubum musannadah; yahsaboona kulla saihatin 'alaihim; humul 'aduwwu fahzarhum; qaatalahumul laahu annaa yu'fakoon"
  },
  {
    "id": 5,
    "text": "Wa izaa qeela lahum ta'aalaw yastaghfir lakum rasoolul laahi lawwaw ru'oo sahum wa ra aytahum yasuddoona wa hum mustakbiroon"
  },
  {
    "id": 6,
    "text": "Sawaaa'un 'alaihim as taghfarta lahum am lam tastaghfir lahum lany yaghfiral laahu lahum; innal laaha laa yahdil qawmal faasiqeen"
  },
  {
    "id": 7,
    "text": "Humul lazeena yaqooloona laa tunfiqoo 'alaa man inda Rasoolil laahi hatta yanfaddoo; wa lillaahi khazaaa' inus samaawaati wal ardi wa laakinnal munaafiqeena la yafqahoon"
  },
  {
    "id": 8,
    "text": "Yaqooloona la'ir raja'naaa ilal madeenati la yukhrijannal a'azzu minhal azall; wa lillaahil 'izzatu wa li Rasoolihee wa lilmu'mineena wa laakinnal munaafiqeena laa ya'lamoon"
  },
  {
    "id": 9,
    "text": "Yaaa ayyuhal lazeena aamanoo la tulhikum amwaalukum wa laa awlaadukum 'anzikril laah; wa mai-yaf'al zaalika fa-ulaaa'ika humul khaasiroon"
  },
  {
    "id": 10,
    "text": "Wa anfiqoo mim maa razaqnaakum min qabli any-ya'tiya ahadakumul mawtu fa yaqoola rabbi law laaa akhkhartaneee ilaaa ajalin qareebin fa assaddaqa wa akum minassaaliheen"
  },
  {
    "id": 11,
    "text": "Wa lany yu 'akhkhiral laahu nafsan izaa jaaa'a ajaluhaa; wallaahu khabeerum bimaa ta'maloon"
  }
];

export default en;
