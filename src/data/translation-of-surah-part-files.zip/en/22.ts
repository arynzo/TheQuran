import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yaaa ayyuhan naasuttaqoo Rabbakum; inna zalzalatas Saa'ati shai'un 'azeem"
  },
  {
    "id": 2,
    "text": "Yawma tarawnahaa tazhalu kullu murdi'atin 'ammaaa arda'at wa tada'u kullu zaati hamlin hamlahaa wa tarannaasa sukaaraa wa maa hum bisukaaraa wa lakinna 'azaabal laahi shadeed"
  },
  {
    "id": 3,
    "text": "Wa minan naasi mai yujaadilu fil laahi bighairi 'ilminw wa yattabi'u kullaa shaitaanim mareed"
  },
  {
    "id": 4,
    "text": "Kutiba 'alaihi annahoo man tawallaahu fa annahoo yudilluhoo wa yahdeehi ilaa 'azaabis sa'eer"
  },
  {
    "id": 5,
    "text": "Yaaa ayyuhan naasu in kuntum fee raibin minal ba'thi fa innaa khalaqnaakum min turaabin thumma min nutfatin thumma min 'alaqatin thumma min mudghatin mukhallaqatinw wa ghairi mukhallaqatin linubaiyina lakum; wa nuqirru fil arhaami maa nashaaa'u ilaaa ajalin musamman thumma nukhrijukum tiflan thumma litablughooo ashuddakum wa minkum mai yutawaffa wa minkum mai yuraddu ilaaa arzalil 'umuri likailaa ya'lama min ba'di 'ilmin shai'aa; wa taral arda haamidatan fa izaaa anzalnaa 'alaihal maaa'ah tazzat wa rabat wa ambatat min kulli zawjin baheej"
  },
  {
    "id": 6,
    "text": "Zaalika bi annal laaha Huwal haqqu wa annahoo yuhyil mawtaa wa annahoo 'alaakulli shai'in Qadeer"
  },
  {
    "id": 7,
    "text": "Wa annas Saa'ata aatiya tul laa raiba feeha wa annal laaha yab'asuman fil quboor"
  },
  {
    "id": 8,
    "text": "Wa minan naasi mai yujaadilu fil laahi bighairi 'ilminw wa laa hudanw wa laa Kitaabim Muneer"
  },
  {
    "id": 9,
    "text": "Saaniya 'itfihee liyudilla 'an sabeelil laahi lahoo fiddun yaa khizyunw wa nuzeequhoo Yawmal Qiyaamati 'azaabal lhareeq"
  },
  {
    "id": 10,
    "text": "Zaalika bimaa qaddamat yadaaka wa annal laaha laisa bizallaamil lil'abeed"
  },
  {
    "id": 11,
    "text": "Wa minan naasi mai ya'budul laaha 'alaa harfin fa in asaabahoo khairunit maanna bihee wa in asaabat hu fitnatunin qalaba 'alaa wajhihee khasirad dunyaa wal aakhirah; zaalika huwal khusraanul mubeen"
  },
  {
    "id": 12,
    "text": "Yad'oo min doonil laahi maa laa yadurruhoo wa maa laa yanfa'uh' zaalika huwad dalaalul ba'ed"
  },
  {
    "id": 13,
    "text": "Yad'oo laman darruhooo aqrabu min naf'ih; labi'salmawlaa wa labi'sal 'asheer"
  },
  {
    "id": 14,
    "text": "Innal laaha yudkhilul lazeena aamanoo wa 'amilus saalihaati jannaatin tajree min tahtihal anhaar; innal laaha yaf'alu maa yureed"
  },
  {
    "id": 15,
    "text": "Man kaana yazunnu allai yansurahul laahu fid dunyaa wal aakhirati fal yamdud bisababin ilas samaaa'i summal yaqta' falyanzur hal yuzhibanna kaiduhoo maa yagheez"
  },
  {
    "id": 16,
    "text": "Wa kazaalika anzalnaahu aayaatim baiyinaatinw wa annal laaha yahdee mai yureed"
  },
  {
    "id": 17,
    "text": "Innal lazeena aamanoo wallazeena haadoo was saabi'eena wan nasaaraa wal Majoosa wallazeena ashrakooo innal laaha yafsilu bainahum yawmal qiyaamah; innal laaha 'alaa kulli shai'in shaheed"
  },
  {
    "id": 18,
    "text": "Alam tara annal laaha yasjudu lahoo man fis samaawaati wa man fil ardi wash shamsu walqamaru wan nu joomu wal jibaalu wash shajaru wad dawaaabbu wa kaseerum minan naasi wa kaseerun haqqa 'alaihil 'azaab; wa mai yuhinil laahu famaa lahoo mim mukrim; innallaaha yaf'alu maa yashaaa"
  },
  {
    "id": 19,
    "text": "Haazaani khasmaanikh tasamoo fee Rabbihim fal lazeena kafaroo qutti'at lahum siyaabum min naar; yusabbu min fawqi ru'oosihimul hameem"
  },
  {
    "id": 20,
    "text": "Yusharu bihee maa fee butoonihim waljulood"
  },
  {
    "id": 21,
    "text": "Wa lahum maqaami'u min hadeed"
  },
  {
    "id": 22,
    "text": "Kullamaa araadooo any yakhrujoo minhaa min ghammin u'eedoo feeha wa zooqoo 'azaabal hareeq"
  },
  {
    "id": 23,
    "text": "Innal laaha yudkhilul lazeena aamanoo wa 'amilus saalihaati jannaatin tajree min tahtihal anhaaru yuhallawna feehaa min asaawira min zahabinw wa lu'lu'aa; wa libaasuhum feehaa hareer"
  },
  {
    "id": 24,
    "text": "Wa hudooo ilat taiyibi minal qawli wa hudooo ilaaa siraatil hameed"
  },
  {
    "id": 25,
    "text": "Innal lazeena kafaroo wa yasuddoona 'an sabeelil laahi wal Masjidil Haraamil lazee ja'alnaahu linnaasi sawaaa'anil 'aakifu feehi walbaad; wa mai yurid feehi bi ilhaadim bizulmin nuziqhu min 'azaabin aleem"
  },
  {
    "id": 26,
    "text": "Wa iz bawwaanaa li Ibraaheema makaanal Baiti allaa tushrik bee shai'anw wa tahhir Baitiya litaaa'ifeena walqaaa' imeena warrukka 'is sujood"
  },
  {
    "id": 27,
    "text": "Wa azzin fin naasi bil Hajji yaatooka rijaalanw wa 'alaa kulli daamiriny yaateena min kulli fajjin 'ameeq"
  },
  {
    "id": 28,
    "text": "Li yashhadoo manaafi'a lahum wa yazkurus mal laahi feee ayyaamimma'loomaatin 'alaa maa razaqahum mim baheematil an'aami fakuloo minhaa wa at'imul baaa'isal faqeer"
  },
  {
    "id": 29,
    "text": "Summal yaqdoo tafasahum wal yoofoo nuzoorahum wal yattawwafoo bil Baitil 'Ateeq"
  },
  {
    "id": 30,
    "text": "Zaalika wa mai yu'azzim hurumaatil laahi fahuwa khairul lahoo 'inda Rabbih; wa uhillat lakumul an'aamu illaa maa yutlaa 'alaikum fajtanibur rijsa minal awsaani wajtaniboo qawlaz zoor"
  },
  {
    "id": 31,
    "text": "Hunafaaa'a lillaahi ghaira mushrikeena bih; wa mai yushrik billaahi faka annamaa kharra minas samaaa'i fatakh tafuhut tairu aw tahwee bihir reehu bee makaanin saheeq"
  },
  {
    "id": 32,
    "text": "Zaalika wa mai yu'azzim sha'aaa'iral laahi fa innahaa min taqwal quloob"
  },
  {
    "id": 33,
    "text": "Lakum feehaa manaafi'u ilaaa ajalim musamman summa mahilluhaaa ilal Baitil 'Ateeq"
  },
  {
    "id": 34,
    "text": "Wa likulli ummatin ja'alnaa mansakal liyazkurus mal laahi 'alaa maa razaqahum mim baheematil an'aam; failaahukum ilaahunw Waahidun falahooo aslimoo; wa bashshiril mukhbiteen"
  },
  {
    "id": 35,
    "text": "Allazeena izaa zukiral laahu wajilat quloobuhum wassaabireena 'alaa maaa asaabahum walmuqeemis Salaati wa mimmaa razaqnaahum yunfiqoon"
  },
  {
    "id": 36,
    "text": "Walbudna ja'alnaahaa lakum min sha'aaa'iril laahi lakum feehaa khairun fazkurusmal laahi 'alaihaa sawaaff; fa izaa wajabat junoobuhaa fakuloo minhaa wa at'imul qaani'a walmu'tarr; kazaalika sakhkharnaahaa lakum la'allakum tashkuroon"
  },
  {
    "id": 37,
    "text": "Lany yanaalal laaha luhoo muhaa wa laa dimaaa'uhaa wa laakiny yanaaluhut taqwaa minkum; kazaalika sakhkharhaa lakum litukabbirul laaha 'alaa ma hadaakum; wa bashshiril muhsineen"
  },
  {
    "id": 38,
    "text": "Innal laaha yudaafi' 'anil lazeena aamanoo; innal laaha laa yuhibbu kulla khawwaanin kafoor"
  },
  {
    "id": 39,
    "text": "Uzina lillazeena yuqaataloona bi annahum zulimoo; wa innal laaha 'alaa nasrihim la Qadeer"
  },
  {
    "id": 40,
    "text": "Allazeena ukhrijoo min diyaarihim bighairi haqqin illaaa any yaqooloo rabbunallaah; wa law laa daf'ul laahin naasa ba'dahum biba'dil lahuddimat sawaami'u wa biya'unw wa salawaatunw wa masaajidu yuzkaru feehasmul laahi kaseeraa; wa layansurannal laahu mai yansuruh; innal laaha la qawiyyun 'Azeez"
  },
  {
    "id": 41,
    "text": "Allazeena im makkan naahum fil ardi aqaamus Salaata wa aatawuz Zakaata wa amaroo bilma'roofi wa nahaw 'anil munkar; wa lillaahi 'aaqibatul umoor"
  },
  {
    "id": 42,
    "text": "Wa iny yukazzibooka faqad kazzabat qablahum qawmu Noohinw wa Aadunw wa Samood"
  },
  {
    "id": 43,
    "text": "Wa qawmu Ibraaheema wa qawmu Loot"
  },
  {
    "id": 44,
    "text": "Wa as haabu Madyana wa kuzziba Moosaa fa amlaitu lilkaafireena summa akhaztuhum fakaifa kaana nakeer"
  },
  {
    "id": 45,
    "text": "Faka ayyim min qaryatin ahlaknaahaa wa hiya zaalimatun fahiya khaawiyatun 'alaa 'urooshihaa wa bi'rim mu'at talatinw wa qasrim masheed"
  },
  {
    "id": 46,
    "text": "Afalam yaseeroo fil ardi fatakoona lahum quloobuny ya'qiloona bihaaa aw aazaanuny yasma'oona bihaa fa innahaa laa ta'mal absaaru wa laakin ta'mal quloobul latee fissudoor"
  },
  {
    "id": 47,
    "text": "Wa yasta'jiloonaka bil'azaabi wa lany yukhlifal laahu wa'dah; wa inna yawman 'inda Rabbika ka'alfi sanatim mimmaa ta'uddoon"
  },
  {
    "id": 48,
    "text": "Wa ka ayyim min qaryatin amlaitu lahaa wa hiya zaalimatun summa akhaztuhaa wa ilaiyal maseer"
  },
  {
    "id": 49,
    "text": "Qul yaaa ayyuhan naasu innamaaa ana lakum nazeerum mubeen"
  },
  {
    "id": 50,
    "text": "Fallazeena aamanoo wa 'amilus saalihaati lahum maghfiratunw wa rizqun kareem"
  },
  {
    "id": 51,
    "text": "Wallazeena sa'aw feee Aayaatinaa mu'aajizeena ulaaa ika As-haabul jaheem"
  },
  {
    "id": 52,
    "text": "Wa maaa arsalnaa min qablika mir Rasoolinnw wa laa Nabiyyin illaaa izaaa tamannaaa alqash Shaitaanu feee umniy yatihee fa yansakhul laahu maa yulqish Shaitaanu summa yuhkimul laahu aayaatih; wallaahu 'Aleemun Hakeem"
  },
  {
    "id": 53,
    "text": "Liyaj'ala maa yulqish Shaitaanu fitnatal lillazeena fee quloobihim maradunw walqaasiyati quloobuhum; wa innaz zaalimeena lafee shiqaaqim ba'eed"
  },
  {
    "id": 54,
    "text": "Wa liya'lamal lazeena ootul 'ilma annahul haqqu mir Rabbika fa yu'minoo bihee fatukhbita lahoo quloobuhum; wa innal laaha lahaadil lazeena aamanoo ilaa Siraatim Mustaqeem"
  },
  {
    "id": 55,
    "text": "Wa laa yazaalul lazeena kafaroo fee miryatim minhu hattaa taatiyahumus Saa'atu baghtatan aw yaatiyahum 'azaabu Yawmin 'aqeem"
  },
  {
    "id": 56,
    "text": "Almulku Yawma'izil lillaahi yahkumu bainahum; fallazeena aamanoo wa 'amilus saalihaati fee jannaatin Na'eem"
  },
  {
    "id": 57,
    "text": "Wallazeena kafaroo wa kazzaboo bi Aayaatinaa fa ulaaa'ika lahum 'azaabum muheen"
  },
  {
    "id": 58,
    "text": "Wallazeena haajaroo fee sabeelil laahi summa qutilooo aw maatoo la yarzuqan nahumul laahu rizqan hasanaa; wa innal laaha la Huwa khairur raaziqeen"
  },
  {
    "id": 59,
    "text": "La yudkhilan nahum mud khalany yardawnah; wa innal laaha la 'Aleemun Haleem"
  },
  {
    "id": 60,
    "text": "Zaalika wa man 'aaqaba bimisli maa 'ooqiba bihee summa bughiya 'alaihi la yansurannahul laah; innal laaha la 'Afuwwun Ghafoor"
  },
  {
    "id": 61,
    "text": "Zaalika bi annal laaha yoolijul laila fin nahaari wa yoolijun nahaara fil laili wa annal laaha Samee'um Baseer"
  },
  {
    "id": 62,
    "text": "Zaalika bi annal laaha Huwal haqqu wa anna maa yad'oona min doonihee huwal baatilu wa annal laaha Huwal 'Aliyyul kabeer"
  },
  {
    "id": 63,
    "text": "Alam tara annal laaha anzala minas samaaa'i maaa'an fatusbihul ardu mukhdarrah; innal laaha Lateefun Khabeer"
  },
  {
    "id": 64,
    "text": "Lahoo ma fis samaawaati wa ma fil ard; wa innal laaha la Huwal Ghaniyyul Hameed"
  },
  {
    "id": 65,
    "text": "Alam tara annal laaha sakhkhara lakum maa fil ardi wal fulka tajree fil bahri bi amrihee wa yumsikus samaaa'a an taqa'a 'alal ardi illaa biiznih; innal laaha binnaasi la Ra'oofur Raheem"
  },
  {
    "id": 66,
    "text": "Wa Huwal lazee ahyaakum summa yumeetukum summa yuhyeekum; innal insaana la kafoor"
  },
  {
    "id": 67,
    "text": "Likulli ummatin ja'alnaa mansakan hum naasikoohu falaa yunaazi 'unnaka fil amr; wad'u ilaa Rabbika innaka la 'alaa hudan mustaqeem"
  },
  {
    "id": 68,
    "text": "Wa in jaadalooka faqulil laahu a'lamu bimaa ta'maloon"
  },
  {
    "id": 69,
    "text": "Allaahu yahkumu bainakum Yawmal Qiyaamati feemaa kuntum feehi takhtalifoon"
  },
  {
    "id": 70,
    "text": "Alam ta'lam annal laaha ya'lamu maa fis samaaa'i wal ard; inna zaalika fee kitaab; inna zaalika 'alal laahi yaseer"
  },
  {
    "id": 71,
    "text": "Wa ya'budoona min doonil laahi maa lam yunazzil bihee sultaananw wa maa laisa lahum bihee 'ilm; wa maa lizzaalimeena min naseer"
  },
  {
    "id": 72,
    "text": "Wa izaa tutlaa 'alaihim Aayaatunaa baiyinaatin ta'rifu fee wujoohil lazeena kafarul munkara yakaadoona yastoona bil lazeena yatloona 'alaihim Aayaatinaa; qul afa unab bi'ukum bisharrim min zaalikum; an Naaru wa 'adahal laahul lazeena kafaroo wa bi'sal maseer"
  },
  {
    "id": 73,
    "text": "Yaaa ayyuhan naasu duriba masalun fastami'oo lah; innal lazeena tad'oona min doonil laahi lai yakhluqoo zubaabanw wa lawijtama'oo lahoo wa iny yaslub humuz zubaabu shai'an laa yastanqizoohu minh; da'ufat taalibu wal matloob"
  },
  {
    "id": 74,
    "text": "Maa qadrul laaha haqqa qadrih; innal laaha la Qawiyyun 'Azeez"
  },
  {
    "id": 75,
    "text": "Allahu yastafee minal malaaa'ikati Rusulanw wa minan naas; innal laaha Samee'un Baseer"
  },
  {
    "id": 76,
    "text": "Ya'lamu maa baina aydeehim wa maa khalfahum; wa ilal laahi turja'ul umoor"
  },
  {
    "id": 77,
    "text": "Yaaa ayyuhal lazeena aamanur ka'oo wasjudoo wa'budoo Rabbakum waf'alul khaira la'allakum tuflihoon"
  },
  {
    "id": 78,
    "text": "Wa jaahidoo fil laahi haqqa jihaadih; Huwaj tabaakum wa maa ja'ala 'alaikum fid deeni min haraj; Millata abeekum Ibraaheem; Huwa sammaakumul muslimeena min qablu wa fee haaza li yakoonar Rasoolu shaheedan 'alaikum wa takoonoo shuhadaaa'a 'alan naas; fa aqeemus salaata wa aatuz zakaata wa'tasimoo billaahi Huwa mawlaakum fani'mal mawlaa wa ni'man naseer"
  }
];

export default en;
