import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wassamaaa'i wattaariq"
  },
  {
    "id": 2,
    "text": "Wa maaa adraaka mattaariq"
  },
  {
    "id": 3,
    "text": "Annajmus saaqib"
  },
  {
    "id": 4,
    "text": "In kullu nafsil lammaa 'alaihaa haafiz"
  },
  {
    "id": 5,
    "text": "Fal yanzuril insaanu mimma khuliq"
  },
  {
    "id": 6,
    "text": "Khuliqa mim maaa'in daafiq"
  },
  {
    "id": 7,
    "text": "Yakhruju mim bainissulbi wat taraaa'ib"
  },
  {
    "id": 8,
    "text": "Innahoo 'alaa raj'ihee laqaadir"
  },
  {
    "id": 9,
    "text": "Yawma tublas saraaa'ir"
  },
  {
    "id": 10,
    "text": "Famaa lahoo min quwwatinw wa laa naasir"
  },
  {
    "id": 11,
    "text": "Wassamaaa'i zaatir raj'"
  },
  {
    "id": 12,
    "text": "Wal ardi zaatis sad'"
  },
  {
    "id": 13,
    "text": "Innahoo laqawlun fasl"
  },
  {
    "id": 14,
    "text": "Wa maa huwa bil hazl"
  },
  {
    "id": 15,
    "text": "Innahum yakeedoona kaidaa"
  },
  {
    "id": 16,
    "text": "Wa akeedu kaidaa"
  },
  {
    "id": 17,
    "text": "Famahhilil kaafireena amhilhum ruwaidaa"
  }
];

export default en;
