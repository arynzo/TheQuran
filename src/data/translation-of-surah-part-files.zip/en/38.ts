import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Saaad; wal-Qur-aani ziz zikr"
  },
  {
    "id": 2,
    "text": "Balil lazeena kafaroo fee 'izzatinw wa shiqaaq"
  },
  {
    "id": 3,
    "text": "Kam ahlaknaa min qablihim min qarnin fanaadaw wa laata heena manaas"
  },
  {
    "id": 4,
    "text": "Wa 'ajibooo an jaaa'a hum munzirum minhum wa qaalal kaafiroona haazaa saahirun kazzaab"
  },
  {
    "id": 5,
    "text": "Aja'alal aalihata Ilaahanw Waahidan inna haazaa lashai'un 'ujaab"
  },
  {
    "id": 6,
    "text": "Wantalaqal mala-u minhum anim shoo wasbiroo 'alaaa aalihatikum innna haazaa lashai 'uny yuraad"
  },
  {
    "id": 7,
    "text": "Maa sami'naa bihaazaa fil millatil aakhirati in haazaaa illakh tilaaq"
  },
  {
    "id": 8,
    "text": "'A-unzila 'alaihiz zikru min baininaa; bal hum fee shakkin min Zikree bal lammaa yazooqoo 'azaab"
  },
  {
    "id": 9,
    "text": "Am'indahum khazaaa 'inu rahmati Rabbikal 'Azeezil Wahhab"
  },
  {
    "id": 10,
    "text": "Am lahum mulkus samaawaati wal ardi wa maa bainahumaa falyartaqoo fil asbaab"
  },
  {
    "id": 11,
    "text": "Jundum maa hunaalika mahzoomum minal Ahzaab"
  },
  {
    "id": 12,
    "text": "Kazzabat qablahum qawmu Noohinw wa 'Aadunw wa Fir'awnu zul awtaad"
  },
  {
    "id": 13,
    "text": "Wa Samoodu wa qawmu Lootinw wa Ashaabul 'Aykah; ulaaa'ikal Ahzaab"
  },
  {
    "id": 14,
    "text": "In kullun illaa kazzabar Rusula fahaqqa 'iqaab"
  },
  {
    "id": 15,
    "text": "Wa maa yanzuru haaa ulaaa'i illaa saihatanw waahidatam maa lahaa min fawaaq"
  },
  {
    "id": 16,
    "text": "Wa qaaloo Rabbanaa 'ajjil lanaa qittanaa qabla Yawmil Hisaab"
  },
  {
    "id": 17,
    "text": "Isbir 'alaa maa yaqooloona wazkur 'abdanaa Daawooda zal aidi innahooo awwaab"
  },
  {
    "id": 18,
    "text": "Innaa sakhkharnal jibaala ma'ahoo yusabbihna bil'ashiyyi wal ishraaq"
  },
  {
    "id": 19,
    "text": "Wattayra mahshoorah; kullul lahooo awwaab"
  },
  {
    "id": 20,
    "text": "Wa shadadnaa mulkahoo wa aatainaahul Hikmata wa faslal khitaab"
  },
  {
    "id": 21,
    "text": "Wa hal ataaka naba'ul khasm; iz tasawwarul mihraab"
  },
  {
    "id": 22,
    "text": "Iz dakhaloo 'alaa Daawooda fafazi'a minhum qaaloo laa takhaf khasmaani baghaa ba'dunaa 'alaa ba'din fahkum bainanaaa bilhaqqi wa laa tushtit wahdinaaa ilaa Sawaaa'is Siraat"
  },
  {
    "id": 23,
    "text": "Inna haazaaa akhee lahoo tis'unw wa tis'oona na'jatanw wa liya na'jatunw waahidah; faqaala akfilneeha wa 'azzanee filkhitaab"
  },
  {
    "id": 24,
    "text": "Qaala laqad zalamaka bisu 'aali na'jatika ilaa ni'aajih; wa inna kaseeran minal khulataaa'i la-yabghee ba'duhum 'alaa ba'din illal lazeena aamanoo wa 'amilus saalihaati wa qaleelun maa hum; wa zanna Daawoodu annamaa fatannaahu fastaghfara Rabbahoo wa kharra raaki'anw wa anaab"
  },
  {
    "id": 25,
    "text": "Faghafarnaa lahoo zaalik; wa inna lahoo 'indanaa lazulfaa wa husna ma aab"
  },
  {
    "id": 26,
    "text": "Yaa Daawoodu innaa ja'alnaaka khaleefatan fil ardi fahkum bainan naasi bilhaqqi wa laa tattabi'il hawaa fayudillaka 'an sabeelil laah; innal lazeena yadilloona 'an sabeelil laah; lahum 'azaabun shadeedum bimaa nasoo Yawmal Hisaab"
  },
  {
    "id": 27,
    "text": "Wa maa khalaqnas samaaa'a wal arda wa maa bainahumaa baatilaa; zaalika zannul lazeena kafaroo; fa waylul lil lazeena kafaroo minan Naar"
  },
  {
    "id": 28,
    "text": "Am naj'alul lazeena aamanoo wa 'amilus saalihaati kalmufisdeena fil ardi am naj'alul muttaqeena kalfujjaar"
  },
  {
    "id": 29,
    "text": "Kitaabun anzalnaahu ilaika mubaarakul liyaddabbarooo Aayaatihee wa liyatazakkara ulul albaab"
  },
  {
    "id": 30,
    "text": "Wa wahabnaa li Daawooda Sulaimaan; ni'mal 'abd; innahoo awwaab"
  },
  {
    "id": 31,
    "text": "Iz 'urida 'alaihi bil'ashiy yis saafinaatul jiyaad"
  },
  {
    "id": 32,
    "text": "Faqaala inneee ahbabtu hubbal khairi 'an zikri Rabbee hattaa tawaarat bilhijaab"
  },
  {
    "id": 33,
    "text": "Ruddoohaa 'alaiya fa tafiqa mas-ham bissooqi wal a'naaq"
  },
  {
    "id": 34,
    "text": "Wa laqad fatannaa Sulaimaana wa alqainaa 'alaa kursiyyihee jasadan summa anaab"
  },
  {
    "id": 35,
    "text": "Qaala Rabbigh fir lee wa hab lee mulkal laa yambaghee li ahadin min ba'dee innaka Antal Wahhaab"
  },
  {
    "id": 36,
    "text": "Fa sakharnaa lahur reeha tajree bi amrihee rukhaaa'an haisu asaab"
  },
  {
    "id": 37,
    "text": "Wash Shayaateena kulla bannaaa'inw wa ghawwaas"
  },
  {
    "id": 38,
    "text": "Wa aakhareena muqarraneena fil asfaad"
  },
  {
    "id": 39,
    "text": "Haazaa 'ataaa'unaa famnun aw amsik bighairi hisaab"
  },
  {
    "id": 40,
    "text": "Wa inna lahoo 'indanaa lazulfaa wa husna ma-aab"
  },
  {
    "id": 41,
    "text": "Wazkur 'abdanaaa Ayyoob; iz naada Rabbahooo annee massaniyash Shaitaanu bi nusbinw wa 'azaab"
  },
  {
    "id": 42,
    "text": "Urkud bi rijlika haaza mughtasalun baaridunw wa sharaab"
  },
  {
    "id": 43,
    "text": "Wa wahabnaa lahoo ahlahoo wa mislahum ma'ahum rahmatan minna wa zikraa li ulil albaab"
  },
  {
    "id": 44,
    "text": "Wa khuz biyadika dighsan fadrib bihee wa laa tahnas, innaa wajadnaahu saabiraa; ni'mal 'abd; innahooo awwaab"
  },
  {
    "id": 45,
    "text": "Wazkur 'ibaadanaaa Ibraaheema wa Is-haaqa wa Ya'qooba ulil-aydee walabsaar"
  },
  {
    "id": 46,
    "text": "Innaaa akhlasnaahum bi khaalisatin zikrad daar"
  },
  {
    "id": 47,
    "text": "Wa innahum 'indanaa laminal mustafainal akhyaar"
  },
  {
    "id": 48,
    "text": "Wazkur Ismaa'eela wal Yasa'a wa Zal-Kifli wa kullun minal akhyaar"
  },
  {
    "id": 49,
    "text": "Haazaa zikrun wa inna lil muttaqeena la husna ma aab"
  },
  {
    "id": 50,
    "text": "Jannaati 'adnin mufattahatan lahumul abwaab"
  },
  {
    "id": 51,
    "text": "Muttaki'eena feehaa yad'oona feehaa bifaakihatin kaseeratinw wa sharaab"
  },
  {
    "id": 52,
    "text": "Wa 'indahum qaasiraatut tarfi atraab"
  },
  {
    "id": 53,
    "text": "Haazaa maa too'adoona li Yawmil Hisaab"
  },
  {
    "id": 54,
    "text": "Inna haazaa larizqunaa maa lahoo min nafaad"
  },
  {
    "id": 55,
    "text": "Haazaa; wa inna littaagheena lasharra ma-aab"
  },
  {
    "id": 56,
    "text": "Jahannama yaslawnahaa fa bi'sal mihaad"
  },
  {
    "id": 57,
    "text": "Haazaa falyazooqoohu hameemunw wa ghassaaq"
  },
  {
    "id": 58,
    "text": "Wa aakharu min shakliheee azwaaj"
  },
  {
    "id": 59,
    "text": "Haazaa fawjun muqtahimun ma'akum laa marhaban bihim; innahum saalun Naar"
  },
  {
    "id": 60,
    "text": "Qaaloo bal antum laa marhaban bikum; antum qaddamtumoohu lanaa fabi'sal qaraar"
  },
  {
    "id": 61,
    "text": "Qaaloo Rabbanaa man qaddama lanaa haazaa fa zidhu 'azaaban di'fan fin Naar"
  },
  {
    "id": 62,
    "text": "Wa qaaloo maa lanaa laa naraa rijaalan kunnaa na'udduhum minal ashraar"
  },
  {
    "id": 63,
    "text": "Attakhaznaahum sikh riyyan am zaaghat 'anhumul absaar"
  },
  {
    "id": 64,
    "text": "Inna zaalika lahaqqun takhaasumu Ahlin Naar"
  },
  {
    "id": 65,
    "text": "Qul innamaaa ana munzirunw wa maa min laahin illal laahul Waahidul Qahhaar"
  },
  {
    "id": 66,
    "text": "Rabbus samaawaati wal ardi wa maa bainahumal 'Azeezul Ghaffaar"
  },
  {
    "id": 67,
    "text": "Qul huwa naba'un 'azeem"
  },
  {
    "id": 68,
    "text": "Antum 'anhu mu'ridoon"
  },
  {
    "id": 69,
    "text": "Maa kaana liya min 'ilmin bil mala'il a'laaa iz yakhtasimoon"
  },
  {
    "id": 70,
    "text": "Iny-yoohaaa ilaiya illaaa anna maaa ana nazeerun mubeen"
  },
  {
    "id": 71,
    "text": "Iz qaala Rabbuka lilmalaaa'ikati innee khaaliqun basharan min teen"
  },
  {
    "id": 72,
    "text": "Fa-iza sawwaituhoo wa nafakhtu feehi mir roohee faqa'oo lahoo saajideen"
  },
  {
    "id": 73,
    "text": "Fasajadal malaaa'ikatu kulluhum ajma'oon"
  },
  {
    "id": 74,
    "text": "Illaaa Iblees; stakbara wa kaana minal kaafireen"
  },
  {
    "id": 75,
    "text": "Qaala yaaa Ibleesu maa mana'aka an tasjuda limaa khalaqtu bi yadaiya 'a stakbarta am kunta min al 'aaleen"
  },
  {
    "id": 76,
    "text": "Qaala ana khairum minhu; khalaqtanee min naarinw wa khalaqtahoo min teen"
  },
  {
    "id": 77,
    "text": "Qaala fakhruj minhaa fa innaka rajeem"
  },
  {
    "id": 78,
    "text": "Wa inna 'alaika la'nateee ilaa Yawmid Deen"
  },
  {
    "id": 79,
    "text": "Qaala Rabbi fa anzirneee ilaa Yawmi yub'asoon"
  },
  {
    "id": 80,
    "text": "Qaala fa innaka minal munzareen"
  },
  {
    "id": 81,
    "text": "Ilaa Yawmil waqtil ma'loom"
  },
  {
    "id": 82,
    "text": "Qaala fa bi 'izzatika la ughwiyannahum ajma'een"
  },
  {
    "id": 83,
    "text": "Illaa 'ibaadaka minhumul mukhlaseen"
  },
  {
    "id": 84,
    "text": "Qaala falhaqq, walhaqqa aqool"
  },
  {
    "id": 85,
    "text": "La amla'anna Jahannama minka wa mimman tabi'aka minhum ajma'een"
  },
  {
    "id": 86,
    "text": "Qul maaa as'alukum 'alaihi min ajrinw wa maaa ana minal mutakallifeen"
  },
  {
    "id": 87,
    "text": "In huwa illaa zikrul lil'aalameen"
  },
  {
    "id": 88,
    "text": "Wa lata'lamunna naba ahoo ba'da heen"
  }
];

export default en;
