import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yas'aloonaka 'anil anfaali qulil anfaalu lillaahi war Rasooli fattaqul laaha wa aslihoo zaata bainikum wa atee'ul laaha wa Rasoolahooo in kuntum mu'mineen"
  },
  {
    "id": 2,
    "text": "Innamal mu'minoonal lazeena izaa zukiral laahu wajilat quloobuhum wa izaa tuliyat 'alaihim Aayaatuhoo zaadat hum eemaananw wa 'alaa Rabbihim yatawakkaloon"
  },
  {
    "id": 3,
    "text": "Allazeena yuqeemoonas Salaata wa mimmaa razaqnaahum yunfiqoon"
  },
  {
    "id": 4,
    "text": "Ulaaa'ika humul mu'minoona haqqaa; lahum darajaatun 'inda Rabbihim wa magh firatunw wa rizqun kareem"
  },
  {
    "id": 5,
    "text": "Kaamaaa akhrajaka Rabbuka mim baitika bilhaqq; wa inna fareeqam minal mu'mineena lakaarihoon"
  },
  {
    "id": 6,
    "text": "Yujaadiloonaka fil haqqi ba'da maa tabaiyana ka'annamaa yasaaqoona ilal mawti wa hum yanzuroon"
  },
  {
    "id": 7,
    "text": "Wa iz ya'idukumul laahu ihdat taaa'ifataini annahaa lakum wa tawaddoona anna ghaira zaatish shawkati takoonu lakum wa yureedul laahu ai yuhiqqal haqqa bikalimaatihee wa yaqta'a daabiral kaafireen"
  },
  {
    "id": 8,
    "text": "Liyuhiqqal haqqa wa yubtilal baatila wa law karihal mujrimoon"
  },
  {
    "id": 9,
    "text": "Iz tastagheesoona Rabbakum fastajaaba lakum annee mumiddukum bi alfim minal malaaa'ikati murdifeen"
  },
  {
    "id": 10,
    "text": "Wa maa ja'alahul laahu illaa bushraa wa litatma'inna bihee quloobukum; wa man nasru illaa min 'indil laah; innal laaha Azeezun Hakeem"
  },
  {
    "id": 11,
    "text": "Iz yughashsheekumun nu'assa amanatam minhu wa yunazzilu 'alaikum minas samaaa'i maaa'al liyutah hirakum bihee wa yuzhiba 'ankum rijzash Shaitaani wa liyarbita 'ala quloobikum wa yusabbita bihil aqdaam"
  },
  {
    "id": 12,
    "text": "Iz yoohee Rabbuka ilal malaaa'ikati annee ma'akum fasabbitul lazeena aamanoo; sa ulqee fee quloobil lazeena kafarur ru'ba fadriboo fawqal a'naaqi wadriboo minhum kulla banaan"
  },
  {
    "id": 13,
    "text": "Zaalika bi annahum shaaaqqul laaha wa Rasoolah; wa mai yushaqiqil laaha wa Rasoolahoo fa innal laaha shadeedul 'iqaab"
  },
  {
    "id": 14,
    "text": "Zaalikum fazooqoohu wa anna lilkaafireena 'azaaban Naar"
  },
  {
    "id": 15,
    "text": "Yaaa aiyuhal lazeena aamanoo izaa laqeetumul lazeena kafaroo zahfan falaa tuwalloohumul adbaar"
  },
  {
    "id": 16,
    "text": "Wa mai yuwallihim yawma'izin duburahooo illaa mutaharrifal liqitaalin aw mutahaiyizan ilaa fi'atin faqad baaa'a bighadabim minal laahi wa ma'waahu Jahannamu wa bi'sal maseer"
  },
  {
    "id": 17,
    "text": "Falam taqtuloohum wa laakinnal laaha qatalahum; wa maa ramaita iz ramaita wa laakinnal laaha ramaa; wa liyubliyal mu'mineena minhu balaaa'an hasanaa; innal laaha Samee'un Aleem"
  },
  {
    "id": 18,
    "text": "Zaalikum wa annal laaha moohinu kaidil kaafireen"
  },
  {
    "id": 19,
    "text": "In tastaftihoo faqad jaaa'akumul fathu wa in tantahoo fahuwa khairul lakum wa in ta'oodoo na'ud wa lan tughniya 'ankum fi'atukum shai'anw wa law kasurat wa annal laaha ma'al mu'mineen"
  },
  {
    "id": 20,
    "text": "Yaaa aiyuhal lazeena aamanoo atee'ul laaha wa Rasoolahoo wa laa tawallaw 'anhu wa antum tasma'oon"
  },
  {
    "id": 21,
    "text": "Wa laa takoonoo kallazeena qaaloo sami'naa wa hum laa yasma'oon"
  },
  {
    "id": 22,
    "text": "Inna sharrad dawaaabbi 'indal laahis summul bukmul lazeena laa ya'qiloon"
  },
  {
    "id": 23,
    "text": "Wa law 'alimal laahu feehim khairal la asma'ahum; wa law asma'ahum latawallaw wa hum mu'ridoon"
  },
  {
    "id": 24,
    "text": "Yaaa aiyuhal lazeena aamanus tajeeboo lillaahi wa lir Rasooli izaa da'aakum limaa yuhyeekum wa'lamooo annal laaha yahoolu bainal mar'i wa qalbihee wa anahooo ilaihi tuhsharoon"
  },
  {
    "id": 25,
    "text": "Wattaqoo fitnatal laa tuseebannal lazeena zalamoo minkum khaaaassatanw wa'lamooo annal laaha shadeedul 'iqaab"
  },
  {
    "id": 26,
    "text": "Wazkurooo iz antum qaleelum mustad 'afoona filardi takhaafoona ai yatakhat tafakumun naasu fa aawaakum wa aiyadakum binasrihee wa razaqakum minat taiyibaati la'allakum tashkuroon"
  },
  {
    "id": 27,
    "text": "Yaaa aiyuhal lazeena aamanoo laa takhoonal laaha war Rasoola wa takhoonooo amaanaatikum wa antum ta'lamoon"
  },
  {
    "id": 28,
    "text": "Wa'lamooo annamaaa amwaalukum wa awlaadukum fitnatunw wa annal laaha 'indahooo ajrun azeem"
  },
  {
    "id": 29,
    "text": "Yaaa aiyuhal lazeena aamanooo in tattaqul laaha yaj'al lakum furqaananw wa yukaffir 'ankum saiyi aatikum wa yaghfir lakum; wallaahu zul fadlil 'azeem"
  },
  {
    "id": 30,
    "text": "Wa iz yamkuru bikal lazeena kafaroo liyusbitooka aw yaqtulooka aw yukhrijook; wa yamkuroona wa yamkurul laahu wallaahu khairul maakireen"
  },
  {
    "id": 31,
    "text": "Wa izaa tutlaa 'alaihim Aayaatunaa qaaloo qad sami'naa law nashaaa'u laqulnaa misla haazaaa in haazaaa illaaa asaateerul awwaleen"
  },
  {
    "id": 32,
    "text": "Wa iz qaalul laahumma in kaana haazaa huwal haqqa min 'indika fa amtir 'alainaa hijaaratam minas samaaa'i awi'tinaa bi 'azaabin aleem"
  },
  {
    "id": 33,
    "text": "Wa maa kaanal laahu liyu'az zibahum wa anta feehim; wa maa kaanal laahu mu'az zibahum wa hum yastaghfiroon"
  },
  {
    "id": 34,
    "text": "Wa maa lahum allaa yu'az zibahumul laahu wa hum yasuddoona 'anil Masjidil-Haraami wa maa kaanooo awliyaaa'ah; in awliyaaa' uhooo illal muttaqoona wa laakinna aksarahum laa ya'lamoon"
  },
  {
    "id": 35,
    "text": "Wa maa kaana Salaatuhum 'indal Baiti illa mukaaa anw-wa tasdiyah; fazooqul 'azaaba bimaa kuntum takfuroon"
  },
  {
    "id": 36,
    "text": "Innal lazeena kafaroo yunfiqoona amwaalahum liyasuddoo 'an sabeelil laah; fasayunfiqoonahaa summa takoonu 'alaihim hasratan summa yughlaboon; wal lazeena kafarooo ilaa Jahannnama yuhsharoona"
  },
  {
    "id": 37,
    "text": "Liyameezal laahul khabeesa minat taiyibi wa yaj'alal khabeesa ba'dahoo 'ala ba'din fayarkumahoo jamee'an fayaj'alahoo fee Jahannnam; ulaaa'ika humul khaasiroon"
  },
  {
    "id": 38,
    "text": "Qul lillazeena kafarooo iny yantahoo yughfar lahum maa qad salafa wa iny ya'oodoo faqad madat sunnatul awwaleen"
  },
  {
    "id": 39,
    "text": "Wa qaatiloohum hattaa laa takoona fitnatunw wa yakoonaddeenu kulluhoo lillaah; fainin tahaw fa innallaaha bimaa ya'maloona Baseer"
  },
  {
    "id": 40,
    "text": "Wa in tawallaw fa'lamooo annal laaha mawlaakum; ni'mal mawlaa wa ni'man naseer"
  },
  {
    "id": 41,
    "text": "Wa'lamooo annamaa ghanimtum min sha'in fa anna lillaahi khumusahoo wa lir Rasooli wa lizil qurba walyataamaa walmasaakeeni wabnis sabeeli in kuntum aamantum billaahi wa maaa anzalnaa 'ala 'abdinaa yawmal Furqaani yawmaltaqal jam'aan; wal laahu 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 42,
    "text": "Iz antum bil'udwatid dunyaa wa hum bil'udwatil quswaa warrakbu asfala minkum; wa law tawaa'attum lakhtalaftum fil mee'aadi wa laakil liyaqdiyal laahu amran kaana maf'oolal liyahlika man halaka 'am baiyinatinw wa yahyaa man haiya 'am baiyinah; wa innal laaha la Samee'un 'Aleem"
  },
  {
    "id": 43,
    "text": "Iz yureekahumul laahu fee manaamika qaleela; wa law araakahum kaseeral lafashiltum wa latanaaza'tum fil amri wa laakinnal laaha sallam; innahoo 'aleemum bizaatis sudoor"
  },
  {
    "id": 44,
    "text": "Wa iz yureekumoohum izil taqaitum feee a'yunikum qaleelanw wa yuqallilukum feee a'yunihim liyaqdiyal laahu amran kaana maf'oolaa; wa ilal laahi turja'ul umoor"
  },
  {
    "id": 45,
    "text": "Yaaa aiyuhal lazeena aamanooo izaa laqeetum fi'atan fasbutoo wazkurul laaha kaseeral la'allakum tuflihoon"
  },
  {
    "id": 46,
    "text": "Wa atee'ul laaha wa Rasoolahoo wa laa tanaaza'oo fatafshaloo wa tazhaba reehukum wasbiroo; innal laaha ma'as saabireen"
  },
  {
    "id": 47,
    "text": "Wa laa takoonoo kallazeena kharajoo min diyaarihim bataranw wa ri'aaa'an naasi wa yasuddoona 'an sabeelil laah; wallaahu bimaa ya'maloona muheet"
  },
  {
    "id": 48,
    "text": "Wa iz zaiyana lahumush shaitaanu a'maalahum wa qaala laa ghaaliba lakumul yawma minan naasi wa innee jaarul lakum falammaa taraaa'atil fi'ataani nakasa 'alaa aqibaihi wa qaala innee bareee'um minkum innee araa maa laa tarawna inneee akhaaful laah; wallaahu shadeedul 'iqaab"
  },
  {
    "id": 49,
    "text": "Iz yaqoolul munaafiqoona wallazeena fee quloobihim maradun gharra haaa'ulaaa'i deenuhum; wa mai yatawakkal 'alal laahi fa innal laaha 'azee zun Hakeem"
  },
  {
    "id": 50,
    "text": "Wa law taraaa iz yatawaf fal lazeena kafarul malaaa'ikatu yadriboona wujoohahum wa adbaarahum wa zooqoo 'azaabal hareeq"
  },
  {
    "id": 51,
    "text": "Zaalika bimaa qaddamat aideekum wa anal laaha laisa bizallaamil lil 'abeed"
  },
  {
    "id": 52,
    "text": "Kadaabi Aali Fir'awna wal lazeena min qablihim; kafaroo bi Aayaatil laahi fa akhazahu mul laahu bizunoobihim; innal laaha qawiyyun shadeedul 'iqaab"
  },
  {
    "id": 53,
    "text": "Zaalika bi annal laaha lam yakumu ghaiyiran ni'matan an'amahaa 'alaa qawmin hattaa yughaiyiroo maa bianfusihim wa annallaaha samee'un 'Aleem"
  },
  {
    "id": 54,
    "text": "Kadaabi Aali Fir'awna wallazeena min qablihim; kazzaboo bi Aayaati Rabbihim faahlaknaahum bizunoobihim wa aghraqnaa Aala Fir'awn; wa kullun kaanoo zaalimeen"
  },
  {
    "id": 55,
    "text": "Inna sharrad dawaaabbi 'indal laahil lazeena kafaroo fahum laa yu'minoon"
  },
  {
    "id": 56,
    "text": "Allazeena'aahatta min hum summa yanqudoona 'ahdahum fee kulli marratinw wa hum laa yattaqoon"
  },
  {
    "id": 57,
    "text": "Fa immaa tasqafannahum fil harbi fasharrid bihim man khalfahum la'allahum yazzakkaroon"
  },
  {
    "id": 58,
    "text": "Wa immaa takhaafana min qawmin khiyaanatan fambiz ilaihim 'alaa sawaaa'; innal laaha laayuhibbul khaaa'ineen"
  },
  {
    "id": 59,
    "text": "Wa laa yahsabannal lazeena kafaroo sabaqooo; innahum laa yu'jizoon"
  },
  {
    "id": 60,
    "text": "Wa a'iddoo lahum mastata'tum min quwwatinw wa mirribaatil khaili turhiboona bihee 'aduwwal laahi wa 'aduwwakum wa aakhareena min doonihim laa ta'lamoo nahum Allaahu ya'lamuhum; wa maa tunfiqoo min shai'in fee sabeelil laahi yuwaffa ilaikum wa antum laa tuzlamoon"
  },
  {
    "id": 61,
    "text": "Wa in janahoo lissalmi fajnah lahaa wa tawakkal 'alal laah; innahoo Huwas Samee'ul 'Aleem"
  },
  {
    "id": 62,
    "text": "Wa iny yureedooo any-yakhda'ooka fainna hasbakal laah; Huwal lazeee aiyadaka binasrihee wa bilmu'mineen"
  },
  {
    "id": 63,
    "text": "Wa allafa baina quloobihim; law anfaqta maa fil ardi jamee'am maaa allafta baina quloobihim wa laakinnallaaha allafa bainahum; innaahoo 'Azeezun Hakeem"
  },
  {
    "id": 64,
    "text": "Yaaa aiyuhan Nabiyyu hasbukal laahu wa manittaba 'aka minal mu'mineen"
  },
  {
    "id": 65,
    "text": "Yaaa aiyuhan Nabiyyu harridil mu'mineena 'alal qitaal; iny-yakum minkum 'ishroona saabiroona yaghliboo mi'atayn; wa iny-yakum minkum mi'atuny yaghlibooo alfam minal lazeena kafaroo bi anahum qawmul laa yafqahoon"
  },
  {
    "id": 66,
    "text": "Al'aana khaffafal laahu 'ankum wa 'alima anna feekum da'faa; fa-iny yakum minkum mi'atun saabiratuny yaghliboo mi'atayn; wa iny-yakum minkum alfuny yaghlibooo alfaini bi iznil laah; wallaahu ma'as saabireen"
  },
  {
    "id": 67,
    "text": "Maa kaana li Nabiyyin ai yakoona lahooo asraa hatta yuskhina fil ard; tureedoona aradad dunyaa wallaahu yureedul Aakhirah; wallaahu 'Azeezun Hakeem"
  },
  {
    "id": 68,
    "text": "Law laa Kitaabum minal laahi sabaqa lamassakum fee maaa akhaztum 'azaabun 'azeem"
  },
  {
    "id": 69,
    "text": "Fakuloo mimmaa ghanimtum halaalan taiyibaa; watta qullaah; innal laaha Ghafoorur Raheem"
  },
  {
    "id": 70,
    "text": "Yaaa aiyuhan Nabiyyu qul liman feee aideekum minal asraaa iny-ya'lamillahu fee quloobikum khairany yu'tikum khayram mimmaaa ukhiza minkum wa yaghfir lakum; wallaahu Ghafoorur Raheem"
  },
  {
    "id": 71,
    "text": "Wa iny-yureedoo khiyaa nataka faqad khaanullaaha min qablu fa amkana minhum; wallaahu 'Aleemun Hakeem"
  },
  {
    "id": 72,
    "text": "Innal lazeena aamanoo wa haajaroo wa jaahadoo bi amwaalihim wa anfusihim fee sabeelil laahi wallazeena aawaw wa nasarooo ulaaa'ika ba'duhum awliyaaa'u ba'd; wallazeena aamanoo wa lam yuhaajiroo maa lakum minw walaayatihim min shai'in hatta yuhaajiroo; wa inistan sarookum fid deeni fa'alaiku munnasru illaa 'alaa qawmin bainakum wa bainahum meesaaq; wallaahu bimaa ta'maloona Baseer"
  },
  {
    "id": 73,
    "text": "Wallazeena kafaroo ba'duhum awliyaaa'u ba'd; illaa taf'aloohu takun fitnatun fil ardi wa fasaadun kabeer"
  },
  {
    "id": 74,
    "text": "Wallazeena aamanoo wa haajaroo wa jaahadoo fee sabeelil laahi wallazeena aawaw wa nasarooo ulaaa'ika humul mu'minoona haqqaa; lahum maghfiratunw wa rizqun kareem"
  },
  {
    "id": 75,
    "text": "Wallazeena aamanoo min ba'du wa haajaroo wa jaahadoo ma'akum fa Ulaaa'ika minkum; wa ulul arhaami baduhum awlaa biba'din fee Kitaabil laah; innal laaha bikulli shai'in 'Aleem"
  }
];

export default en;
