import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Raa; Kitaabun uhkimat Aayaatuhoo summa fussilat mil ladun Hakeemin Khabeer"
  },
  {
    "id": 2,
    "text": "Allaa ta'budooo illal laah; innanee lakum minhu nazeerunw wa basheer"
  },
  {
    "id": 3,
    "text": "Wa anis taghfiroo Rabbakum summa toobooo ilaihi yumatti'kum mataa'an hasanan ilaaa ajalim musammanw wa yu'ti kulla zee fadlin fadlahoo wa in tawallaw fa inneee akhaafu 'alaikum 'azaaba Yawmin Kabeer"
  },
  {
    "id": 4,
    "text": "Ilal laahi marji'ukum wa Huwa 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 5,
    "text": "Alaa innahum yasnoona sudoorahum liyastakhfoo minh; alaa heena yastaghshoona siyaabahum ya'lamu maa yusirroona wa maa yu'linoon; innahoo 'aleemun bizaatis sudoor"
  },
  {
    "id": 6,
    "text": "Wa maa min daaabbatin fil ardi illaa 'alal laahi rizquhaa wa ya'lamu mustaqarrahaa wa mustawda'ahaa; kullun fee Kitaabim Mubeen"
  },
  {
    "id": 7,
    "text": "Wa Huwal lazee khalaqas samaawaati wal arda fee sittati aiyaaminw wa kaana 'Arshuhoo alal maaa'i liyabluwakum aiyukum ahsanu 'amalaa; wa la'in qulta innakum mab'oosoona min ba'dil mawti la yaqoolannal lazeena kafaroo in haazaaa illaa sihrum mubeen"
  },
  {
    "id": 8,
    "text": "Wala'in akharnaa 'anhumul 'azaaba ilaaa ummatim ma'doodatil la yaqoolunna maa yahbisuh; alaa yawma ya'teehim laisa masroofan 'anhum wa haaqa bihim maa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 9,
    "text": "Wa la'in azaqnal insaana minnaa rahmatan summa naza'naahaa minhu, innahoo laya'oosun kafoor"
  },
  {
    "id": 10,
    "text": "Wala'in azaqnaahu na'maaa'a ba'da darraaa'a massat hu la yaqoolanna zahabas saiyiaatu 'anneee; innahoo lafarihun fakhoor"
  },
  {
    "id": 11,
    "text": "Illal lazeena sabaroo wa 'amilus saalihaati ulaaa'ika lahum maghfiratunw wa ajrun kabeer"
  },
  {
    "id": 12,
    "text": "Fala'allaka taarikum ba'da maa yoohaaa ilaika wa daaa'iqum bihee sadruka ai yaqooloo law laaa unzila 'alaihi kanzun aw jaaa'a ma'ahoo malak; innamaa anta nazeer; wallaahu 'alaa kulli shai'inw wakeel"
  },
  {
    "id": 13,
    "text": "Am yaqooloonaf taraahu qul faatoo bi'ashri Suwarim mislihee muftarayaatinw wad'oo manis tata'tum min doonil laahi in kuntum saadiqeen"
  },
  {
    "id": 14,
    "text": "Fa il lam yastajeeboo lakum fa'lamooo annamaaa unzilla bi'ilmil laahi wa al laaa ilaaha illaa Huwa fahal antum muslimoon"
  },
  {
    "id": 15,
    "text": "Man kaana yureedul hayaatad dunyaa wa zeenatahaa nuwaffi ilaihim a'maa lahum feehaa wa hum feehaa laa yubkhasoon"
  },
  {
    "id": 16,
    "text": "Ulaaa'ikal lazeena laisa lahum fil Aakhirati illan Naaru wa habita maa sana'oo feehaa wa baatilum maa kaanoo ya'maloon"
  },
  {
    "id": 17,
    "text": "Afaman kaana 'ala baiyinatim mir Rabbihee wa yatloohu shaahidum minhu wa min qablihee Kitaabu Moosaaa imaamanw wa rahmah; ulaaa 'ika yu'minoona bih; wa mai yakfur bihee minal Ahzaabi fan Naaru maw'iduh; falaa taku fee miryatim minh; innahul haqqu mir Rabbika wa laakinna aksaran naasi laa yu'minoon"
  },
  {
    "id": 18,
    "text": "Wa man azlamu mimmanif taraa 'alal laahi kazibaa; ulaaa'ika yu'radoona 'alaa Rabbihim wa yaqoolul ashhaa duhaaa'ulaaa'il lazeena kazaboo 'alaa Rabbihim; alaa la'natul laahi alaz zaalimeen"
  },
  {
    "id": 19,
    "text": "Allazeena yasuddoona 'an sabeelil laahi wa yabghoonahaa 'iwajanw wa hum bil Aakhiratihum kaafiroon"
  },
  {
    "id": 20,
    "text": "Ulaaa'ika lam yakoonoo mu'jizeena fil ardi wa maa kaana lahum min doonil laahi min awliyaaa'; yudaa'afu lahumul 'azaab; maa kaanoo yastatee'oonas sam'a wa maa kaanoo yubsiroon"
  },
  {
    "id": 21,
    "text": "Ulaaa'ikal lazeena khasirooo anfusahum wa dalla 'anhum maa kaanoo yaftaroon"
  },
  {
    "id": 22,
    "text": "Laa jarama annahum fil Aakhirati humul akhsaroon"
  },
  {
    "id": 23,
    "text": "Innal lazeena aamanoo wa 'amilus saalihaati wa akhbatooo ilaa Rabbihim ulaaa'ika Ashaabul Jannati hum feehaa khaalidoon"
  },
  {
    "id": 24,
    "text": "Masalul fareeqaini kal a'maa wal asammi walbaseeri wassamee'; hal yastawiyaani masalaa; afalaa tazakkaroon"
  },
  {
    "id": 25,
    "text": "Wa laqad arsalnaa Noohan ilaa qawmihee innee lakum nazeerum mubeen"
  },
  {
    "id": 26,
    "text": "Al laa ta'budooo illal laaha inneee akhaafu 'alaikum 'azaaba Yawmin aleem"
  },
  {
    "id": 27,
    "text": "Faqaalal mala ul lazeena kafaroo min qawmihee ma naraaka illaa basharam mislanaa wa maa naraakat taba'aka illal lazeena hum araazilunaa baadiyar raayi wa maa naraa lakum 'alainaa min fadlim bal nazunnukum kaazibeen"
  },
  {
    "id": 28,
    "text": "Qaala yaa qawmi ara'aitum in kuntu 'alaa baiyinatim mir Rabbee wa aataanee rahmatam min 'indihee fa'um miyat 'alaikum anulzimuku moohaa wa antum lahaa kaarihoon"
  },
  {
    "id": 29,
    "text": "Wa yaa qawmi laaa as'alukum 'alaihi maalan in ajriya illaa 'alal laah; wa maaa ana bitaaridil lazeena aamanoo; innahum mulaaqoo Rabbihim wa laakinneee araakum qawman tajhaloon"
  },
  {
    "id": 30,
    "text": "Wa yaa qawmi mai yansurunee minal laahi in tarattuhum; afalaa tazak karoon"
  },
  {
    "id": 31,
    "text": "Wa laa aqoolu lakum 'indee khazaa'inul laahi wa laaa a'lamul ghaiba wa laa aqoolu innee malakunw wa laaa aqoolu lillazeena tazdareee a'yunukum lai yu'tiyahumul laahu khairan Allaahu a'lamu bimaa feee anfusihim innee izal laminaz zaalimeen"
  },
  {
    "id": 32,
    "text": "Qaaloo yaa Noohu qad jaadaltanaa fa aksarta jidaalanaa faatinaa bimaa ta'idunaaa in kunta minas saadiqeen"
  },
  {
    "id": 33,
    "text": "Qaala innamaa yaateekum bihil laahu in shaaa'a wa maaa antum bimu'jizeen"
  },
  {
    "id": 34,
    "text": "Wa laa yanfa'ukum nusheee in arattu an ansaha lakum in kaanal laahu yureedu ai yughwi yakum; Huwa Rabbukum wa ilaihi turja'oon"
  },
  {
    "id": 35,
    "text": "Am yaqooloonaf taraahu qul inif taraituhoo fa'alaiya ijraamee wa ana bareee'um mimmaa tujrimoon"
  },
  {
    "id": 36,
    "text": "Wa oohiya ilaa Noohin annahoo lany-yu'mina min qawmika illaa man qad aamana falaa tabta'is bimaa kaanoo yaf'aloon"
  },
  {
    "id": 37,
    "text": "Wasna'il fulka bi-a'yuninaa wa wahyinaa wa laa tukhaa tibnee fil lazeena zalamoo; innahum mughraqoon"
  },
  {
    "id": 38,
    "text": "Wa yasna'ul fulka wa kullamaa marra 'alaihi mala'um min qawmihee sakhiroo minh; qaala in taskharoo minnaa fa innaa naskharu minkum kamaa taskharoon"
  },
  {
    "id": 39,
    "text": "Fasawfa ta'lamoona mai ya'teehi 'azaabuny yukhzeehi wa yahillu 'alaihi 'azaabun muqeem"
  },
  {
    "id": 40,
    "text": "Hattaaa izaa jaaa'a amrunaa wa faarat tannooru qulnah mil feehaa min kullin zawjainis naini wa ahlaka illaa man sabaqa 'alaihil qawlu wa man aaman; wa maaa aamana ma'ahooo illaa qaleel"
  },
  {
    "id": 41,
    "text": "Wa qaalar kaboo feehaa bismil laahi majraihaa wa mursaahaa; inna Rabbee la Ghafoorur Raheem"
  },
  {
    "id": 42,
    "text": "Wa hiya tajree bihim fee mawjin kaljibaali wa naadaa Noohunib nahoo wa kaana fee ma'ziliny yaa bunai yarkam ma'anaa wa laa takum ma'al kaafireen"
  },
  {
    "id": 43,
    "text": "Qaala sa aaweee ilaa jabaliny ya'simunee minal maaa'; qaala laa 'aasimal yawma min amril laahi illaa mar rahim; wa haala bainahumal mawju fakaana minal mughraqeen"
  },
  {
    "id": 44,
    "text": "Wa qeela yaaa ardubla'ee maaa'aki wa yaa samaaa'u aqli'ee wa gheedal maaa'u wa qudiyal amru wastawat 'alal joodiyyi wa qeela bu'dal lilqawmiz zaalimeen"
  },
  {
    "id": 45,
    "text": "Wa naadaa noohur Rabbahoo faqaala Rabbi innabnee min ahlee wa inna wa'dakal haqqu wa Anta ahkamul haakimeen"
  },
  {
    "id": 46,
    "text": "Qaala yaa Noohu innahoo laisa min ahlika innahoo 'amalun ghairu saalihin falaa tas'alni maa laisa laka bihee 'ilmun inneee a'izuka an takoona minal jaahileen"
  },
  {
    "id": 47,
    "text": "Qaala rabbi inneee a'oozu bika an as'alaka maa laisa lee bihee 'ilmunw wa illaa taghfir lee wa tarhamneee akum minal khaasireen"
  },
  {
    "id": 48,
    "text": "Qeela yaa Noohuh bit bisalaamim minnaa wa barakaatin 'alaika wa 'alaaa umamim mimmam ma'ak; wa umamun sanumatti'uhum summa yamassuhum minna 'azaabun aleem"
  },
  {
    "id": 49,
    "text": "Tilka min ambaaa'il ghaibi nooheehaaa ilaika maa kunta ta'lamuhaaaa anta wa laa qawmuka min qabli haazaa fasbir innal 'aaqibata lilmuttaqeen"
  },
  {
    "id": 50,
    "text": "Wa ilaa 'aadin akhaahum Hoodaa; qaala yaa qawmi' budul laaha maa lakum min ilaahin ghairuhooo in antum illaa muftaroon"
  },
  {
    "id": 51,
    "text": "Yaa qawmi laaa as'alukum 'alaihi ajran in ajriya illaa 'alal lazee fataranee; afalaa ta'qiloon"
  },
  {
    "id": 52,
    "text": "Wa yaa qawmis taghfiroo Rabbakum summa toobooo ilaihi yursilis samaaa'a 'alaikum midraaranw wa yazidkum quwwatan ilaa quwwatikum wa laa tatawallaw mujrimeen"
  },
  {
    "id": 53,
    "text": "Qaaloo yaa Hoodu maa ji'tanaa bibaiyinatinw wa maa nahnu bitaarikeee aalihatinaa 'an qawlika wa maa nahnu laka bimu'mineen"
  },
  {
    "id": 54,
    "text": "In naqoolu illa' taraaka ba'du aalihatinaa bisooo'; qaala inneee ushhidul laaha wash hadooo annee bareee'um mimmaa tushrikoon"
  },
  {
    "id": 55,
    "text": "Min doonihee fakeedoonee jamee'an summa laa tunziroon"
  },
  {
    "id": 56,
    "text": "Innee tawakkaltu 'alallaahi Rabbee wa Rabbikum; maa min daaabbatin illaa Huwa aakhizum binaasiyatihaa; inna Rabbee 'alaa Siraatim mustaqeem"
  },
  {
    "id": 57,
    "text": "Fa in tawallaw faqad ablaghtukum maaa ursiltu biheee ilaikum; wa yastakhlifu Rabbee qawman ghairakum wa laa tadur roonahoo shai'aa; inna Rabbee 'alaa kulli shai'in Hafeez"
  },
  {
    "id": 58,
    "text": "Wa lammaa jaaa'a amrunaa najainaa Hoodanw wallazeena aamanoo ma'ahoo birahmatim minnaa wa najainaahum min 'azaabin ghaleez"
  },
  {
    "id": 59,
    "text": "Wa tilka 'aad, jahadoo bi Aayaati Rabbihim wa 'asaw Rusulahoo wattaba'ooo amra kulli jabbaarin 'aneed"
  },
  {
    "id": 60,
    "text": "Wa utbi'oo fee haazihid dunyaa la'natanw wa Yawmal Qiyaamah; alaaa inna 'Aadan kafaroo Rabbahum; alaa bu'dal li 'Aadin qawmin Hood"
  },
  {
    "id": 61,
    "text": "Wa ilaa Samooda akhaahum Saalihaa; qaala yaa qawmi' budul laaha maa lakum min ilaahim ghairuhoo Huwa ansha akum minal ardi wasta' marakum feehaa fastaghfiroohu summa toobooo ilaih; inna Rabbee Qareebum Mujeeb"
  },
  {
    "id": 62,
    "text": "Qaaloo yaa Saalihu qad kunta feenaa marjuwwan qabla haazaaa atanhaanaaa an na'bu da maa ya'budu aabaaa'unaa wa innanaa lafee shakkim mimmaa tad'oonaaa ilaihi mureeb"
  },
  {
    "id": 63,
    "text": "Qaala yaa qawmi ara'aytum in kuntu 'alaa baiyinatim mir Rabbee wa aataanee minhu rahmatan famai yansurunee minal laahi in 'asaituhoo famaa tazeedoonanee ghaira takhseer"
  },
  {
    "id": 64,
    "text": "Wa yaa qawmi haazihee naaqatul laahi lakum aayatan fazaroohaa taakul feee ardil laahi wa laa tamassoohaa bisooo'in fa yaakhuzakum azaabun qareeb"
  },
  {
    "id": 65,
    "text": "Fa 'aqaroohaa faqaala tamatta'oo fee daarikum salaasata aiyaamin zaalika wa'dun ghairu makzoob"
  },
  {
    "id": 66,
    "text": "Falammaa jaaa'a amrunaa najjainaa Saalihanw wal lazeena aamanoo ma'ahoo birahmatim minnaa wa min khizyi Yawmi'iz inna Rabbaka Huwal Qawiyyul 'Azeez"
  },
  {
    "id": 67,
    "text": "Wa akhazal lazeena zalamus saihatu fa asbahoo fee diyaarihim jaasimeena"
  },
  {
    "id": 68,
    "text": "Ka al lam yaghnaw feehaaa; alaaa inna Samooda kafaroo Rabbahum; alaa bu'dal li Samood."
  },
  {
    "id": 69,
    "text": "Wa laqad jaaa'at Rusulunaaa Ibraaheema bilbushraa qaaloo salaaman qaala salaamun famaa labisa an jaaa'a bi'ijlin haneez"
  },
  {
    "id": 70,
    "text": "Falammaa ra aaa aidiyahum laa tasilu ilaihi nakirahum wa awjasa minhum kheefah; qaaloo laa takhaf innaaa ursilnaaa ilaa qawmi Loot"
  },
  {
    "id": 71,
    "text": "Wamra atuhoo qaaa'imatun fadahikat fabashsharnaahaa bi Ishaaqa wa minw waraaa'i Ishaaqa Ya'qoob"
  },
  {
    "id": 72,
    "text": "Qaalat yaa wailataaa 'aalidu wa ana 'ajoozunw wa haaza ba'lee shaikhan inna haazaa lashai'un 'ajeeb"
  },
  {
    "id": 73,
    "text": "Qaalooo ata'jabeena min amril laahi rahmatul laahi wa barakaatuhoo 'alaikum Ahlal Bayt; innahoo Hameedun Majeed"
  },
  {
    "id": 74,
    "text": "Falammaa zahaba an Ibraaheemar raw'u wa jaaa'at hul bushraaa yujaadilunaa fee qawmi Loot"
  },
  {
    "id": 75,
    "text": "Inna Ibraaheema la haleemun awwaahun muneeb"
  },
  {
    "id": 76,
    "text": "Yaaa Ibraaheemu a'rid 'an haazaaa innahoo qad jaaa'a amru Rabbika wa innahum aateehim 'azaabun ghairu mardood"
  },
  {
    "id": 77,
    "text": "Wa lammaa jaaa'at Rusulunaa Lootan seee'a bihim wa daaqa bihim zar'anw wa qaala haazaa yawmun 'aseeb"
  },
  {
    "id": 78,
    "text": "Wa jaaa'ahoo qawmuhoo yuhra'oona ilaihi wa min qablu kaanoo ya'maloonas saiyiaat; qaala yaa qawmi haaa'ulaaa'i banaatee hunna atharu lakum fattaqul laaha wa laa tukhzooni fee daifee alaisa minkum rajulur rasheed"
  },
  {
    "id": 79,
    "text": "Qaaloo laqad 'alimta maa lanaa fee banaatika min haqq, wa innaka lata'lamu maa nureed"
  },
  {
    "id": 80,
    "text": "Qaala law anna lee bikum quwwatan aw aaweee ilaa ruknin shadeed"
  },
  {
    "id": 81,
    "text": "Qaaloo yaa Lootu innaa Rusulu Rabbika lai yasiloo ilaika fa asri bi ahlika biqit 'im minal laili wa laa yaltafit minkum ahadun illam ra ataka innahoo museebuhaa maaa asaabahum; inna maw'i dahumus subh; alaisas subhu biqareeb"
  },
  {
    "id": 82,
    "text": "Falammaa jaaa'a amrunaa ja'alnaa 'aaliyahaa saafilahaa wa amtarnaa 'alaihaa hijaaratam min sijjeelim mandood"
  },
  {
    "id": 83,
    "text": "Musawwamatan 'inda Rabbik; wa maa hiya minaz zaalimena biba'eed"
  },
  {
    "id": 84,
    "text": "Wa ilaa Madyana akhaahum Shu'aibaa; qaala yaa qawmi' budul laaha maa lakum min ilaahin ghairuhoo wa laa tanqusul mikyaala walmeezaan; inneee araakum bikhairinw wa innee akhaafu 'alaikum 'azaaba Yawmim muheet"
  },
  {
    "id": 85,
    "text": "Wa yaa qawmi awful mikyaala walmeezaana bilqisti wa laa tabkhasun naasa ashyaaa'ahum wa laa ta'saw fil ardi mufsideen"
  },
  {
    "id": 86,
    "text": "Baqiyyatul laahi khairul lakum in kuntum mu'mineen; wa maa ana 'alaikum bihafeez"
  },
  {
    "id": 87,
    "text": "Qaaloo yaa Shu'aybu 'a salaatuka ta'muruka an natruka maa ya'budu aabaaa'unaaa aw an naf'ala feee amwaalinaa maa nashaaa'oo innaka la antal haleemur rasheed"
  },
  {
    "id": 88,
    "text": "Qaala yaa qawmi ara'aitum in kuntu 'alaa baiyinatim mir Rabbee wa razaqanee minhu rizqan hasanaa; wa maaa ureedu an ukhaalifakum ilaa maaa anhaakum 'anh; in ureedu illal islaaha mastata't; wa maa tawfeeqeee illaa billaah; 'alaihi tawakkaltu wa ilaihi uneeb"
  },
  {
    "id": 89,
    "text": "Wa yaa qawmi laa yajri mannakum shiqaaqeee ai yuseebakum mislu maaa asaaba qawma Noohin aw qawma Hoodin aw qawma Saalih; wa maa qawmu Lootim minkum biba'eed"
  },
  {
    "id": 90,
    "text": "Wastaghfiroo Rabbakum summa toobooo ilaih; inna Rabbee Raheemunw Wadood"
  },
  {
    "id": 91,
    "text": "Qaaloo yaa Shu'aibu maa nafqahu kaseeram mimmaa taqoolu wa innaa lanaraaka feenaa da'eefanw wa law laa rahtuka larajamnaaka wa maaa anta 'alainaa bi'azeez"
  },
  {
    "id": 92,
    "text": "Qaala yaa qawmi arahteee a'azzu 'alaikum minal laahi wattakhaztumoohu waraaa'akum zihriyyan inna Rabbee bimaa ta'maloona muheet"
  },
  {
    "id": 93,
    "text": "Wa yaa qawmi' maloo 'alaa makaanatikum innee 'aamilun sawfa ta'lamoona many ya'teehi 'azaabuny yukhzeehi wa man huwa kaazib; wartaqibooo innnee ma'akum raqeeb"
  },
  {
    "id": 94,
    "text": "Wa lammaa jaaa'a amrunaa najjainaa shu'aibanw wal lazeena aamanoo ma'ahoo birahmatim minnaa wa akhazatil lazeena zalamus saihatu fa asbahoo fee diyaarihim jaasimeen"
  },
  {
    "id": 95,
    "text": "Ka-al-lam yaghnaw feehaaa; alaa bu'dal li Madyana Kamaa ba'idat Samood"
  },
  {
    "id": 96,
    "text": "Wa laqad arsalnaa Moosaa bi Aayaatinaa wa sultaanim mubeen"
  },
  {
    "id": 97,
    "text": "Ilaa Fir'awna wa mala'ihee fattaba'ooo amra Fir'awna wa maaa amru Fir'awna birasheed"
  },
  {
    "id": 98,
    "text": "Yaqdumu qawmahoo Yawmal Qiyaamati fa awrada humun Naara wa bi'sal wirdul mawrood"
  },
  {
    "id": 99,
    "text": "Wa utbi'oo fee haazihee la'natanw wa Yawmal Qiyaamah; bi'sar rifdul marfood"
  },
  {
    "id": 100,
    "text": "Zaalika min ambaaa'il quraa naqussuhoo 'alaika minhaa qaaa'imunw wa haseed"
  },
  {
    "id": 101,
    "text": "Wa maa zalamnaahum wa laakin zalamooo anfusahum famaaa aghnat 'anhum aalihatuhumul latee yad'oona min doonil laahi min shai'il lammaa jaaa'a amru Rabbika wa maa zaadoohum ghaira tatbeeb"
  },
  {
    "id": 102,
    "text": "Wa kazaalika akhzu Rabbika izaaa akhazal quraa wa hiya zaalimah; inna akhzahooo aleemun shadeed"
  },
  {
    "id": 103,
    "text": "Inna fee zaalika la aayatal liman khaafa 'azaabal Aakhirah; zaalika Yawmum majmoo'ul lahun naasu wa zaalika Yawmum mashhood"
  },
  {
    "id": 104,
    "text": "Wa maa nu'akhkhiruhooo illaa li ajalim ma'dood"
  },
  {
    "id": 105,
    "text": "Yawma yaati laa takallamu nafsun illaa bi iznih; faminhum shaqiyyunw wa sa'eed"
  },
  {
    "id": 106,
    "text": "Fa ammal lazeena shaqoo fafin Naari lahum feehaa zafeerunw wa shaheeq"
  },
  {
    "id": 107,
    "text": "Khaalideena feehaa maa daamatis samaawaatu wal ardu illaa maa shaaa'a Rabbuk; inna Rabbaka fa' 'aalul limaa yureed"
  },
  {
    "id": 108,
    "text": "Wa ammal lazeena su'idoo fafil Jannati khaalideena feehaa maa daamatis samaawaatu wal ardu illaa maa shaaa'a Rabbuk; ataaa'an ghaira majzooz"
  },
  {
    "id": 109,
    "text": "Falaa taku fee miryatim mimmmaa ya'budu haaa'ulaaa'; maa ya'budoona illaa kamaa ya'budu aabaaa'uhum min qabl; wa innaa lamuwaf foohum naseebahum ghaira manqoos"
  },
  {
    "id": 110,
    "text": "Wa laqad aatainaa Moosal Kitaaba fakhtulifa feeh; wa law laa Kalimatun sabaqat mir Rabbika laqudiya bainahum; wa innahum lafee shakkim minhu mureeb"
  },
  {
    "id": 111,
    "text": "Wa inna kullal lammaa la yuwaffiyannahum Rabbuka a'maalahum; innahoo bimaa ya'maloona Khabeer"
  },
  {
    "id": 112,
    "text": "Fastaqim kamaaa umirta wa man taaba ma'aka wa laa tatghaw; innahoo bimaa ta'maloona Baseer"
  },
  {
    "id": 113,
    "text": "Wa laa tarkanooo ilal lazeena zalamoo fatamassa kumun Naaru wa maa lakum min doonil laahi min awliyaaa'a summa laa tunsaroon"
  },
  {
    "id": 114,
    "text": "Wa aqimis Salaata tarafayin nahaari wa zulafam minal layl; innal hasanaati yuzhibnas saiyi aat; zaalika zikraa liz zaakireen"
  },
  {
    "id": 115,
    "text": "Wasbir fa innal laaha laa yudee'u ajral muhsineen"
  },
  {
    "id": 116,
    "text": "Falaw laa kaana minal qurooni min qablikum ooloo baqiyyatiny yanhawna 'anil fasaadi fil ardi illaa qaleelam mimman anjainaa minhum; wattaba'al lazeena zalamoo maaa utrifoo feehi wa kaanoo mujrimeen"
  },
  {
    "id": 117,
    "text": "Wa maa kaana Rabbuka liyuhlikal quraa bizulminw wa ahluhaa muslihoon"
  },
  {
    "id": 118,
    "text": "Wa law shaaa'a Rabbuka laja'alannnaasa ummatanw waa hidatanw wa laa yazaaloona mukhtalifeen"
  },
  {
    "id": 119,
    "text": "Illaa mar rahima Rabbuk; wa lizaalika khalaqahum; wa tammat Kalimatu Rabbika la amla'ana Jahannama minal jinnati wannnaasi ajma'een"
  },
  {
    "id": 120,
    "text": "Wa kullan naqussu 'alaika min ambaaa'ir Rusuli maa nusabbitu bihee fu'aadak; wa jaaa'aka fee haazihil haqqu wa maw'izatunw wa zikraa lilmu' mineen"
  },
  {
    "id": 121,
    "text": "Wa qul lillazeena laa yu'minoo na'maloo 'alaa makaanatikum innaa 'aamiloon"
  },
  {
    "id": 122,
    "text": "Wantaziroo innaa mun taziroon"
  },
  {
    "id": 123,
    "text": "Wa lillaahi ghaibus samaawaati wal ardi wa ilaihi yurja'ul amru kulluhoo fa'bud hu wa tawakkal 'alaih; wa maa Rabbuka bighaafilin 'ammaa ta'maloon"
  }
];

export default en;
