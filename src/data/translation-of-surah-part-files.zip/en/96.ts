import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Iqra bismi rab bikal lazee khalaq"
  },
  {
    "id": 2,
    "text": "Khalaqal insaana min 'alaq"
  },
  {
    "id": 3,
    "text": "Iqra wa rab bukal akram"
  },
  {
    "id": 4,
    "text": "Al lazee 'allama bil qalam"
  },
  {
    "id": 5,
    "text": "'Al lamal insaana ma lam y'alam"
  },
  {
    "id": 6,
    "text": "Kallaa innal insaana layatghaa"
  },
  {
    "id": 7,
    "text": "Ar-ra aahus taghnaa"
  },
  {
    "id": 8,
    "text": "Innna ilaa rabbikar ruj'aa"
  },
  {
    "id": 9,
    "text": "Ara-aital lazee yanhaa"
  },
  {
    "id": 10,
    "text": "'Abdan iza sallaa"
  },
  {
    "id": 11,
    "text": "Ara-aita in kana 'alal hudaa"
  },
  {
    "id": 12,
    "text": "Au amara bit taqwaa"
  },
  {
    "id": 13,
    "text": "Ara-aita in kaz zaba wa ta walla"
  },
  {
    "id": 14,
    "text": "Alam y'alam bi-an nal lahaa yaraa"
  },
  {
    "id": 15,
    "text": "Kalla la illam yantahi la nasfa'am bin nasiyah"
  },
  {
    "id": 16,
    "text": "Nasiyatin kazi batin khaatiah"
  },
  {
    "id": 17,
    "text": "Fal yad'u naadiyah"
  },
  {
    "id": 18,
    "text": "Sanad 'uz zabaaniyah"
  },
  {
    "id": 19,
    "text": "Kalla; la tuti'hu wasjud waqtarib"
  }
];

export default en;
