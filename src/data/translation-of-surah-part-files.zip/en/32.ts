import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Meeem"
  },
  {
    "id": 2,
    "text": "Tanzeelul Kitaabi laa raiba feehi mir rabbil 'aalameen"
  },
  {
    "id": 3,
    "text": "Am yaqooloonaf taraahu bal huwal haqqu mir rabbika litunzira qawma maaa ataahum min nazeerim min qablika la'allahum yahtadoon"
  },
  {
    "id": 4,
    "text": "Allaahul lazee khalaqas samaawaati wal arda wa maa bainahumaa fee sittati ayyaamin thummas tawaa 'alal 'arsh; maa lakum min doonihee minw-waliyyinw-wala shafee'; afalaa tatazakkaroon"
  },
  {
    "id": 5,
    "text": "Yudabbirul amra minas samaaa'i ilal ardi thumma ya'ruju ilaihi fee yawmin kaana miqdaaruhooo alfa sanatim mimmaa ta'uddoon"
  },
  {
    "id": 6,
    "text": "Zaalika 'aalimul ghaybi wash shahaadatil 'azeezur raheem"
  },
  {
    "id": 7,
    "text": "Allazee ahsana kulla shai in khalaqa; wa bada a khalqal insaani min teen"
  },
  {
    "id": 8,
    "text": "Thumma ja'ala naslahoo min sulaalatim mim maaa'immaheen"
  },
  {
    "id": 9,
    "text": "Thumma sawwaahu wa nafakha feehi mir roohihih; wa ja'ala lakumus sam'a wal- absaara wal-af'idah; qaleelam maa tashkuroon"
  },
  {
    "id": 10,
    "text": "Wa qaalooo 'a-izaa dalalnaa fil ardi 'a-innaa lafee khalqin jadeed; bal hum biliqaaa'i rabbihim kaafiroon"
  },
  {
    "id": 11,
    "text": "Qul yatawaffaakum malakul mawtil lazee wukkila bikum Thumma ilaa rabbikum turja'oon"
  },
  {
    "id": 12,
    "text": "Wa law taraaa izil mujrimoona naakisoo ru'oosihim 'inda rabbihim rabbanaaa absarnaa wa sami'naa farji'naa na'mal saalihan innaa mooqinoon"
  },
  {
    "id": 13,
    "text": "Wa law shi'naa la-aatainaa kulla nafsin hudaahaa wa laakin haqqal qawlu minnee la amla'anna jahannama minal jinnati wannaasi ajma'een"
  },
  {
    "id": 14,
    "text": "Fazooqoo bimaa naseetum liqaaa'a yawmikum haaza innaa naseenaakum wa zooqoo 'azaabal khuldi bimaa kuntum ta'maloon"
  },
  {
    "id": 15,
    "text": "Innamaa yu'minu bi aayaatinal lazeena izaa zukkiroo bihaa kharroo sujjadanw wa sabbahoo bihamdi rabbihim wa hum laa yastakbiroon"
  },
  {
    "id": 16,
    "text": "Tatajaafaa junoobuhum 'anil madaaji'i yad'oona rabbahum khawfanw wa tama'anw wa mimmaa razaqnaahum yunfiqoon"
  },
  {
    "id": 17,
    "text": "Falaa ta'lamu nafsum maaa ukhfiya lahum min qurrati a'yunin jazaaa'am bimaa kaanoo ya'maloon"
  },
  {
    "id": 18,
    "text": "Afaman kaana mu'minan kaman kaana faasiqaa; laa yasta woon"
  },
  {
    "id": 19,
    "text": "Ammal lazeena aamanoo wa 'amilus saalihaati falahum jannaatul ma'waa nuzulam bimaa kaanoo ya'maloon"
  },
  {
    "id": 20,
    "text": "Wa ammal lazeena fasaqoo fama'waahumun Naaru kullamaaa araadooo any yakhrujoo minhaaa u'eedoo feehaa wa qeela lahum zooqoo 'azaaaban Naaril lazee kuntum bihee tukazziboon"
  },
  {
    "id": 21,
    "text": "Wa lanuzeeqan nahum minal 'azaabil adnaa doonal 'azaabil akbari la'allahum yarji'oon"
  },
  {
    "id": 22,
    "text": "Wa man azlamu mimman zukkira bi aayaati rabbihee summa a'rada 'anhaa; innaa minal mujrimeena muntaqimoon"
  },
  {
    "id": 23,
    "text": "Wa laqad aatainaa Moosal Kitaaba falaa takun fee miryatim mil liqaaa'ihee wa ja'alnaahu hudal li Baneee Israaa'eel"
  },
  {
    "id": 24,
    "text": "Wa ja'alnaa minhum a'immatany yahdoona bi amrinaa lammaa sabaroo wa kaanoo bi aayaatinaa yooqinoon"
  },
  {
    "id": 25,
    "text": "Inna rabbaka huwa yafsilu bainahum yawmal qiyaamati feemaa kaanoo feehi yakhtalifoon"
  },
  {
    "id": 26,
    "text": "Awalam yahdi lahum kam ahlaknaa min qablihim minal qurooni yamshoona fee masaakinihim; inna fee zaalika la aayaatin afalaa yasma'oon"
  },
  {
    "id": 27,
    "text": "Awalam yaraw annaa nasooqul maaa'a ilal ardil juruzi fanukhriju bihee zar'an ta'kulu minhu an'aamuhum wa anfusuhum afalaa yubsiroon"
  },
  {
    "id": 28,
    "text": "Wa yaqooloona mataa haazal fath hu in kuntum saadiqeen"
  },
  {
    "id": 29,
    "text": "Qul yawmal fath hi laa yanfa'ul lazeena kafarooo eemaanuhum wa laa hum yunzaroon"
  },
  {
    "id": 30,
    "text": "Fa a'rid 'anhum wantazir innahum muntaziroon"
  }
];

export default en;
