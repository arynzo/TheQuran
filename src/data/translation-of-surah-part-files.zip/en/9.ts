import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Baraaa'atum minal laahi wa Rasooliheee ilal lazeena 'aahattum minal mushrikeen"
  },
  {
    "id": 2,
    "text": "Faseehoo fil ardi arba'ata ashhurinw wa'lamoooannakum ghairu mu'jizil laahi wa annal laaha mukhzil kaafireen"
  },
  {
    "id": 3,
    "text": "Wa azaanum minal laahi wa Rasooliheee ilan naasi yawmal Hajjil Akbari annal laaha bareee'um minal mushrikeena wa Rasooluh; fa-in tubtum fahuwa khairullakum wa in tawallaitum fa'lamooo annakum ghairu mu'jizil laah; wa bashiril lazeena kafaroo biazaabin aleem"
  },
  {
    "id": 4,
    "text": "Illal lazeena 'aahattum minal mushrikeena summa lam yanqusookum shai'anw-wa lam yuzaahiroo 'alaikum ahadan fa atimmooo ilaihim 'ahdahum ilaa muddatihim; innal laaha yuhibbul muttaqeen"
  },
  {
    "id": 5,
    "text": "Fa izansalakhal Ashhurul Hurumu faqtulul mushrikeena haisu wajattumoohum wa khuzoohum wahsuroohum waq'udoo lahum kulla marsad; fa-in taaboo wa aqaamus Salaata wa aatawuz Zakaata fakhalloo sabeelahum; innal laaha Ghafoorur Raheem"
  },
  {
    "id": 6,
    "text": "Wa in ahadum minal mushrikeenas tajaaraka fa ajirhu hattaa yasma'a Kalaamal laahi summa ablighhu maa manah; zaalika bi annahum qawmul laa ya'lamoon"
  },
  {
    "id": 7,
    "text": "Kaifa yakoonu lilmush rikeena 'ahdun 'indallaahi wa 'inda Rasoolihee illal lazeena 'aahattum 'indal Masjidil Haraami famas taqaamoo lakum fastaqeemoo lahum; innallaaha yuhibbul muttaqeen"
  },
  {
    "id": 8,
    "text": "Kaifa wa iny-yazharoo 'alaikum laa yarquboo feekum illanw wa laa zimmah; yurdoo nakum biafwaahihim wa ta'baa quloobuhum wa aksaruhum faasiqoon"
  },
  {
    "id": 9,
    "text": "Ishtaraw bi Aayaatil laahi samanan qaleelan fasaddoo 'an sabeelih; innahum saaa'a maa kaanoo ya'maloon"
  },
  {
    "id": 10,
    "text": "Laa yarquboona fee mu'minin illanw wa laa zimmah wa ulaaa 'ika humulmu 'tadoon"
  },
  {
    "id": 11,
    "text": "Fa in taaboo wa aqaamus Salaata wa aatawuz Zakaata fa ikhwaanukum fid deen; wa nufassilul Aayaati liqawminy ya'lamoon"
  },
  {
    "id": 12,
    "text": "Wa in nakasooo aimaanahum mim ba'di 'ahdihim wa ta'anoo fee deenikum faqaatilooo a'immatal kufri innahum laaa aimaana lahum la'allahum yantahoon"
  },
  {
    "id": 13,
    "text": "Alaa tuqaatiloona qawman nakasooo aimaanahum wa hammoo bi ikhraajir Rasooli wa hum bada'ookum awwala marrah; atakhshawnahum; fallaahu ahaqqu an takhshawhu in kuntum mu'mineen"
  },
  {
    "id": 14,
    "text": "Qaatiloohum yu'az zibhumul laahu bi aideekum wa yukhzihim wa yansurkum 'alaihim wa yashfi sudoora qawmim mu 'mineen"
  },
  {
    "id": 15,
    "text": "Wa yuzhib ghaiza quloobihim; wa yatoobullaahu 'alaa mai yashaaa'; wallaahu 'Aleemun Hakeem"
  },
  {
    "id": 16,
    "text": "Am hasibtum an tutrakoo wa lammaa ya'lamil laahul lazeena jaahadoo minkum wa lam yattakhizoo min doonil laahi wa laa Rasoolihee wa lalmu'mineena waleejah; wallaahu khabeerum bimaa ta'maloon"
  },
  {
    "id": 17,
    "text": "Maa kaana lilmushrikeena ai ya'muroo masaajidal laahi shaahideena 'alaaa anfusihim bilkufr; ulaaa'ika habitat a'maaluhum wa fin naari hum khaalidoon"
  },
  {
    "id": 18,
    "text": "Innamaa ya'muru masaa jidal laahi man aamana billaahi wal Yawmil Aakhiri wa aqaamas Salaata wa aataz Zakaata wa lam yakhshaa illal laaha fa'asaaa ulaaa'ika ai yakoonoo minal muhtadeen"
  },
  {
    "id": 19,
    "text": "Aja'altum siqaayatal haaajji wa 'imaaratal masjidil haraami kamman aamana billaahi wal Yawmil Aakhiri wa jaahada fee sabeelil laah; laa yastawoona 'indal laah; wallaahu laa yahdil qawmaz zaalimeen"
  },
  {
    "id": 20,
    "text": "Allazeena aamanoo wa haajaroo wa jaahadoo fee sabeelil laahi bi amwaalihim wa anfusihim a'zamu darajatan 'indal laah; wa ulaaa'ika humul faaa'izoon"
  },
  {
    "id": 21,
    "text": "Yubashshiruhum Rabbuhum birahmatim minhu wa ridwaaninw wa Jannaatil lahum feehaa na'eemum muqeem"
  },
  {
    "id": 22,
    "text": "Khaalideena feehaaa abadaa; innal laaha 'indahooo ajrun 'azeem"
  },
  {
    "id": 23,
    "text": "Yaaa aiyuhal lazeena aamanoo laa tattakhizooo aabaaa 'akum wa ikhwaanakum awliyaaa'a inis tahabbul kufra 'alal eemaan; wa mai yatawal lahum minkum fa ulaaa'ika humuz zaalimoon"
  },
  {
    "id": 24,
    "text": "Qul in kaana aabaaa'ukum wa abnaaa'ukum wa ikhwaanukum wa azwaajukum wa 'asheeratukum wa amwaaluniq taraftumoohaa wa tijaaratun takhshawna kasaadahaa wa masaakinu tardawnahaaa ahabba ilaikum minal laahi wa Rasoolihee wa Jihaadin fee Sabeelihee fatarabbasoo hattaa ya'tiyallahu bi amrih; wallaahu laa yahdil qawmal faasiqeen"
  },
  {
    "id": 25,
    "text": "Laqad nasarakumul laahu fee mawaatina kaseeratinw wa yawma Hunainin iz a'jabatkum kasratukum falam tughni 'ankum shai'anw wa daaqat 'alaikumul ardu bimaa rahubat summa wallaitum mudbireen"
  },
  {
    "id": 26,
    "text": "Summa anzalal laahu sakeenatahoo 'alaa Rasoolihee wa'alal mu'mineena wa anzala junoodal lam tarawhaa wa azzabal lazeena kafaroo; wa zaalika jazaaa'ul kaafireen"
  },
  {
    "id": 27,
    "text": "Summa yatoobul laahu mim ba'di zaalika 'alaa mai yashaaa'; wallaahu Ghafoorur Raheem"
  },
  {
    "id": 28,
    "text": "Yaaa aiyuhal lazeena aamanooo innamal mushrikoona najasun falaa yaqrabul Masjidal Haraama ba'da 'aamihim haaza; wa in khiftum 'ailatan fasawfa yughnee kumul laahu min fadliheee in shaaa'; innallaaha 'Aleemun hakeem"
  },
  {
    "id": 29,
    "text": "Qaatilul lazeena laa yu'minoona billaahi wa laa bil yawmil Aakhiri wa laa yuharrimoona maa harramal laahu wa Rasooluhoo wa laa yadeenoona deenal haqqi minal lazeena ootul Kitaaba hattaa yu'tul jizyata ai yadinw wa hum saaghiroon"
  },
  {
    "id": 30,
    "text": "Wa qaalatil yahoodu 'Uzairunib nul laahi wa qaalatin Nasaaral Maseehub nul laahi zaalika qawluhum bi afwaahihim yudaahi'oona qawlal lazeena kafaroo min qabl; qatalahumul laah; annaa yu'fakoon"
  },
  {
    "id": 31,
    "text": "Ittakhazooo ahbaarahum wa ruhbaanahum arbaabammin doonil laahi wal Maseehab na Maryama wa maaa umirooo illaa liya'budooo Ilaahanw Waa hidan laaa ilaaha illaa Hoo; Subhaanahoo 'ammaa yushrikoon"
  },
  {
    "id": 32,
    "text": "Yureedoona ai yutfi'oo nooral laahi bi'afwaahihim wa ya'ballaahu illaaa ai yutimma noorahoo wa law karihal kaafiroon"
  },
  {
    "id": 33,
    "text": "Huwal lazeee ar sala Rasoolahoo bilhudaa wa deenil haqqi liyuzhirahoo 'alad deeni kullihee wa law karihal mushrikoon"
  },
  {
    "id": 34,
    "text": "Yaaa aiyuhal lazeena aamanooo inna kaseeramminal ahbaari warruhbaani la ya'kuloona amwaalan naasi bil baatili wa yasuddoona 'an sabeelil laah; wallazeena yaknizoonaz zahaba wal fiddata wa laayunfiqoonahaa fee sabeelil laahi fabashshirhum bi'azaabin aleem"
  },
  {
    "id": 35,
    "text": "Yawma yuhmaa 'alaihaa fee naari jahannama fatukwaa bihaa jibaahuhum wa junoobuhum wa zuhooruhum haazaa maa kanaztum li anfusikum fazooqoo maa kuntum taknizoon"
  },
  {
    "id": 36,
    "text": "Inna 'iddatash shuhoori 'indal laahis naa 'ashara shahran fee Kitaabil laahi yawma khalaqas samaawaati wal arda minhaaa arba'atun hurum; zaalikad deenul qaiyim; falaa tazlimoo feehinna anfusakum; wa qaatilul mushrikeena kaaaffatan kamaa yuqaati loonakum kaaaffah; wa'lamooo annal laaha ma'al muttaqeen"
  },
  {
    "id": 37,
    "text": "Inna man naseee'u ziyaadatun filkufri yudallu bihil lazeena kafaroo yuhil loonahoo 'aamanw wa yuhar rimoonahoo 'aamal liyuwaati'oo 'iddata maa harramal laahu fayuhilloo maa harramal-laah; zuyyina lahum sooo'u a'maalihim; wallaahu laa yahdil qawmal kaafireen"
  },
  {
    "id": 38,
    "text": "Yaaa aiyuhal lazeena aamanoo maa lakum izaa qeela lakumun firoo fee sabeelil laahis saaqaltum ilal ard; aradeetum bilhayaatid dunyaa minal Aakhirah; famaamataa'ul hayaatiddunyaa fil Aakhirati illaa qaleel"
  },
  {
    "id": 39,
    "text": "Illaa tanfiroo yu'az zibkum 'azaaban aleemanw wa yastabdil qawman ghairakum wa laa tadurroohu shai'aa; wal laahu 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 40,
    "text": "Illaa tansuroohu faqad nasarahul laahu iz akhrajahul lazeena kafaroo saaniyasnaini iz humaa filghaari iz yaqoolu lisaahibihee laa tahzan innnal laaha ma'anaa; fa anzalallaahu sakeenatahoo 'alaihi wa aiyadahoo bijunoodil lam tarawhaa wa ja'ala kalimatal lazeena kafarus suflaa; wa Kalimatul laahi hiyal 'ulyaa; wallaahu 'Azeezun Hakeem"
  },
  {
    "id": 41,
    "text": "Infiroo khifaafanw wa siqaalanw wa jaahidoo bi amwaalikum wa anfusikum fee sabeelil laah; zaalikum khairul lakum in kuntum ta'lamoon"
  },
  {
    "id": 42,
    "text": "Law kaana 'aradan qareebanw wa safaran qaasidal lattaba'ooka wa laakim ba'udat 'alaihimush shuqqah; wa sayahlifoona billaahi lawis tata'naa lakharajnaa ma'akum; yuhlikoona anfusahum wal laahu ya'lamu innahum lakaa ziboon"
  },
  {
    "id": 43,
    "text": "'Afal laahu 'anka lima azinta lahum hattaa yatabai yana lakal lazeena sadaqoo wa ta'lamal kaazibeen"
  },
  {
    "id": 44,
    "text": "Laa yastaazinukal lazeena yu'minoona billaahi wal Yawmil Aakhiri ai yujaa hidoo bi amwaalihim wa anfusihim; wallaahu 'aleemum bilmut taqeen"
  },
  {
    "id": 45,
    "text": "Innamaa yastaazinukal lazeena laa yu'minoona billaahi wal Yawmil Aakhiri wartaabat quloobuhum fahum fee raibihim yataraddadoon"
  },
  {
    "id": 46,
    "text": "Wa law araadul khurooja la-'addoo lahoo 'uddatanw wa laakin karihal laahum bi'aasahum fasabbatahum wa qeelaq 'udoo ma'al qaa'ideen"
  },
  {
    "id": 47,
    "text": "Law kharajoo feekum maa zaadookum illaa Khabaalanw wa la awda'oo khilaalakum yabghoona kumul fitnata wa feekum sammaa'oona lahum; wallaahu 'aleemum biz zaalimeen"
  },
  {
    "id": 48,
    "text": "Laqadib taghawul fitnata min qablu wa qallaboo lakal umoora hattaa jaaa'al haqqu wa zahara amrul laahi wa hum kaarihoon"
  },
  {
    "id": 49,
    "text": "Wa minhum mai yaqoolu' zal lee wa laa taftinneee; alaa fil fitnati saqatoo; wa inna Jahannama lamuheetatum bil kaafireen"
  },
  {
    "id": 50,
    "text": "In tusibka hasanatun tasu'hum; wa in tusibka museebatuny yaqooloo qad akhaznaaa amranaa min qablu wa yatawallaw wa hum farihoon"
  },
  {
    "id": 51,
    "text": "Qul lany-yuseebanaaa illaa maa katabal laahu lanaa Huwa mawlaanaa; wa 'alal laahi fal yatawakka lil mu'minoon"
  },
  {
    "id": 52,
    "text": "Qul hal tarabbasoona binaaa illaaa ihdal husnayayni wa nahnu natrabbasu bikum ai yus eebakumul laahu bi'azaa bim min 'indiheee aw biaidee naa fatarabbasooo innaa ma'akum mutarabbisoon"
  },
  {
    "id": 53,
    "text": "Qul anfiqoo taw'an aw karhal lany yutaqabbala min kum innakum kuntum qawman faasiqeen"
  },
  {
    "id": 54,
    "text": "Wa maa mana'ahum 'an tuqbala minhum nafaqaatuhum illaaa annahum kafaroo billaahi wa bi Rasoolihee wa laa ya'toonas Salaata illaa wa hum kusaalaa wa laa yunfiqoona illaa wa hum kaarihoon"
  },
  {
    "id": 55,
    "text": "Falaa tu'jibka amwaaluhum wa laaa awlaaduhum; innamaa yureedul laahu liyu'az zibahum bihaa fil hayaatid dunyaa wa tazhaqa anfusuhum wa hum kaafiroon"
  },
  {
    "id": 56,
    "text": "Wa yahlifoona billaahi innnahum laminkum wa maa hum minkum wa laakinnahum qawmuny yafraqoon"
  },
  {
    "id": 57,
    "text": "Law yajidoona malja'an aw maghaaraatin aw mudda khalal lawallaw ilaihi wa hum yajmahoon"
  },
  {
    "id": 58,
    "text": "Wa minhum mai yalmizuka fis sadaqaati fa-in u'too minhaa radoo wa illam yu'taw minhaaa izaa hum yaskhatoon"
  },
  {
    "id": 59,
    "text": "Wa law annahum radoo maaa aataahumul laahu wa Rasooluhoo wa qaaloo hasbunal laahu sayu'teenallaahu min fadlihee wa Rasooluhooo innaaa ilallaahi raaghiboon"
  },
  {
    "id": 60,
    "text": "Innamas sadaqaatu lilfuqaraaa'i walmasaakeeni wal 'aamileena 'alaihaa wal mu'al lafati quloobuhum wa fir riqaabi walghaarimeena wa fee sabeelil laahi wabnis sabeeli fareedatam minal laah; wal laahu 'Aleemun Hakeem"
  },
  {
    "id": 61,
    "text": "Wa minhumul lazeena yu'zoonan nabiyya wa yaqooloona huwa uzun; qul uzunu khairil lakum yu'minu billaahi wa yu'minu lil mu'mineena wa rahmatul lil lazeena aamanoo minkum; wallazeena yu'zoona Rasoolal laahi lahum 'azaabun 'aleem"
  },
  {
    "id": 62,
    "text": "Yahlifoona billaahi lakum liyurdookum wallaahu wa Rasooluhoo ahaqqu ai yurdoohu in kaanoo mu'mineen"
  },
  {
    "id": 63,
    "text": "Alam ya'lamooo annahoo mai yuhaadidillaaha wa Rasoolahoo fa'anna lahoo Naara jahannama khaalidan feehaa; zaalikal khizyul 'Azeem"
  },
  {
    "id": 64,
    "text": "Yahzarul munaafiqoona an tunaz zala 'alaihim Sooratun tunabbi 'uhum bimaa feequloobihim; qulistahzi'oo innal laaha mukhrijum maa tahzaroon"
  },
  {
    "id": 65,
    "text": "Wala'in sa altahum layaqoolunna innamaa kunnaa nakhoodu wa nal'ab; qul abillaahi wa 'Aayaatihee wa Rasoolihee kuntum tastahzi'oon"
  },
  {
    "id": 66,
    "text": "Laa ta'taziroo qad kafartum ba'da eemaanikum; in na'fu 'an taaa'ifatin minkum nu'az zib taaa'ifatan bi annahum kaanoo mujrimeen"
  },
  {
    "id": 67,
    "text": "Almunaafiqoona wal munaafiqaatu ba'duhum mim ba'd; yaamuroona bilmunkari wa yanhawna 'anil ma'roofi wa yaqbidoona aidiyahum; nasul laaha fanasiyahum; innal munaafiqeena humul faasiqoon"
  },
  {
    "id": 68,
    "text": "Wa'adal laahul munafiqeena wal munaafiqaati wal kuffaara naara jahannnamma khaalideena feehaa; hiya hasbuhum; wa la'annahumul laahu wa lahum 'azaabum muqeem"
  },
  {
    "id": 69,
    "text": "Kallazeena min qablikum kaanoo ashadda minkum quwwatanw wa aksara amwaalanw wa awlaadan fastamta'oo bikhalaaqihim fastamta'tum bikhalaaqikum kamas tamta'al lazeena min qablikum bikhalaa qihim wa khudtum kallazee khaadooo; ulaaa'ika habitat a'maaluhum fid dunyaa wal Aakhirati wa ulaaa'ika humul khaasiroon"
  },
  {
    "id": 70,
    "text": "Alam ya'tihim naba ul lazeena min qablihim qawmi Noohinw wa 'Aadinw wa Samooda wa qawmi Ibraaheema wa ashaabi Madyana wal mu'tafikaat; atathum Rusuluhum bilbaiyinaati famaa kaanal laahu liyazlimahum wa laakin kaanooo anfusahum yazlimoon"
  },
  {
    "id": 71,
    "text": "Wal mu'minoona wal mu'minaatu ba'duhum awliyaaa'u ba'd; ya'muroona bilma'roofi wa yanhawna 'anil munkari wa yuqeemoonas Salaata wa yu'toonaz Zakaata wa yutee'oonal laaha wa Rasoolah; ulaaa'ika sayarhamu humul laah; innallaaha 'Azeezun Hakeem"
  },
  {
    "id": 72,
    "text": "Wa'adal laahulmu' mineena walmu'minaati Jannaatin tajree min tahtihal anhaaru khaalideena feehaa wa masaakina taiyibatan fee Jannnaati 'adn; wa ridwaanum minal laahi akbar; zaalika huwal fawzul 'azeem"
  },
  {
    "id": 73,
    "text": "Yaaa aiyuhan Nabiyyu jaahidil kuffaara walmunaafiqeena waghluz 'alaihim; wa maawaahum jahannnamu wa bi'sal maseer"
  },
  {
    "id": 74,
    "text": "Yahlifoona billaahi ma qaaloo wa laqad qaaloo kalimatal kufri wa kafaroo ba'da Islaamihim wa hammoo bimaa lam yanaaloo; wa maa naqamooo illaaa an aghnaa humullaahu wa Rasooluhoo min fadlih; fainy yatooboo yaku khairal lahum wa iny yatawal law yu'az zibhumullaahu 'azaaban aleeman fiddunyaa wal Aakhirah; wamaa lahum fil ardi minw waliyyinw wa laa naseer"
  },
  {
    "id": 75,
    "text": "Wa minhum man 'aaha dal laaha la'in aataanaa min fadlihee lanas saddaqanna wa lanakoonanna minassaaliheen"
  },
  {
    "id": 76,
    "text": "Falammaaa aataahum min fadlihee bakhiloo bihee wa tawallaw wa hum mu'ridoon"
  },
  {
    "id": 77,
    "text": "Fa a'qabahum nifaaqan fee quloobihim ilaa Yawmi yalqaw nahoo bimaaa akhlaful laaha maa wa'adoohu wa bimaa kaanoo yak ziboon"
  },
  {
    "id": 78,
    "text": "Alam ya'lamooo annal laaha ya'lamu sirrahum wa najwaahum wa annal laaha 'Allaamul Ghuyoob"
  },
  {
    "id": 79,
    "text": "Allazeena yalmizoonal mut tawwi'eena minalmu'mineena fis sadaqaati wallazeena laa yajidoona illaa juhdahum fayaskharoona minhum sakhiral laahu minhum wa lahum azaabun aleem"
  },
  {
    "id": 80,
    "text": "Istaghfir lahum aw laa tastaghfir lahum in tastaghfir lahum sab'eena marratan falany yaghfiral laahu lahum; zaalika bi annahum kafaroo billaahi wa Rasoolih; wallaahu laa yahdil qawmal faasiqeen"
  },
  {
    "id": 81,
    "text": "Farihal mukhallafoona bimaq'adihim khilaafa Rasoolil laahi wa karihooo ai yujaahidoo bi amwaalihim wa anfusihim fee sabeelil laahi wa qaaloo laa tanfiroo fil harr; qul Naaru jahannama ashaddu harraa; law kaanoo yafqahoon"
  },
  {
    "id": 82,
    "text": "Falyadhakoo qaleelanw walyabkoo kaseeran jazaaa'an bimaa kaanoo yaksiboon"
  },
  {
    "id": 83,
    "text": "Fa ir raja'akal laahu ilaa taaa'ifatim minhum fastaaa zanooka lilkhurooji faqul lan takhrujoo ma'iya abadanw wa lan tuqaatiloo ma'iya 'aduwwan innakum radeetum bilqu'oodi awwala marratin faq'udoo ma'al khaalifeen"
  },
  {
    "id": 84,
    "text": "Wa laa tusalli 'alaaa ahadim minhum maata abadanw wa laa taqum 'alaa qabriheee innahum kafaroo billaahi wa Rasoolihee wa maatoo wa hum faasiqoon"
  },
  {
    "id": 85,
    "text": "Wa laa tu'jibka amwaaluhum wa awlaaduhum; innamaa yureedul laahu any yu'azzibahum bihaa fid dunyaa wa tazhaqa anfusuhum wa hum kaafiroon"
  },
  {
    "id": 86,
    "text": "Wa izaaa unzilat Sooratun an aaminoo billaahi wa jaahidoo ma'a Rasoolihis taazanaka uluttawli minhum wa qaaloo zarnaa nakum ma'alqaa 'ideen"
  },
  {
    "id": 87,
    "text": "Radoo bi ai yakoonoo ma'al khawaalifi wa tubi'a 'alaa quloobihim fahum laa yafqahoon"
  },
  {
    "id": 88,
    "text": "Laakinir Rasoolu wal lazeena aamanoo ma'ahoo jaahadoo bi amwaalihim wa anfusihim; wa ulaaa'ika lahumul khairaatu wa ulaaa'ika humul muflihoon"
  },
  {
    "id": 89,
    "text": "A'addal laahu lahum Jannaatin tajree min tahtihal anhaaru khaalideena feehaa; zaalikal fawzul 'azeem"
  },
  {
    "id": 90,
    "text": "Wa jaaa'al mu'az ziroona minal A'raabi liyu'zana lahum wa qa'adal lazeena kazabul laaha wa Rasoolah; sayuseebul lazeena kafaroo minhum 'azaabun aleem"
  },
  {
    "id": 91,
    "text": "Laisa 'alad du'aafaaa'i wa laa 'alal mardaa wa laa 'alal lazeena laa yajidoona maa yunfiqoona harajun izaa nasahoo lillaahi wa Rasoolih; maa 'alal muhsineena min sabeel; wallaahu Ghafoorur Raheem"
  },
  {
    "id": 92,
    "text": "Wa laa 'alal lazeena izaa maaa atawka litahmilahum qulta laaa ajidu maaa ahmilukum 'alaihi tawallaw wa a'yunuhum tafeedu minaddam'i hazanan allaa yajidoo maa yunfiqoon"
  },
  {
    "id": 93,
    "text": "Innamas sabeelu 'alal lazeena yasta'zinoonaka wa hum aghniyaaa'; radoo biany- yakoonoo ma'al khawaalifi wa taba'al laahu 'alaa quloobihim fahum laa ya'lamoon"
  },
  {
    "id": 94,
    "text": "Ya'taziroona ilaikum izaa raja'tum ilaihim; qul laa ta'taziroo lan nu'mina lakum qad nabba annal laahu min akhbaarikum; wa sa yaral laahu 'amalakum wa Rasooluhoo thumma turaddoona ilaa 'Aalimil Ghaibi washshahaadati fa yunabbi'ukum bimaa kuntum ta'maloon"
  },
  {
    "id": 95,
    "text": "Sa yahlifoona billaahi lakum izanqalabtum ilaihim litu'ridoo 'anhum fa a'ridoo 'anhum innahum rijsunw wa ma'waahum jahannamu jazaaa'an bi maakaanoo yaksiboon"
  },
  {
    "id": 96,
    "text": "Yahlifoona lakum litardaw 'anhum fa in tardaw 'anhum fa innal laaha laa yardaa 'anil qawmil faasiqeen"
  },
  {
    "id": 97,
    "text": "Al A'raabu ashaddu kufranw wa nifaaqanw wa ajdaru allaa ya'lamoo hudooda maaa anzalal laahu 'alaa Rasoolih; wallaahu 'Aleemun Hakeem"
  },
  {
    "id": 98,
    "text": "Wa minal A'raabi mai yattakhizu maa yunfiqu maghramanw wa yatarabbasu bikumud dawaaa'ir; alaihim daaa'iratus saw'; wallaahu Samee'un 'Aleem"
  },
  {
    "id": 99,
    "text": "Wa minal A'raabi mai yu'minu billaahi wal yawmil aakhiri wa yattakhizu maa yunfiqu qurubaatin 'indal laahi wa salawaatir Rasool; 'alaaa innahaa qurbatul lahum; sayudkhilu humul laahu fee rahmatih; innal laaha Ghafoorur Raheem"
  },
  {
    "id": 100,
    "text": "Was saabiqoonal awwaloona minal Muhaajireena wal Ansaari wallazeenat taba'oo hum bi ihsaanir radiyal laahu 'anhum wa radoo 'anhu wa a'adda lahum jannaatin tajree tahtahal anhaaru khaalideena feehaaa abadaa; zaalikal fawzul 'azeem"
  },
  {
    "id": 101,
    "text": "Wa mimmann hawlakum minal A'raabi munaafiqoona wa min ahlil Madeenati maradoo 'alan nifaaq, laa ta'lamuhum nahnu na'lamuhum; sanu'azzibuhum marrataini summa yuraddoona ilaa 'azaabin 'azeem"
  },
  {
    "id": 102,
    "text": "Wa aakharoo na'tarafoo bizunoobihim khalatoo 'amalan saalihanw wa aakhara saiyi'an 'asal laahu 'any yatooba 'alaihim; innal laaha Ghafoorur Raheem"
  },
  {
    "id": 103,
    "text": "Khuz min amwaalihim sadaqatan tutahhiruhum wa tuzakkeehim bihaa wa salli 'alaihim inna salaataka sakanul lahum; wallaahu Samee'un 'Aleem"
  },
  {
    "id": 104,
    "text": "Alam ya'lamooo annal laaha huwa yaqbalut tawbata 'an ibaadihee wa ya'khuzus sadaqaati wa annal laaha huwat Tawwaabur Raheem"
  },
  {
    "id": 105,
    "text": "Wa qul i'maloo fasayaral laahu 'amalakum wa Rasooluhoo wal mu'minoon; wa saturaddoona ilaa 'Aalimil Ghaibi washshahaadati fa yunabbi'ukum bimaa kuntum ta'maloon"
  },
  {
    "id": 106,
    "text": "Wa aakharoona murjawna li amril laahi immaa yu'azzibuhum wa immaa yatoobu 'alaihim; wallaahu 'Aleemun Hakeem"
  },
  {
    "id": 107,
    "text": "Wallazeenat takhazoo masjidan diraaranw wa kufranw wa tafreeqan bainal mu'mineena wa irsaadal liman haarabal laaha wa Rasoolahoo min qabl; wa la yahlifunna in aradnaaa illal husnaa wallaahu yash hadu innahum lakaaziboon"
  },
  {
    "id": 108,
    "text": "Laa taqum feehi abadaa; lamasjidun ussisa 'alat taqwaa min awwali yawmin ahaqqu 'an taqooma feeh; feehi rijaaluny yuhibbona 'any yata tah haroo; wallaahu yuhibbul muttah hireen"
  },
  {
    "id": 109,
    "text": "Afaman assasa bunyaanahoo 'alaa taqwaa minal laahi wa ridwaanin khairun am man assasa bunyaanahoo 'alaa shafaa jurufin haarin fanhaara bihee fee Naari Jahannam; wallaahu laa yahdil qawmaz zaalimeen"
  },
  {
    "id": 110,
    "text": "Laa yazaalu bunyaanu humul lazee banaw reebatan fee quloobihim illaaa an taqatta'a quloobuhum; wal laahu 'Aleemun Hakeem"
  },
  {
    "id": 111,
    "text": "Innal laahash taraa minal mu'mineena anfusahum wa amwaalahum bi anna lahumul jannah; yuqaatiloona fee sabeelil laahi fa yaqtuloona wa yuqtaloona wa'dan 'alaihi haqqan fit Tawraati wal Injeeli wal Qur'aaan; wa man awfaa bi'ahdihee minal laah; fastabshiroo bi bay'ikumul lazee baaya'tum bih; wa zaalika huwal fawzul 'azeem"
  },
  {
    "id": 112,
    "text": "At taaa'iboonal 'aabidoonal haamidoonas saaa'ihoonar raaki'oonas saajidoonal aamiroona bilma'roofi wannaahoona 'anil munkari walhaafizoona lihudoodil laah; wa bashshiril mu'mineen"
  },
  {
    "id": 113,
    "text": "Maa kaana lin nabiyyi wallazeena aamanooo 'any yastaghfiroo lil mushrikeena wa law kaanoo ulee qurbaa min ba'di maa tabiyana lahum annahum Ashaabul jaheem"
  },
  {
    "id": 114,
    "text": "Wa maa kaanas tighfaaru ibraaheema li abeehi illaa 'an maw'idatinw wa 'adahaaa iyyaahu falammaa tabaiyana lahooo annahoo 'aduwwul lillaahi tabarra a minh; inna Ibraaheema la awwaahun haleem"
  },
  {
    "id": 115,
    "text": "Wa maa kaanal laahu liyudilla qawman ba'da iz hadaahum hatta yubaiyina lahum maa yattaqoon; innal laaha bikulli shai'in 'Aleem"
  },
  {
    "id": 116,
    "text": "Innal laaha lahoo mulkus samaawaati wal ardi yuhyee wa yumeet; wa maa lakum min doonil laahi minw waliyyinw wa laa naseer"
  },
  {
    "id": 117,
    "text": "Laqat taabal laahu 'alan nabiyyi wal Muhaajireena wal Ansaaril lazeenat taba'oohu fee saa'atil 'usrati min ba'di maa kaada yazeeghu quloobu fariqin minhum thumma taaba 'alaihim; innahoo bihim Ra'oofur Raheem"
  },
  {
    "id": 118,
    "text": "Wa 'alas salaasatil lazeena khullifoo hattaaa izaa daaqat 'alaihimul ardu bimaa rahubat wa daaqat 'alaihim anfusuhum wa zannnooo al laa malja-a minal laahi illaaa ilaihi summa taaba 'alaihim liyatooboo; innal laaha Huwat Tawwaabur Raheem"
  },
  {
    "id": 119,
    "text": "Yaaa aiyuhal lazeena aamanut taqul laaha wa koonoo ma'as saadiqeen"
  },
  {
    "id": 120,
    "text": "Maa kaana li ahlil Madeenati wa man hawlahum minal A'raabi ai yatakhallafoo 'ar- Rasoolil laahi wa laa yarghaboo bi anfusihim 'an nafsih; zaalika bi annahum laa yuseebuhum zama unw wa laa nasabunw wa laa makhmasatun fee sabeelil laahi wa laa yata'oona mawti'ai yagheezul kuffaara wa laa yanaaloona min 'aduwwin nailan illaa kutiba lahum bihee 'amalun saalih; innal laaha laa yudee'u ajral muhsineen"
  },
  {
    "id": 121,
    "text": "Wa laa yunfiqoona nafa qatan sagheeratanw wa laa kabeeratanw wa laa yaqta'oona waadiyan illaa kutiba lahum liyajziyahumul laahu ahsana maa kaanoo ya'maloon"
  },
  {
    "id": 122,
    "text": "Wa maa kaanal mu'minoona liyanfiroo kaaaffah; falaw laa nafara min kulli firqatim minhum taaa'ifatul liyatafaqqahoo fiddeeni wa liyunziroo qawmahum izaa raja'ooo ilaihim la'allahum yahzaroon"
  },
  {
    "id": 123,
    "text": "Yaaa aiyuhal lazeena aamanoo qaatilul lazeena yaloonakum minal kuffaari walyajidoo feekum ghilzah; wa'lamooo annal laaha ma'al muttaqeen"
  },
  {
    "id": 124,
    "text": "Wa izaa maaa unzilat Sooratun faminhum mai yaqoolu aiyukum zaadat hu haazihee eemaanaa; fa ammal lazeena aamanoo fazaadat hum eemaananw wa hum yastabshiroon"
  },
  {
    "id": 125,
    "text": "Wa ammal lazeena fee quloobihim maradun fazaadat hum rijsan ilaa rijsihim wa maatoo wa hum kaafiroon"
  },
  {
    "id": 126,
    "text": "'A wa laa yarawna annahum yuftanoona fee kulli 'aamin marratan 'aw marrataini thumma laa yatooboona wa laa hum yazzakkaroon"
  },
  {
    "id": 127,
    "text": "Wa izaa maaa unzilat Sooratun nazara ba'duhum ilaa ba'din hal yaraakum min ahadin thumman sarafoo; sarafal laahu quloobahum bi annahum qawmul laa yafqahoon"
  },
  {
    "id": 128,
    "text": "Laqad jaaa'akum Rasoolum min anfusikum 'azeezun 'alaihi maa 'anittum hareesun 'alaikum bilmu'mineena ra'oofur raheem"
  },
  {
    "id": 129,
    "text": "Fa in tawallaw faqul hasbiyal laahu laaa ilaaha illaa Huwa 'alaihi tawakkkaltu wa Huwa Rabbul 'Arshil 'Azeem"
  }
];

export default en;
