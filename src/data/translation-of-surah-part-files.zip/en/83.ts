import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wailul lil mutaffifeen"
  },
  {
    "id": 2,
    "text": "Allazeena izak taaloo 'alan naasi yastawfoon"
  },
  {
    "id": 3,
    "text": "Wa izaa kaaloohum aw wazanoohum yukhsiroon"
  },
  {
    "id": 4,
    "text": "Alaa yazunnu ulaaa'ika annahum mab'oosoon"
  },
  {
    "id": 5,
    "text": "Li Yawmin 'Azeem"
  },
  {
    "id": 6,
    "text": "Yawma yaqoomun naasu li Rabbil 'aalameen"
  },
  {
    "id": 7,
    "text": "Kallaaa inna kitaabal fujjaari lafee Sijjeen"
  },
  {
    "id": 8,
    "text": "Wa maa adraaka maa Sijjeen"
  },
  {
    "id": 9,
    "text": "Kitaabum marqoom"
  },
  {
    "id": 10,
    "text": "Wailuny yawma'izil lil mukazzibeen"
  },
  {
    "id": 11,
    "text": "Allazeena yukazziboona bi yawmid deen"
  },
  {
    "id": 12,
    "text": "Wa maa yukazzibu biheee illaa kullu mu'tadin aseem"
  },
  {
    "id": 13,
    "text": "Izaa tutlaa'alaihi aayaatunaa qaala asaateerul awwaleen"
  },
  {
    "id": 14,
    "text": "Kallaa bal raana 'alaa quloobihim maa kaanoo yaksiboon"
  },
  {
    "id": 15,
    "text": "Kallaaa innahum 'ar Rabbihim yawma'izil lamah jooboon"
  },
  {
    "id": 16,
    "text": "Summa innahum lasaa lul jaheem"
  },
  {
    "id": 17,
    "text": "Summa yuqaalu haazal lazee kuntum bihee tukazziboon"
  },
  {
    "id": 18,
    "text": "Kallaaa inna kitaabal abraari lafee'Illiyyeen"
  },
  {
    "id": 19,
    "text": "Wa maaa adraaka maa 'Illiyyoon"
  },
  {
    "id": 20,
    "text": "Kitaabum marqoom"
  },
  {
    "id": 21,
    "text": "Yashhadu hul muqarra boon"
  },
  {
    "id": 22,
    "text": "Innal abraara lafee Na'eem"
  },
  {
    "id": 23,
    "text": "'Alal araaa'iki yanzuroon"
  },
  {
    "id": 24,
    "text": "Ta'rifu fee wujoohihim nadratan na'eem"
  },
  {
    "id": 25,
    "text": "Yusqawna mir raheeqim makhtoom"
  },
  {
    "id": 26,
    "text": "Khitaamuhoo misk; wa fee zaalika falyatanaafasil Mutanaafisoon"
  },
  {
    "id": 27,
    "text": "Wa mizaajuhoo min Tasneem"
  },
  {
    "id": 28,
    "text": "'Ainaiy yashrabu bihal muqarraboon"
  },
  {
    "id": 29,
    "text": "Innal lazeena ajramoo kaanoo minal lazeena aamanoo yadhakoon"
  },
  {
    "id": 30,
    "text": "Wa izaa marroo bihim yataghaamazoon"
  },
  {
    "id": 31,
    "text": "Wa izan qalabooo ilaaa ahlihimun qalaboo fakiheen"
  },
  {
    "id": 32,
    "text": "Wa izaa ra awhum qaalooo inna haaa'ulaaa'i ladaaal loon"
  },
  {
    "id": 33,
    "text": "Wa maaa ursiloo 'alaihim haafizeen"
  },
  {
    "id": 34,
    "text": "Fal yawmal lazeena aamanoo minal kuffaari yadhakoon"
  },
  {
    "id": 35,
    "text": "'Alal araaa'iki yanzuroon"
  },
  {
    "id": 36,
    "text": "Hal suwwibal kuffaaru maa kaanoo yaf'aloon"
  }
];

export default en;
