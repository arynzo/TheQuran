import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Taa-Seeen; tilka Aayaatul Qur-aani wa Kitaabim Mubeen"
  },
  {
    "id": 2,
    "text": "Hudanw wa bushraa lil mu'mineen"
  },
  {
    "id": 3,
    "text": "Allazeena yuqeemoonas Salaata wa yu'toonaz Zakaata wa hum bil Aakhirati hum yooqinoon"
  },
  {
    "id": 4,
    "text": "Innal lazeena laa yu'minoona bil Aakhirati zaiyannaa lahum a'maalahum fahum ya'mahoon"
  },
  {
    "id": 5,
    "text": "Ulaaa'ikal lazeena lahum sooo'ul 'azaabi wa hum fil Aakhirati humul akhsaroon"
  },
  {
    "id": 6,
    "text": "Wa innaka latulaqqal Qur-aana mil ladun Hakeemin 'Aleem"
  },
  {
    "id": 7,
    "text": "Iz qaala Moosaa li ahliheee inneee aanastu naaran sa'aateekum minhaa bikhabarin aw aateekum bishihaabin qabasil la'allakum tastaloon"
  },
  {
    "id": 8,
    "text": "Falammaa jaaa'ahaa noodiya am boorika man finnnnaari wa man hawlahaa wa Subhaanal laahi Rabbil 'aalameen"
  },
  {
    "id": 9,
    "text": "Yaa Moosaaa innahooo Anal laahul 'Azeezul Hakeem"
  },
  {
    "id": 10,
    "text": "Wa alqi 'asaak; falammmaa ra aahaa tahtazzu ka annahaa jaaannunw wallaa mudbiranw wa lam yu'aqqib; yaa Moosaa laa takhaf innee laa yakhaafu ladaiyal mursaloon"
  },
  {
    "id": 11,
    "text": "Illaa man zalama summa baddala husnam ba'da sooo'in fa innee Ghafoorur Raheem"
  },
  {
    "id": 12,
    "text": "Wa adkhil yadaka fee jaibika takhruj baidaaa'a min ghairisooo'in feetis'i Aayaatin ilaa Fir'awna wa qawmih; innahum kaanoo qawman faasiqeen"
  },
  {
    "id": 13,
    "text": "Falammaa jaaa'at hum Aayaatunaa mubsiratan qaaloo haazaa sihrum mubeen"
  },
  {
    "id": 14,
    "text": "Wa jahadoo bihaa wastaiqanat haaa anfusuhum zulmanw-wa 'uluwwaa; fanzur kaifa kaana 'aaqibatul mufsideen"
  },
  {
    "id": 15,
    "text": "Wa laqad aatainaa Daawooda wa sulaimaana 'ilmaa; wa qaalal hamdu lil laahil lazee faddalanaa 'alaa kaseerim min 'ibaadihil mu'mineen"
  },
  {
    "id": 16,
    "text": "Wa warisa Sulaimaanu Daawooda wa qaala yaaa aiyuhan naasu 'ullimnaa mantiqat tairi wa ooteenaa min kulli shai'in inna haazaa lahuwal fadlul mubeen"
  },
  {
    "id": 17,
    "text": "Wa hushira li Sulaimaana junooduhoo minal jinni wal insi wattairi fahum yooza'oon"
  },
  {
    "id": 18,
    "text": "Hattaaa izaaa ataw 'alaa waadin namli qaalat namlatuny yaaa aiyuhan namlud khuloo masaakinakum laa yahtimannakum Sulaimaanu wa junooduhoo wa hum laa yash'uroon"
  },
  {
    "id": 19,
    "text": "Fatabassama daahikam min qawlihaa wa qaala Rabbi awzi'nee an ashkura ni'mata kal lateee an'amta 'alaiya wa 'alaa waalidaiya wa an a'mala saalihan tardaahu wa adkhilnee birahmatika fee 'ibaadikas saaliheen"
  },
  {
    "id": 20,
    "text": "Wa tafaqqadat taira faqaala maa liya laaa araa al hudhuda, am kaana minal ghaaa'ibeen"
  },
  {
    "id": 21,
    "text": "La-u'azzibanahoo 'azaaban shadeedan aw la azbahannahoo aw layaatiyannee bisultaanim mubeen"
  },
  {
    "id": 22,
    "text": "Famakasa ghaira ba'eedin faqaala ahattu bimaa lam tuhit bihee wa ji'tuka min Sabaim binaba iny-yaqeen"
  },
  {
    "id": 23,
    "text": "Innee wajattum ra atan tamlikuhum wa ootiyat min kulli shai'inw wa lahaa 'arshun 'azeem"
  },
  {
    "id": 24,
    "text": "Wajattuhaa wa qawmahaa yasjudoona lishshamsi min doonil laahi wa zaiyana lahumush Shaitaanu a'maalahum fasaddahum 'anis sabeeli fahum laa yahtadoon"
  },
  {
    "id": 25,
    "text": "Allaa yasjudoo lillaahil lazee yukhrijul khab'a fis samaawaati wal ardi wa ya'lamu maa tukhfoona wa maa tu'linoon"
  },
  {
    "id": 26,
    "text": "Allaahu laaa ilaaha illaa Huwa Rabbul 'Arshil Azeem"
  },
  {
    "id": 27,
    "text": "Qaala sananzuru asadaqta am kunta minal kaazibeen"
  },
  {
    "id": 28,
    "text": "Izhab bikitaabee haaza fa alqih ilaihim summma tawalla 'anhum fanzur maazaa yarji'oon"
  },
  {
    "id": 29,
    "text": "Qaalat yaaa aiyuhal mala'u innee ulqiya ilaiya kitaabun kareem"
  },
  {
    "id": 30,
    "text": "Innahoo min Sulaimaana wa innahoo bismil laahir Rahmaanir Raheem"
  },
  {
    "id": 31,
    "text": "Allaa ta'loo 'alaiya waa toonee muslimeen"
  },
  {
    "id": 32,
    "text": "Qaalat yaaa aiyuhal mala'u aftoonee fee amree maa kuntu qaati'atan amran hattaa tashhhadoon"
  },
  {
    "id": 33,
    "text": "Qaaloo nahnu uloo quwwatinw wa uloo baasin shadeed; wal amru ilaiki fanzuree maazaa taamureen"
  },
  {
    "id": 34,
    "text": "Qaalat innal mulooka izaa dakhaloo qaryatan afsadoohaa wa ja'alooo a'izzata ahlihaaa azillah; wa kazaalika yaf'aloon"
  },
  {
    "id": 35,
    "text": "Wa innee mursilatun ilaihim bihadiyyatin fanaaziratum bima yarji'ul mursaloon"
  },
  {
    "id": 36,
    "text": "Falammaa jaaa'a Sulaimaana qaala atumiddoonani bimaalin famaaa aataaniyal laahu khairum mimmmaaa aataakum bal antum bihadiy-yatikum tafrahoon"
  },
  {
    "id": 37,
    "text": "Irji' ilaihim falanaatiyan nahum bijunoodil laa qibala lahum bihaa wa lanukhri jannahum minhaaa azillatanw wa hum saaghiroon"
  },
  {
    "id": 38,
    "text": "Qaala yaaa aiyuhal mala'u aiyukum yaateenee bi'arshihaa qabla ai yaatoonee muslimeen"
  },
  {
    "id": 39,
    "text": "Qaala 'ifreetum minal jinni ana aateeka bihee qabla an taqooma mim maqaamika wa innee 'alaihi laqawiyyun ameen"
  },
  {
    "id": 40,
    "text": "Qaalal lazee indahoo 'ilmum minal Kitaabi ana aateeka bihee qabla ai yartadda ilaika tarfuk; falammaa ra aahu mustaqirran 'indahoo qaala haazaa min fadli Rabbee li yabluwaneee 'a-ashkuru am akfuru wa man shakara fa innamaa yashkuru linafsihee wa man kafara fa inna Rabbee Ghaniyyun Kareem"
  },
  {
    "id": 41,
    "text": "Qaala nakkiroo lahaa 'arshahaa nanzur atahtadeee am takoonu minal lazeena laa yahtadoon"
  },
  {
    "id": 42,
    "text": "Falammaa jaaa'at qeela ahaakaza 'arshuki qaalat ka'annahoo hoo; wa ooteenal 'ilma min qablihaa wa kunnaa muslimeen"
  },
  {
    "id": 43,
    "text": "Wa saddahaa maa kaanat ta'budu min doonil laahi innahaa kaanat min qawmin kaafireen"
  },
  {
    "id": 44,
    "text": "Qeela lahad khulis sarha falammaa ra at hu hasibat hu lujjatanw wa kashafat 'an saaqaihaa; qaala innahoo sarhum mumarradum min qawaareer; qaalat Rabbi innee zalamtu nafsee wa aslamtu ma'a Sulaimaana lillaahi Rabbil 'aalameen"
  },
  {
    "id": 45,
    "text": "Wa laqad arsalnaaa ilaa Samooda akhaahum Saalihan ani'budul laaha fa izaa hum fareeqaani yakhtasimoon"
  },
  {
    "id": 46,
    "text": "Qaala yaa qawmi lima tasta'jiloona bissaiyi'ati qablal hasanati law laa tas taghfiroonal laaha la'allakum turhamoon"
  },
  {
    "id": 47,
    "text": "Qaalut taiyarnaa bika wa bimam ma'ak; qaala taaa'irukum 'indal laahi bal antum qawmun tuftanoon"
  },
  {
    "id": 48,
    "text": "Wa kaana fil madeenati tis'atu rahtiny yufsidoona fil ardi wa laa yuslihoon"
  },
  {
    "id": 49,
    "text": "Qaaloo taqaasamoo billaahi lanubaiyitannahoo wa ahlahoo summaa lanaqoolana liwaliy yihee maa shahidnaa mahlika ahlihee wa innaa lasaadiqoon"
  },
  {
    "id": 50,
    "text": "Wa makaroo makranw wa makarnaa makranw wa hum laa yash'uroon"
  },
  {
    "id": 51,
    "text": "Fanzur kaifa kaana 'aaqibatu makrihim annaa dammar naahum wa qawmahum ajma'een"
  },
  {
    "id": 52,
    "text": "Fatilka buyootuhum khaa wiyatam bimaa zalamoo; inna fee zaalika la Aayatal liqaw miny-ya'lamoon"
  },
  {
    "id": 53,
    "text": "Wa anjainal lazeena aamanoo wa kaanoo yattaqoon"
  },
  {
    "id": 54,
    "text": "Wa lootan iz qaala liqawmiheee ataatoonal faa hishata wa antum tubsiroon"
  },
  {
    "id": 55,
    "text": "A'innakum lataatoonar rijaala shahwatam min doonin nisaaa'; bal antum qawmun tajhaloon"
  },
  {
    "id": 56,
    "text": "Famaa kaana jawaaba qawmiheee illaaa an qaalooo akhrijooo aalaa Lootim min qaryatikum innahum unaasuny yatatahharoon"
  },
  {
    "id": 57,
    "text": "Fa anjainaahu wa ahlahooo illam ra atahoo qaddarnaahaa minal ghaabireen"
  },
  {
    "id": 58,
    "text": "Wa amtarnaa 'alaihimm mataran fasaaa'a matarul munzareen"
  },
  {
    "id": 59,
    "text": "Qulil hamdu lillaahi wa salaamun 'alaa 'ibaadihil lazeenas tafaa; aaallaahu khairun ammmaa yushrikoon"
  },
  {
    "id": 60,
    "text": "Amman khalaqas samaawaati wal arda wa anzala lakum minas samaaa'i maaa'an fa anbatnaa bihee hadaaa'iqa zaata bahjah; maa kaana lakum an tunbitoo shajarahaa; 'a- ilaahun ma'al laah; bal hum qawmuny ya'diloon"
  },
  {
    "id": 61,
    "text": "Ammann ja'alal arda qaraaranw wa ja'ala khilaalahaaa anhaaranw wa ja'ala lahaa rawaasiya wa ja'ala bainal bahraini haajizaa; 'a-ilaahun ma'allah; bal aksaruhum laa ya'lamoon"
  },
  {
    "id": 62,
    "text": "Ammany-yujeebul mud tarra izaa da'aahu wa yakshifus sooo'a wa yaj'alukum khula faaa'al ardi 'a-ilaahun ma'allah qaleelan maa tazak karoon"
  },
  {
    "id": 63,
    "text": "Ammany-yahdeekum fee zulumaatil barri wal bahri wa many yursilu riyaaha bushran baina yadai rahmatih; 'a-ilaahun ma'allah; Ta'aalal laahu 'ammaa yushrikoon"
  },
  {
    "id": 64,
    "text": "Ammany yabda'ul khalqa thumma yu'eeduhoo wa many-yarzuqukum minas sammaaa'i wal ard; 'a-ilaahun ma'allah; qul haatoo burhaanakum in kuntum saadiqeen"
  },
  {
    "id": 65,
    "text": "Qul laa ya'lamu man fis sammaawaati wal ardil ghaiba illal laah; wa maa yash'uroona aiyaana yub'asoon"
  },
  {
    "id": 66,
    "text": "Balid daaraka 'ilmuhum fil Aakhirah; bal hum fee shakkin minhaa bal hum minhaa 'amoon"
  },
  {
    "id": 67,
    "text": "Wa qaalal lazeena kafarooo 'a-izaa kunnaa turaabanw wa aabaaa'unaaa a'innaa lamukhrajoon"
  },
  {
    "id": 68,
    "text": "Laqad wu'idnaa haazaa nahnu wa aabaaa'unaa min qablu in haazaaa illaaa asaateerul awwaleen"
  },
  {
    "id": 69,
    "text": "Qul seeroo fil ardi fanzuroo kaifa kaana 'aaqibatul mujrimeen"
  },
  {
    "id": 70,
    "text": "Wa laa tahzan 'alaihim wa laa takun fee daiqin mimmaa yamkuroon"
  },
  {
    "id": 71,
    "text": "Wa yaqooloona mataa haazal wa'du in kuntum saadiqeen"
  },
  {
    "id": 72,
    "text": "Qul 'asaaa any-yakoona radifa lakum ba'dul lazee tasta'jiloon"
  },
  {
    "id": 73,
    "text": "Wa inna Rabbaka lazoo fadlin 'alan naasi wa laakinna aksarahum laa yashkuroon"
  },
  {
    "id": 74,
    "text": "Wa inna Rabbaka la ya'lamu maa tukinnu sudooruhum wa maa yu'linoon"
  },
  {
    "id": 75,
    "text": "Wa maa min ghaaa'ibatin fis samaaa'i wal ardi illaa fee kitaabin mubeen"
  },
  {
    "id": 76,
    "text": "Inna haazal Qur-aana yaqussu 'alaa Baneee israaa'eela aksaral lazee hum feehi yakhtalifoon"
  },
  {
    "id": 77,
    "text": "Wa innahoo lahudanw wa rahmatul lilmu'mineen"
  },
  {
    "id": 78,
    "text": "Inna Rabbaka yaqdee bainahum bihukmih; wa Huwal 'Azeezul 'Aleem"
  },
  {
    "id": 79,
    "text": "Fatawakkal 'alal laahi innaka 'alal haqqil mubeen"
  },
  {
    "id": 80,
    "text": "Innaka laa tusmi'ul mawtaa wa laa tusmi'us summad du'aaa izaa wallaw mudbireen"
  },
  {
    "id": 81,
    "text": "Wa maaa anta bihaadil 'umyi 'an dalaalatihim in tusmi'u illaa mai yu'minu bi aayaatinaa fahum muslimoon"
  },
  {
    "id": 82,
    "text": "Wa izaa waqa'al qawlu 'alaihim akhrajnaa lahum daaabbatan minal ardi tukal limuhum annan naasa kaanoo bi aayaatinaa laa yooqinoon"
  },
  {
    "id": 83,
    "text": "Wa Yawma nahshuru min kulli ummatin fawjan mimmany yukazzibu bi Aayaatinaa fahum yooza'oon"
  },
  {
    "id": 84,
    "text": "Hattaaa izaa jaaa'oo qaala akazzabtum bi Aayaatee wa lam tuheetoo bihaa 'ilman ammaazaa kuntum ta'maloon"
  },
  {
    "id": 85,
    "text": "Wa waqa'al qawlu 'alaihim bimaa zalamoo fahum laa yantiqoon"
  },
  {
    "id": 86,
    "text": "Alam yaraw annaa ja'alnal laila li yaskunoo feehi wannahaara mubsiraa; inna fee zaalika la Aayaatil liqaw miny-yu'minoon"
  },
  {
    "id": 87,
    "text": "Wa Yawma yunfakhu fis Soori fafazi'a man fis samaawaati wa man fil ardi illaa man shaaa'al laah; wa kullun atawhu daakhireen"
  },
  {
    "id": 88,
    "text": "Wa taral jibaala tahsabuhaa jaamidatanw wa hiya tamurru marras sahaab; sun'al laahil lazeee atqana kulla shai'; innahoo khabeerun bimaa taf'aloon"
  },
  {
    "id": 89,
    "text": "Man jaaa'a bil hasanati falahoo khairun minhaa wa hum min faza'iny Yawma'izin aaminoon"
  },
  {
    "id": 90,
    "text": "Wa man jaaa'a bissai yi'ati fakubbat wujoohuhum fin Naari hal tujzawna illaa maa kuntum ta'maloon"
  },
  {
    "id": 91,
    "text": "Innamaaa umirtu an a'buda Rabba haazihil baldatil lazee harramahaa wa lahoo kullu shai'inw wa umirtu an akoona minal muslimeen"
  },
  {
    "id": 92,
    "text": "Wa an atluwal Qur-aana famanih tadaa fa innamaa yahtadee linafsihee wa man dalla faqul innamaaa ana minal munzireen"
  },
  {
    "id": 93,
    "text": "Wa qulil hamdu lillaahi sa yureekum Aayaatihee fa ta'rifoonahaa; wa maa Rabbuka bighaafilin 'ammaa ta'maloon"
  }
];

export default en;
