import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wal-Fajr"
  },
  {
    "id": 2,
    "text": "Wa layaalin 'ashr"
  },
  {
    "id": 3,
    "text": "Wash shaf'i wal watr"
  },
  {
    "id": 4,
    "text": "Wallaili izaa yasr"
  },
  {
    "id": 5,
    "text": "Hal fee zaalika qasamul lizee hijr"
  },
  {
    "id": 6,
    "text": "Alam tara kaifa fa'ala rabbuka bi'aad"
  },
  {
    "id": 7,
    "text": "Iramaa zaatil 'imaad"
  },
  {
    "id": 8,
    "text": "Allatee lam yukhlaq misluhaa fil bilaad"
  },
  {
    "id": 9,
    "text": "Wa samoodal lazeena jaabus sakhra bil waad"
  },
  {
    "id": 10,
    "text": "Wa fir'awna zil awtaad"
  },
  {
    "id": 11,
    "text": "Allazeena taghaw fil bilaad"
  },
  {
    "id": 12,
    "text": "Fa aksaroo feehal fasaad"
  },
  {
    "id": 13,
    "text": "Fasabba 'alaihim Rabbuka sawta 'azaab"
  },
  {
    "id": 14,
    "text": "Inna Rabbaka labil mirsaad"
  },
  {
    "id": 15,
    "text": "Fa ammal insaanu izaa mab talaahu Rabbuhoo fa akramahoo wa na' 'amahoo fa yaqoolu Rabbeee akraman"
  },
  {
    "id": 16,
    "text": "Wa ammaaa izaa mabtalaahu faqadara 'alaihi rizqahoo fa yaqoolu Rabbeee ahaanan"
  },
  {
    "id": 17,
    "text": "Kalla bal laa tukrimooo nal yateem"
  },
  {
    "id": 18,
    "text": "Wa laa tahaaaddoona 'alaata'aamil miskeen"
  },
  {
    "id": 19,
    "text": "Wa taakuloonat turaasa aklal lammaa"
  },
  {
    "id": 20,
    "text": "Wa tuhibboonal maala hubban jammaa"
  },
  {
    "id": 21,
    "text": "Kallaaa izaaa dukkatil ardu dakkan dakka"
  },
  {
    "id": 22,
    "text": "Wa jaaa'a Rabbuka wal malaku saffan saffaa"
  },
  {
    "id": 23,
    "text": "Wa jeee'a yawma'izim bi jahannnam; Yawma 'iziny yatazakkarul insaanu wa annaa lahuz zikraa"
  },
  {
    "id": 24,
    "text": "Yaqoolu yaa laitanee qaddamtu lihayaatee"
  },
  {
    "id": 25,
    "text": "Fa Yawma izil laa yu'azzibu 'azaabahooo ahad"
  },
  {
    "id": 26,
    "text": "Wa laa yoosiqu wasaaqa hooo ahad"
  },
  {
    "id": 27,
    "text": "Yaaa ayyatuhan nafsul mutma 'innah"
  },
  {
    "id": 28,
    "text": "Irji'eee ilaa Rabbiki raadiyatam mardiyyah"
  },
  {
    "id": 29,
    "text": "Fadkhulee fee 'ibaadee"
  },
  {
    "id": 30,
    "text": "Wadkhulee jannatee"
  }
];

export default en;
