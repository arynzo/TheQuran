import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wai lul-li kulli hu mazatil-lumaza"
  },
  {
    "id": 2,
    "text": "Al-lazi jama'a maalaw wa'addadah"
  },
  {
    "id": 3,
    "text": "Yahsabu anna maalahu akhladah"
  },
  {
    "id": 4,
    "text": "Kalla layum ba zanna fil hutamah"
  },
  {
    "id": 5,
    "text": "Wa maa adraaka mal-hutamah"
  },
  {
    "id": 6,
    "text": "Narul laahil-mooqada"
  },
  {
    "id": 7,
    "text": "Al latee tat tali'u 'alalafidah"
  },
  {
    "id": 8,
    "text": "Innaha 'alaihim moosada"
  },
  {
    "id": 9,
    "text": "Fee 'amadim-mu mad dadah"
  }
];

export default en;
