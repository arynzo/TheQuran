import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Haa Meeem"
  },
  {
    "id": 2,
    "text": "Tanzeelum Minar-Rahmaanir-Raheem"
  },
  {
    "id": 3,
    "text": "Kitaabun fussilat Aayaatuhoo Qur-aanan 'Arabiyyal liqawminy ya'lamoon"
  },
  {
    "id": 4,
    "text": "Basheeranw wa nazeeran fa-a'rada aksaruhum fahum laa yasma'oon"
  },
  {
    "id": 5,
    "text": "Wa qaaloo quloobunaa feee akinnatim mimmaa tad'oonaaa ilaihi wa feee aazaaninaa waqrunw wa mim baininaa wa bainika hijaabun fa'mal innanaa 'aamiloon"
  },
  {
    "id": 6,
    "text": "Qul innamaaa ana basharum mislukum yoohaaa ilaiya annamaaa ilaahukum Ilaahunw Waahidun fastaqeemooo ilaihi wastaghfirooh; wa wailul lil mushrikeen"
  },
  {
    "id": 7,
    "text": "Allazeena laa yu'toonaz Zakaata wa hum bil-Aakhiratihum kaafiroon"
  },
  {
    "id": 8,
    "text": "Innal lazeena aamanoo wa 'amilus saalihaati lahum ajrun ghairu mamnoon"
  },
  {
    "id": 9,
    "text": "Qul a'innakum latakfuroona billazee khalaqal arda fee yawmaini wa taj'aloona lahooo andaadaa; zaalika Rabbul 'aalameen"
  },
  {
    "id": 10,
    "text": "Wa ja'ala feehaa rawaa siya min fawqihaa wa baaraka feehaa wa qaddara feehaaaa aqwaatahaa feee arba'ati ayyaamin sawaaa'al lissaaa'ileen"
  },
  {
    "id": 11,
    "text": "Summas tawaaa ilas-samaaa'i wa hiya dukhaanun faqaala lahaa wa lil ardi'tiyaaa taw'an aw karhan qaalataaa atainaa taaa'i'een"
  },
  {
    "id": 12,
    "text": "Faqadaahunna sab'a samaawaatin fee yawmaini wa awhaa fee kulli samaaa'in amarahaa; wa zaiyannassa maaa'ad dunyaa bimasaabeeha wa hifzaa; zaalika taqdeerul 'Azeezil 'Aleem"
  },
  {
    "id": 13,
    "text": "Fa-in a'radoo faqul anzartukum saa'iqatam misla saa'iqati 'Aadinw wa Samood"
  },
  {
    "id": 14,
    "text": "Iz jaaa'at humur Rusulu mim baini aydeehim wa min khalfihim allaa ta'budooo illal laaha qaaloo law shaaa'a Rabunaa la anzala malaaa 'ikatan fa innaa bimaaa ursiltum bihee kaafiroon"
  },
  {
    "id": 15,
    "text": "Fa ammaa 'Aadun fastak baroo fil ardi bighairul haqqi wa qaaloo man ashaddu minnaa quwwatan awalam yaraw annal laahal lazee khalaqahum Huwa ashaddu minhum quwwatanw wa kaanoo bi Aayaatinaa yajhadoon"
  },
  {
    "id": 16,
    "text": "Fa arsalnaa 'alaihim reehan sarsaran feee ayyaamin nahisaatil linuzeeqahum 'azaabal khizyi fil hayaatid dunyaa wa la'azaabul Aakhirati akhzaa wa hum laa yunsaroon"
  },
  {
    "id": 17,
    "text": "Wa ammaa Samoodu fahadinaahum fastahabbul 'ama 'alal huda fa akhazathum saa'iqatul 'azaabil hooni bimaa kaanoo yaksiboon"
  },
  {
    "id": 18,
    "text": "Wa najjainal lazeena aamanoo wa kaanoo yattaqoon"
  },
  {
    "id": 19,
    "text": "Wa yawma yuhsharu a'daaa'ul laahi ilan Naari fahum yooza'oon"
  },
  {
    "id": 20,
    "text": "Hattaaa izaa maa jaaa'oohaa shahida 'alaihim samu'uhum wa absaaruhum wa julooduhum bimaa kaanoo ya'maloon"
  },
  {
    "id": 21,
    "text": "Wa qaaloo lijuloodihim lima shahittum 'alainaa qaaloo antaqanal laahul lazeee antaqa kulla shai'inw wa Huwa khalaqakum awwala marratinw wa ilaihi turja'oon"
  },
  {
    "id": 22,
    "text": "Wa maa kuntum tastatiroona ai-yashhada 'alaikum sam'ukum wa laaa absaarukum wa laa juloodukum wa laakin zanantum annal laaha laa ya'lamu kaseeram mimmaa ta'maloon"
  },
  {
    "id": 23,
    "text": "Wa zaalikum zannukumul lazee zanantum bi-Rabbikum ardaakum fa asbahtum minal khaasireen"
  },
  {
    "id": 24,
    "text": "Fa-iny yasbiroo fan Naaru maswal lahum wa iny-yasta'tiboo famaa hum minal mu'tabeen"
  },
  {
    "id": 25,
    "text": "Wa qaiyadnaa lahum quranaaa'a fazaiyanoo lahum maa baina aideehim wa maa khalfahum wa haqqa 'alaihimul qawlu feee umamin qad khalat min qablihim minal jinni wal insi innahum kaanoo khaasireen"
  },
  {
    "id": 26,
    "text": "Wa qaalal lazeena kafaroo laa tasma'oo lihaazal Quraani walghaw feehi la'allakum taghliboon"
  },
  {
    "id": 27,
    "text": "Falanuzeeqannal lazeena kafaroo 'azaaban shadeedanw wa lanajziyannahum aswallazee kaanoo ya'maloon"
  },
  {
    "id": 28,
    "text": "Zaalika jazaaa'u a'daaa'il laahin Naaru lahum feehaa daarul khuld, jazaaa'am bimaa kaanoo bi aayaatinaa yajhadoon"
  },
  {
    "id": 29,
    "text": "Wa qaalal lazeena kafaroo Rabbanaaa arinal lazaini adal laanaa minal jinni wal insi naj'alhumaa tahta aqdaaminaa liyakoonaa minal asfaleen"
  },
  {
    "id": 30,
    "text": "Innal lazeena qaaloo Rabbunal laahu summas taqaamoo tatanazzalu 'alaihimul malaaa 'ikatu allaa takhaafoo wa laa tahzanoo wa abshiroo bil Jannnatil latee kuntum too'adoon"
  },
  {
    "id": 31,
    "text": "Nahnu awliyaaa'ukum fil hayaatid dunyaa wa fil Aakhirati wa lakum feehaa maa tashtaheee anfusukum wa lakum feehaa ma tadda'oon"
  },
  {
    "id": 32,
    "text": "Nuzulam min Ghafoorir Raheem"
  },
  {
    "id": 33,
    "text": "Wa man ahsanu qawlam mimman da'aaa ilal laahi wa 'amila saalihanw wa qaala innanee minal muslimeen"
  },
  {
    "id": 34,
    "text": "Wa laa tastawil hasanatu wa las saiyi'ah; idfa' billatee hiya ahsanu fa'izal lazee bainaka wa bainahoo 'adaawatun ka'annahoo waliyun hameem"
  },
  {
    "id": 35,
    "text": "Wa maa yulaqqaahaaa illal lazeena sabaroo wa maa yulaqqaahaaa illaa zoo hazzin 'azeem"
  },
  {
    "id": 36,
    "text": "Wa immaa yanzaghannaka minash Shaitaani nazghun fasta'iz billaahi innahoo Huwas Samee'ul 'Aleem"
  },
  {
    "id": 37,
    "text": "Wa min Aayaatihil lailu wannahaaru washshamsu walqamar; laa tasjudoo lishshamsi wa laa lilqamari wasjudoo lillaahil lazee khala qahunna in kuntum iyyaahu ta'budoon"
  },
  {
    "id": 38,
    "text": "Fa inis-takbaroo fallazee na 'inda Rabbika yusabbihoona lahoo billaili wannnahaari wa hum laa yas'amoon"
  },
  {
    "id": 39,
    "text": "Wa min Aayaatiheee annaka taral arda khaashi'atan fa izaaa anzalna 'alaihal maaa'ah tazzat wa rabat; innal lazeee ahyaahaa lamuhiyil mawtaa; innahoo 'alaa kulli shai-in Qadeer"
  },
  {
    "id": 40,
    "text": "Innal lazeena yulhidoona feee Aayaatina laa yakhfawna 'alainaa' afamai yulqaa fin Naari khayrun am mai yaateee aaminai Yawmal Qiyaamah; i'maloo ma shi'tum innahoo bimaa ta'maloona Baseer"
  },
  {
    "id": 41,
    "text": "Innal Lazeena kafaroo biz Zikri lammaa jaa'ahum wa innahoo la Kitaabun 'Azeez"
  },
  {
    "id": 42,
    "text": "Laa yaateehil baatilu mim baini yadaihi wa laa min khalfihee tanzeelum min Hakeemin Hameed"
  },
  {
    "id": 43,
    "text": "Maa yuqaalu laka illaa maa qad qeela lir Rusuli min qablik; inna Rabbaka lazoo maghfiratinw wa zoo 'iqaabin aleem"
  },
  {
    "id": 44,
    "text": "Wa law ja'alnaahu Qur-aanan A'jamiyyal laqaaloo law laa fussilat Aayaatuhoo 'a A'jamiyyunw wa 'Arabiyy; qul huwa lillazeena aamanoo hudanw wa shifaaa'unw wallazeena la yu'minoona feee aazaanihim waqrunw wa huwa 'alaihim 'amaa; ulaaa'ika yunaadawna mim maakaanim ba'eed"
  },
  {
    "id": 45,
    "text": "Wa laqad aatainaa Moosal Kitaaba fakhtulifa fee; wa lawlaa Kalimatun sabaqat mir Rabbika laqudiya bainahum; wa innahum lafee shakkim minhu mureeb"
  },
  {
    "id": 46,
    "text": "Man 'amila salihan falinafsihee wa man asaaa'a fa'alaihaa; wamaa rabbuka bizallaamil lil 'abeed"
  },
  {
    "id": 47,
    "text": "Ilaihi yuraddu 'ilmus Saaa'ah; wa maa takhruju min samaraatim min akmaamihaa wa maa tahmilu min unsaa wa laa tada'u illaa bi'ilmih; wa Yawma yunaadeehim aina shurakaaa'ee qaalooo aazannaaka maa minnaa min shaheed"
  },
  {
    "id": 48,
    "text": "Wa dalla 'anhum maa kaanoo yad'oona min qablu wa zannoo maa lahum mim mahees"
  },
  {
    "id": 49,
    "text": "Laa yas'amul insaanu min du'aaa'il khairi wa im massa hush sharru fa ya'oosun qanoot"
  },
  {
    "id": 50,
    "text": "Wa la in azaqnaahu rahmatam minnaa mim ba'di dar raaa'a massat hu la yaqoolanna haazaa lee wa maaa azunnus Saa'ata qaaa'imatanw wa la'in ruji'tu ilaa Rabbeee inna lee 'indahoo lalhusnaa; falanu nabbi'annal lazeena kafaroo bimaa 'amiloo wa lanuzeeqan nahum min 'azaabin ghaleez"
  },
  {
    "id": 51,
    "text": "Wa izaaa an'amnaa 'alal insaani a'rada wa na-aa bijaani bihee wa izaa massahush sharru fazoo du'aaa'in 'areed"
  },
  {
    "id": 52,
    "text": "Qul araaitum in kaana min 'indil laahi summa kafar tum bihee man adallu mimman huwa fee shiqaqim ba'eed"
  },
  {
    "id": 53,
    "text": "Sanureehim Aayaatinaa fil aafaaqi wa feee anfusihim hattaa yatabaiyana lahum annahul haqq; awa lam yakfi bi Rabbika annahoo 'alaa kulli shai-in Shaheed"
  },
  {
    "id": 54,
    "text": "Alaaa innahum fee miryatim mil liqaaa'i Rabbihim; alaaa innahoo bikulli shai'im muheet"
  }
];

export default en;
