import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Qul huwal laahu ahad"
  },
  {
    "id": 2,
    "text": "Allah hus-samad"
  },
  {
    "id": 3,
    "text": "Lam yalid wa lam yoolad"
  },
  {
    "id": 4,
    "text": "Wa lam yakul-lahoo kufuwan ahad"
  }
];

export default en;
