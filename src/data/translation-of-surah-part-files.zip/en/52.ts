import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wat-Toor"
  },
  {
    "id": 2,
    "text": "Wa kitaabim mastoor"
  },
  {
    "id": 3,
    "text": "Fee raqqim manshoor"
  },
  {
    "id": 4,
    "text": "Wal baitil ma'moor"
  },
  {
    "id": 5,
    "text": "Wassaqfil marfoo'"
  },
  {
    "id": 6,
    "text": "Wal bahril masjoor"
  },
  {
    "id": 7,
    "text": "Inna 'azaaba Rabbika lawaaqi'"
  },
  {
    "id": 8,
    "text": "Maa lahoo min daafi'"
  },
  {
    "id": 9,
    "text": "Yawma tamoorus samaaa'u mawraa"
  },
  {
    "id": 10,
    "text": "Wa taseerul jibaalu sairaa"
  },
  {
    "id": 11,
    "text": "Fawailuny yawma 'izil lil mukaazzibeen"
  },
  {
    "id": 12,
    "text": "Allazeena hum fee khawdiny yal'aboon"
  },
  {
    "id": 13,
    "text": "Yawma yuda'-'oona ilaa naari jahannama da'-'aa"
  },
  {
    "id": 14,
    "text": "Haazihin naarul latee kuntum bihaa tukazziboon"
  },
  {
    "id": 15,
    "text": "Afasihrun haazaaaa am antum laa tubsiroon"
  },
  {
    "id": 16,
    "text": "Islawhaa fasbirooo aw laa tasbiroo sawaaa'un 'alaikum innamaa tujzawna maa kuntum ta'maloon"
  },
  {
    "id": 17,
    "text": "Innal muttaqeena fee jannaatinw wa na'eem"
  },
  {
    "id": 18,
    "text": "Faakiheena bimaaa aataahum rabbuhum wa waqaahum rabbuhum 'azaabal jaheem"
  },
  {
    "id": 19,
    "text": "Kuloo washraboo haneee 'am bimaa kuntum ta'maloon"
  },
  {
    "id": 20,
    "text": "Muttaki'eena 'alaa sururim masfoofatinw wa zawwaj naahum bihoorin 'een"
  },
  {
    "id": 21,
    "text": "Wallazeena aamanoo wattaba'at hum zurriyyatuhum bieemaanin alhaqnaa bihim zurriyyatahum wa maaa alatnaahum min 'amalihim min shai'; kullum ri'im bimaa kasaba raheen"
  },
  {
    "id": 22,
    "text": "Wa amdadnaahum bifaa kihatinw wa lahmim mimmaa yashtahoon"
  },
  {
    "id": 23,
    "text": "Yatanaaza'oona feehaa kaasal laa laghwun feehaa wa laa taaseem"
  },
  {
    "id": 24,
    "text": "Wa yatoofu 'alaihim ghilmaanul lahum ka annahum lu'lu'um maknoon"
  },
  {
    "id": 25,
    "text": "Wa aqbala ba'duhum 'alaa ba'diny yatasaaa'aloon"
  },
  {
    "id": 26,
    "text": "Qaalooo innaa kunnaa qablu feee ahlinaa mushfiqeen"
  },
  {
    "id": 27,
    "text": "Famannnal laahu 'alainaa wa waqaanaa 'azaabas samoom"
  },
  {
    "id": 28,
    "text": "Innaa kunnaa min qablu nad'oohu innahoo huwal barrur raheem"
  },
  {
    "id": 29,
    "text": "Fazakkir famaaa anta bini'mati rabbika bikaahininw wa laa majnoon"
  },
  {
    "id": 30,
    "text": "Am yaqooloona shaa'irun natarabbasu bihee raibal manoon"
  },
  {
    "id": 31,
    "text": "Qul tarabbasoo fa innee ma'akum minal mutarabbiseen"
  },
  {
    "id": 32,
    "text": "Am taamuruhum ahlaamuhum bihaazaaa am hum qawmun taaghoon"
  },
  {
    "id": 33,
    "text": "Am yaqooloona taqawwalah; bal laa yu'minoon"
  },
  {
    "id": 34,
    "text": "Falyaatoo bihadeesim misliheee in kaanoo saadiqeen"
  },
  {
    "id": 35,
    "text": "Am khuliqoo min ghairi shai'in am humul khaaliqoon"
  },
  {
    "id": 36,
    "text": "Am khalaqus samaawaati wal ard; bal laa yooqinoon"
  },
  {
    "id": 37,
    "text": "Am'indahum khazaaa'inu rabbika am humul musaitiroon"
  },
  {
    "id": 38,
    "text": "Am lahum sullamuny yastami'oona feehi falyaati mustami'uhum bisultaanim mubeen"
  },
  {
    "id": 39,
    "text": "Am lahul banaatu wa lakumul banoon"
  },
  {
    "id": 40,
    "text": "Am tas'aluhum ajran fahum mim maghramim musqaloon"
  },
  {
    "id": 41,
    "text": "Am 'indahumul ghaibu fahum yaktuboon"
  },
  {
    "id": 42,
    "text": "Am yureedoona kaidan fallazeena kafaroo humul makeedoon"
  },
  {
    "id": 43,
    "text": "Am lahum ilaahun ghairul laa; subhaanal laahi 'ammaa yushrikoon"
  },
  {
    "id": 44,
    "text": "Wa iny yaraw kisfam minas samaaa'i saaqitany yaqooloo sahaabum markoom"
  },
  {
    "id": 45,
    "text": "Fazarhum hatta yulaaqoo yawmahumul lazee feehi yus'aqoon"
  },
  {
    "id": 46,
    "text": "Yawma laa yughnee 'anhum kaiduhum shai'anw wa laa hum yunsaroon"
  },
  {
    "id": 47,
    "text": "Wa inna lillazeena zalamoo 'azaaban doona zalika wa laakinna aksarahum laa ya'lamoon"
  },
  {
    "id": 48,
    "text": "Wasbir lihukmi rabbika fa innaka bi-a'yuninaa wa sabbih bihamdi rabbika heena taqoom"
  },
  {
    "id": 49,
    "text": "Wa minal laili fasabbihhu wa idbaaran nujoom"
  }
];

export default en;
