import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alhamdu lillaahil lazee khalaqas samaawaati wal arda wa ja'alaz zulumaati wannoor; summal lazeena kafaroo bi Rabbihim ya'diloon"
  },
  {
    "id": 2,
    "text": "Huwal lazee khalaqakum min teenin summa qadaaa ajalanw wa ajalum musamman 'indahoo summa antum tamtaroon"
  },
  {
    "id": 3,
    "text": "Wa Huwal laahu fissamaawaati wa fil ardi ya'lamu sirrakum wa jahrakum wa ya'lamu maa taksiboon"
  },
  {
    "id": 4,
    "text": "Wa maa ta'teehim min Aayatim min Aayaati Rabbihim illaa kaanoo 'anhaa mu'rideen"
  },
  {
    "id": 5,
    "text": "Faqad kazzaboo bilhaqqi lammaa jaaa'ahum fasawfa ya'teehim ambaaa'u maa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 6,
    "text": "Alam yaraw kam ahlaknaa min qablihim min qarnim makkannaahum fil ardi maa lam numakkil lakum wa arsalnas samaaa'a 'alaihim midraaranw wa ja'alnal anhaara tajree min tahtihim fa ahlak naahum bizunoobihim wa ansha'naa mim ba'dihim qarnan aakhareen"
  },
  {
    "id": 7,
    "text": "Wa law nazzalnaa 'alaika Kitaaban fee qirtaasin falamasoohu bi aideehim laqaalal lazeena kafarooo in haazaaa illaa sihrum mubeen"
  },
  {
    "id": 8,
    "text": "Wa qaaloo law laaa unzila alaihi malakunw wa law anzalna malakal laqudiyal amru summa laa yunzaroon"
  },
  {
    "id": 9,
    "text": "Wa law ja'alnaahu malakal laja'alnaahu rajulanw wa lalabasnaa 'alaihim maa yalbisoon"
  },
  {
    "id": 10,
    "text": "Wa laqadis tuhzi'a bi-Rusulim min qablika fahaaqa billazeena sakhiroo minhum maa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 11,
    "text": "Qul seeroo fil ardi summan zuroo kaifa kaana 'aaqibatul mukazzibeen"
  },
  {
    "id": 12,
    "text": "Qul limam maa fis samaawaati wal ardi qul lillaah; kataba 'alaa nafsihir rahmah; la yajma 'annakum ilaa Yawmil Qiyaamati laa raiba feeh; allazeena khasirooo anfusahum fahum laa yu'minoon"
  },
  {
    "id": 13,
    "text": "Wa lahoo maa sakana fillaili wannahaar; wa Huwas Samee'ul Aleem"
  },
  {
    "id": 14,
    "text": "Qul aghairal laahi attakhizu waliyyan faatiris samaawaati wal ardi wa Huwa yut'imu wa laa yut'am; qul inneee umirtu an akoona awwala man aslama wa laa takoonanna minal mushrikeen"
  },
  {
    "id": 15,
    "text": "Qul inneee akhaafu in 'asaitu Rabbee 'azaaba Yawmin 'Azeem"
  },
  {
    "id": 16,
    "text": "Mai yusraf 'anhu Yawma'izin faqad rahimah; wa zaalikal fawzul mubeen"
  },
  {
    "id": 17,
    "text": "Wa iny-yamsaskal laahu bidurrin falaaa kaashifa lahoo illaa Huwa wa iny-yamsaska bikhairin fa Huwa 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 18,
    "text": "Wa Huwal qaahiru fawqa 'ibaadih; wa Huwal Hakeemul Khabeer"
  },
  {
    "id": 19,
    "text": "Qul ayyu shai'in akbaru shahaadatan qulil laahu shaheedum bainee wa bainakum; wa oohiya ilaiya haazal Qur'aanu li unzirakum bihee wa man balagh; a'innakum latashhadoona anna ma'al laahi aalihatan ukhraa; qul laaa ashhad; qul innamaa Huwa Ilaahunw Waahidunw wa innanee baree'um mimmaa tushrikoon"
  },
  {
    "id": 20,
    "text": "Allazeena aatainaa humul Kitaaba ya'rifoonahoo kamaa ya'rifoona abnaaa'ahum; allazeena khasirooo anfusahum fahum laa yu'minoon"
  },
  {
    "id": 21,
    "text": "Wa man azlamu mim manif tara 'alal laahi kaziban aw kazzaba bi Aayaatih; innahoo laa yuflihuz zaalimoon"
  },
  {
    "id": 22,
    "text": "Wa yawma nahshuruhum jamee'an summa naqoolu lillazeena ashrakooo ayna shurakaaa' ukumul lazeena kuntum taz'umoon"
  },
  {
    "id": 23,
    "text": "Summa lam takun fitnatuhum illaaa an qaaloo wallaahi Rabbinaa maa kunnaa mushrikeen"
  },
  {
    "id": 24,
    "text": "Unzur kaifa kazaboo 'alaaa anfusihim, wa dalla 'anhum maa kaanoo yaftaroon"
  },
  {
    "id": 25,
    "text": "Wa minhum mai yastami'u ilaika wa ja'alnaa 'alaa quloobihim akinnatan ai yafqahoohu wa feee aazaanihim waqraa; wa ai yaraw kulla Aayatil laa yu'minoo bihaa; hattaaa izaa jaaa'ooka yujaadiloonaka yaqoolul lazeena kafaroo in haazaa illaaa asaateerul awwaleen"
  },
  {
    "id": 26,
    "text": "Wa hum yanhawna 'anhu wa yan'awna 'anhu wa iny yuhlikoona illaa anfusahum wa maa yash'uroon"
  },
  {
    "id": 27,
    "text": "Wa law taraaa iz wuqifoo 'alan Naari faqaaloo yaa laitanaa nuraddu wa laa nukaz ziba bi Aayaati Rabbinaa wa nakoona minal mu'mineen"
  },
  {
    "id": 28,
    "text": "Bal badaa lahum maa kaanoo yukhfoona min qablu wa law ruddoo la'aadoo limaa nuhoo 'anhu wa innahum lakaaziboon"
  },
  {
    "id": 29,
    "text": "Wa qaalooo in hiya illaa hayaatunad dunyaa wa maa nahnu bimab'ooseen"
  },
  {
    "id": 30,
    "text": "Wa law taraa iz wuqifoo 'alaa Rabbihim; qaala alaisa haazaa bilhaqq; qaaloo balaa wa Rabbinaa; qaala fazooqul 'azaaba bimaa kuntum takfuroon"
  },
  {
    "id": 31,
    "text": "Qad khasiral lazeena kazzaboo biliqaaa'il laahi hattaaa izaa jaaa'at humus Saa'atu baghtatan qaaloo yaa hasratanaa 'alaa maa farratnaa feehaa wa hum yahmiloona awzaarahum 'alaa zuhoorihim; alaa saaa'a ma yaziroon"
  },
  {
    "id": 32,
    "text": "Wa mal hayaatud dunyaaa illaa la'ibunw wa lahwunw wa lad Daarul Aakhiratu khaiyrul lillazeena yattaqoon; afalaa ta'qiloon"
  },
  {
    "id": 33,
    "text": "Qad na'lamu innahoo layahzunukal lazee yaqooloona fa innahum laa yukazziboonaka wa laakinnaz zaalimeena bi Aayaatil laahi yajhadoon"
  },
  {
    "id": 34,
    "text": "Wa laqad kuzzibat Rusulum min qablika fasabaroo 'alaa maa kuzziboo wa oozoo hattaaa ataahum nasrunaa; wa laa mubaddila li Kalimaatil laah; wa laqad jaaa'aka min naba'il mursaleen"
  },
  {
    "id": 35,
    "text": "Wa in kaana kabura 'alaika i'raaduhum fa inistata'ta an tabtaghiya nafaqan fil ardi aw sullaman fis samaaa'i fata' tiyahum bi Aayah; wa law shaaa'al laahu lajama'ahum 'alal hudaa; falaa takoonanna minal jaahileen"
  },
  {
    "id": 36,
    "text": "Innamaa yastajeebul lazeena yasma'oon; walmawtaa yab'asuhumul laahu summa ilaihi yurja'oon"
  },
  {
    "id": 37,
    "text": "Wa qaaloo law laa nuzzila 'alaihi Aayatum mir Rabbih; qul innal laaha qaadirun 'alaaa ai yunazzila Aayatanw wa laakinna aksarahum laa ya'lamoon"
  },
  {
    "id": 38,
    "text": "Wa maa min daaabbatin fil ardi wa laa taaa'iriny yateeru bijanaahaihi illaaa umamun amsaalukum; maa farratnaa fil Kitaabi min shaiyy' summa ilaa Rabbihim yuhsharoon"
  },
  {
    "id": 39,
    "text": "Wallazeena kazzaboo bi Aayaatinaa summunw wa bukmun fiz zulumaat; mai yasha il laahu yudlillhu; wa mai yashaa yaj'alhu 'alaa Siraatim Mustaqeem"
  },
  {
    "id": 40,
    "text": "Qul ara'aytakum in ataakum 'azaabul laahi aw atatkumus Saa'atu a-ghairal laahi tad'oona in kuntum saadiqeen"
  },
  {
    "id": 41,
    "text": "Bal iyyaahu tad'oona fa yakshifu maa tad'oona ilaihi in shaaa'a wa tansawna maa tushrikoon"
  },
  {
    "id": 42,
    "text": "Wa laqad arsalnaaa ilaaa umamim min qablika fa akhaznaahum bil ba'saaa'i waddarraaa'i la'allahum yata darra'oon"
  },
  {
    "id": 43,
    "text": "Falaw laaa iz jaaa'ahum ba'sunaa tadarra'oo wa laakin qasat quloobuhum wa zaiyana lahumush Shaitaanu maa kaanoo ya'maloon"
  },
  {
    "id": 44,
    "text": "Falammaa nasoo maa zukkiroo bihee fatahnaa 'alaihim abwaaba kulli shai'in hattaaa izaa farihoo bimaaa ootooo akhaznaahum baghtatan fa izaa hum mublisoon"
  },
  {
    "id": 45,
    "text": "Faquti'a daabirul qawmil lazeena zalamoo; walhamdu lillaahi Rabbil 'aalameen"
  },
  {
    "id": 46,
    "text": "Qul ara'aitum in akhazal laahu sam'akum wa absaarakum wa khatama 'alaa quloobikum man ilaahun ghairul laahi ya'teekum bih; unzur kaifa nusarriful Aayaati summa hum yasdifoon"
  },
  {
    "id": 47,
    "text": "Qul ara'aitakum in ataakum 'azaabul laahi baghtatan aw jahratan hal yuhlaku illal qawmuz zaalimoon"
  },
  {
    "id": 48,
    "text": "Wa maa nursilul mursaleena illaa mubashshireena wa munzireena faman aamana wa aslaha falaa khawfun 'alaihim wa laa hum yahzanoon"
  },
  {
    "id": 49,
    "text": "Wallazeena kazzaboo bi Aayaatinaa yamassuhumul 'azaabu bimaa kaanoo yafsuqoon"
  },
  {
    "id": 50,
    "text": "Qul laaa aqoolu lakum 'indee khazaaa'inul laahi wa laaa a'lamul ghaiba wa laaa aqoolu lakum innee malakun in attabi'u illaa maa yoohaaa ilaiy; qul hal yastawil a'maa walbaseer; afalaa tatafakkaroon"
  },
  {
    "id": 51,
    "text": "Wa anzir bihil lazeena yakhaafoona ai yuhsharooo ilaa Rabbihim laisa lahum min doonihee waliyyunw wa laa shafee'ul la'allahum yattaqoon"
  },
  {
    "id": 52,
    "text": "Wa laa tatrudil lazeena yad'oona Rabbahum bilghadaati wal 'ashiyyi yureedoona Wajhahoo ma 'alaika min hisaabihim min shai'inw wa maa min hisaabika 'alaihim min shai'in fatatrudahum fatakoona minaz zaalimeen"
  },
  {
    "id": 53,
    "text": "Wa kazaalika fatannaa ba'dahum biba'dil liyaqoolooo ahaaa'ulaaa'i mannal laahu 'alaihim mim baininaa; alaisal laahu bi-a'lama bish shaakireen"
  },
  {
    "id": 54,
    "text": "Wa izaa jaaa'akal lazeena yu'minoona bi Aayaatinaa faqul salaamun 'alaikum kataba Rabbukum 'alaa nafsihir rahmata annahoo man 'amila minkum sooo'am bijahaalatin summa taaba mim ba'dihee wa aslaha fa annahoo Ghafoorur Raheem"
  },
  {
    "id": 55,
    "text": "Wa kazaalika nufassilul Aayaati wa litastabeena sabeelul mujrimeen"
  },
  {
    "id": 56,
    "text": "Qul innee nuheetu an a'budal lazeena tad'oona min doonil laah; qul laaa attabi'u ahwaaa'akum qad dalaltu izanw wa maaa ana minal muhtadeen"
  },
  {
    "id": 57,
    "text": "Qul innee 'alaa baiyinatim mir Rabbee wa kazzabtum bih; maa 'indee maa tasta'jiloona bih; inil hukmu illaa lillaahi yaqussul haqqa wa Huwa khairul faasileen"
  },
  {
    "id": 58,
    "text": "Qul law anna 'indee maa tasta'jiloona bihee laqudiyal amru bainee wa bainakum; wallaahu a'lamu bizzaalimeen"
  },
  {
    "id": 59,
    "text": "Wa 'indahoo mafaatihul ghaibi laa ya'lamuhaaa illaa Hoo; wa ya'lamu maa fil barri walbahr; wa maa tasqutu minw waraqatin illaa ya'lamuhaa wa laa habbatin fee zulumaatil ardi wa laa ratbinw wa laa yaabisin illaa fee Kitaabim Mubeen"
  },
  {
    "id": 60,
    "text": "Wa Huwal lazee yatawaf faakum billaili wa ya'lamu maa jarahtum binnahaari summa yab'asukum feehee liyuqdaaa ajalum musamman summa ilaihi marji'ukum summa yunabbi 'ukum bimaa kuntum ta'maloon"
  },
  {
    "id": 61,
    "text": "Wa huwal qaahiru fawqa 'ibaadihee wa yursilu 'alaikum hafazatan hattaaa izaa jaaa'a ahadakumul mawtu tawaffathu rusulunaa wa hum laa yufarritoon"
  },
  {
    "id": 62,
    "text": "Summa ruddooo ilallaahi mawlaahumul haqq; alaa lahul hukmu wa Huwa asra'ul haasibeen"
  },
  {
    "id": 63,
    "text": "Qul mai yunajjeekum min zulumaatil barri walbahri tad'oonahoo tadarru'anw wa khufyatal la'in anjaanaa min haazihee lanakoonanna minash shaakireen"
  },
  {
    "id": 64,
    "text": "Qulil laahu yunajjjeekum minhaa wa min kulli karbin summa antum tushrikoon"
  },
  {
    "id": 65,
    "text": "Qul huwal Qaadiru 'alaaa ai yab'asa 'alaikum 'azaabam min fawqikum aw min tahti arjulikum aw yalbisakum shiya'anw wa yuzeeqa ba'dakum ba'sa ba'd; unzur kaifa nusarriful Aayaati la'allahum yafqahoon"
  },
  {
    "id": 66,
    "text": "Wa kaz zaba bihee qawmuka wa huwal haqq; qul lastu'alaikum biwakeel"
  },
  {
    "id": 67,
    "text": "Likulli naba im mustaqar runw wa sawfa ta'lamoon"
  },
  {
    "id": 68,
    "text": "Wa izaa ra aital lazeena yakhoodoona feee Aayaatinaa fa a'rid 'anhum hattaa yakkhoodoo fee hadeesin ghairih; wa immaa yunsiyannakash Shaitaanu falaa taq'ud ba'dazzikraa ma'al qawmiz zaalimeen"
  },
  {
    "id": 69,
    "text": "Wa maa 'alal lazeena yattaqoona min hisaabihim min shai'inw wa laakin zikraa la'allahum yattaqoon"
  },
  {
    "id": 70,
    "text": "Wa zaril lazeenat takhazoo deenahum la'ibanwwa lahwanw wa gharrat humul ha yaatud dunyaa; wa zakkir biheee an tubsala nafsum bimaa kasabat laisa lahaa min doonil laahi waliyyunw wa laa shafee'unw wa in ta'dil kulla 'adlil laa yu'khaz minhaa; ulaaa 'ikal lazeena ubsiloo bimaa kasaboo lahum sharaabum min hameeminw wa 'azaabun aleemum bimaa kaanoo yakkfuroon"
  },
  {
    "id": 71,
    "text": "Qul anad'oo min doonil laahi maa laa yanfa'unaa wa laa yadurrunaa wa nuraddu 'alaaa a'qaabina ba'da iz hadaanal laahu kallazis tahwat hush Shayaateenu fil ardi hairaana lahooo ashaabuny yad'oo nahooo ilal huda' tinaa; qul inna hudal laahi huwal hudaa wa umirnaa linuslima li Rabbil 'aalameen"
  },
  {
    "id": 72,
    "text": "Wa an aqeemus Salaata wattaqooh; wa Huwal lazeee ilaihi tuhsharoon"
  },
  {
    "id": 73,
    "text": "Wa Huwal lazee khalaqas samaawaati wal arda bilhaqq; wa Yawma yaqoolu kun fa yakoon; Qawluhul haqq; wa lahul mulku Yawma yunfakhu fis Soor; 'Aalimul Ghaibi wash shahaadah; wa Huwal Hakeemul Khabeer"
  },
  {
    "id": 74,
    "text": "Wa iz qaala Ibraaheemu li abeehi Aazara a-tattakhizu asnaaman aalihatan inneee araaka wa qawmaka fee dalaalim mubeen"
  },
  {
    "id": 75,
    "text": "Wa kazaalika nureee Ibraaheema malakootas samaawaati wal ardi wa liyakoona minal mooqineen"
  },
  {
    "id": 76,
    "text": "Falammaa janna 'alaihil lailu ra aa kawkabaan qaala haaza Rabbee falammaaa afala qaala laaa uhibbul aafileen"
  },
  {
    "id": 77,
    "text": "Falammmaa ra al qamara baazighan qaala haazaa Rabbee falammaaa afala qaala la'il lam yahdinee Rabbee la akoonanna minal qawmid daaalleen"
  },
  {
    "id": 78,
    "text": "Falammaa ra ashshamsa baazighatan qaala haazaa Rabbee haazaaa akbaru falammaaa afalat qaala yaa qawmi innee bareee'um mimmaa tushrikoon"
  },
  {
    "id": 79,
    "text": "Innnee wajjahtu wajhiya lillazee fataras samaawaati wal arda haneefanw wa maaa ana minal mushrikeen"
  },
  {
    "id": 80,
    "text": "Wa haaajjahoo qawmuh; qaala a-tuh'haaajjooonnee fillaahi wa qad hadaan; wa laaa akhaafu maa tushrikoona bihee illaaa ai yashaaa'a Rabbee shai'anw wasi'a Rabbee kulla shai'in 'ilman afalaa tatazakkaroon"
  },
  {
    "id": 81,
    "text": "Wa kaifa akhaafu maaa ashraktum wa laa takhaafoona annakum ashraktum billaahi maa lam yunazzil bihee 'alaikum sultaanaa; fa aiyul fareeqaini ahaqqu bil amni in kuntum ta'lamoon"
  },
  {
    "id": 82,
    "text": "Allazeena aamanoo wa lam yalbisooo eemaanahum bizulmin ulaaa'ika lahumul amnu wa hum muhtadoon"
  },
  {
    "id": 83,
    "text": "Wa tilka hujjatunaaa aatainaahaaa Ibraaheema 'alaa qawmih; narfa'u darajaatim man nashaaa'; inna Rabbaka Hakeemun 'Aleem"
  },
  {
    "id": 84,
    "text": "Wa wahabnaa lahoo ishaaqa wa ya'qoob; kullan hadainaa; wa Noohan hadainaa min qablu wa min zurriyyatihee Daawooda wa Sulaimaana wa Ayyooba wa Yoosufa wa Moosaa wa Haaroon; wa kazaalika najzil muhsineen"
  },
  {
    "id": 85,
    "text": "Wa Zakariyyaa wa Yahyaa wa 'Eesaa wa Illyaasa kullum minas saaliheen"
  },
  {
    "id": 86,
    "text": "Wa Ismaa'eela wal Yasa'a wa Yoonusa wa Lootaa; wa kullan faddalnaa 'alal 'aalameen"
  },
  {
    "id": 87,
    "text": "Wa min aabaaa'ihim wa zurriyyaatihim wa ikhwaanihim wajtabainaahum wa hadainaahum ilaa Siraatim Mustaqeem"
  },
  {
    "id": 88,
    "text": "Zaalika hudal laahi yahdee bihee mai yashaaa'u min 'ibaadih; wa law ashrakoo lahabita 'anhum maa kaanoo ya'maloon"
  },
  {
    "id": 89,
    "text": "Ulaaa'ikal lazeena aatainaahumul Kitaaba wal hukma wan Nubuwwah; fa iny yakfur bihaa haaa'ulaaa'i faqad wakkalnaa bihaa qawmal laisoo bihaa bikaafireen"
  },
  {
    "id": 90,
    "text": "Ulaaa'ikal lazeena hadal laahu fabihudaahumuq tadih; qul laaa as'alukum 'alaihi ajran in huwa illaa zikraa lil 'aalameen"
  },
  {
    "id": 91,
    "text": "Wa maa qadarul laaha haqqa qadriheee iz qaaloo maaa anzalal laahu 'alaa basharim min shai'; qul man anzalal Kitaabal lazee jaaa'a bihee Moosaa nooranw wa hudal linnaasi taj'aloonahoo qaraateesa tubdoonahaa wa tukhfoona kaseeranw wa 'ullimtum maa lam ta'lamooo antum wa laaa aabaaa'ukum qulil laahu summa zarhum fee khawdihim yal'aboon"
  },
  {
    "id": 92,
    "text": "Wa haazaa Kitaabun anzalnaahu Mubaarakum musaddiqul lazee bainaa yadaihi wa litunzira ummal Quraa wa man hawlahaa; wallazeena yu'minoona bil Aakhirati yu'minoona bihee wa hum'alaa Salaatihim yuhaafizoon"
  },
  {
    "id": 93,
    "text": "Wa man azlamu mimmanif taraa 'alal laahi kaziban aw qaala oohiya ilaiya wa lam yooha ilaihi shai'un wa man qaala sa unzilu misla maaa anzalal laah; wa law taraaa iziz zaalimoona fee ghamaraatil mawti walmalaaa'ikatu baasitooo aideehim akhrijooo anfusakum; al yawma tujzawna 'azaabal hooni bimaa kuntum taqooloona 'alal laahi ghairal haqqi wa kuntum 'an aayaatihee tastakbiroon"
  },
  {
    "id": 94,
    "text": "Wa laqad ji'tumoonaa furaadaa kamaa khalaqnaakum awwala marratinw wa taraktum maa khawwalnaakum waraaa'a zuhoorikum wa maa naraa ma'akum shufa'aaa' akumul lazeena za'amtum annahum feekum shurakaaa'; laqat taqatta'a bainakum wa dalla 'annkum maa kuntum taz'umoon"
  },
  {
    "id": 95,
    "text": "Innal laaha faaliqul habbi wannawaa yukhrijul haiya minal maiyiti wa mukhrijul maiyiti minal haiy; zaalikumul laahu fa annaa tu'fakoon"
  },
  {
    "id": 96,
    "text": "Faaliqul isbaahi wa ja'alal laila sakananw wash shamsa walqamara husbaanaa; zaalika taqdeerul 'Azeezil 'Aleem"
  },
  {
    "id": 97,
    "text": "Wa Huwal lazee ja'ala lakumun nujooma litahtadoo bihaa fee zulumaatil barri walbahr; qad fassalnal Aayaati liqawminy ya'lamoon"
  },
  {
    "id": 98,
    "text": "Wa huwal lazeee ansha akum min nafsinw waahidatin famustaqarrunw wa mustawda'; qad fassalnal Aayaati liqaw miny-yafqahoon"
  },
  {
    "id": 99,
    "text": "Wa Huwal lazeee anzala minas samaaa'i maaa'an fa akhrajnaa bihee nabaata kulli shai'in fa akhrajnaa minhu khadiran nukhriju minhu habbam mutaraakibanw wa minan nakhli min tal'ihaa qinwaanun daaniyatunw wa jannaatim min a'naabinw wazzaitoona warrummaana mushtabihanw wa ghaira mutashaabih; unzurooo ilaa samariheee izaaa asmara wa yan'ih; inna fee zaalikum la Aayaatil liqawminy yu'minoon"
  },
  {
    "id": 100,
    "text": "Wa ja'aloo lillaahi shurakaaa'al jinna wa khalaqa hum wa kharaqoo lahoo baneena wa banaatim bighairi 'ilm Subhaanahoo wa Ta'aalaa 'amma yasifoon"
  },
  {
    "id": 101,
    "text": "Badee'us samaawaati wal ardi annnaa yakoonu lahoo waladunw wa lam takul lahoo saahibatunw wa khalaqa kulla shain'inw wa Huwa bikulli shai'in 'Aleem"
  },
  {
    "id": 102,
    "text": "Zaalikumul laahu Rabbukum laaa ilaaha illaa huwa khaaliqu kulli shai'in fa'budooh; wa huwa 'alaa kulli shai'inw Wakeel"
  },
  {
    "id": 103,
    "text": "Laa tudrikuhul absaaru wa Huwa yudrikul absaara wa huwal Lateeful Khabeer"
  },
  {
    "id": 104,
    "text": "Qad jaaa'akum basaaa'iru mir Rabbikum faman absara falinafsihee wa man 'amiya fa'alaihaa; wa maaa ana 'alaikum bihafeez"
  },
  {
    "id": 105,
    "text": "Wa kazaalika nusarriful Aayaati wa liyaqooloo darasta wa linubaiyinahoo liqawminy ya'lamoon"
  },
  {
    "id": 106,
    "text": "Ittabi' maaa oohiya ilaika mir Rabbika laaa ilaaha illaa Huwa wa a'rid 'anil mushrikeen"
  },
  {
    "id": 107,
    "text": "Wa law shaaa'al laahu maaa ashrakoo; wa maa ja'alnaaka 'alaihim hafeezanw wa maaa anta 'alaihim biwakeel"
  },
  {
    "id": 108,
    "text": "Wa laa tasubbul lazeena yad'oona min doonil laahi fa yasubbul laaha 'adwam bighairi 'ilm; kazaalika zaiyannaa likulli ummatin 'amalahum summa ilaa Rabbihim marji'uhum fa yunabbi'uhum bimaa kaanoo ya'maloon"
  },
  {
    "id": 109,
    "text": "Wa aqsamoo billaahi jahda aimaanihim la'in jaaa'at hum Aayatul la yu'minunna bihaa; qul innamal Aayaatu 'indal laahi wa maa yush'irukum annahaaa izaa jaaa'at laa yu'minoon"
  },
  {
    "id": 110,
    "text": "Wa nuqallibu af'idatahum wa absaarahum kamaa lam yu'minoo biheee awwala marratinw wa nazaruhum fee tughyaanihim ya'mahoon"
  },
  {
    "id": 111,
    "text": "Wa law annanaa nazzal naaa ilaihimul malaaa'ikata wa kallamahumul mawtaa wa hasharnaa 'alaihim kulla shai'in qubulam maa kaanoo liyu'minooo illaaa ai yashaaa'al laahu wa laakinna aksarahum yajhaloon"
  },
  {
    "id": 112,
    "text": "Wa kazaalika ja'alnaa likulli nabiyyin 'aduwwan Shayaateenal insi waljinni yoohee ba'duhum ilaa ba'din zukhrufal qawli ghurooraa; wa law shaaa'a Rabbuka maa fa'aloohu fazarhum wa maa yaftaroon"
  },
  {
    "id": 113,
    "text": "Wa litasghaaa ilaihi af'idatul lazeena laa yu'minoona bil Aakhirati wa liyardawhu wa liyaqtarifoo maa hum muqtarifoon"
  },
  {
    "id": 114,
    "text": "Afaghairal laahi abtaghee hakamanw wa Huwal lazee anzala ilaikumul Kitaaba mufassalaa; wallazeena atai naahumul Kitaaba ya'lamoona annahoo munazzalum mir Rabbika bilhaqqi falaa takoonanna minal mumtareen"
  },
  {
    "id": 115,
    "text": "Wa tammat Kalimatu Rabbika sidqanw wa 'adlaa; laa mubaddila li Kalimaatih; wa Huwas Samee'ul 'Aleem"
  },
  {
    "id": 116,
    "text": "Wa in tuti' aksara man fil ardi yudillooka 'an sabeelil laah; iny yattabi'oona illaz zanna wa in hum illaa yakhrusoon"
  },
  {
    "id": 117,
    "text": "Inna rabbaka Huwa a'lamu mai yadillu 'an sabeelihee wa Huwa a'lamu bilmuhtadeen"
  },
  {
    "id": 118,
    "text": "Fakuloo mimmmaa zukirasmul laahi 'alaihi in kuntum bi Aayaatihee mu'mineen"
  },
  {
    "id": 119,
    "text": "Wa maa lakum allaa ta'kuloo mimmaa zukirasmul laahi 'alaihi wa qad fassala lakum maa harrama 'alaikum illaa mad turirtum ilaih; wa inna kaseeral la yudilloona bi ahwaaa'ihim bighairi 'ilm; inna Rabbaka Huwa a'lamu bilmu'tadeen"
  },
  {
    "id": 120,
    "text": "Wa zaroo zaahiral ismi wa baatinah; innal lazeena yaksiboonal ismaa sa yujzawna bimaa kaanoo yaqtarifoon"
  },
  {
    "id": 121,
    "text": "Wa laa ta'kuloo mimmaa lam yuzkaris mullaahi 'alaihi wa innahoo lafisq; wa innash Shayaateena la yoohoona ilaaa awliyaaa'ihim liyujaadilookum wa in ata'tumoohum innakum lamushrikoon"
  },
  {
    "id": 122,
    "text": "Awa man kaana maitan fa ahyainaahu wa ja'alnaa lahoo noorany yamshee bihee fin naasi kamamm masaluhoo fiz zulumaati laisa bikhaarijim minhaa; kazaalika zuyyina lilkaafireena maa kaanoo ya'maloon"
  },
  {
    "id": 123,
    "text": "Wa kazaalika ja'alnaa fee kulli qaryatin akaabira mujrimeehaa liyamkuroo feehaa wa maa yamkuroona illaa bi anfusihim wa maa yash'uroon"
  },
  {
    "id": 124,
    "text": "Wa izaa jaaa'athum Aayatun qaaloo lan nu'mina hatta nu'taa misla maaa ootiya Rusulul laah; Allahu a'alamu haisu yaj'alu Risaalatah; sa yuseebul lazeena ajramoo saghaarun 'indal laahi wa 'azaabun shadeedum bimaa kaanoo yamkuroon"
  },
  {
    "id": 125,
    "text": "Famai yuridil laahu ai yahdiyahoo yashrah sadrahoo lil islaami wa mai yurid ai yudillahoo yaj'al sadrahoo daiyiqan harajan ka annamaa yassa' 'adu fis samaaa'; kazaalika yaj'alul laahur rijsa 'alal lazeena laa yu'minoon"
  },
  {
    "id": 126,
    "text": "Wa haazaa siraatu Rabbika Mustaqeemaa; qad fassalnal Aayaati liqawminy yazzakkaroon"
  },
  {
    "id": 127,
    "text": "Lahum daarus salaami 'inda Rabbihim wa huwa waliyyuhum bimaa kaanoo ya'maloon"
  },
  {
    "id": 128,
    "text": "Wa yawma yahshuruhum jamee'ai yaa ma'sharal jinni qadistaksartum minal insi wa qaala awliyaa'uhum minal insi Rabbanas tamta'a ba'dunaa biba'dinw wa balaghnaaa ajalannal lazeee ajjalta lanaa; qaalan Naaru maswaakum khaalideena feehaaa illaa maa shaaa'allaah; inna Rabbaka Hakeemun 'Aleem"
  },
  {
    "id": 129,
    "text": "Wa kazaalika nuwallee ba'daz zaalimeena ba'dam bimaa kaanoo yaksiboon"
  },
  {
    "id": 130,
    "text": "Yaa ma'sharal jinni wal insi alam ya'tikum Rusulum minkum yaqussoona 'alaikum Aayaatee wa yunziroonakum liqaaa'a Yawmikum haazaa; qaaloo shahidnaa 'alaaa anfusinaa wa gharrat humul hayaatud dunyaa wa shahidooo 'alaa anfusihim annahum kaanoo kaafireen"
  },
  {
    "id": 131,
    "text": "Zaalika al lam yakkur Rabbuka muhlikal quraa bizulminw wa ahluhaa ghaafiloon"
  },
  {
    "id": 132,
    "text": "Wa likullin darajaatum mimmaa 'amiloo; wa maa Rabbuka bighaafilin 'ammaa ya'maloon"
  },
  {
    "id": 133,
    "text": "Wa Rabbukal ghaniyyu zur rahmah; iny yasha' yuz hibkum wa yastakhlif mim ba'dikum maa yashaaa'u kamaaa ansha akum min zurriyyati qawmin aakhareen"
  },
  {
    "id": 134,
    "text": "Inna maa too'adoona la aatinw wa maaa antum bimu'jizeen"
  },
  {
    "id": 135,
    "text": "Qul yaa qawmi' maloo 'alaa makaanatikum innee 'aamilun fasawfa ta'lamoona man takoonu lahoo 'aaqibatud daar; innahoo laa yuflihuz zaalimoon"
  },
  {
    "id": 136,
    "text": "Wa ja'aloo lillaahi mimmaa zara-a minal harsi walan'aami naseeban faqaaloo haazaa lillaahi biza'mihim wa haaza lishurakaa'inaa famaa kaana lishurakaaa'ihim falaa yasilu ilal laahi wa maa kaana lillaahi fahuwa yasilu ilaa shurakaaa'ihim; saaa'a maa yahkumoon"
  },
  {
    "id": 137,
    "text": "Wa kazaalika zaiyana likaseerim minal mushrikeena qatla awlaadihim shurakaaa'uhum liyurdoohum wa liyalbisoo 'alaihim deenahum wa law shaaa'al laahu maa fa'aloohu fazarhum wa maa yaftaroon"
  },
  {
    "id": 138,
    "text": "Wa qaaloo haaziheee an'aamunw wa harsun hijrun laa yat'amuhaaa illaa man nashaaa'u biza'mihim wa an'aamun hurrimat zuhooruhaa wa an'aamul laa yazkuroonas mal laahi 'alaihaf tiraaa'an 'alaiyyh; sa yajzeehim bimaa kaanoo yaftaroon"
  },
  {
    "id": 139,
    "text": "Wa qaaloo maa fee butooni haazihil an'aami khaalisatul lizukoorinaa wa muharramun 'alaaa azwaajinaa wa iny yakum maitatan fahum feehi shurakaaa'; sa yajzeehim wasfahum; innahoo Hakeemun 'Aleem"
  },
  {
    "id": 140,
    "text": "Qad khasiral lazeena qatalooo awlaadahum safaham bighairi 'ilminw wa harramoo maa razaqahumul laahuf tiraaa'an 'alal laah; qad dalloo wa maa kaanoo muhtadeen"
  },
  {
    "id": 141,
    "text": "Wa Huwal lazee ansha-a jannaatim ma'rooshaatinw wa ghaira ma'rooshaatinw wan nakhla wazzar'a mukhtalifan ukuluhoo wazzaitoona warrum maana mutashaabihanw wa ghaira mutashaabih; kuloo min samariheee izaaa asmara wa aatoo haqqahoo yawma hasaadihee wa laa tusrifoo; innahoo laa yuhibbul musrifeen"
  },
  {
    "id": 142,
    "text": "Wa minal an'aami hamoolatanw wa farshaa; kuloo mimmaa razaqakumul laahu wa laa tattabi'oo khutuwaatish Shaitaan; innahoo lakum 'aduwwum mubeen"
  },
  {
    "id": 143,
    "text": "Samaaniyata azwaajim minad da'nisnaini wa minal ma'zis nain; qul 'aaazzaka raini harrama amil unsaiyayni ammash tamalat 'alaihi arhaamul unsayayni nabbi 'oonee bi'ilmin in kuntum saadiqeen"
  },
  {
    "id": 144,
    "text": "Wa minal ibilis naini wa minal baqaris nain; qul 'aaazzakaraini harrama amil unsayaini ammash tamalat 'alaihi arhaamul unsayaini am kuntum shuhadaaa'a iz wassaakumul laahu bihaazaa; faman azlamu mimmanif taraa 'alal laahi kazibal liyuddillan naasa bighairi 'ilm; innal laaha laa yahdil qawmaz zaalimeen"
  },
  {
    "id": 145,
    "text": "Qul laaa ajidu fee maaa oohiya ilaiya muharraman 'alaa taa'iminy yat'amuhooo illaaa ai yakoona maitatan aw damam masfoohan aw lahma khinzeerin fa innahoo rijsun aw fisqan uhilla lighairil laahi bih; famanid turra ghaira baa ghinw wa laa 'aadin fa inna Rabbaka Ghafoorur Raheem"
  },
  {
    "id": 146,
    "text": "Wa 'alal lazeena haadoo harramnaa kulla zee zufurinw wa minal baqari walghanami harramnaa 'alaihim shuhoo mahumaaa illaa maa hamalat zuhooruhumaaa awil hawaayaaa aw makhtalata bi'azm; zaalika jazainaahum bibaghyihim wa innaa la saadiqoon"
  },
  {
    "id": 147,
    "text": "Fa in kazzabooka faqur Rabbukum zoo rahmatinw waasi'atinw wa laa yuraddu ba'suhoo 'anil qawmil mujrimeen"
  },
  {
    "id": 148,
    "text": "Sayaqoolul lazeena ashrakoo law shaaa'al laahu maaa ashraknaa wa laaa aabaaa'unaa wa laa harramnaa min shai'; kazaalika kazzabal lazeena min qablihim hattaa zaaqoo ba'sanaa; qul hal 'indakum min 'ilmin fatukh rijoohu lanaa in tattabi'oona illaz zanna wa in antum illaa takhhrusoon"
  },
  {
    "id": 149,
    "text": "Qul falillaahil hujjatul baalighatu falaw shaaa'a lahadaakum ajma'een"
  },
  {
    "id": 150,
    "text": "Qul halumma shuhadaaa'akumul lazeena yash hadoona annal laaha harrama haazaa fa in shahidoo falaa tashhad ma'ahum; wa laa tattabi' ahwaaa'al lazeena kazzaboo bi Aayaatinaa wallazeena laa yu'minoona bil Aakhirati wa hum bi Rabbihim ya'diloon"
  },
  {
    "id": 151,
    "text": "Qul ta'aalaw atlu maa harrama Rabbukum 'alaikum allaa tushrikoo bihee shai'anw wa bilwaalidaini ihsaananw wa laa taqtulooo awlaadakum min imlaaq; nahnu narzuqukum wa iyyaahum wa laa taqrabul fawaahisha maa zahara minhaa wa maa batana wa laa taqtulun nafsal latee harramal laahu illaa bilhaqq; zaalikum wassaakum bihee la'allakum ta'qiloon"
  },
  {
    "id": 152,
    "text": "Wa laa taqraboo maalal yateemi illaa billatee hiyaa ahsanu hattaa yablugha ashuddahoo wa awful kaila walmeezaana bilqisti laa nukallifu nafsan illaa wus'ahaa wa izaa qultum fa'diloo wa law kaana zaa qurbaa wa bi 'ahdil laahi awfoo; zaalikum wassaakum bihee la'allakum tazakkaroon"
  },
  {
    "id": 153,
    "text": "Wa annna haazaa Siraatee mustaqeeman fattabi'oohu wa laa tattabi'us subula fatafarraqa bikum 'an sabeelih; zaalikum wassaakum bihee la'allakum tattaqoon"
  },
  {
    "id": 154,
    "text": "Summa aatainaa Moosal Kitaaba tammaaman 'alal lazeee ahsana wa tafseelal likulli shai'inw wa hudanw wa rahmatal la'allahum biliqaaa'i Rabbihim yu'minoon"
  },
  {
    "id": 155,
    "text": "Wa haazaa Kitaabun anzalnaahu Mubaarakun fattabi'oohu wattaqoo la'al lakum turhamoon"
  },
  {
    "id": 156,
    "text": "An taqooloo inna maaa unzilal Kitaabu 'alaa taaa'ifataini min qablinaa wa in kunnaa 'an diraasatihim laghaafileen"
  },
  {
    "id": 157,
    "text": "Aw taqooloo law annaaa unzila 'alainal kitaabu lakunnaaa ahdaa minhum; faqad jaaa'akum baiyinatum mir Rabbikum wa hudanw wa rahmah; faman azlamu mimman kazzaba bi Aayaatil laahi wa sadafa 'anhaa; sanajzil lazeena yasdifoona 'an Aayaatinaa sooo'al 'azaabi bimaa kaanoo yasdifoon"
  },
  {
    "id": 158,
    "text": "Hal yanzuroona illaaa an ta'tiyahumul malaaa'ikatu aw ya'tiya Rabbuka aw ya'tiya ba'du Aayaati Rabbik; yawma ya'tee ba'du Aayaati Rabbika laa yanfa'u nafsan eemaanuhaa lam takun aamanat min qablu aw kasabat feee eemaanihaa khairaa; qulin tazirooo innaa muntaziroon"
  },
  {
    "id": 159,
    "text": "Innal lazeena farraqoo deenahum wa kaanoo shiya'allasta minhum fee shaiyy'; innamaaa amruhum ilallaahi summa yunabbi'uhum bimaa kaanoo yaf'aloon"
  },
  {
    "id": 160,
    "text": "Man jaaa'a bilhasanati falahoo 'ashru amsaalihaa wa man jaaa'a bissaiyi'ati falaa yujzaaa illaa mislahaa wa hum laa yuzlamoon"
  },
  {
    "id": 161,
    "text": "Qul innanee hadaanee Rabbeee ilaa Siraatim Mustaqeemin deenan qiyamam Millata Ibraaheema haneefaa; wa maa kaana minal mushrikeen"
  },
  {
    "id": 162,
    "text": "Qul inna Salaatee wa nusukee wa mahyaaya wa mamaatee lillaahi Rabbil 'aalameen"
  },
  {
    "id": 163,
    "text": "Laa shareeka lahoo wa bizaalika umirtu wa ana awwalul muslimeen"
  },
  {
    "id": 164,
    "text": "Qul aghairal laahi abghee Rabbanw wa Huwa Rabbu kulli shaiyy'; wa laa taksibu kullu nafsin illaa 'alaihaa; wa laa taziru waaziratunw wizra ukhraa; summa ilaa Rabbikum marji'ukum fa yunabbi'ukum bimaa kuntum feehi takhtalifoon"
  },
  {
    "id": 165,
    "text": "Wa Huwal lazee ja'alakum khalaaa'ifal ardi wa rafa'a ba'dakum fawqa ba'din darajaatil liyabluwakum fee maaa aataakum; inna Rabbaka saree'ul 'iqaabi wa innahoo la Ghafoorur Raheem"
  }
];

export default en;
