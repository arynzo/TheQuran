import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Meeem-Saaad"
  },
  {
    "id": 2,
    "text": "Kitaabun unzila ilaika falaa yakun fee sadrika harajum minhu litunzira bihee wa zikraa lilmu'mineen"
  },
  {
    "id": 3,
    "text": "Ittabi'oo maaa unzila 'ilaikum mir Rabbikum wa laa tattabi'oo min dooniheee awliyaaa'a; qaleelam maa tazakkaroon"
  },
  {
    "id": 4,
    "text": "Wa kam min qaryatin ahlaknaahaa fajaaa'ahaa ba'sunaa bayaatan aw hum qaaa'iloon"
  },
  {
    "id": 5,
    "text": "Famaa kaana da'waahum iz jaaa'ahum ba'sunaa illaaa an qaalooo innaa kunnaa zaalimeen"
  },
  {
    "id": 6,
    "text": "Falanas 'alannal lazeena ursila ilaihim wa lanas 'alannal mursaleen"
  },
  {
    "id": 7,
    "text": "Falanaqussanna 'alaihim bi'ilminw wa maa kunnaa ghaaa'ibeen"
  },
  {
    "id": 8,
    "text": "Walwaznu Yawma'izinil haqq; faman saqulat mawaa zeenuhoo fa-ulaaa'ika humul muflihoon"
  },
  {
    "id": 9,
    "text": "Wa man khaffat mawaazeenuhoo fa ulaaa'ikal lazeena khasirooo anfusahum bimaa kaanoo bi Aayaatinaa yazlimoon"
  },
  {
    "id": 10,
    "text": "Wa laqad makkannaakum fil ardi wa ja'alnaa lakum feehaa ma'aayish; qaleelam maa tashkuroon"
  },
  {
    "id": 11,
    "text": "Wa laqad khalaqnaakum summa sawwarnaakum summa qulnaa lilmalaaa'ikatis judoo li Aadama fa-sajadooo illaaa Ibleesa lam yakum minas saajideen"
  },
  {
    "id": 12,
    "text": "Qaala maa mana'aka allaa tasjuda iz amartuka qaala ana khairum minhu khalaqtanee min naarinw wa khalaqtahoo min teen"
  },
  {
    "id": 13,
    "text": "Qaala fahbit minhaa famaa yakoonu laka an tatakabbara feehaa fakhruj innaka minas saaghireen"
  },
  {
    "id": 14,
    "text": "Qaala anzirneee ilaa Yawmi yub'asoon"
  },
  {
    "id": 15,
    "text": "Qaala innaka minal munzareen"
  },
  {
    "id": 16,
    "text": "Qaala fabimaaa aghway tanee la aq'udanna lahum Siraatakal Mustaqeem"
  },
  {
    "id": 17,
    "text": "Summa la aatiyannahum mim baini aideehim wa min khalfihim wa 'an aimaanihim wa 'an shamaaa'ilihim wa laa tajidu aksarahum shaakireen"
  },
  {
    "id": 18,
    "text": "Qaalakhruj minhaa maz'oomam madhooraa; laman tabi'aka minhum la amla'anna Jahannama minkum ajma'een"
  },
  {
    "id": 19,
    "text": "Wa yaaa Aadamus kun anta wa zawjukal Jannata fakulaa min haisu shi'tumaa wa laa taqrabaa haazihish shajarata fatakoonaa minaz zaalimeen"
  },
  {
    "id": 20,
    "text": "Fawaswasa lahumash Shaitaanu liyubdiya lahumaa maa wooriya 'anhumaa min saw aatihimaa wa qaala maa nahaakumaa Rabbukumaa 'an haazihish shajarati illaaa an takoonaa malakaini aw takoonaa minal khaalideen"
  },
  {
    "id": 21,
    "text": "Wa qaasamahumaaa innee lakumaa laminan naasiheen"
  },
  {
    "id": 22,
    "text": "Fadallaahumaa bighuroor; falammaa zaaqash shajarata badat lahumaa saw aatuhumaa wa tafiqaa yakhsifaani 'alaihimaa minw waraqil jannati wa naadaahumaa Rabbuhumaaa alam anhakumaa 'an tilkumash shajarati wa aqul lakumaaa innash Shaitaana lakumaa 'aduwwum mubeen"
  },
  {
    "id": 23,
    "text": "Qaalaa Rabbanaa zalamnaaa anfusanaa wa illam taghfir lanaa wa tarhamnaa lanakoonanna minal khaasireen"
  },
  {
    "id": 24,
    "text": "Qaalah bitoo ba'dukum liba'din aduwwunw wa lakum fil ardi mustaqarrunw wa mataa'un ilaaheen"
  },
  {
    "id": 25,
    "text": "Qaala feehaa tahyawna wa feehaa tamootoona wa minhaa tukhrajoon"
  },
  {
    "id": 26,
    "text": "Yaa Baneee Aadama qad anzalnaa 'alaikum libaasany yuwaaree saw aatikum wa reeshanw wa libaasut taqwaa zaalika khair; zaalika min Aayaatil laahi la'allahum yaz zakkaroon"
  },
  {
    "id": 27,
    "text": "Yaa Banee Aadama laa yaftinannnakumush Shaitaanu kamaaa akhraja abawaikum minal Jannati yanzi'u 'anhumaa libaasahumaa liyuriyahumaa saw aatihimaaa; innahoo yaraakum huwa wa qabeeluhoo min haisu laa tarawnahum; innaa ja'alnash Shayaateena awliyaaa'a lillazeena laa yu'minoon"
  },
  {
    "id": 28,
    "text": "Wa izaa fa'aloo faahishatan qaaloo wajadnaa 'alaihaaa aabaaa'ana wallaahu amaranaa bihaa; qul innal laaha laa ya'muru bilfahshaaa'i a-taqooloona 'alal laahi maa laa ta'lamoon"
  },
  {
    "id": 29,
    "text": "Qul amara Rabbee bilqisti wa aqeemoo wujoohakum 'inda kulli masjidin wad'oohu mukhliseena lahud deen; kamaa bada akum ta'oodoon"
  },
  {
    "id": 30,
    "text": "Fareeqan hadaa wa fareeqan haqqa 'alaihimud dalaalah; innahumut takhazush Shayaateena awliyaaa'a min doonil laahi wa yahsaboona annahum muhtadoon"
  },
  {
    "id": 31,
    "text": "Yaa Banneee Adama khuzoo zeenatakum 'inda kulli masjidinw wa kuloo washraboo wa laa tusrifoo; innahoo laa yuhibbul musrifeen"
  },
  {
    "id": 32,
    "text": "Qul man harrama zeenat Allahil lateee akhraja li'ibaadihee wattaiyibaati minar rizq; qul hiya lillazeena aamanoo fil hayaatid dunyaa khaalisatany Yawmal Qiyaamah; kazaalika nufassilul Aayaati li qawminy ya'lamoon"
  },
  {
    "id": 33,
    "text": "Qul innamaa harrama Rabbiyal fawaahisha maa zahara minhaa wa maa batana wal isma walbaghya bighairil haqqi wa an tushrikoo billaahi maa lam yunazzil bihee sultaananw wa an taqooloo 'alal laahi maa laa ta'lamoon"
  },
  {
    "id": 34,
    "text": "Wa likulli ummatin ajalun fa izaa jaaa'a ajaluhum laa yasta' khiroona saa'atanw wa laa yastaqdimoon"
  },
  {
    "id": 35,
    "text": "Yaa Banee Aadama immaa ya'tiyannakum Rusulum minkum yaqussoona 'alaikum Aayaatee famanit taqaa wa aslaha falaa khawfun 'alaihim wa laa hum yahzanoon"
  },
  {
    "id": 36,
    "text": "Wallazeena kazzaboo bi Aayaatinaa wastakbaroo 'an haaa ulaaa'ika Ashaabun naari hum feehaa khaalidoon"
  },
  {
    "id": 37,
    "text": "Faman azlamu mimmanif taraa 'alal laahi kaziban aw kazzaba bi Aayaatih; ulaaa'ika yanaaluhum naseebuhum minal Kitaab; hatta izaa jaaa'at hum rusulunaa yatawaf fawnahum qaalooo aina maa kuntum tad'oonaa min doonil laahi qaaloo dalloo 'annaa wa shahidoo 'alaaa anfusihim annahum kaanoo kaafireen"
  },
  {
    "id": 38,
    "text": "Qaalad khuloo feee umamin qad khalat min qablikum minal jinni wal insi fin naari kullamaa dakhalat ummatul la'anat ukhtahaa hattaaa izad daarakoo feehaa jamee'an qaalat ukhraahum li oolaahum Rabbannaa haaa u'laaa'i adalloonaa fa aatihim 'azaaban di'fam minan naari qaala likullin di'funw wa laakil laa ta'lamoon"
  },
  {
    "id": 39,
    "text": "Wa qaalat oolaahum li ukhraahum famaa kaana lakum 'alainaa min fadlin fazooqul azaaba bimaa kuntum taksiboon"
  },
  {
    "id": 40,
    "text": "Innal lazeena kazzaboo bi Aayaatinaa wastakbaroo 'anhaa laa tufattahu lahum abwaabus samaaa'i wa laa yadkhuloonal jannata hattaa yalijal jamalu fee sammil khiyaat; wa kazaalika najzil mujrimeen"
  },
  {
    "id": 41,
    "text": "Lahum min jahannama mihaadunw wa min fawqihim ghawaash; wa kazaalika najziz zaalimeen"
  },
  {
    "id": 42,
    "text": "Wallazeena aamanoo wa 'amilus saalihaati laa nukallifu nafsan illaa wus'ahaaa ulaaa'ika Ashaabul jannati hum feehaa khaalidoon"
  },
  {
    "id": 43,
    "text": "Wa naza'naa maa fee sudoorihim min ghillin tajree min tahtihimul anhaaru wa qaalul hamdu lillaahil lazee hadaanaa lihaaza wa maa kunna linahtadiya law laaa ann hadaanal laahu laqad jaaa'at Rusulu Rabbinaa bilhaqq; wa noodoo an tilkumul jannnatu ooristumoohaa bimaa kuntum ta'maloon"
  },
  {
    "id": 44,
    "text": "Wa naadaa Ashaabul jannati ashaaban Naari an qad wajadnaa maa wa'adannaa Rabbunaa haqqan fahal wajattum maa wa'ada Rabbukum haqqan qaaloo na'am; fa azzana mu'azzinum bainahum al la'natul laahi 'alaz zaalimeen"
  },
  {
    "id": 45,
    "text": "Allazeena yasuddoona 'an sabeelil laahi wa yabghoo nahaa 'iwajanw wa hum bil Aakhirati kaafiroon"
  },
  {
    "id": 46,
    "text": "Wa bainahumaa hijaab; wa 'alal A'raafi rijaaluny ya'rifoona kullam biseemaahum; wa naadaw Ashaabal jannati an salaamun 'alaikum; lam yadkhuloohaa wa hum yatma'oon"
  },
  {
    "id": 47,
    "text": "Wa izaa surifat absaaruhum tilqaaa'a Ashaabin Naari qaaloo Rabbanaa laa taj'alnaa ma'al qawmiz zaalimeen"
  },
  {
    "id": 48,
    "text": "Wa naadaaa Ashaabul a'raafi rijaalany ya'rifoonahum biseemaahum qaaloo maaa aghnaa 'ankum jam'ukum wa maa kuntum tastakbiroon"
  },
  {
    "id": 49,
    "text": "A haaa'ulaaa'il lazeena aqsamtum laa yanaaluhumul laahu bi rahmah; udkhulul Jannata laa khawfun 'alaikum wa laaa antum tahzanoon"
  },
  {
    "id": 50,
    "text": "Wa naadaaa Ashaabun Naari Ashaabal jannati an afeedoo 'alainaa minal maaa'i aw mimma razaqakumul laah; qaaloo innal laaha harrama humaa 'alal kaafireen"
  },
  {
    "id": 51,
    "text": "Allazeenat takhazoo deenahum lahwanw wa la'i-banw wa gharrat humul hayaatud dunyaa; fal Yawma nannsaahum kamaa nasoo liqaaa'a Yawmihim haazaa wa maa kaanoo bi aayaatinaa yajhadoon"
  },
  {
    "id": 52,
    "text": "Wa laqad ji'naahum bi Kitaabin fassalnaahu 'alaa 'ilmin hudanw wa rahmatal liqawminy- yu'minoon"
  },
  {
    "id": 53,
    "text": "Hal yanzuroona illaa ta'weelah; yawma ya'tee ta'weeluhoo yaqoolul lazeena nasoohu min qablu qad jaaa'at Rusulu Rabbinaa bilhaqq; fahal lanaa min shufa'aaa'a fa yashfa'oo lanaaa aw nuraddu fana'mala ghairal lazee kunnaa na'mal; qad khasirooo anfusahum wa dalla 'anhum maa kaanoo yaftaroon"
  },
  {
    "id": 54,
    "text": "Inna Rabbakumul laahul lazee khalaqas samaawaati wal arda fee sittati ayyaamin summas tawaa 'alal 'arshi yughshil lailan nahaara yatlu buhoo haseesanw washshamsa walqamara wannujooma musakharaatim bi amrih; alaa lahul khalqu wal-amr; tabaarakal laahu Rabbul 'aalameen"
  },
  {
    "id": 55,
    "text": "Ud'oo Rabbakum tadarru'anw wa khufyah; innahoo laa yuhibbul mu'tadeen"
  },
  {
    "id": 56,
    "text": "Wa laa tufsidoo fil ardi ba'da islaahihaa wad'oohu khawfanw wa tama'aa; inna rahmatal laahi qareebum minal muhsineen"
  },
  {
    "id": 57,
    "text": "Wa Huwal lazee yursilur riyaaha bushram baina yadai rahmatihee hattaaa izaaa aqallat sahaaban siqaalan suqnaahu libaladim maiyitin fa annzalnaa bihil maaa'a fa akhrajnaa bihee minn kullis samaraat; kazaalika nukhrijul mawtaa la'allakum tazakkaroon"
  },
  {
    "id": 58,
    "text": "Walbaladut taiyibu yakhruju nabaatuhoo bi-izni Rabbihee wallazee khabusa laa yakhruju illaa nakidaa; kazaalika nusarriful Aayaati liqawminy yashkuroon"
  },
  {
    "id": 59,
    "text": "Laqad arsalnaa noohan ilaa qawmihee faqaala yaa qawmi' budul laaha maa lakum min ilaahin ghairuhoo inneee akhaafu 'alaikum 'azaaba Yawmin 'Azeem"
  },
  {
    "id": 60,
    "text": "Qaalal mala-u min qaw miheee innaa lanaraaka fee dalaalim mubeen"
  },
  {
    "id": 61,
    "text": "Qaala yaa qawmi laisa bee dalaalatunw wa laakinnee Rasoolum mir Rabbil 'aalameen"
  },
  {
    "id": 62,
    "text": "Uballighukum Risaalaati Rabbee wa ansahu lakum wa a'lamu minal laahi maa laa ta'lamoon"
  },
  {
    "id": 63,
    "text": "Awa 'ajibtum an jaaa'akum zikrum mir Rabbikum 'alaa rajulim minkum liyunzirakum wa litattaqoo wa la'allakum turhamoon"
  },
  {
    "id": 64,
    "text": "Fakazzaboohu fa anjai naahu wallazeena ma'ahoo fil fulki wa aghraqnal lazeena kazzaboo bi Aayaatinaa; innahum kaanoo qawman 'ameen"
  },
  {
    "id": 65,
    "text": "Wa ilaa 'aadin akhaahum Hoodaa; qaala yaa qawmi' budul laaha maa lakum min ilaahin ghairuh; afalaa tattaqoon"
  },
  {
    "id": 66,
    "text": "Qaalal mala ul lazeena kafaroo min qawmiheee innaa lanaraaka fee safaahatinw wa innaa la nazunnuka minal kaazibeen"
  },
  {
    "id": 67,
    "text": "Qaala yaa qawmi laisa bee safaahatunw wa laakinnee Rasoolum mir Rabbil 'aalameen"
  },
  {
    "id": 68,
    "text": "Uballighukum Risaalaati Rabbee wa ana lakum naasihun ameen"
  },
  {
    "id": 69,
    "text": "Awa 'ajibtum an jaaa'akum zikrum mir Rabbikum 'alaa rajulim minkum liyunzirakum; wazkurooo iz ja'alakum khulafaaa'a mim ba'di qawmi noohinw wa zaadakum filkhalqi bastatan fazkurooo aalaaa'al laahi la'allakum tuflihoon"
  },
  {
    "id": 70,
    "text": "Qaalooo aji'tanaa lina'budal laaha wahdahoo wa nazara maa kaana ya'budu aabaaa'unaa fa'tinaa bimaa ta'idunaaa in kunta minas saadiqeen"
  },
  {
    "id": 71,
    "text": "Qaala qad waqa'a alaikum mir Rabbikum rijsunw wa ghadab, atujaadiloonanee feee asmaaa'in sammaitumoohaaa antum wa aabaaa'ukum maa nazzalal laahu bihaa min sultaan; fantazirooo innee ma'akum minal muntazireen"
  },
  {
    "id": 72,
    "text": "Fa anjainaahu wallazeena ma'ahoo birahmatim minnaa wa qata'naa daabiral lazeena kazzaboo bi Aayaatinaa wa maa kaanoo mu'mineen"
  },
  {
    "id": 73,
    "text": "Wa ilaa Samooda akhaahum Saalihaa; qaala yaa qawmi' budul laaha maa lakum min ilaahin ghairuhoo qad jaaa'atkum baiyinatum mir Rabbikum haazihee naaqatul laahi lakum Aayatan fazaroohaa ta'kul feee ardil laahi wa laa tamassoohaa bisooo'in fa ya'khuzakum 'azaabun aleem"
  },
  {
    "id": 74,
    "text": "Wazkuroo iz ja'alakum khulafaaa'a mim ba'di 'Aadinw wa bawwa akum fil ardi tattakhizoona min suhoolihaa qusooranw wa tanhitoonal jibaala buyootan fazkurooo aalaaa'al laahi wa laa ta'saw fil ardi mufsideen"
  },
  {
    "id": 75,
    "text": "Qaalal mala ul lazeenas takbaroo min qawmihee lillazeenas tud'ifoo liman aamana minhum ata'lamoona anna Saaliham mursalum mir Rabbih; qaalooo innaa bimaaa ursila bihee mu'minoon"
  },
  {
    "id": 76,
    "text": "Qaalal lazeenas takbarooo innaa billazeee aamanntum bihee kaafiroon"
  },
  {
    "id": 77,
    "text": "Fa'aqarun naaqata wa'ataw 'an amri Rabbihim wa qaaloo yaa Saalihu' tinaa bimaa ta'idunaaa in kunta minal mursaleen"
  },
  {
    "id": 78,
    "text": "Fa akhazat humur rajfatu fa asbahoo fee daarihim jaasimeen"
  },
  {
    "id": 79,
    "text": "Fa tawalla 'anhum wa qaala yaa qawmi laqad ablaghtukum Risaalata Rabbee wa nasahtu lakum wa laakil laa tuhibboonan naasiheen"
  },
  {
    "id": 80,
    "text": "Wa Lootan iz qaala liqawmiheee ata'toonal faahishata maa sabaqakum bihaa min ahadim minal 'aalameen"
  },
  {
    "id": 81,
    "text": "Innakum lata'toonar rijaala shahwatam min doonin nisaaa'; bal antumqawmum musrifoon"
  },
  {
    "id": 82,
    "text": "Wa maa kaana jawaaba qawmihee illaa an qaalooo akhrijoohum min qaryatikum innahum unaasuny yatatahharoon"
  },
  {
    "id": 83,
    "text": "Fa anjainaahu wa ahlahooo illam ra atahoo kaanat minal ghaabireen"
  },
  {
    "id": 84,
    "text": "Wa 'amtarnaa 'alaihim mataran fanzur kaifa kaana aaqibatul mujrimeen"
  },
  {
    "id": 85,
    "text": "Wa ilaa Madyana akhaahum Shu'aybaa; qaala yaa qawmi' budul laaha maa lakum min ilaahin ghairuhoo qad jaaa'atkum baiyinatum mir Rabbikum fa awful kaila walmeezaana wa laa tabkhasun naasa ashyaa'ahum wa laa tufsidoo fil ardi ba'da islaahihaa; zaalikum khairul lakum in kuntum mu'mineen"
  },
  {
    "id": 86,
    "text": "Wa laa taq'udoo bikulli siraatin too'idoona wa tasuddoona 'an sabeelil laahi man aamana bihee wa tabghoonahaa 'iwajaa; waz kurooo iz kuntum qaleelan fakassarakum wanzuroo kaifa kaana 'aaqibatul mufsideen"
  },
  {
    "id": 87,
    "text": "Wa In kaana taaa'ifatum minkum aamanoo billazeee ursiltu bihee wa taaa'ifatul lam yu'minoo fasbiroo hattaa yahkumal laahu bainanaa; wa Huwa khairul haakimeen"
  },
  {
    "id": 88,
    "text": "Qaalal mala ul lazeenas takbaroo min qawmihee lanukhrijannaka yaa Shu'aibu wallazeena aamanoo ma'aka min qaryatinaaa aw lata'oo dunna fee millatinaa; qaala awa law kunnaa kaariheen"
  },
  {
    "id": 89,
    "text": "Qadif tarainaa 'alal laahi kaziban in 'udnaa fee millatikum ba'da iz najjaanal laahu minhaa; wa maa yakoonu lanaaa an na'ooda feehaaa illaaa ai yashaaa'al laahu Rabbunaa; wasi'a Rabbunaa kulla shai'in 'ilmaa; 'alal laahi tawakkalnaa; Rabbanaf tah bainanaa wa baina qawminaa bilhaqqi wa Anta khairul faatiheen"
  },
  {
    "id": 90,
    "text": "Wa qaalal mala ul lazeena kafaroo min qawmihee la'init taba'tum Shu'aiban innakum izal lakhaasiroon"
  },
  {
    "id": 91,
    "text": "Fa akhazat humur rajfatu fa asbahoo fee daarihim jaasimeen"
  },
  {
    "id": 92,
    "text": "Allazeena kazzaboo Shu'aiban ka al lam yaghnaw feehaa; allazeena kazzaboo Shu'aiban kaanoo humul khaasireen"
  },
  {
    "id": 93,
    "text": "Fatawalla 'anhum wa qaala yaa qawmi laqad ablaghtukum Risaalaati Rabbee wa nasahtu lakum fakaifa aasaa'alaa qawmin kaafireen"
  },
  {
    "id": 94,
    "text": "Wa maaa arsalnaa fee qaryatim min Nabiyyin illaaa akhaznaaa ahlahaa bil ba'saaa'i waddarraaa'i la'allahum yaddarra'oon"
  },
  {
    "id": 95,
    "text": "Summa baddalnaa makaa nas saiyi'atil hasanata hattaa 'afaw wa qaaloo qad massa aabaa'anad darraaa'u wassarraaa'u fa akhaznaahum baghtatanw wa hum laa yash'uroon"
  },
  {
    "id": 96,
    "text": "Wa law anna ahlal quraaa aamanoo wattaqaw lafatahnaa 'alaihim barakaatim minas samaaa'i wal ardi wa laakin kazzaboo fa akhaznaahum bimaa kaanoo yaksiboon"
  },
  {
    "id": 97,
    "text": "Afa amina ahlul quraaa ai ya'tiyahum ba'sunaa bayaatanw wa hum naaa'imoon"
  },
  {
    "id": 98,
    "text": "Awa amina ahlul quraaa ai ya'tiyahum ba'sunaa duhanw wa hum yal'aboon"
  },
  {
    "id": 99,
    "text": "Afa aminoo makral laah; falaa ya'manu makral laahi illal qawmul khaasiroon"
  },
  {
    "id": 100,
    "text": "Awa lam yahdi lillazeena yarisoonal arda mim ba'di ahlihaaa al law nashaaa'u asabnaahum bizunoobihim; wa natba'u 'alaa quloobihim fahum laa yasma'oon"
  },
  {
    "id": 101,
    "text": "Tilkal quraa naqussu 'alaika min ambaaa'ihaa; wa laqad jaaa'at hum Rusuluhum bilbaiyinaati famaa kaanoo liyu'minoo bimaa kazzaboo min qabl; kazaalika yatba'ul laahu 'alaa quloobil kaafireen"
  },
  {
    "id": 102,
    "text": "Wa maa wajadnaa li aksarihim min 'ahd; wa inw wajadnaaa aksarahum lafaasiqeen"
  },
  {
    "id": 103,
    "text": "Summa ba'asnaa mim ba'dihim Moosaa bi Aayaatinaaa ilaa Fir'awana wa mala'ihee fazalamoo bihaa fanzur kaifa kaana 'aaqibatul mufsideen"
  },
  {
    "id": 104,
    "text": "Wa qaala Moosaa yaa Fir'awnu inneee Rasoolum mir Rabbil 'aalameen"
  },
  {
    "id": 105,
    "text": "Haqeequn 'alaaa al laaa aqoola 'alal laahi illal haqq; qad ji'tukum bibaiyinatim mir Rabbikum fa arsil ma'iya Baneee Israaa'eel"
  },
  {
    "id": 106,
    "text": "Qaala in kunnta ji'ta bi Aayatin fa'tibihaa in kunnta minas saadiqeen"
  },
  {
    "id": 107,
    "text": "Fa alqaa 'asaahu fa izaa hiya su'baanum mubeen"
  },
  {
    "id": 108,
    "text": "Wa naza'a yadahoo fa izaa hiya baidaaa'u linnaazireen"
  },
  {
    "id": 109,
    "text": "Qaalal mala-u min qawmi Fir'awna inna haazaa lasaahirun 'aleem"
  },
  {
    "id": 110,
    "text": "Yureedu ai yukhrijakum min ardikum famaazaa ta'muroon"
  },
  {
    "id": 111,
    "text": "Qaalooo arjih wa akhaahu wa arsil filmadaaa'ini haashireen"
  },
  {
    "id": 112,
    "text": "Ya'tooka bikulli saahirin 'aleem"
  },
  {
    "id": 113,
    "text": "Wa jaaa'as saharatu Fir'awna qaaloo inna lanaa la ajjran in kunnaa nahnul ghaalibeen"
  },
  {
    "id": 114,
    "text": "Qaala na'am wa innakum laminal muqarrabeen"
  },
  {
    "id": 115,
    "text": "Qaaloo yaa Moosaaa immaaa an tulqiya wa immaaa an nakoona nahnul mulqeen"
  },
  {
    "id": 116,
    "text": "Qaala alqoo falam maaa alqaw saharooo a'yunannaasi wastarhaboohum wa jaaa'oo bisihrin 'azeem"
  },
  {
    "id": 117,
    "text": "Wa awhainaaa ilaa Moosaaa an alqi 'asaaka fa izaa hiya talqafu maa ya'fikoon"
  },
  {
    "id": 118,
    "text": "Fawaqa'al haqqu wa batala maa kaanoo ya'maloon"
  },
  {
    "id": 119,
    "text": "Faghuliboo hunaalika wanqalaboo saaghireen"
  },
  {
    "id": 120,
    "text": "Wa ulqiyas saharatu saajideen"
  },
  {
    "id": 121,
    "text": "Qaaloo aamannaa bi Rabbil 'aalameen"
  },
  {
    "id": 122,
    "text": "Rabbi Moosaa wa Haaroon"
  },
  {
    "id": 123,
    "text": "Qaala Fir'awnu aamantum bihee qabla an aazana lakum; inna haaza lamakrum makartumoohu filmadeenati litukhrijoo minhaaa ahlahaa fasawfa ta'lamoon"
  },
  {
    "id": 124,
    "text": "La uqatti'anna aidiyakum wa arjulakum min khilaafin summa la usallibannakum ajma'een"
  },
  {
    "id": 125,
    "text": "Qaaloo innaaa ilaa Rabbinaa munqaliboon"
  },
  {
    "id": 126,
    "text": "Wa maa tanqimu minnaaa illaaa an aamannaa bi Aayaati Rabbinaa lammaa jaaa'atnaa; Rabbanaaa afrigh 'alainaa sabranw wa tawaffanaa muslimeen"
  },
  {
    "id": 127,
    "text": "Wa qaalal mala-u min qawmi Fir'awna atazaru Moosaa wa qawmahoo liyufsidoo fil ardi wa yazaraka wa aalihatak; qaala sanuqattilu abnaaa 'ahum wa nastahyee nisaaa'ahum wa innaa fawqahum qaahiroon"
  },
  {
    "id": 128,
    "text": "Qaala Moosaa liqawmihis ta'eenoo billaahi wasbiroo innal arda lillaahi yoorisuhaa mai yashaaa'u min 'ibaadihee wal 'aaqibatu lilmuttaqeen"
  },
  {
    "id": 129,
    "text": "Qaaloo oozeenaa min qabli an ta'tiyanaa wa mim ba'di maa ji'tanaa; qaala 'asaa Rabbukum ai yuhlika 'aduwwakum wa yastakhli fakum fil ardi fayanzura kaifa ta'maloon"
  },
  {
    "id": 130,
    "text": "Wa laqad akhaznaaa Aala Fir'awna bis sineena wa naqsim minas samaraati la'allahum yazzakkaroon"
  },
  {
    "id": 131,
    "text": "Fa izaa jaaa'at humul hasanatu qaaloo lanaa haazihee wa in tusibhum saiyi'atuny yattaiyaroo bi Moosaa wa mam ma'ah; alaaa innamaa taaa'iruhum 'indal laahi wa laakinna aksarahum laa ya'lamoon"
  },
  {
    "id": 132,
    "text": "Wa qaaloo mahmaa taatinaa bihee min Aayatil litas'haranaa bihaa famaa nahnu laka bimu'mineen"
  },
  {
    "id": 133,
    "text": "Fa arsalnaa 'alaihimut toofaana waljaraada walqum mala waddafaadi'a waddama Aayaatim mufassalaatin fastakbaroo wa kaanoo qawmam mujrimeen"
  },
  {
    "id": 134,
    "text": "Wa lammaa waqa'a 'alaihimur rijzu qaaloo ya Moosad-u lanaa rabbaka bimaa 'ahida 'indaka la'in kashafta 'annar rijza lanu 'minanna laka wa lanursilanna ma'aka Banee Israaa'eel"
  },
  {
    "id": 135,
    "text": "Falammaa kashafnaa 'anhumur rijza ilaaa ajalin hum baalighoohu izaa hum yankusoon"
  },
  {
    "id": 136,
    "text": "Fantaqamnaa minhum fa'aghraqnaahum Fil'yammi Bi Annahum kazzaboo bi Aayaatinaa wa kaanoo 'anhaa ghaafileen"
  },
  {
    "id": 137,
    "text": "Wa awrasnal qawmal lazeena kaanoo yustad'afoona mashaariqal ardi wa maghaari bahal latee baaraknaa feehaa wa tammat kalimatu Rabbikal husnaa 'alaa Baneee Israaa'eela bimaa sabaroo wa dammarnaa maa kaana yasna'u Fir'awnu wa qawmuhoo wa maa kaanoo ya'rishoon"
  },
  {
    "id": 138,
    "text": "Wa jaawaznaa bi Banneee Israaa'eelal bahra fa ataw 'alaa qawminy ya'kufoona 'alaaa asnaamil lahum; qaaloo yaa Moosaj'al lanaa ilaahan kamaa lahum aalihah; qaala innakum qawmun tajhaloon"
  },
  {
    "id": 139,
    "text": "Innaa haaa'ulaaa'i mutabbarum maa hum feehi wa baatilum maa kaanoo ya'maloon"
  },
  {
    "id": 140,
    "text": "Qaala a-ghairal laahi abgheekum ilaahanw wa Huwa faddalakum 'alal 'aalameen"
  },
  {
    "id": 141,
    "text": "Wa iz anjainaakum min Aali Fir'awna yasoomoo nakum sooo'al 'azaab, yuqattiloona abnaaa'akum wa yastahyoona nisaaa'akum; wa fee zaalikum balaaa'um mir Rabbikum 'azeem"
  },
  {
    "id": 142,
    "text": "Wa waa'adnaa Moosaa salaaseena lailatanw wa at mamnaahaa bi'ashrim fatamma meeqaatu Rabbihee arba'eena lailah; wa qaala Moosaa liakheehi Haaroonakh lufnee fee qawmee wa aslih wa laa tattabi' sabeelal mufsideen"
  },
  {
    "id": 143,
    "text": "Wa lammaa jaaa'a Moosa limeeqaatinaa wa kallamahoo Rabbuhoo qaala Rabbi arineee anzur ilaik; qaala lan taraanee wa laakininzur ilal jabali fa inistaqarra makaanahoo fasawfa taraanee; falammaa tajallaa Rabbuhoo liljabali ja'alahoo dakkanw wa kharra Moosaa sa'iqaa; falammaaa afaaqa qaala Subhaanaka tubtu ilaika wa ana awwalul mu'mineen"
  },
  {
    "id": 144,
    "text": "Qaala yaa Moosaaa innis tafaituka 'alan naasi bi Risaalaatee wa bi kalaamee fakhuz maaa aataituka wa kum minash shaakireen"
  },
  {
    "id": 145,
    "text": "Wa katabnaa lahoo fil alwaahi minkulli shai'im maw'izataw wa tafseelal likulli shai'in fakhuzhaa biquwwatinw wa'mur qawmaka ya'khuzoo bi ahsanihaa; sa'ooreekum daaral faasiqeen"
  },
  {
    "id": 146,
    "text": "Sa asrifu 'an Aayaatiyal lazeena yatakabbaroona fil ardi bighairil haqq; wa iny-yaraw kulla Aayatil laa yu'minoo bihaa wa iny-yaraw sabeelar rushdi laa yattakhizoohu sabeelanw wa iny-yaraw sabeelal ghaiyi yattakhizoohu sabeelaa; zaalika bi annahum kazzaboo bi Aayaatinaa wa kaanoo 'anhaa ghaafileen"
  },
  {
    "id": 147,
    "text": "Wallazeena kazzaboo bi Aayaatinaa wa liqaaa'il Aakhirati habitat 'amaaluhum; hal yujzawna illaa maa kaanoo ya'maloon"
  },
  {
    "id": 148,
    "text": "Wattakhaza qawmu Moosaa mim ba'dihee min huliyyihim 'ijlan jasadal lahoo khuwaar; alam yaraw annahoo laa yukallimuhum wa laa yahdeehim sabeelaa; ittakhazoohu wa kaanoo zaalimeen"
  },
  {
    "id": 149,
    "text": "Wa lammaa suqita feee aideehim wa ra aw annahum qad dalloo qaaloo la'il lam yarhamnaa Rabbunaa wa yaghfir lanaa lanakoonanna minal khaasireen"
  },
  {
    "id": 150,
    "text": "Wa lammaa raja'a Moosaaa ilaa qawmihee ghadbaana asifan qaala bi'samaa khalaftumoonee min ba'dee 'a-'ajiltum amra Rabbikum wa alqal alwaaha wa akhaza bira'si akheehi yajurruhoo ilaiyh; qaalab na umma innal qawmas tad'afoonee wa kadoo yaqtu loonanee; falaa tushmit biyal a'daaa'a wa laa taj'alnee ma'al qawmiz zaalimeen"
  },
  {
    "id": 151,
    "text": "Qaala Rabbighfirlee wa li akhee wa adkhilnaa fee rahmatika wa Anta arhamur raahimeen"
  },
  {
    "id": 152,
    "text": "Innal lazeenat takhazul 'ijla-sa yanaaluhum ghadabum mir Rabbihim wa zillatun fil hayaatid dunyaa; wa kazaalika najzil muftareen"
  },
  {
    "id": 153,
    "text": "Wallazeena 'amilus saiyiaati summa taaboo min ba'dihaa wa aamanooo inna Rabbaka min ba'dihaa la Ghafoorur Raheem"
  },
  {
    "id": 154,
    "text": "Wa lammaa sakata 'an Moosal ghadabu akhazal alwaaha wa fee nuskhatihaa hudanw wa rahmatul lil lazeena hum li Rabbihim yarhaboon"
  },
  {
    "id": 155,
    "text": "Wakhtaara Moosaa qawmahoo sab'eena rajulal li meeqaatinaa falammaa akhazat humur rajfatu qaala Rabbi law shi'ta ahlaktahum min qablu wa iyyaay; 'a tuhlikuna bimaa fa'alas sufahaaa'u minna in hiya illaa fitnatuka tudillu bihaa man tashaaa'u wa tahdee man tashaaa; Anta waliyyunaa faghfir lanaa warhamnaa wa Anta khairul ghaafireen"
  },
  {
    "id": 156,
    "text": "Waktub lanaa fee haazi hid dunyaa hasanatanw wa fil Aakhirati innaa hudnaaa ilaik; qaala 'azaabee useebu bihee man ashaaa'u wa rahmatee wasi'at kulla shai'; fasa aktubuhaa lil lazeena yattaqoona wa yu'toonaz Zakaata wal lazeena hum bi Aayaatinaa yu'minoon"
  },
  {
    "id": 157,
    "text": "Allazeena yattabi'oonar Rasoolan Nabiyyal ummiyyal lazee yajidoonahoo maktooban 'indahum fit Tawraati wal Injeeli ya' muruhum bilma'roofi wa yanhaahum 'anil munkari wa yuhillu lahumul taiyibaati wa yuharrimu 'alaihimul khabaaa'isa wa yada'u 'anhum israhum wal aghlaalal latee kaanat 'alaihim; fallazeena aamanoo bihee wa 'azzaroohu wa nasaroohu wattaba'un nooral lazeee unzila ma'ahooo ulaaa'ika humul muflihoon"
  },
  {
    "id": 158,
    "text": "Qul yaaa aiyuhan naasu innee Rasoolul laahi ilaikum jamee'anil lazee lahoo mulkus samaawaati wal ardi laaa ilaaha illaa Huwa yuhyee wa yumeetu fa aaminoo billaahi wa Rasoolihin Nabiyyil ummiy yil lazee yu'minu billaahi wa Kalimaatihee wattabi'oohu la'allakum tahtadoon"
  },
  {
    "id": 159,
    "text": "Wa min qawmi Moosaaa ummatuny yahdoona bilhaqqi wa bihee ya'diloon"
  },
  {
    "id": 160,
    "text": "Wa qatta' naahumus natai 'ashrata asbaatan umamaa; wa awhainaa ilaa Moosaaa izis tasqaahu qawmuhooo anid rib bi'asaakal hajara fambajasat minhus nata 'ashrata 'ainan qad 'alima kullu unaasim mashrabahum; wa zallalnaa 'alaihimul ghamaama wa anzalnaa 'alaihimul manna was Salwaa kuloo min taiyibaati maa razaqnaakum; wa maa zalamoonaa wa laakin kaanooo anfusahum yazlimoon"
  },
  {
    "id": 161,
    "text": "Wa iz qeela lahumuskunoo haazihil qaryata wa kuloo minhaa haisu shi'tum wa qooloo hittatunw wadkhulul baaba sujjadan naghfir lakum khateee'aatikum; sanazeedul muhsineen"
  },
  {
    "id": 162,
    "text": "Fabaddalal lazeena zalamoo minhum qawlan ghairal lazee qeela lahum fa arsalnaa 'alaihim rijzan minas samaaa'i bimaa kaanoo yazlimoon"
  },
  {
    "id": 163,
    "text": "Was'alhum 'anil qaryatil latee kaanat haadiratal bahri iz ya'doona fis Sabti iz ta'teehim heetaanuhum yawma Sabtihim shurra'anw wa yawma laa yasbitoona laa ta'teehim; kazaalika nabloohum bimaa kaanoo yafsuqoon"
  },
  {
    "id": 164,
    "text": "Wa iz qaalat ummatum minhum lima ta'izoona qaw manil laahu muhlikuhum aw mu'azzibuhum 'azaaban shadeedan qaaloo ma'ziratan ilaa Rabbikum wa la'allahum yattaqoon"
  },
  {
    "id": 165,
    "text": "Falammaa nasoo maa zukkiroo bihee anjainal lazeena yanhawna 'anis sooo'i wa akhaznal lazeena zalamoo bi'azaabim ba'eesim bimaa kaanoo yafsuqoon"
  },
  {
    "id": 166,
    "text": "Falammaa 'ataw 'ammaa nuhoo 'anhu qulna lahum koonoo qiradatan khaasi'een"
  },
  {
    "id": 167,
    "text": "Wa iz ta azzana Rabbuka la yab'asannna 'alaihim ilaa Yawmil Qiyaamati mai yasoomuhum sooo'al 'azaab; inna Rabbaka lasaree'ul 'iqaabi wa innahoo la Ghafoorur Raheem"
  },
  {
    "id": 168,
    "text": "Wa qatta'naahum fil ardi umaman min humus saalihoona wa min hum doona zaalika wa balawnaahum bil hasanaati was saiyi'aati la'allahum yarji'oon"
  },
  {
    "id": 169,
    "text": "Fakhalafa min ba'dihim khalfunw warisul Kitaaba ya'khuzoona 'arada haazal adnaa wa yaqooloona sayughfaru lanaa wa iny ya'tihim 'aradun misluhoo ya'khuzooh; alam yu'khaz 'alaihim meesaaqul Kitaabi an laa yaqooloo 'alal laahi illal haqqa wa darasoo maa feeh; wad Daarul Aakhiratu khairul lil lazeena yattaqoon; afalaa ta'qiloon"
  },
  {
    "id": 170,
    "text": "Wallazeena yumas sikoona bil Kitaabi wa aqaamus Salaata innaa laa nudeeu'ajral musliheen"
  },
  {
    "id": 171,
    "text": "Wa iz nataqnal jabala fawqahum ka annahoo zullatunw wa zannooo annahoo waaqi'un bihim khuzoo maaa aatainaakum biquwwatinw wazkuroo maa feehi la'allakum tattaqoon"
  },
  {
    "id": 172,
    "text": "Wa iz akhaza Rabbuka min Baneee Aadama min zuhoorihim zurriyyatahum wa ashhadahum 'alaa anfusihim alastu bi Rabbikum qaaloo balaa shahidnaaa; an taqooloo Yawmal Qiyaamati innaa kunnaa 'an haazaa ghaafileen"
  },
  {
    "id": 173,
    "text": "Aw taqoolooo innamaaa ashraka aabaaa 'unaa min qablu wa kunnaa zurriyyatan min ba'dihim 'a fa tuhlikunaa bi maa fa'alal mubtiloon"
  },
  {
    "id": 174,
    "text": "Wa kazaalika nufassilul Aayaati wa la'allahum yarji'oon"
  },
  {
    "id": 175,
    "text": "Watlu 'alaihim naba allazeee aatainaahu Aayaatinaa fansalakha minhaa fa atba'a hush Shaytaanoo fakaana minal ghaaween"
  },
  {
    "id": 176,
    "text": "Wa law shi'naa larafa'naahu bihaa wa laakin nahooo akhlada ilal ardi wattaba'a hawaah; famasaluhoo kamasalil kalbi in tahmil 'alaihi yalhas aw tatruk hu yalhas; zaalika masalul qawmil lazeena kazzaboo bi Aayaatinaa; faqsusil qasasa la'allahum yatafakkaroon"
  },
  {
    "id": 177,
    "text": "Saaa'a masalanil qawmul lazeena kazzaboo bi Aayaatinaa wa anfusahum kaanoo yazlimoon"
  },
  {
    "id": 178,
    "text": "Mai yahdil laahu fa huwal muhtadee wa mai yudlil fa ulaaa'ika humul khaasiroon"
  },
  {
    "id": 179,
    "text": "Wa laqad zara'naa li jahannama kaseeran minal jinni wal insi lahum quloobul laa yafqahoona bihaa wa lahum a'yunul laa yubisiroona bihaa wa lahum aazaanul laa yasma'oona bihaa; ulaaa'ika kal an'aami bal hum adall; ulaaa'ika humul ghaafiloon"
  },
  {
    "id": 180,
    "text": "Wa lillaahil Asmaaa 'ul Husnaa fad'oohu bihaa wa zarul lazeena yulhidoona feee Asmaaa'ih; sa yujzawna maa kaanoo ya'maloon"
  },
  {
    "id": 181,
    "text": "Wa mimman khalaqnaaa ummatuny yahdoona bilhaqqi wa bihee ya'diloon"
  },
  {
    "id": 182,
    "text": "Wallazeena kazzaboo bi Aayaatinaa sanastadrijuhum min haisu laa ya'lamoon"
  },
  {
    "id": 183,
    "text": "Wa umlee lahum; inna kaidee mateen"
  },
  {
    "id": 184,
    "text": "Awalam yatafakkaroo maa bisaahibihim min jinnah; in huwa illaa nazeerun mubeen"
  },
  {
    "id": 185,
    "text": "Awalam yanzuroo fee malakootis samaawaati wal ardi wa maa khalaqal laahu min shai'inw wa an 'asaaa ai yakoona qadiqtaraba ajaluhum fa bi ayyi hadeesin ba'dahoo yu'minoon"
  },
  {
    "id": 186,
    "text": "Mai yudlil lillaahi falaa haadiya lah; wa yazaruhum fee tughyaanihim ya'mahoon"
  },
  {
    "id": 187,
    "text": "Yas'aloonaka 'anis Saa'ati aiyaana mursaahaa qul innamaa 'ilmuhaa 'inda Rabbee laa yujalleehaa liwaqtihaaa illaa Hoo; saqulat fis samaawaati wal ard; laa ta'teekum illaa baghtah; yas'aloonaka ka annaka hafiyyun 'anhaa qul innamaa 'ilmuhaa 'indal laahi wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 188,
    "text": "Qul laaa amliku linafsee naf'anw wa laa darran illaa maa shaaa'al laah; wa law kuntu a'lamul ghaiba lastaksartu minal khairi wa maa massaniyas soo'; in ana illaa nazeerunw wa basheerul liqawminy yu'minoon"
  },
  {
    "id": 189,
    "text": "Huwal lazee khalaqakum min nafsinw waahidatinw wa ja'ala minhaa zawjahaa liyas kuna ilaihaa falammaa taghash shaahaa hamalat hamlan khafeefan famarrat bihee falammaaa asqalad da'a wallaaha Rabbahumaa la'in aataitana saalihal lanakoonanna minash shaakireen"
  },
  {
    "id": 190,
    "text": "Falammaaa aataahumaa saalihan ja'alaa lahoo shurakaaa'a feemaaa aataahumaa; fata'aalal laahu 'ammaa yushrikoon"
  },
  {
    "id": 191,
    "text": "A yushrikoona maa laa yakhluqu shai'anw wa hum yukhlaqoon"
  },
  {
    "id": 192,
    "text": "Wa laa yastatee'oona lahum nasranw wa laaa anfusahum yansuroon"
  },
  {
    "id": 193,
    "text": "Wa in tad'oohum ilalhudaa laa yattabi'ookum; sawaaa'un 'alaikum a-da'awtumoohum 'am antum saamitoon"
  },
  {
    "id": 194,
    "text": "Innal lazeena tad'oona min doonil laahi 'ibaadun amsaalukum fad'oohum fal yastajeeboo lakum in kuntum saadiqeen"
  },
  {
    "id": 195,
    "text": "'A lahum arjuluny yamshoona bihaa 'am lahum 'aidiny yabtishoona bihaaa 'am lahum a'yunuy yubsiroona bihaaa 'am lahum aazaanuny yasma'oona bihaa; qulid'oo shurakaaa'akum thumma keedooni falaa tunziroon"
  },
  {
    "id": 196,
    "text": "Inna waliyyial laahul lazee nazzalal Kitaaba wa Huwa yatawallas saaliheen"
  },
  {
    "id": 197,
    "text": "Wallazeena tad'oona min doonihee laa yastatee'oona nasrakum wa laaa anfusahum yansuroon"
  },
  {
    "id": 198,
    "text": "Wa in tad'oohum ilal hudaa laa yasma'oo wa taraahum yanzuroona ilaika wa hum laa yubsiroon"
  },
  {
    "id": 199,
    "text": "Khuzil 'afwa wa mur bil'urfi wa A'rid 'anil jaahileen"
  },
  {
    "id": 200,
    "text": "Wa immaa yanzaghannaka minash Shaitaani nazghun fasta'iz billaah; innahoo Samee'un Aleem"
  },
  {
    "id": 201,
    "text": "Innal lazeenat taqaw izaa massahum taaa'ifun minash Shaitaani tazakkaroo fa izaa hum mubsiroon"
  },
  {
    "id": 202,
    "text": "Wa ikhwaanuhum yamuddoonahum fil ghayyi thumma laa yuqsiroon"
  },
  {
    "id": 203,
    "text": "Wa izaa lam ta'tihim bi aayatin qaaloo law lajtabai tahaa; qul innamaaa attabi'u maa yoohaaa ilaiya mir Rabbee; haazaa basaaa'iru mir Rabbikum wa hudanw wa rahmatul liqawminy yu'minoon"
  },
  {
    "id": 204,
    "text": "Wa izaa quri'al Quraanu fastami'oo lahoo wa ansitoo la 'allakum turhamoon"
  },
  {
    "id": 205,
    "text": "Wazkur Rabbaka fee nafsika tadarru'anw wa kheefatanw wa doonal jahri minal qawli bilghuduwwi wal aasali wa laa takum minal ghaafileen"
  },
  {
    "id": 206,
    "text": "Innal lazeena 'inda Rabbika laa yastakbiroona 'an 'ibaadatihee wa yusabbihoonahoo wa lahoo yasjudoon"
  }
];

export default en;
