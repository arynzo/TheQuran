import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Sa'ala saaa'ilun bi 'azaabinw waaqi'"
  },
  {
    "id": 2,
    "text": "Lil kaafireena laisa lahoo daafi'"
  },
  {
    "id": 3,
    "text": "Minal laahi zil ma'aarij"
  },
  {
    "id": 4,
    "text": "Ta'rujul malaaa'ikatu war Roohu ilaihi fee yawmin kaana miqdaaruhoo khamseena alfa sanah"
  },
  {
    "id": 5,
    "text": "Fasbir sabran jameelaa"
  },
  {
    "id": 6,
    "text": "Inaahum yarawnahoo ba'eedaa"
  },
  {
    "id": 7,
    "text": "Wa naraahu qareebaa"
  },
  {
    "id": 8,
    "text": "Yawma takoonus samaaa'u kalmuhl"
  },
  {
    "id": 9,
    "text": "Wa takoonul jibaalu kal'ihn"
  },
  {
    "id": 10,
    "text": "Wa laa yas'alu hameemun hameemaa"
  },
  {
    "id": 11,
    "text": "Yubassaroonahum; ya waddul mujrimu law yaftadee min 'azaabi yawmi izin bibaneeh"
  },
  {
    "id": 12,
    "text": "Wa saahibatihee wa akheeh"
  },
  {
    "id": 13,
    "text": "Wa faseelathil latee tu'weeh"
  },
  {
    "id": 14,
    "text": "Wa man fil ardi jamee'an summa yunjeeh"
  },
  {
    "id": 15,
    "text": "Kallaa innahaa lazaa"
  },
  {
    "id": 16,
    "text": "Nazzaa'atal lishshawaa"
  },
  {
    "id": 17,
    "text": "Tad'oo man adbara wa tawallaa"
  },
  {
    "id": 18,
    "text": "Wa jama'a fa aw'aa"
  },
  {
    "id": 19,
    "text": "Innal insaana khuliqa haloo'aa"
  },
  {
    "id": 20,
    "text": "Izaa massahush sharru jazoo'aa"
  },
  {
    "id": 21,
    "text": "Wa izaa massahul khairu manoo'aa"
  },
  {
    "id": 22,
    "text": "Illal musalleen"
  },
  {
    "id": 23,
    "text": "Allazeena hum 'alaa Salaatihim daaa'imoon"
  },
  {
    "id": 24,
    "text": "Wallazeena feee amwaalihim haqqun ma'loom"
  },
  {
    "id": 25,
    "text": "Lissaaa 'ili walmahroom"
  },
  {
    "id": 26,
    "text": "Wallazeena yusaddiqoona bi yawmid Deen"
  },
  {
    "id": 27,
    "text": "Wallazeena hum min 'azaabi Rabbihim mushfiqoon"
  },
  {
    "id": 28,
    "text": "Inna 'azaaba Rabbihim ghairu ma' moon"
  },
  {
    "id": 29,
    "text": "Wallazeena hum li furoojihim haafizoon"
  },
  {
    "id": 30,
    "text": "Illaa 'alaaa azwaajihim aw maa malakat aymaanuhum fa innahum ghairu maloomeen"
  },
  {
    "id": 31,
    "text": "Famanib taghaa waraaa'a zaalika fa ulaaa'ika humul 'aadoon"
  },
  {
    "id": 32,
    "text": "Wallazeena hum li amaanaatihim wa 'ahdihim raa'oon"
  },
  {
    "id": 33,
    "text": "Wallazeena hum bi shahaadaatihim qaaa'imoon"
  },
  {
    "id": 34,
    "text": "Wallazeena hum 'alaa salaatihim yuhaafizoon"
  },
  {
    "id": 35,
    "text": "Ulaaa'ika fee jannaatim mukramoon"
  },
  {
    "id": 36,
    "text": "Famaa lil lazeena kafaroo qibalaka muhti'een"
  },
  {
    "id": 37,
    "text": "'Anil yameeni wa 'anish shimaali 'izeen"
  },
  {
    "id": 38,
    "text": "Ayatma'u kullum ri'im minhum anyyudkhala jannata Na'eem"
  },
  {
    "id": 39,
    "text": "Kallaaa innaa khalaq nahum mimmaa ya'lamoon"
  },
  {
    "id": 40,
    "text": "Falaaa uqsimu bi Rabbil mashaariqi wal maghaaribi innaa laqaadiroon"
  },
  {
    "id": 41,
    "text": "'Alaaa an nubaddila khairan minhum wa maa nahnu bi masbooqeen"
  },
  {
    "id": 42,
    "text": "Fazarhum yakhoodoo wa yal'aboo hattaa yulaaqoo yawma humul lazee yoo'adoon"
  },
  {
    "id": 43,
    "text": "Yawma yakhrujoona minal ajdaasi siraa'an ka anna hum ilaa nusubiny yoofidoon"
  },
  {
    "id": 44,
    "text": "Khaashi'atan absaaruhum tarhaquhum zillah; zaalikal yawmul lazee kaanoo yoo'adoon"
  }
];

export default en;
