import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Tabaarakal lazee biyadihil mulku wa huwa 'alaa kulli shai-in qadeer"
  },
  {
    "id": 2,
    "text": "Allazee khalaqal mawta walhayaata liyabluwakum ayyukum ahsanu 'amalaa; wa huwal 'azeezul ghafoor"
  },
  {
    "id": 3,
    "text": "Allazee khalaqa sab'a samaawaatin tibaaqa; maa taraa fee khalqir rahmaani min tafaawut farji'il basara hal taraa min futoor"
  },
  {
    "id": 4,
    "text": "Summar ji'il basara karrataini yanqalib ilaikal basaru khaasi'anw wa huwa haseer"
  },
  {
    "id": 5,
    "text": "Wa laqad zaiyannas samaaa'ad dunyaa bimasaa beeha wa ja'alnaahaa rujoomal lish shayaateeni wa a'tadnaa lahum 'azaabas sa'eer"
  },
  {
    "id": 6,
    "text": "Wa lillazeena kafaroo bi rabbihim 'azaabu jahannama wa bi'sal maseer"
  },
  {
    "id": 7,
    "text": "Izaaa ulqoo feehaa sami'oo lahaa shaheeqanw wa hiya tafoor"
  },
  {
    "id": 8,
    "text": "Takaadu tamayyazu minal ghaizz kullamaaa ulqiya feehaa fawjun sa alahum khazanatuhaaa alam ya'tikum nazeer"
  },
  {
    "id": 9,
    "text": "Qaaloo balaa qad jaaa'anaa nazeerun fakazzabnaa wa qulnaa maa nazzalal laahu min shai in in antum illaa fee dalaalin kabeer"
  },
  {
    "id": 10,
    "text": "Wa qaaloo law kunnaa nasma'u awna'qilu maa kunnaa feee as haabis sa'eer"
  },
  {
    "id": 11,
    "text": "Fa'tarafoo bizambihim fasuhqal li as haabis sa'eer"
  },
  {
    "id": 12,
    "text": "Innal lazeena yakhshawna rabbahum bilghaibi lahum maghfiratunw wa ajrun kabeer"
  },
  {
    "id": 13,
    "text": "Wa asirroo qawlakum awijharoo bih; innahoo 'aleemum bizaatis sudoor"
  },
  {
    "id": 14,
    "text": "Alaa ya'lamu man khalaqa wa huwal lateeful khabeer"
  },
  {
    "id": 15,
    "text": "Huwal lazee ja'ala lakumul arda zaloolan famshoo fee manaakibihaa wa kuloo mir rizqih; wa ilaihin nushoor"
  },
  {
    "id": 16,
    "text": "'A-amintum man fissamaaa'i aiyakhsifa bi kumul arda fa izaa hiya tamoor"
  },
  {
    "id": 17,
    "text": "Am amintum man fissamaaa'i ai yursila 'alaikum haasiban fasata'lamoona kaifa nazeer"
  },
  {
    "id": 18,
    "text": "Wa laqad kazzabal lazeena min qablihim fakaifa kaana nakeer"
  },
  {
    "id": 19,
    "text": "Awalam yaraw ilat tairi fawqahum saaaffaatinw wa yaqbidn; maa yumsikuhunna il'lar rahmaan; innahoo bikulli shai im baseer"
  },
  {
    "id": 20,
    "text": "Amman haazal lazee huwa jundul lakum yansurukum min doonir rahmaan; inilkaafiroona illaa fee ghuroor"
  },
  {
    "id": 21,
    "text": "Amman haazal lazee yarzuqukum in amsaka rizqah; bal lajjoo fee 'utuwwinw wa nufoor"
  },
  {
    "id": 22,
    "text": "Afamai yamshee mukibban 'alaa wajhihee ahdaaa ammany yamshee sawiyyan 'alaa siratim mustaqeem"
  },
  {
    "id": 23,
    "text": "Qul huwal lazee ansha akum wa ja'ala lakumus sam'a wal absaara wal af'idata qaleelam maa tashkuroon"
  },
  {
    "id": 24,
    "text": "Qul huwal lazee zara akum fil ardi wa ilaihi tuhsharoon"
  },
  {
    "id": 25,
    "text": "Wa yaqooloona mataa haazal wa'du in kuntum saadiqeen"
  },
  {
    "id": 26,
    "text": "Qul innamal 'ilmu 'indallaahi wa innamaaa ana nazeerum mubeen"
  },
  {
    "id": 27,
    "text": "Falammaa ra-awhu zulfatan seee'at wujoohul lazeena kafaroo wa qeela haazal lazee kuntum bihee tadda'oon"
  },
  {
    "id": 28,
    "text": "Qul ara'aytum in ahlaka niyal laahu wa mam ma'iya aw rahimanaa famai-yujeerul kaafireena min 'azaabin aleem"
  },
  {
    "id": 29,
    "text": "Qul huwar rahmaanu aamannaa bihee wa 'alaihi tawakkalnaa fasata'lamoona man huwa fee dalaalim mubeen"
  },
  {
    "id": 30,
    "text": "Qul ara'aytum in asbaha maaa'ukum ghawran famai ya'teekum bimaaa'im ma'een"
  }
];

export default en;
