import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Hal ataa 'alal insaani heenum minad dahri lam yakun shai'am mazkooraa"
  },
  {
    "id": 2,
    "text": "Innaa khalaqnal insaana min nutfatin amshaajin nabta leehi faja'alnaahu samee'am baseeraa"
  },
  {
    "id": 3,
    "text": "Innaa hadainaahus sabeela immaa shaakiranw wa immaa kafoora"
  },
  {
    "id": 4,
    "text": "Innaaa a'tadnaa lilkaa fireena salaasila wa aghlaalanw wa sa'eeraa"
  },
  {
    "id": 5,
    "text": "Innal abraara yashra boona min kaasin kaana mizaa juhaa kaafooraa"
  },
  {
    "id": 6,
    "text": "'Aynany yashrabu bihaa 'ibaadul laahi yufajjiroonahaa tafjeeraa"
  },
  {
    "id": 7,
    "text": "Yoofoona binnazri wa yakhaafoona yawman kaana sharruhoo mustateeraa"
  },
  {
    "id": 8,
    "text": "Wa yut''imoonat ta'aama 'alaa hubbihee miskeenanw wa yateemanw wa aseeraa"
  },
  {
    "id": 9,
    "text": "Innaamaa nut'imukum li wajhil laahi laa nureedu minkum jazaaa'anw wa laa shukooraa"
  },
  {
    "id": 10,
    "text": "Innaa nakhaafu mir Rabbinna Yawman 'aboosan qamtareeraa"
  },
  {
    "id": 11,
    "text": "Fa waqaahumul laahu sharra zaalikal yawmi wa laqqaahum nadratanw wa surooraa"
  },
  {
    "id": 12,
    "text": "Wa jazaahum bimaa sabaroo jannatanw wa hareeraa"
  },
  {
    "id": 13,
    "text": "Muttaki'eena feeha 'alal araaa 'iki laa yarawna feehaa shamsanw wa laa zamhareeraa"
  },
  {
    "id": 14,
    "text": "Wa daaniyatan 'alaihim zilaaluhaa wa zullilat qutoofu haa tazleela"
  },
  {
    "id": 15,
    "text": "Wa yutaafu 'alaihim bi aaniyatim min fiddatinw wa akwaabin kaanat qawaareeraa"
  },
  {
    "id": 16,
    "text": "Qawaareera min fiddatin qaddaroohaa taqdeeraa"
  },
  {
    "id": 17,
    "text": "Wa yuskawna feehaa ka'asan kaana mizaajuhaa zanjabeelaa"
  },
  {
    "id": 18,
    "text": "'Aynan feeha tusammaa salsabeelaa"
  },
  {
    "id": 19,
    "text": "Wa yatoofu 'alaihim wildaanum mukhalladoona izaa ra aytahum hasibtahum lu'lu 'am mansoora"
  },
  {
    "id": 20,
    "text": "Wa izaa ra ayta samma ra ayta na'eemanw wa mulkan kabeera"
  },
  {
    "id": 21,
    "text": "'Aaliyahum siyaabu sundusin khudrunw wa istabraq, wa hullooo asaawira min fiddatinw wa saqaahum Rabbuhum sharaaban tahooraa"
  },
  {
    "id": 22,
    "text": "Innaa haazaa kaana lakum jazaa 'anw wa kaana sa'yukum mashkooraa"
  },
  {
    "id": 23,
    "text": "Innaa nahnu nazzalnaa 'alaikal quraana tanzeelaa"
  },
  {
    "id": 24,
    "text": "Fasbir lihukmi Rabbika wa laa tuti' minhum aasiman aw kafooraa"
  },
  {
    "id": 25,
    "text": "Wazkuris ma Rabbika bukratanw wa aseelaa"
  },
  {
    "id": 26,
    "text": "Wa minal laili fasjud lahoo wa sabbihhu lailan taweelaa"
  },
  {
    "id": 27,
    "text": "Inna haaa'ulaa'i yuhibboona 'aajilata wa yazaroona waraaa'ahum yawman saqeelaa"
  },
  {
    "id": 28,
    "text": "Nahnu khalaqnaahum wa shadadnaaa asrahum wa izaa shi'naa baddalnaaa amsaala hum tabdeelaa"
  },
  {
    "id": 29,
    "text": "Inna haazihee tazkiratun fa man shaaa'at takhaza ilaa rabbihee sabeela"
  },
  {
    "id": 30,
    "text": "Wa maa tashaaa'oona illaa anyyashaaa'al laah; innal laahaa kaana'Aleeman Hakeema"
  },
  {
    "id": 31,
    "text": "Yudkhilu mai yashaaa'u fee rahmatih; wazzaalimeena a'adda lahum 'azaaban aleemaa"
  }
];

export default en;
