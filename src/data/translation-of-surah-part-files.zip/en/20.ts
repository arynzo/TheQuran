import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Taa-Haa"
  },
  {
    "id": 2,
    "text": "Maaa anzalnaa 'alaikal Qur-aana litashqaaa"
  },
  {
    "id": 3,
    "text": "Illaa tazkiratal limany yakhshaa"
  },
  {
    "id": 4,
    "text": "Tanzeelam mimman khalaqal arda was samaawaatil 'ulaa"
  },
  {
    "id": 5,
    "text": "Ar-Rahmaanu 'alal 'Arshis tawaa"
  },
  {
    "id": 6,
    "text": "Lahoo maa fis samaawaati wa maa fil ardi wa maa bainahumaa wa maa tahtassaraa"
  },
  {
    "id": 7,
    "text": "Wa in tajhar bilqawli fainnahoo ya'lamus sirra wa akhfaa"
  },
  {
    "id": 8,
    "text": "Allaahu laaa ilaaha illaa huwa lahul asmaa'ul husnaa"
  },
  {
    "id": 9,
    "text": "Wa hal ataaka hadeesu Moosa"
  },
  {
    "id": 10,
    "text": "Iz ra aa naaran faqaala li ahlihim kusooo inneee aanastu naaral la'alleee aateekum minhaa biqabasin aw ajidu 'alan naari hudaa"
  },
  {
    "id": 11,
    "text": "Falammaaa ataahaa noodiya yaa Moosaa"
  },
  {
    "id": 12,
    "text": "Inneee Ana Rabbuka fakhla' na'laika innaka bilwaadil muqaddasi Tuwaa"
  },
  {
    "id": 13,
    "text": "Wa anakhtartuka fastami' limaa yoohaa"
  },
  {
    "id": 14,
    "text": "Innaneee Anal laahu laaa ilaaha illaa Ana fa'budnee wa aqimis-salaata lizikree"
  },
  {
    "id": 15,
    "text": "Innas Saa'ata aatiyatun akaadu ukhfeehaa litujzaa kullu nafsin bimaa tas'aa"
  },
  {
    "id": 16,
    "text": "Falaa yasuddannaka 'anhaa mal laa yu'minu bihaa wattaba'a hawaahu fatardaa"
  },
  {
    "id": 17,
    "text": "Wa maa tilka bi yamee nika yaa Moosaa"
  },
  {
    "id": 18,
    "text": "Qaala hiya 'asaaya atawakka'u alaihaa wa ahushshu bihaa 'alaa ghanamee wa liya feehaa ma aaribu ukhraa"
  },
  {
    "id": 19,
    "text": "Qaala alqihaa yaa Moosaa"
  },
  {
    "id": 20,
    "text": "Fa-alqaahaa fa -izaa hiya haiyatun tas'aa"
  },
  {
    "id": 21,
    "text": "Qaala khuzhaa wa laa ta khaf sanu'eeduhaa seeratahal oolaa"
  },
  {
    "id": 22,
    "text": "Wadmum yadaka ilaa janaahika takhruj baidaaa'a min ghairi sooo'in Aayatan ukhraa"
  },
  {
    "id": 23,
    "text": "Linuriyaka min Aayaatinal Kubra"
  },
  {
    "id": 24,
    "text": "Izhab ilaa Fir'awna innahoo taghaa"
  },
  {
    "id": 25,
    "text": "Qaala Rabbish rah lee sadree"
  },
  {
    "id": 26,
    "text": "Wa yassir leee amree"
  },
  {
    "id": 27,
    "text": "Wahlul 'uqdatan milli saanee"
  },
  {
    "id": 28,
    "text": "Yafqahoo qawlee"
  },
  {
    "id": 29,
    "text": "Waj'al lee wazeeran min ahlee"
  },
  {
    "id": 30,
    "text": "Haaroona akhee"
  },
  {
    "id": 31,
    "text": "Ushdud biheee azree"
  },
  {
    "id": 32,
    "text": "Wa ashrik hu feee amree"
  },
  {
    "id": 33,
    "text": "Kai nusabbihaka kaseeraa"
  },
  {
    "id": 34,
    "text": "Wa nazkuraka kaseeraa"
  },
  {
    "id": 35,
    "text": "Innaka kunta binaa baseeraa"
  },
  {
    "id": 36,
    "text": "Qaala qad ooteeta su'laka yaa Moosaa"
  },
  {
    "id": 37,
    "text": "Wa laqad manannaa 'alaika marratan ukhraaa"
  },
  {
    "id": 38,
    "text": "Iz awhainaaa ilaaa ummika maa yoohaaa"
  },
  {
    "id": 39,
    "text": "'Aniqzifeehi fit Taabooti faqzifeehi fil yammi fal yul qihil yammu bis saahili ya'khuzhu 'aduwwul lee wa 'aduwwul lah; wa alqaitu 'alaika mahabbatan minnee wa litusna'a 'alaa 'ainee"
  },
  {
    "id": 40,
    "text": "Iz tamsheee ukhtuka fataqoolu hal adullukum 'alaa mai yakfuluhoo faraja 'naaka ilaaa ummika kai taqarra 'ainuhaa wa laa tahzan; wa qatalta nafsan fanajjainaaka minal ghammi wa fatannaaka futoonaa; falabista sineena feee ahli Madyana summa ji'ta 'alaa qadariny yaa Moosa"
  },
  {
    "id": 41,
    "text": "Wastana' tuka linafsee"
  },
  {
    "id": 42,
    "text": "Izhab anta wa akhooka bi Aayaatee wa laa taniyaa fee zikree"
  },
  {
    "id": 43,
    "text": "Izhabaaa ilaa Fir'awna innahoo taghaa"
  },
  {
    "id": 44,
    "text": "Faqoolaa lahoo qawlal laiyinal la allahoo yatazakkkaru 'aw yakhshaa"
  },
  {
    "id": 45,
    "text": "Qaalaa Rabbanaaa innanaa nakhaafu ai yafruta 'alainaaa aw ai yatghaa"
  },
  {
    "id": 46,
    "text": "Qaala laa takhaafaaa innanee ma'akumaa asma'u wa araa"
  },
  {
    "id": 47,
    "text": "Faatiyaahu faqoolaaa innaa Rasoolaa Rabbika fa arsil ma'anaa Banee Israaa'eela wa laa tu'azzibhum qad ji'naaka bi Aayatim mir Rabbika wassa laamu 'alaa manit taba'al hudaa"
  },
  {
    "id": 48,
    "text": "Innaa qad oohiya ilainaaa annnal 'azaaba 'alaa man kaz zaba wa tawalla"
  },
  {
    "id": 49,
    "text": "Qaala famar Rabbu kumaa yaa Moosa"
  },
  {
    "id": 50,
    "text": "Qaala Rabbunal lazeee a'taa kulla shai'in khalqahoo summa hadaa"
  },
  {
    "id": 51,
    "text": "Qaala famaa baalul quroonil oolaa"
  },
  {
    "id": 52,
    "text": "Qaala 'ilmuhaa 'inda Rabee fee kitaab, laa yadillu Rabbee wa laa yansaa"
  },
  {
    "id": 53,
    "text": "Allazee ja'ala lakumul arda mahdanw wa salaka lakum feehaa subulanw wa anzala minas samaaa'i maaa'an fa akhrajnaa biheee azwaajam min nabaatin shatta"
  },
  {
    "id": 54,
    "text": "Kuloo war'aw an'aamakum; inna fee zaalika la Aayaatil li ulin nuhaa"
  },
  {
    "id": 55,
    "text": "Minhaa khalaqnaakum wa feehaa nu'eedukum wa minhaa nukhrijukum taaratan ukhraa"
  },
  {
    "id": 56,
    "text": "Wa laqad arainaahu Aayaatinaa kullahaa fakaz zaba wa abaa"
  },
  {
    "id": 57,
    "text": "Qaala aji'tanaa litukhri janaa min ardinaa bisihrika yaa Moosa"
  },
  {
    "id": 58,
    "text": "Falanaatiyannaka bisihrim mislihee faj'al bainanaa wa bainaka maw'idal laa nukhlifuhoo nahnu wa laaa anta makaanan suwaa"
  },
  {
    "id": 59,
    "text": "Qaala maw'idukum yawmuz zeenati wa ai yuhsharan naasu duhaa"
  },
  {
    "id": 60,
    "text": "Fatawallaa Fir'awnu fajjama'a kaidahoo summa ataa"
  },
  {
    "id": 61,
    "text": "Qaala lahum Moosaa wailakum laa taftaroo 'alal laahi kaziban fa yus hitakum bi 'azaab, wa qad khaaba manif taraa"
  },
  {
    "id": 62,
    "text": "Fatanaaza'ooo amrahum bainahum wa asarrun najwaa"
  },
  {
    "id": 63,
    "text": "Qaalooo in haaazaani lasaahiraani yureedaani ai yukhrijaakum min ardikum bisihrihimaa wa yazhabaa bitareeqatikumul muslaa"
  },
  {
    "id": 64,
    "text": "Fa ajmi'oo kaidakum summma'too saffaa; wa qad aflahal yawma manis ta'laa"
  },
  {
    "id": 65,
    "text": "Qaaloo yaa Moosaaa immaaa an tulqiya wa immaaa an nakoona awala man alqaa"
  },
  {
    "id": 66,
    "text": "Qaala bal alqoo fa izaa hibaaluhum wa 'isiyyuhum yukhaiyalu ilaihi min sihrihim annahaa tas'aa"
  },
  {
    "id": 67,
    "text": "Fa awjasa fee nafsihee kheefatam Moosa"
  },
  {
    "id": 68,
    "text": "Qulnaa laa takhaf innaka antal a'laa"
  },
  {
    "id": 69,
    "text": "Wa alqi maa fee yamee nika talqaf maa sana'oo; innamaa sana'oo kaidu saahir; wa laa yuflihus saahiru haisu ataa"
  },
  {
    "id": 70,
    "text": "Fa ulqiyas saharatu sujjadan qaalooo aamannaa bi Rabbi Haaroona wa Moosa"
  },
  {
    "id": 71,
    "text": "Qaala aamantum lahoo qabla an aazana lakum; innahoo lakabeerukumul lazee 'allama kumus sihra fala uqatti'anna aidiyakum wa arjulakum min khilaafinw wa la usallibannakum fee juzoo'in nakhli wa lata'lamunna aiyunaaa ashaddu 'azaabanw wa abqaa"
  },
  {
    "id": 72,
    "text": "Qaaloo lan nu'siraka 'alaa maa jaaa'anaa minal baiyinaati wallazee fataranaa faqdimaaa anta qaad; innamaa taqdee haazihil hayaatad dunyaa"
  },
  {
    "id": 73,
    "text": "Innaaa aamannaa bi Rabbinaa liyaghfira lanaa khataayaanaa wa maaa akrahtanaa 'alaihi minas sihr; wallaahu khairunw wa abqaa"
  },
  {
    "id": 74,
    "text": "Innahoo mai ya'ti Rabbahoo mujriman fa inna lahoo Jahannama laa yamootu feehaa wa laa yahyaa"
  },
  {
    "id": 75,
    "text": "Wa mai ya'tihee mu'minan qad 'amilas saalihaati fa ulaaa'ika lahumud darajaatul 'ulaa"
  },
  {
    "id": 76,
    "text": "Jannaatu 'Adnin tajree min tahtihal anhaaru khaalideena feehaa; wa zaalika jazaaa'u man tazakka"
  },
  {
    "id": 77,
    "text": "Wa laqad awhainaaa ilaa Moosaaa an asri bi'ibaadee fadrib lahum tareeqan fil bahri yabasal laa takhaafu darakanw wa laa takhshaa"
  },
  {
    "id": 78,
    "text": "Fa atba'ahum Fir'awnu bijunoodihee faghashiyahum minal yammmi maa ghashi yahum"
  },
  {
    "id": 79,
    "text": "Wa adalla fir'awnu qawmahoo wa maa hadaa"
  },
  {
    "id": 80,
    "text": "Yaa Baneee Israaa'eela qad anjainaakum min 'aduw wikum wa wa'adnaakum jaanibat Tooril aimana wa nazzalnaa 'alaikumul Manna was Salwaa"
  },
  {
    "id": 81,
    "text": "Kuloo min taiyibaati maa razaqnaakum wa laa tatghaw feehi fa yahilla 'alaikum ghadabee wa mai yahlil 'alaihi ghadabee faqad hawaa"
  },
  {
    "id": 82,
    "text": "Wa innee la Ghaffaarul liman taaba wa aamana wa 'amila saalihan summah tadaa"
  },
  {
    "id": 83,
    "text": "Wa maaa a'jalaka 'an qawmika yaa Moosa"
  },
  {
    "id": 84,
    "text": "Qaala hum ulaaa'i 'alaaa asaree wa 'ajiltu ilaika Rabbi litardaa"
  },
  {
    "id": 85,
    "text": "Qaala fa innaa qad fatannaa qawmaka mim ba'dika wa adallahumus Saamiriyy"
  },
  {
    "id": 86,
    "text": "Faraja'a Moosaaa ilaa qawmihee ghadbaana asifaa; qaala yaa qawmi alam ya'idkum Rabbukum wa'dan hasanaa; afataala 'alaikumul 'ahdu am arattum ai yahilla 'alaikum ghadabum mir Rabbikum fa akhlaftum maw'idee"
  },
  {
    "id": 87,
    "text": "Qaaloo maaa akhlafnaa maw'idaka bimalkinna wa laakinna hummilnaaa awzaaram min zeenatil qawmi faqazafnaahaa fakazaalika alqas Saamiriyy"
  },
  {
    "id": 88,
    "text": "Fa akhraja lahum 'ijlan jasadal lahoo khuwaarun faqaaloo haazaaa ilaahukum wa ilaahu Moosaa fanasee"
  },
  {
    "id": 89,
    "text": "Afalaa yarawna allaa yarji'u ilaihim qawlanw wa laa yamliku lahum darranw wa laa naf'aa"
  },
  {
    "id": 90,
    "text": "Wa laqad qaala lahum Haaroonu min qablu yaa qawmi innamaa futintum bihee wa inna Rabbakumur Rahmaanu fattabi'oonee wa atee'ooo amree"
  },
  {
    "id": 91,
    "text": "Qaaloo lan nabraha 'alaihi 'aakifeena hattaa yarji'a ilainaa Moosaa"
  },
  {
    "id": 92,
    "text": "Qaala Yaa Haaroonu maa mana 'aka iz ra aitahum dallooo"
  },
  {
    "id": 93,
    "text": "Allaa tattabi'ani afa'asaita amree"
  },
  {
    "id": 94,
    "text": "Qaala yabna'umma laa ta'khuz bi lihyatee wa laa bi ra'see innee khasheetu an taqoola farraqta baina Baneee Israaa'eela wa lam tarqub qawlee"
  },
  {
    "id": 95,
    "text": "Qaala famaa khatbuka yaa Saamiriyy"
  },
  {
    "id": 96,
    "text": "Qaala basurtu bimaa lam yabsuroo bihee faqabadtu qabdatam min asarir Rasooli fanabaztuhaa wa kazaalika sawwalat lee nafsee"
  },
  {
    "id": 97,
    "text": "Qaala fazhab fa inna laka fil hayaati an taqoola laa misaasa wa inna laka maw'idal lan tukhlafahoo wanzur ilaaa ilaahikal lazee zalta 'alaihi 'aakifaa; la nuharriqannahoo thumma la nansifannahoo fil yammi nasfaa"
  },
  {
    "id": 98,
    "text": "Innamaaa ilaahu kumul laahul lazee laa ilaaha illaa Hoo; wasi'a kulla shai'in ilmaa"
  },
  {
    "id": 99,
    "text": "Kazaalika naqussu 'alaika min anbaaa'i maa qad sabaq; wa qad aatainaaka mil ladunnaa Zikraa"
  },
  {
    "id": 100,
    "text": "Man a'rada 'anhu, fa innahoo yahmilu Yawmal Qiyaamati wizraa"
  },
  {
    "id": 101,
    "text": "Khaalideena feehi wa saaa'a lahum Yawmal Qiyaamati himlaa"
  },
  {
    "id": 102,
    "text": "Yawma yunfakhu fissoori wa nahshurul mujrimeena Yawma 'izin zurqaa"
  },
  {
    "id": 103,
    "text": "Yatakhaafatoona bainahum il labistum illaa 'ashraa"
  },
  {
    "id": 104,
    "text": "Nahnu a'lamu bimaa yaqooloona iz yaqoolu amsaluhum tareeqatan illabistum illaa yawmaa"
  },
  {
    "id": 105,
    "text": "Wa yas'aloonaka 'anil jibaali faqul yansifuhaa Rabbee nasfaa"
  },
  {
    "id": 106,
    "text": "Fa yazaruhaa qaa'an safsafaa"
  },
  {
    "id": 107,
    "text": "Laa taraa feehaa 'iwajanw wa laaa amtaa"
  },
  {
    "id": 108,
    "text": "Yawma iziny yattabi'oonad daa'iya laa 'iwaja lahoo wa khasha'atil aswaatu lir Rahmaani falaa tasma'u illaa hamsaa"
  },
  {
    "id": 109,
    "text": "Yawma 'izil laa tanfa'ush shafaa'atu illaa man azina lahur Rahmaanu wa radiya lahoo qawlaa"
  },
  {
    "id": 110,
    "text": "Ya'lamu maa bainaa aideehim wa maa khalfahum wa laa yuheetoona bihee 'ilmaa"
  },
  {
    "id": 111,
    "text": "Wa 'anatil wujoohu lil Haiiyil Qaiyoomi wa qad khaaba man hamala zulmaa"
  },
  {
    "id": 112,
    "text": "Wa mai ya'mal minas saalihaati wa huwa mu'minun falaa yakhaafu zulmanw wa laa hadmaa"
  },
  {
    "id": 113,
    "text": "Wa kazaalika anzalnaahu Qur-aanan 'Arabiyyanw wa sarrafnaa fee hi minal wa'eedi la'allahum yattaqoona aw yuhdisu lahum zikraa"
  },
  {
    "id": 114,
    "text": "Fata'aalal laahul Malikul Haqq; wa laa ta'jal bil Quraani min qabli ai yuqdaaa ilaika wahyuhoo wa qur Rabbi zidnee 'ilmaa"
  },
  {
    "id": 115,
    "text": "Wa laqad 'ahidnaaa ilaaa Aadama min qablu fanasiya wa lam najid lahoo 'azmaa"
  },
  {
    "id": 116,
    "text": "Wa iz qulnaa lilma laaa'ikatis judoo li Aadama fasajadooo illaaa Ibleesa; abaa"
  },
  {
    "id": 117,
    "text": "Faqulnaa yaaa Aadamu inna haazaa 'aduwwul laka wa lizawjika falaa yukhrijan nakumaa minal Jannati fatashqaa"
  },
  {
    "id": 118,
    "text": "Innaa laka allaa tajoo'a feeha wa laa ta'raa"
  },
  {
    "id": 119,
    "text": "Wa annaka laa tazma'u feehaa wa laa tadhaa"
  },
  {
    "id": 120,
    "text": "Fa waswasa ilaihish Shaitaanu qaala yaaa Aadamu hal adulluka 'alaa shajaratil khuldi wa mulkil laa yablaa"
  },
  {
    "id": 121,
    "text": "Fa akalaa minhaa fabadat lahumaa saw aatuhumaa wa tafiqaa yakhsifaani 'alaihimaa minw waraqil jannah; wa 'asaaa Aadamu Rabbahoo faghawaa"
  },
  {
    "id": 122,
    "text": "Summaj tabbahu Rabbuhoo fataaba 'alaihi wa hadaa"
  },
  {
    "id": 123,
    "text": "Qaalah bita minhaa jamee'am ba'dukum liba'din 'aduww; fa immaa ya'tiyannakum minnee hudan famanit taba'a hudaaya falaa yadillu wa laa yashqaa"
  },
  {
    "id": 124,
    "text": "Wa man a'rada 'an Zikree fa inna lahoo ma'eeshatan dankanw wa nahshuruhoo Yawmal Qiyaamati a'maa"
  },
  {
    "id": 125,
    "text": "Qaala Rabbi lima hashar tanee a'maa wa qad kuntu baseeraa"
  },
  {
    "id": 126,
    "text": "Qaala kazaalika atatka Aayaatunaa fanaseetahaa wa kazaalikal Yawma tunsaa"
  },
  {
    "id": 127,
    "text": "Wa kazaalika najzee man asrafa wa lam yu'min bi Aayaati Rabbih; wa la'azaabul Aakhirati ashaddu wa abqaa"
  },
  {
    "id": 128,
    "text": "Afalam yahdi lahum kam ahlaknaa qablahum minal qurooni yamshoona fee masaakinihim; inna fee zaalika la Aayaatil li ulinnuhaa"
  },
  {
    "id": 129,
    "text": "Wa law laa Kalimatun sabaqat mir Rabbika lakaana lizaamanw wa 'ajalun musammaa"
  },
  {
    "id": 130,
    "text": "Fasbir 'alaa maa yaqooloona wa sabbih bihamdi Rabbika qabla tuloo'ish shamsi wa qabla ghuroobihaa wa min aanaaa'il laili fasabbih wa atraafan nahaari la 'allaka tardaa"
  },
  {
    "id": 131,
    "text": "Wa laa tamuddanna 'ainaika ilaa ma matta'na biheee azwajam minhum zahratal hayaatid dunya linaftinahum feeh; wa rizqu Rabbika khairunw wa abqaa"
  },
  {
    "id": 132,
    "text": "Wa'mur ahlaka bis Salaati wastabir 'alaihaa laa nas'aluka rizqaa; nahnu narzuquk; wal 'aaqibatu littaqwaa"
  },
  {
    "id": 133,
    "text": "Wa qaaloo law laa ya'teenaa bi aayatin mir Rabbih; awa lam ta'tihim baiyinatu maa fis suhufil oolaa"
  },
  {
    "id": 134,
    "text": "Wa law annaaa ahlaknaahum bi 'azaabin min qablihee laqaaloo Rabbanaa law laaa arsalta ilainaa Rasoolan fanattabi'a Aayaatika min qabli an nazilla wa nakhzaa"
  },
  {
    "id": 135,
    "text": "Qul kullum mutarabbisun fa tarabbasoo fa sa ta'lamoona man Ashaabus Siraatis Sawiyyi wa manih tadaa"
  }
];

export default en;
