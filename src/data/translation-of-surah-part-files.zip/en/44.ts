import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Haa Meeem"
  },
  {
    "id": 2,
    "text": "Wal Kitaabil Mubeen"
  },
  {
    "id": 3,
    "text": "Innaaa anzalnaahu fee lailatim mubaarakah; innaa kunnaa munzireen"
  },
  {
    "id": 4,
    "text": "Feehaa yufraqu kullu amrin hakeem"
  },
  {
    "id": 5,
    "text": "Amram min 'indinaaa; innaa kunnaa mursileen"
  },
  {
    "id": 6,
    "text": "Rahmatam mir rabbik; innahoo Huwas Samee'ul 'Aleem"
  },
  {
    "id": 7,
    "text": "Rabbis samaawaati wal ardi wa maa bainahumaa; in kuntum mooqineen"
  },
  {
    "id": 8,
    "text": "Laaa ilaaha illaa Huwa yuhyee wa yumeetu Rabbukum wa Rabbu aabaaa'ikumul awwaleen"
  },
  {
    "id": 9,
    "text": "Bal hum fee shakkiny yal'aboon"
  },
  {
    "id": 10,
    "text": "Fartaqib Yawma ta'tis samaaa'u bi dukhaanin mubeen"
  },
  {
    "id": 11,
    "text": "Yaghshan naasa haazaa 'azaabun aleem"
  },
  {
    "id": 12,
    "text": "Rabbanak shif 'annal 'azaaba innaa mu'minoon"
  },
  {
    "id": 13,
    "text": "Annaa lahumuz zikraa wa qad jaaa'ahum Rasoolum mubeen"
  },
  {
    "id": 14,
    "text": "Summaa tawallaw 'anhu wa qaaloo mu'allamum majnoon"
  },
  {
    "id": 15,
    "text": "Innaa kaashiful 'azaabi qaleelaa; innakum 'aaa'idoon"
  },
  {
    "id": 16,
    "text": "Yawma nabtishul batsha tal kubraa innaa muntaqimoon"
  },
  {
    "id": 17,
    "text": "Wa laqad fatannaa qablahum qawma Fir'awna wa jaaa'ahum Rasoolun kareem"
  },
  {
    "id": 18,
    "text": "An addooo ilaiya 'ibaadal laahi innee lakum Rasoolun ameen"
  },
  {
    "id": 19,
    "text": "Wa al laa ta'loo 'alal laahi innee aateekum bisultaanim mubeen"
  },
  {
    "id": 20,
    "text": "Wa innee 'uztu bi Rabbee wa rabbikum an tarjumoon"
  },
  {
    "id": 21,
    "text": "Wa il lam tu'minoo lee fa'taziloon"
  },
  {
    "id": 22,
    "text": "Fada'aa rabbahooo anna haaa'ulaaa'i qawmum mujrimoon"
  },
  {
    "id": 23,
    "text": "Fa asri bi'ibaadee lailan innakum muttaba'oon"
  },
  {
    "id": 24,
    "text": "Watrukil bahra rahwan innahum jundum mughraqoon"
  },
  {
    "id": 25,
    "text": "Kam tarakoo min jannaatinw wa 'uyoon"
  },
  {
    "id": 26,
    "text": "Wa zuroo'inw wa maqaa min kareem"
  },
  {
    "id": 27,
    "text": "Wa na'matin kaanoo feehaa faakiheen"
  },
  {
    "id": 28,
    "text": "Kazaalika wa awrasnaahaa qawman aakhareen"
  },
  {
    "id": 29,
    "text": "Famaa bakat 'alaihimus samaaa'u wal ardu wa maa kaanoo munzareen"
  },
  {
    "id": 30,
    "text": "Wa laqad najjainaa Baneee Israaa'eela minal'azaabil muheen"
  },
  {
    "id": 31,
    "text": "Min Fir'awn; innahoo kaana 'aaliyam minal musrifeen"
  },
  {
    "id": 32,
    "text": "Wa laqadikh tarnaahum 'alaa 'ilmin 'alal 'aalameen"
  },
  {
    "id": 33,
    "text": "Wa aatainaahum minal aayaati maa feehi balaaa'um mubeen"
  },
  {
    "id": 34,
    "text": "Inna haaa'ulaaa'i la yaqooloon"
  },
  {
    "id": 35,
    "text": "In hiya illaa mawtatunal oolaa wa maa nahnu bimun shareen"
  },
  {
    "id": 36,
    "text": "Fa'too bi aabaaa'inaaa inkuntum saadiqeen"
  },
  {
    "id": 37,
    "text": "Ahum khayrun am qawmu Tubba'inw wallazeena min qablihim; ahlaknaahum innahum kaanoo mujrimeen"
  },
  {
    "id": 38,
    "text": "Wa maa khalaqnas samaawaati wal arda wa maa baina humaa laa'ibeen"
  },
  {
    "id": 39,
    "text": "Maa khalaqnaahumaaa illaa bilhaqqi wa laakinna aksarahum laa ya'lamoon"
  },
  {
    "id": 40,
    "text": "Inna yawmal fasli meeqaatuhum ajma'een"
  },
  {
    "id": 41,
    "text": "Yawma laa yughnee mawlan 'am mawlan shai'anw wa laa hum yunsaroon"
  },
  {
    "id": 42,
    "text": "Illaa mar rahimal laah' innahoo huwal 'azeezur raheem"
  },
  {
    "id": 43,
    "text": "Inna shajarataz zaqqoom"
  },
  {
    "id": 44,
    "text": "Ta'aamul aseem"
  },
  {
    "id": 45,
    "text": "Kalmuhli yaghlee filbutoon"
  },
  {
    "id": 46,
    "text": "Kaghalyil hameem"
  },
  {
    "id": 47,
    "text": "Khuzoohu fa'tiloohu ilaa sawaaa'il Jaheem"
  },
  {
    "id": 48,
    "text": "Summa subboo fawqa ra'sihee min 'azaabil hameem"
  },
  {
    "id": 49,
    "text": "Zuq innaka antal 'azeezul kareem"
  },
  {
    "id": 50,
    "text": "Inna haazaa maa kuntum bihee tamtaroon"
  },
  {
    "id": 51,
    "text": "Innal muttaqeena fee maqaamin ameen"
  },
  {
    "id": 52,
    "text": "Fee jannaatinw wa 'uyoon"
  },
  {
    "id": 53,
    "text": "Yalbasoona min sundusinw wa istabraqim mutaqaabileen"
  },
  {
    "id": 54,
    "text": "Kazaalika wa zawwajnaahum bihoorin 'een"
  },
  {
    "id": 55,
    "text": "Yad'oona feehaa bikulli faakihatin aamineen"
  },
  {
    "id": 56,
    "text": "Laa yazooqoona feehal mawtaa illal mawtatal oolaa wa waqaahum 'azaabal jaheem"
  },
  {
    "id": 57,
    "text": "Fadlam mir rabbik; zaalika huwal fawzul 'azeem"
  },
  {
    "id": 58,
    "text": "Fa innamaa yassarnaahu bilisaanika la'allahum yatazakkaroon"
  },
  {
    "id": 59,
    "text": "Fartaqib innahum murta qiboon"
  }
];

export default en;
