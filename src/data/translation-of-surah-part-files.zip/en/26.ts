import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Taa-Seeen-Meeem"
  },
  {
    "id": 2,
    "text": "Tilka Aayaatul Kitaabil Mubeen"
  },
  {
    "id": 3,
    "text": "La'allaka baakhi'un nafsaka allaa yakoonoo mu'mineen"
  },
  {
    "id": 4,
    "text": "In nashaa nunazzil 'alaihim minas samaaa'i Aayatan fazallat a'naaquhum lahaa khaadi'een"
  },
  {
    "id": 5,
    "text": "Wa maa yaateehim min zikrim minar Rahmaani muhdasin illaa kaanoo 'anhu mu'rideen"
  },
  {
    "id": 6,
    "text": "Faqad kazzaboo fasa yaateehim ambaaa'u maa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 7,
    "text": "Awa lam yaraw ilal ardi kam ambatnaa feehaa min kulli zawjin kareem"
  },
  {
    "id": 8,
    "text": "Inna fee zaalika la Aayah; wa maa kaana aksaruhum mu'mineen"
  },
  {
    "id": 9,
    "text": "Wa inna Rabbaka la Huwal 'Azeezur Raheem"
  },
  {
    "id": 10,
    "text": "Wa iz naadaa Rabbuka Moosaaa ani'-til qawmaz zaalimeen"
  },
  {
    "id": 11,
    "text": "Qawma Fir'awn; alaa yattaqoon"
  },
  {
    "id": 12,
    "text": "Qaala Rabbi inneee akhaafu ai yukazziboon"
  },
  {
    "id": 13,
    "text": "Wa yadeequ sadree wa laa yantaliqu lisaanee fa arsil ilaa Haaroon"
  },
  {
    "id": 14,
    "text": "Wa lahum 'alaiya zambun fa akhaafu ai yaqtuloon"
  },
  {
    "id": 15,
    "text": "Qaala kallaa fazhabaa bi Aayaatinaaa innaa ma'akum mustami'oon"
  },
  {
    "id": 16,
    "text": "Faatiyaa Fir'awna faqoolaaa innaa Rasoolu Rabbil 'aalameen"
  },
  {
    "id": 17,
    "text": "An arsil ma'anaa Baneee Israaa'eel"
  },
  {
    "id": 18,
    "text": "Qaala alam nurabbika feenaa waleedanw wa labista feenaa min 'umurika sineen"
  },
  {
    "id": 19,
    "text": "Wa fa'alta fa'latakal latee fa'alta wa anta minal kaafireen"
  },
  {
    "id": 20,
    "text": "Qaala fa'altuhaaa izanw wa ana minad daaaleen"
  },
  {
    "id": 21,
    "text": "Fafarartu minkum lam maa khiftukum fawahaba lee Rabbee hukmanw wa ja'alanee minal mursaleen"
  },
  {
    "id": 22,
    "text": "Wa tilka ni'matun tamun nuhaa 'alaiya an 'abbatta Baneee Israaa'eel"
  },
  {
    "id": 23,
    "text": "Qaala Fir'awnu wa maa Rabbul 'aalameen"
  },
  {
    "id": 24,
    "text": "Qaala Rabbus samaawaati wal ardi wa maa bainahumaa in kuntum mooqineen"
  },
  {
    "id": 25,
    "text": "Qaala liman hawlahooo alaa tastami'oon"
  },
  {
    "id": 26,
    "text": "Qaala Rabbukum wa Rabbu aabaaa'ikumul awwaleen"
  },
  {
    "id": 27,
    "text": "Qaala inna Rasoolakumul lazee ursila ilaikum lamajnoon"
  },
  {
    "id": 28,
    "text": "Qaala Rabbul mashriqi wal maghribi wa maa baina humaa in kuntum ta'qiloon"
  },
  {
    "id": 29,
    "text": "Qaala la'init takhazta ilaahan ghairee la aj'alannaka minal masjooneen"
  },
  {
    "id": 30,
    "text": "Qaala awalaw ji'tuka bishai'im mubeen"
  },
  {
    "id": 31,
    "text": "Qaala faati biheee in kunta minas saadiqeen"
  },
  {
    "id": 32,
    "text": "Fa alqaa 'asaahu fa izaaa hiya su'baanum mubeen"
  },
  {
    "id": 33,
    "text": "Wa naza'a yadahoo faizaa hiya baidaaa'u linnaa zireen"
  },
  {
    "id": 34,
    "text": "Qaala lilmala-i hawlahooo inna haazaa lasaahirun 'aleem"
  },
  {
    "id": 35,
    "text": "Yureedu ai yukhrijakum min ardikum bisihrihee famaazaa taamuroon"
  },
  {
    "id": 36,
    "text": "Qaalooo arjih wa akhaahu wab'as filmadaaa'ini haashireen"
  },
  {
    "id": 37,
    "text": "Yaatooka bikulli sah haarin 'aleem"
  },
  {
    "id": 38,
    "text": "Fa jumi'as saharatu limeeqaati Yawmim ma'loom"
  },
  {
    "id": 39,
    "text": "Wa qeela linnaasi hal antum mujtami'oon"
  },
  {
    "id": 40,
    "text": "La'allanaa nattabi'us saharata in kaanoo humul ghaalibeen"
  },
  {
    "id": 41,
    "text": "Falammaa jaaa'as saharatu qaaloo li Fir'awna a'inna lanaa la ajjran in kunnaa nahnul ghaalibeen"
  },
  {
    "id": 42,
    "text": "Qaala na'am wa innakum izal laminal muqarrabeen"
  },
  {
    "id": 43,
    "text": "Qaala lahum Moosaaa alqoo maaa antum mulqoon"
  },
  {
    "id": 44,
    "text": "Fa alqaw hibaalahum wa 'isiyyahum wa qaaloo bi'izzati Fir'awna innaa lanahnul ghaaliboon"
  },
  {
    "id": 45,
    "text": "Fa alqaa Moosaa 'asaahu fa izaa hiya talqafu maa yaafikoon"
  },
  {
    "id": 46,
    "text": "Fa ulqiyas saharatu saajideen"
  },
  {
    "id": 47,
    "text": "Qaalooo aamannaa bi Rabbil 'aalameen"
  },
  {
    "id": 48,
    "text": "Rabbi Moosaa wa Haaroon"
  },
  {
    "id": 49,
    "text": "Qaala aamantum lahoo qabla an aazana lakum innahoo lakabeerukumul lazee 'alla makumus sihra falasawfa ta'lamoon; la uqatti'anna aidiyakum wa arjulakum min khilaafinw wa la usallibanna kum ajma'een"
  },
  {
    "id": 50,
    "text": "Qaaloo la daira innaaa ilaa Rabbinaa munqalliboon"
  },
  {
    "id": 51,
    "text": "Innaa natma'u ai yaghfira lanaa Rabbunaa khataa yaanaaa an kunnaaa awwalal mu'mineen"
  },
  {
    "id": 52,
    "text": "Wa awhainaaa ilaa Moosaaa an asri bi'ibaadeee innakum muttaba'oon"
  },
  {
    "id": 53,
    "text": "Fa arsala Fir'awnu filmadaaa'ini haashireen"
  },
  {
    "id": 54,
    "text": "Inna haaa'ulaaa'i lashir zimatun qaleeloon"
  },
  {
    "id": 55,
    "text": "Wa innahum lanaa laghaaa'izoon"
  },
  {
    "id": 56,
    "text": "Wa innaa lajamee'un haaziroon"
  },
  {
    "id": 57,
    "text": "Fa akhrajnaahum min Jannaatinw wa 'uyoon"
  },
  {
    "id": 58,
    "text": "Wa kunoozinw wa ma qaamin kareem"
  },
  {
    "id": 59,
    "text": "Kazaalika wa awrasnaahaa Baneee Israaa'eel"
  },
  {
    "id": 60,
    "text": "Fa atba'oohum mushriqeen"
  },
  {
    "id": 61,
    "text": "Falammaa taraaa'al jam'aani qaala as haabu Moosaaa innaa lamudrakoon"
  },
  {
    "id": 62,
    "text": "Qaala kallaaa inna ma'iya Rabbee sa yahdeen"
  },
  {
    "id": 63,
    "text": "Fa awhainaaa ilaa Moosaaa anidrib bi'asaakal bahra fanfalaqa fakaana kullu firqin kattawdil 'azeem"
  },
  {
    "id": 64,
    "text": "Wa azlafnaa sammal aakhareen"
  },
  {
    "id": 65,
    "text": "Wa anjainaa Moosaa wa mam ma'ahooo ajma'een"
  },
  {
    "id": 66,
    "text": "Summa aghraqnal aakhareen"
  },
  {
    "id": 67,
    "text": "Inna fee zaalika la Aayaah; wa maa kaana aksaru hu mu'mineen"
  },
  {
    "id": 68,
    "text": "Wa inna Rabbaka la Huwal 'Azeezur Raheem"
  },
  {
    "id": 69,
    "text": "Watlu 'alaihim naba-a Ibraaheem"
  },
  {
    "id": 70,
    "text": "Iz qaala li abeehi wa qawmihee maa ta'budoon"
  },
  {
    "id": 71,
    "text": "Qaaloo na'budu asnaaman fanazallu lahaa 'aakifeen"
  },
  {
    "id": 72,
    "text": "Qaala hal yasma'oona kum iz tad'oon"
  },
  {
    "id": 73,
    "text": "Aw yanfa'oonakum aw yadurroon"
  },
  {
    "id": 74,
    "text": "Qaaloo bal wajadnaaa aabaaa 'anaa kazaalika yaf'aloon"
  },
  {
    "id": 75,
    "text": "Qaala afara 'aitum maa kuntum ta'budoon"
  },
  {
    "id": 76,
    "text": "Antum wa aabaaa'ukumul aqdamoon"
  },
  {
    "id": 77,
    "text": "Fa innahum 'aduwwwul leee illaa Rabbal 'aalameen"
  },
  {
    "id": 78,
    "text": "Allazee khalaqanee fa Huwa yahdeen"
  },
  {
    "id": 79,
    "text": "Wallazee Huwa yut'imunee wa yasqeen"
  },
  {
    "id": 80,
    "text": "Wa izaa maridtu fahuwa yashfeen"
  },
  {
    "id": 81,
    "text": "Wallazee yumeetunee summa yuhyeen"
  },
  {
    "id": 82,
    "text": "Wallazeee atma'u ai yaghfira lee khateee' atee Yawmad Deen"
  },
  {
    "id": 83,
    "text": "Rabbi hab lee hukmanw wa alhiqnee bis saaliheen"
  },
  {
    "id": 84,
    "text": "Waj'al lee lisaana sidqin fil aakhireen"
  },
  {
    "id": 85,
    "text": "Waj'alnee minw warasati Jannnatin Na'eem"
  },
  {
    "id": 86,
    "text": "Waghfir li abeee innahoo kaana mind daalleen"
  },
  {
    "id": 87,
    "text": "Wa laa tukhzinee Yawma yub'asoon"
  },
  {
    "id": 88,
    "text": "Yawma laa yanfa'u maalunw wa laa banoon"
  },
  {
    "id": 89,
    "text": "Illaa man atal laaha biqalbin saleem"
  },
  {
    "id": 90,
    "text": "Wa uzlifatil Jannatu lilmuttaqeen"
  },
  {
    "id": 91,
    "text": "Wa burrizatil Jaheemu lilghaaween"
  },
  {
    "id": 92,
    "text": "Wa qeela lahum aina maa kuntum ta'budoon"
  },
  {
    "id": 93,
    "text": "Min doonil laahi hal yansuroonakum aw yantasiroon"
  },
  {
    "id": 94,
    "text": "Fakubkiboo feehaa hum walghaawoon"
  },
  {
    "id": 95,
    "text": "Wa junoodu Ibleesa ajma'oon"
  },
  {
    "id": 96,
    "text": "Qaaloo wa hum feehaa yakkhtasimoon"
  },
  {
    "id": 97,
    "text": "Tallaahi in kunnaa lafee dalaalim mubeen"
  },
  {
    "id": 98,
    "text": "Iz nusawweekum bi Rabbil 'aalameen"
  },
  {
    "id": 99,
    "text": "Wa maaa adallanaaa illal mujrimoon"
  },
  {
    "id": 100,
    "text": "Famaa lanaa min shaa fi'een"
  },
  {
    "id": 101,
    "text": "Wa laa sadeeqin hameem"
  },
  {
    "id": 102,
    "text": "Falaw anna lanaa karratan fanakoona minal mu'mineen"
  },
  {
    "id": 103,
    "text": "Inna fee zaalika la Aayatanw wa maa kaana aksaruhum mu'mineen"
  },
  {
    "id": 104,
    "text": "Wa inna Rabbaka la Huwal 'Azeezur Raheem"
  },
  {
    "id": 105,
    "text": "Kazzabat qawmu Noohinil Mursaleen"
  },
  {
    "id": 106,
    "text": "Iz qaala lahum akhoohum Noohun alaa tattaqoon"
  },
  {
    "id": 107,
    "text": "Innee lakum Rasoolun ameen"
  },
  {
    "id": 108,
    "text": "Fattaqullaaha wa atee'oon"
  },
  {
    "id": 109,
    "text": "Wa maaa as'alukum 'alaihi min ajrin in ajriya illaa 'alaa Rabbil 'aalameen"
  },
  {
    "id": 110,
    "text": "Fattaqul laaha wa atee'oon"
  },
  {
    "id": 111,
    "text": "Qaalooo anu'minu laka wattaba 'akal arzaloon"
  },
  {
    "id": 112,
    "text": "Qaala wa maa 'ilmee bimaa kaanoo ya'maloon"
  },
  {
    "id": 113,
    "text": "In hisaabuhum illaa 'alaa Rabbee law tash'uroon"
  },
  {
    "id": 114,
    "text": "Wa maaa ana bitaaridil mu'mineen"
  },
  {
    "id": 115,
    "text": "In ana illaa nazeerum mubeen"
  },
  {
    "id": 116,
    "text": "Qaaloo la'il lam tantahi yaa Noohu latakoonanna minal marjoomeen"
  },
  {
    "id": 117,
    "text": "Qaala Rabbi inna qawmee kazzaboon"
  },
  {
    "id": 118,
    "text": "Faftab bainee wa bai nahum fat hanw wa najjinee wa mam ma'iya minal mu'mineen"
  },
  {
    "id": 119,
    "text": "Fa anjainaahu wa mamma'ahoo fil fulkil mashhoon"
  },
  {
    "id": 120,
    "text": "Summa aghraqnaa ba'dul baaqeen"
  },
  {
    "id": 121,
    "text": "Inna fee zaalika la Aayaah; wa maa kaana aksaruhum mu'mineen"
  },
  {
    "id": 122,
    "text": "Wa inna Rabbaka la huwal 'Azeezur Raheem"
  },
  {
    "id": 123,
    "text": "Kazzabat 'Aadunil mursaleen"
  },
  {
    "id": 124,
    "text": "Iz qaala lahum akhoohum Hoodun alaa tattaqoon"
  },
  {
    "id": 125,
    "text": "Innee lakum Rasoolun ameen"
  },
  {
    "id": 126,
    "text": "Fattaqullaaha wa atee'oon"
  },
  {
    "id": 127,
    "text": "Wa maa as'alukum 'alaihi min ajrin in ajriya illaa 'alaa Rabbil 'aalameen"
  },
  {
    "id": 128,
    "text": "Atabnoona bikulli ree'in aayatan ta'basoon"
  },
  {
    "id": 129,
    "text": "Wa tattakhizoona masaani'a la'allakum takhludoon"
  },
  {
    "id": 130,
    "text": "Wa izaa batashtum batashtum jabbaareen"
  },
  {
    "id": 131,
    "text": "Fattaqul laaha wa atee'oon"
  },
  {
    "id": 132,
    "text": "Wattaqul lazeee amad dakum bimaa ta'lamoon"
  },
  {
    "id": 133,
    "text": "Amaddakum bi an'aa minw wa baneen"
  },
  {
    "id": 134,
    "text": "Wa jannaatinw wa 'uyoon"
  },
  {
    "id": 135,
    "text": "Innee akhaafu 'alaikum 'azaaba Yawmin 'azeem"
  },
  {
    "id": 136,
    "text": "Qaaloo sawaaa'un 'alainaaa awa 'azta am lam takum minal waa'izeen"
  },
  {
    "id": 137,
    "text": "In haazaaa illaa khuluqul awwaleen"
  },
  {
    "id": 138,
    "text": "Wa maa nahnu bimu 'azzabeen"
  },
  {
    "id": 139,
    "text": "Fakazzaboohu fa ahlaknaahum; inna fee zaalika la aayah; wa maa kaana aksaruhum mu'mineen"
  },
  {
    "id": 140,
    "text": "Wa inna Rabbaka la huwal 'Azeezur Raheem"
  },
  {
    "id": 141,
    "text": "Kazzabat Samoodul mursaleen"
  },
  {
    "id": 142,
    "text": "Iz qaala lahum akhoohum Saalihun alaa tattaqoon"
  },
  {
    "id": 143,
    "text": "Innee lakum Rasoolun ameen"
  },
  {
    "id": 144,
    "text": "Fattaqul laaha wa atee'oon"
  },
  {
    "id": 145,
    "text": "Wa maaa as'alukum 'alaihi min ajrin in ajriya illaa 'alaa Rabbil 'aalameen"
  },
  {
    "id": 146,
    "text": "Atutrakoona fee maa haahunnaaa aamineen"
  },
  {
    "id": 147,
    "text": "Fee jannaatinw wa 'uyoon"
  },
  {
    "id": 148,
    "text": "Wa zuroo inw wa nakhlin tal 'uhaa hadeem"
  },
  {
    "id": 149,
    "text": "Wa tanhitoona minal jibaali buyootan faariheen"
  },
  {
    "id": 150,
    "text": "Fattaqul laaha wa atee'oon"
  },
  {
    "id": 151,
    "text": "Wa laa tutee'ooo amral musrifeen"
  },
  {
    "id": 152,
    "text": "Allazeena yufsidoona fil ardi wa laa yuslihoon"
  },
  {
    "id": 153,
    "text": "Qaalooo innamaa anta minal musahhareen"
  },
  {
    "id": 154,
    "text": "Maaa anta illaa basharum mislunaa faati bi Aayatin in kunta minas saadiqeen"
  },
  {
    "id": 155,
    "text": "Qaala haazihee naaqatul lahaa shirbunw walakum shirbu yawmim ma'loom"
  },
  {
    "id": 156,
    "text": "Wa laa tamassoohaa bisooo'in fa yaakhuzakum 'azaabu Yawmin 'Azeem"
  },
  {
    "id": 157,
    "text": "Fa'aqaroohaa fa asbahoo naadimeen"
  },
  {
    "id": 158,
    "text": "Fa akhazahumul 'azaab; inna fee zaalika la Aayah; wa maa kaana aksaruhum mu'mineen"
  },
  {
    "id": 159,
    "text": "Wa inna Rabbaka la Huwal 'Azeezur Raheem"
  },
  {
    "id": 160,
    "text": "Kazzabat qawmu Lootinil mursaleen"
  },
  {
    "id": 161,
    "text": "Iz qaala lahum akhoohum Lootun alaa tattaqoon"
  },
  {
    "id": 162,
    "text": "Innee lakum rasoolun ameen"
  },
  {
    "id": 163,
    "text": "Fattaqul laaha wa atee'oon"
  },
  {
    "id": 164,
    "text": "Wa maaa as'alukum 'alaihi min ajrin in ajriya illaa 'alaa Rabbil 'aalameen"
  },
  {
    "id": 165,
    "text": "Ataatoonaz zukraana minal 'aalameen"
  },
  {
    "id": 166,
    "text": "Wa tazaroona maa khalaqa lakum Rabbukum min azwaajikum; bal antum qawmun 'aadoon"
  },
  {
    "id": 167,
    "text": "Qaloo la'il lam tantahi yaa Lootu latakoonanna minal mukhrajeen"
  },
  {
    "id": 168,
    "text": "Qaala innee li'amalikum minal qaaleen"
  },
  {
    "id": 169,
    "text": "Rabbi najjjinee wa ahlee mimmmaa ya'maloon"
  },
  {
    "id": 170,
    "text": "Fanajjainaahu wa ahlahooo ajma'een"
  },
  {
    "id": 171,
    "text": "Illaa 'ajoozan filghaabireen"
  },
  {
    "id": 172,
    "text": "Summa dammarnal aa khareen"
  },
  {
    "id": 173,
    "text": "Wa amtarnaa 'alaihim mataran fasaaa'a matarul munzareen"
  },
  {
    "id": 174,
    "text": "Inna fee zaalika la Aayah; wa maa kaana aksaruhum mu'mineen"
  },
  {
    "id": 175,
    "text": "Wa inna Rabbaka la Huwal 'Azeezur Raheem"
  },
  {
    "id": 176,
    "text": "Kazzaba As haabul Aykatil mursaleen"
  },
  {
    "id": 177,
    "text": "Iz qaala lahum Shu'aybun alaa tattaqoon"
  },
  {
    "id": 178,
    "text": "Innee lakum Rasoolun ameen"
  },
  {
    "id": 179,
    "text": "Fattaqul laaha wa atee'oon"
  },
  {
    "id": 180,
    "text": "Wa maaa as'alukum 'alaihi min ajrin in ajriya illaa 'alaa Rabbil 'aalameen"
  },
  {
    "id": 181,
    "text": "Awful kaila wa laa takoonoo minal mukhsireen"
  },
  {
    "id": 182,
    "text": "Wa zinoo bilqistaasil mustaqeem"
  },
  {
    "id": 183,
    "text": "Wa laa tabkhasun naasa ashyaaa 'ahum wa laa ta'saw fil ardi mufsideen"
  },
  {
    "id": 184,
    "text": "Wattaqul lazee khalaqakum waljibillatal awwaleen"
  },
  {
    "id": 185,
    "text": "Qaalooo innamaa anta minal musahhareen"
  },
  {
    "id": 186,
    "text": "Wa maaa anta illaa basharum mislunaa wa innazunnuka laminal kaazibeen"
  },
  {
    "id": 187,
    "text": "Fa asqit 'alainaa kisafam minas samaaa'i in kunta minas saadiqeen"
  },
  {
    "id": 188,
    "text": "Qaala Rabbeee a'lamu bimaa ta'maloon"
  },
  {
    "id": 189,
    "text": "Fakazzaboohu fa akhazahum 'azaabu Yawmiz zullah; innahoo kaana 'azaaba Yawmin 'Azeem"
  },
  {
    "id": 190,
    "text": "Inna fee zaalika la Aayah; wa maa kaana aksaruhum mu'mineen"
  },
  {
    "id": 191,
    "text": "Wa inna Rabbaka la huwal 'Azeezur Raheem"
  },
  {
    "id": 192,
    "text": "Wa innahoo latanzeelu Rabbil 'aalameen"
  },
  {
    "id": 193,
    "text": "Nazala bihir Roohul Ameen"
  },
  {
    "id": 194,
    "text": "'Alaa qalbika litakoona minal munzireen"
  },
  {
    "id": 195,
    "text": "Bilisaanin 'Arabiyyim mubeen"
  },
  {
    "id": 196,
    "text": "Wa innahoo lafee Zuburil awwaleen"
  },
  {
    "id": 197,
    "text": "Awalam yakul lahum Aayatan ai ya'lamahoo 'ulamaaa'u Baneee Israaa'eel"
  },
  {
    "id": 198,
    "text": "Wa law nazzalnaahu 'alaa ba'dil a'jameen"
  },
  {
    "id": 199,
    "text": "Faqara ahoo 'alaihim maa kaanoo bihee mu'mineen"
  },
  {
    "id": 200,
    "text": "Kazaalika salaknaahu fee quloobil mujrimeen"
  },
  {
    "id": 201,
    "text": "Laa yu'minoona bihee hattaa yarawul 'azaabal aleem"
  },
  {
    "id": 202,
    "text": "Fayaatiyahum baghtatanw wa hum laa yash'uroon"
  },
  {
    "id": 203,
    "text": "Fa yaqooloo hal nahnu munzaroon"
  },
  {
    "id": 204,
    "text": "Afabi 'azaabinaa yasta'jiloon"
  },
  {
    "id": 205,
    "text": "Afara'aita im matta'naahum sineen"
  },
  {
    "id": 206,
    "text": "Summa jaaa'ahum maa kaanoo yoo'adoon"
  },
  {
    "id": 207,
    "text": "Maaa aghnaaa 'anhum maa kaanoo yumatta'oon"
  },
  {
    "id": 208,
    "text": "Wa maaa ahlaknaa min qaryatin illaa lahaa munziroon"
  },
  {
    "id": 209,
    "text": "Zikraa wa maa kunnaa zaalimeen"
  },
  {
    "id": 210,
    "text": "Wa maa tanazzalat bihish Shayaateen"
  },
  {
    "id": 211,
    "text": "Wa maa yambaghee lahum wa maa yastatee'oon"
  },
  {
    "id": 212,
    "text": "Innahum 'anis sam'i lama'zooloon"
  },
  {
    "id": 213,
    "text": "Falaa tad'u ma'al laahi ilaahan aakhara fatakoona minal mu'azzabeen"
  },
  {
    "id": 214,
    "text": "Wa anzir 'asheeratakal aqrabeen"
  },
  {
    "id": 215,
    "text": "Wakhfid janaahaka limanit taba 'aka minal mu'mineen"
  },
  {
    "id": 216,
    "text": "Fa in asawka faqul innee bareee'um mimmmaa ta'maloon"
  },
  {
    "id": 217,
    "text": "Wa tawakkal alal 'Azeezir Raheem"
  },
  {
    "id": 218,
    "text": "Allazee yaraaka heena taqoom"
  },
  {
    "id": 219,
    "text": "Wa taqallubaka fis saajideen"
  },
  {
    "id": 220,
    "text": "Innahoo Huwas Samee'ul 'Aleem"
  },
  {
    "id": 221,
    "text": "Hal unabbi'ukum 'alaa man tanazzalush Shayaateen"
  },
  {
    "id": 222,
    "text": "Tanazzalu 'alaa kulli affaakin aseem"
  },
  {
    "id": 223,
    "text": "Yulqoonas sam'a wa aksaruhum kaaziboon"
  },
  {
    "id": 224,
    "text": "Washshu 'araaa'u yattabi 'uhumul ghaawoon"
  },
  {
    "id": 225,
    "text": "Alam tara annahum fee kulli waadiny yaheemoon"
  },
  {
    "id": 226,
    "text": "Wa annahum yaqooloona ma laa yaf'aloon"
  },
  {
    "id": 227,
    "text": "Illal lazeena aamanoo wa 'amilus saalihaati wa zakarul laaha kaseeranw wantasaroo min ba'di maa zulimoo; wa saya'lamul lazeena zalamooo aiya munqalabiny yanqaliboon"
  }
];

export default en;
