import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Iqtaraba linnaasi hisaabuhum wa hum fee ghaflatim mu'ridoon"
  },
  {
    "id": 2,
    "text": "Maa ya'teehim min zikrim mir Rabbihim muhdasin illas tama'oohu wa hum yal'aboon"
  },
  {
    "id": 3,
    "text": "Laahiyatan quloobuhum; wa asarrun najwal lazeena zalamoo hal haazaaa illaa basharum mislukum 'afa ta'toonas sihra wa antum tubsiroon"
  },
  {
    "id": 4,
    "text": "Qaala Rabbee ya'lamul qawla fis samaaa'i wal ardi wa Huwas Samee'ul 'Aleem"
  },
  {
    "id": 5,
    "text": "Bal qaalooo adghaasu ahlaamin bal iftaraahu bal huwa shaa'irun fal ya'tinaa bi Aayatin kamaa ursilal awwaloon"
  },
  {
    "id": 6,
    "text": "Maaa aaamanat qablahum min qaryatin ahlaknaahaa a-fahum yu'minoon"
  },
  {
    "id": 7,
    "text": "Wa maaa arsalnaa qablaka illaa rijaalan nooheee ilaihim fas'aloo ahlaz zikri in kuntum laa ta'lamoon"
  },
  {
    "id": 8,
    "text": "Wa maa ja'alnaahum jasadal laa ya'kuloonat ta'aama wa maa kaanoo khaalideen"
  },
  {
    "id": 9,
    "text": "Summa sadaqnaa humul wa'da fa-anjainaahum wa man nashaaa'u wa ahlaknal musrifeen"
  },
  {
    "id": 10,
    "text": "Laqad anzalnaaa ilaikum Kitaaban feehi zikrukum afalaa ta'qiloon"
  },
  {
    "id": 11,
    "text": "Wa kam qasamnaa min qaryatin kaanat zaalimatanw wa ansha' naa ba'dahaa qawman aakhareen"
  },
  {
    "id": 12,
    "text": "Falammaaa ahassoo ba'sanaaa izaa hum minhaa yarkudoon"
  },
  {
    "id": 13,
    "text": "Laa tarkudoo warji'ooo ilaa maaa utriftum feehi wa masaakinikum la'allakum tus'aloon"
  },
  {
    "id": 14,
    "text": "Qaaloo yaa wailanaaa innaa kunnaa zaalimeen"
  },
  {
    "id": 15,
    "text": "Famaa zaalat tilka da'waahum hattaa ja'alnaahum haseedan khaamideen"
  },
  {
    "id": 16,
    "text": "Wa maa khalaqnas samaaa'a wal arda wa maa bainahumaa laa'ibeen"
  },
  {
    "id": 17,
    "text": "Law aradnaaa an nattakhiza lahwal lat takhaznaahu mil ladunnaaa in kunnaa faa'ileen"
  },
  {
    "id": 18,
    "text": "Bal naqzifu bilhaqqi 'alal baatili fa yadmaghuhoo fa izaa huwa zaahiq; wa lakumul wailu mimmaa tasifoon"
  },
  {
    "id": 19,
    "text": "Wa lahoo man fis samaawaati wal ard; wa man 'indahoo laa yastakbiroona 'an 'ibaada tihee wa laa yastahsiroon"
  },
  {
    "id": 20,
    "text": "Yusabbihoona laila wannahaara laa yafturoon"
  },
  {
    "id": 21,
    "text": "Amit takhazooo aalihatam minal ardi hum yunshiroon"
  },
  {
    "id": 22,
    "text": "Law kaana feehimaaa aalihatun illal laahu lafasadataa; fa-Subhaanal laahi Rabbil 'Arshi 'ammaa yasifoon"
  },
  {
    "id": 23,
    "text": "Laa yus'alu 'ammaa yaf'alu wa hum yus'aloon"
  },
  {
    "id": 24,
    "text": "Amit takhazoo min doonihee aalihatan qul haatoo burhaanakum haaza zikru mam ma'iya wa zikru man qablee; bal aksaruhum laa ya'lamoonal haqqa fahum mu'ridoon"
  },
  {
    "id": 25,
    "text": "Wa maaa arsalnaa min qablika mir Rasoolin illaa nooheee ilaihi annahoo laaa ilaaha illaaa Ana fa'budoon"
  },
  {
    "id": 26,
    "text": "Wa qaalut takhazar Rahmaanu waladaa; Subhaanahu bal 'ibaadum mukramoon"
  },
  {
    "id": 27,
    "text": "Laa yasbiqoonahoo bil qawli wa hum bi amrihee ya'maloon"
  },
  {
    "id": 28,
    "text": "Ya'lamu maa baina aideehim wa maa khalfahum wa laa yashfa'oona illaa limanir tadaa wa hum min khash yatihee mushfiqoon"
  },
  {
    "id": 29,
    "text": "Wa mai yaqul minhum inneee ilaahum min doonihee fazaalika najzeehi Jahannam; kazaalika najziz zaalimeen"
  },
  {
    "id": 30,
    "text": "Awalam yaral lazeena kafarooo annas samaawaati wal arda kaanataa ratqan fafataqnaa humaa wa ja'alnaa minal maaa'i kulla shai'in haiyin afalaa yu'minoon"
  },
  {
    "id": 31,
    "text": "Wa ja'alnaa fil ardi rawaasiya an tameeda bihim wa ja'alnaa feehaa fijaajan subulal la'allahum yahtadoon"
  },
  {
    "id": 32,
    "text": "Wa ja'alnas samaaa'a saqfam mahfoozanw wa hum 'an Aayaatihaa mu'ridoon"
  },
  {
    "id": 33,
    "text": "Wa Huwal lazee khalaqal laila wannahaara washshamsa wal qamara kullun fee falakiny yasbahoon"
  },
  {
    "id": 34,
    "text": "Wa maa ja'alnaa libasharim min qablikal khuld; afa immitta fahumul khaalidoon"
  },
  {
    "id": 35,
    "text": "Kullu nafsin zaaa'iqatul mawt; wa nablookum bi sharri walkhairi fitnatanw wa ilainaa turja'oon"
  },
  {
    "id": 36,
    "text": "Wa izaa ra aakal lazeena kafarooo iny-yattakhizoonaka illa huzuwan; ahaazal lazee yazkuru aalihatakum wa hum bi zikrir Rahmaani hum kaafiroon"
  },
  {
    "id": 37,
    "text": "Khuliqal insaanu min 'ajal; sa ureekum Aayaatee falaa tasta'jiloon"
  },
  {
    "id": 38,
    "text": "Wa yaqooloona mataa haazal wa'du in kuntum saadiqeen"
  },
  {
    "id": 39,
    "text": "Law ya'lamul lazeena kafaroo heena laa yakuffoona 'anw wujoohihimun Naara wa laa 'an zuhoorihim wa laa hum yunsaroon"
  },
  {
    "id": 40,
    "text": "Bal ta'teehim baghtatan fatabhatuhum falaa yastatee'oona raddahaa wa laa hum yunzaroon"
  },
  {
    "id": 41,
    "text": "Wa laqadis tuhzi'a bi-Rusulim min qablika fahaaqa billazeena sakhiroo minhum maa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 42,
    "text": "Qul mai yakla 'ukum billaili wannahaari minar Rahmaan; bal hum 'an zikri Rabbihim mu'ridoon"
  },
  {
    "id": 43,
    "text": "Am lahum aalihatun tamna'uhum min dooninaa; laa yastatee'oona nasra anfusihim wa laa hum minna yus-haboon"
  },
  {
    "id": 44,
    "text": "Bal matta'naa haaa'ulaaa'i wa aabaaa'ahum hattaa taala 'alaihimul 'umur; afalaa yarawna anna na'til arda nanqusuhaa min atraafihaa; afahumul ghaaliboon"
  },
  {
    "id": 45,
    "text": "Qul innamaaa unzirukum bilwahyi; wa laa yasma'us summud du'aaa 'a izaa maa yunzaroon"
  },
  {
    "id": 46,
    "text": "Wa la'in massat hum nafhatun min 'azaabi Rabbika la yaqoolunna yaawailanaaa innnaa kunnaa zaalimeen"
  },
  {
    "id": 47,
    "text": "Wa nada'ul mawaazeenal qista li Yawmil Qiyaamati falaa tuzlamu nafsun shai'aa; wa in kaana misqaala habbatim min khardalin atainaa bihaa; wa kafaa binaa haasibeen"
  },
  {
    "id": 48,
    "text": "Wa laqad aatainaa Moosa wa haaroonal Furqaana wa diyaa'anw wa zikral lilmuttaqeen"
  },
  {
    "id": 49,
    "text": "Allazeena yakhshawna Rabbahum bilghaibi wa hum minas Saa'ati mushfiqoon"
  },
  {
    "id": 50,
    "text": "Wa haazaa Zikrum Mubaarakun anzalnaah; afa antum lahoo munkiroon"
  },
  {
    "id": 51,
    "text": "Wa laqad aatainaaa Ibraaheema rushdahoo min qablu wa kunnaa bihee 'aalimeen"
  },
  {
    "id": 52,
    "text": "Iz qaala li abeehi wa qawmihee maa haazihit tamaaseelul lateee antum lahaa 'aakifoon"
  },
  {
    "id": 53,
    "text": "Qaaloo wajadnaaa aabaaa'anaa lahaa 'aabideen"
  },
  {
    "id": 54,
    "text": "Qaala laqad kuntum antum wa aabaaa'ukum fee dalaalin mubeen"
  },
  {
    "id": 55,
    "text": "Qaalooo aji'tanaa bil haqqi am anta minal laa'ibeen"
  },
  {
    "id": 56,
    "text": "Qaala bar Rabbukum Rabbus samaawaati wal ardil lazee fatarahunna wa ana 'alaa zaalikum minash shaahideen"
  },
  {
    "id": 57,
    "text": "Wa tallaahi la akeedanna asnaamakum ba'da an tuwalloo mudbireen"
  },
  {
    "id": 58,
    "text": "Faja'alahum juzaazan illaa kabeeral lahum la'allahum ilaihi yarji'oon"
  },
  {
    "id": 59,
    "text": "Qaaloo man fa'ala haazaa bi aalihatinaaa innahoo laminaz zaalimeen"
  },
  {
    "id": 60,
    "text": "Qaaloo sami'naa fatany yazkuruhum yuqaalu lahooo Ibraaheem"
  },
  {
    "id": 61,
    "text": "Qaaloo fa'too bihee 'alaaa a'yunin naasi la'allahum yash hadoon"
  },
  {
    "id": 62,
    "text": "Qaalooo 'a-anta fa'alta haazaa bi aalihatinaa yaaa Ibraaheem"
  },
  {
    "id": 63,
    "text": "Qaala bal fa'alahoo kabeeruhum haazaa fas'aloohum in kaanoo yantiqoon"
  },
  {
    "id": 64,
    "text": "Faraja'ooo ilaaa anfusihim faqaalooo innakum antumuz zaalimoon"
  },
  {
    "id": 65,
    "text": "Summa nukisoo 'alaa ru'oosihim laqad 'alimta maa haaa'ulaaa'i yantiqoon"
  },
  {
    "id": 66,
    "text": "Qaala afata'budoona min doonil laahi maa laa yanfa'ukum shai'anw wa laa yadurrukum"
  },
  {
    "id": 67,
    "text": "Uffil lakum wa limaa ta'budoona min doonil laah; afalaa ta'qiloon"
  },
  {
    "id": 68,
    "text": "Qaaloo harriqoohu wansurooo aalihatakum in kuntum faa'ileen"
  },
  {
    "id": 69,
    "text": "Qulnaa yaa naaru koonee bardanw wa salaaman 'alaaa Ibraaheem"
  },
  {
    "id": 70,
    "text": "Wa araadoo bihee kaidan faja'alnaahumul akhsareen"
  },
  {
    "id": 71,
    "text": "Wa najjainaahu wa Lootan ilal ardil latee baaraknaa feehaa lil 'aalameen"
  },
  {
    "id": 72,
    "text": "Wa wahabnaa lahooo Ishaaqa; wa Ya'qooba naafilah; wa kullan ja'alnaa saaliheen"
  },
  {
    "id": 73,
    "text": "Wa ja'alnaahum a'immatany yahdoona bi amrinaa wa awhainaaa ilaihim fi'lal khairaati wa iqaamas Salaati wa eetaaa'az Zakaati wa kaanoo lanaa 'aabideen"
  },
  {
    "id": 74,
    "text": "Wa Lootan aatainaahu hukmanw wa 'ilmanw wa najjainaahu minal qaryatil latee kaanat ta'malul khabaaa'is; innahum kaanoo qawma saw'in faasiqeen"
  },
  {
    "id": 75,
    "text": "Wa adkhalnaahu fee rahmatinaa innahoo minas saaliheen"
  },
  {
    "id": 76,
    "text": "Wa noohan iz naadaa min qablu fastajabnaa lahoo fanajjainaahu wa ahlahoo minal karbil 'azeem"
  },
  {
    "id": 77,
    "text": "Wa nasarnaahu minal qawmil lazeena kazzaboo bi Aayaatinaa; innahum kaanoo qawma saw'in fa-aghraq naahum ajma'een"
  },
  {
    "id": 78,
    "text": "Wa Daawooda wa Sulaimaana iz yahkumaani fil harsi iz nafashat feehi ghanamul qawmi wa kunnaa lihukmihim shaahideen"
  },
  {
    "id": 79,
    "text": "Fafahhamnaahaa sulaimaan; wa kullan aatainaa hukmanw wa'ilmanw wa sakh kharnaa ma'a Daawoodal jibaala yusabbihna wattayr; wa kunnaa faa'ileen"
  },
  {
    "id": 80,
    "text": "Wa 'allamnaahu san'ata laboosil lakum lituhsinakum min ba'sikum fahal antum shaakiroon"
  },
  {
    "id": 81,
    "text": "Wa li Sulaimaanar reeha 'aasifatan tajree bi amriheee ilal ardil latee baaraknaa feehaa; wa kunnaa bikulli shai'in 'aalimeen"
  },
  {
    "id": 82,
    "text": "Wa minash Shayaateeni mai yaghoosoona lahoo wa ya'maloona 'amalan doona zaalika wa kunna lahum haafizeen"
  },
  {
    "id": 83,
    "text": "Wa Ayyooba iz naadaa Rabbahooo annee massaniyad durru wa Anta arhamur raahimeen"
  },
  {
    "id": 84,
    "text": "Fastajabnaa lahoo fakashaf naa maa bihee min durrinw wa aatainaahu ahlahoo wa mislahum ma'ahum rahmatan min 'indinaa wa zikraa lil'aabideen"
  },
  {
    "id": 85,
    "text": "Wa Ismaa'eela wa Idreesa wa Zal Kifli kullum minas saabireen"
  },
  {
    "id": 86,
    "text": "Wa adkhalnaahum fee rahmatinaa innahum minas saaliheen"
  },
  {
    "id": 87,
    "text": "Wa Zan Nooni iz zahaba mughaadiban fa zannaa al lan naqdira 'alaihi fanaadaa fiz zulumaati al laaa ilaaha illaaa Anta Subhaanaka innee kuntu minaz zaalimeen"
  },
  {
    "id": 88,
    "text": "Fastajabnaa lahoo wa najjainaahu minal ghamm; wa kazaalika nunjil mu'mineen"
  },
  {
    "id": 89,
    "text": "Wa Zakariyyaaa iz naadaa Rabbahoo Rabbi laa tazarnee fardanw wa Anta khairul waariseen"
  },
  {
    "id": 90,
    "text": "Fastajabnaa lahoo wa wahabnaa lahoo Yahyaa Wa aslahnaa lahoo zawjah; innahum kaanoo yusaari'oona fil khairaati wa yad'oonanaa raghabanw wa rahabaa; wa kaanoo lanaa khaashi'een"
  },
  {
    "id": 91,
    "text": "Wallateee ahsanat farjahaa fanafakhnaa feehaa min roohinaa wa ja'alnaahaa wabnahaaa Aayatan lil'aalameen"
  },
  {
    "id": 92,
    "text": "Inna haaziheee ummatukum ummatanw waahidatanw wa Ana Rabbukum fa'budoon"
  },
  {
    "id": 93,
    "text": "Wa taqatta'ooo amrahum bainahum kullun ilainaaa raaji'oon"
  },
  {
    "id": 94,
    "text": "Famai ya'mal minas saalihaati wa huwa mu'minun falaa kufraana lisa'yihee wa innaa lahoo kaatiboon"
  },
  {
    "id": 95,
    "text": "Wa haraamun 'alaa qaryatin ahlaknaahaaa annahum laa yarji'oon"
  },
  {
    "id": 96,
    "text": "Hattaaa izaa futihat Ya'jooju wa Ma'jooju wa hum min kulli hadabiny yansiloon"
  },
  {
    "id": 97,
    "text": "Waqtarabal wa'dul haqqu fa-izaa hiya shaakhisatun absaarul lazeena kafaroo yaawailanaa qad kunna fee ghaflatin min haaza bal kunnaa zaalimeen"
  },
  {
    "id": 98,
    "text": "Innakum wa maa ta'budoona min doonil laahi hasabu Jahannama antum lahaa waaridoon"
  },
  {
    "id": 99,
    "text": "Law kaana haaa'ulaaa'i aalihatan maa waradoohaa wa kullun feehaa khaalidoon"
  },
  {
    "id": 100,
    "text": "Lahum feehaa zafeerunw wa hum feehaa laa yasma'oon"
  },
  {
    "id": 101,
    "text": "Innal lazeena sabaqat lahum minnal husnaaa ulaaa'ika 'anhaa mub'adoon"
  },
  {
    "id": 102,
    "text": "Laa yasma'oona hasee sahaa wa hum fee mash tahat anfusuhum khaalidoon"
  },
  {
    "id": 103,
    "text": "Laa yahzunuhumul faza'ul akbaru wa tatalaq qaahumul malaaa'ikatu haazaa Yawmukumul lazee kuntum too'adoon"
  },
  {
    "id": 104,
    "text": "Yawma natwis samaaa'a kataiyis sijilli lilkutub; kamaa bada'naa awwala khalqin nu'eeduh; wa'dan 'alainaa; innaa kunna faa'ileen"
  },
  {
    "id": 105,
    "text": "Wa laqad katabnaa fiz Zaboori min ba'diz zikri annal arda yarisuhaa 'ibaadi yas saalihoon"
  },
  {
    "id": 106,
    "text": "Inna fee haaza labalaa ghal liqawmin 'aabideen"
  },
  {
    "id": 107,
    "text": "Wa maaa arsalnaaka illaa rahmatal lil'aalameen"
  },
  {
    "id": 108,
    "text": "Qul innamaa yoohaa ilaiya annamaaa ilaahukum illaahunw Waahid, fahal antum muslimoon"
  },
  {
    "id": 109,
    "text": "Fa in tawallaw faqul aazantukum 'alaa sawaaa'; wa in adreee aqareebun am ba'eedun maa too'adoon"
  },
  {
    "id": 110,
    "text": "Innahoo ya'lamul jahra minal qawli wa ya'lamu maa taktumoon"
  },
  {
    "id": 111,
    "text": "Wa in adree la'allahoo fitnatul lakum wa mataa'un ilaaheen"
  },
  {
    "id": 112,
    "text": "Qaala Rabbih kum bil haqq; wa Rabbunar Rahmaa nul musta'aanu 'alaa maa tasifoon"
  }
];

export default en;
