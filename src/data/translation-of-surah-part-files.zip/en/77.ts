import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wal mursalaati'urfaa"
  },
  {
    "id": 2,
    "text": "Fal'aasifaati 'asfaa"
  },
  {
    "id": 3,
    "text": "Wannaashiraati nashraa"
  },
  {
    "id": 4,
    "text": "Falfaariqaati farqaa"
  },
  {
    "id": 5,
    "text": "Falmulqiyaati zikra"
  },
  {
    "id": 6,
    "text": "'Uzran aw nuzraa"
  },
  {
    "id": 7,
    "text": "Innamaa too'adoona lawaaqi'"
  },
  {
    "id": 8,
    "text": "Fa izam nujoomu tumisat"
  },
  {
    "id": 9,
    "text": "Wa izas samaaa'u furijat"
  },
  {
    "id": 10,
    "text": "Wa izal jibaalu nusifat"
  },
  {
    "id": 11,
    "text": "Wa izar Rusulu uqqitat"
  },
  {
    "id": 12,
    "text": "Li ayyi yawmin ujjilat"
  },
  {
    "id": 13,
    "text": "Li yawmil Fasl"
  },
  {
    "id": 14,
    "text": "Wa maaa adraaka maa yawmul fasl"
  },
  {
    "id": 15,
    "text": "Wailuny yawma 'izillilmukazzibeen"
  },
  {
    "id": 16,
    "text": "Alam nuhlikil awwaleen"
  },
  {
    "id": 17,
    "text": "Summa nutbi'uhumul aakhireen"
  },
  {
    "id": 18,
    "text": "Kazzalika naf'alu bilmujrimeen"
  },
  {
    "id": 19,
    "text": "Wailunw yawma 'izil lil mukazzibeen"
  },
  {
    "id": 20,
    "text": "Alam nakhlukkum mimmaaa'im maheen"
  },
  {
    "id": 21,
    "text": "Faja'alnaahu fee qaraarim makeen"
  },
  {
    "id": 22,
    "text": "Illaa qadrim ma'loom"
  },
  {
    "id": 23,
    "text": "Faqadarnaa fani'mal qaadiroon"
  },
  {
    "id": 24,
    "text": "Wailuny yawma 'izil lilmukazzibeen"
  },
  {
    "id": 25,
    "text": "Alam naj'alil arda kifaataa"
  },
  {
    "id": 26,
    "text": "Ahyaaa'anw wa amwaataa"
  },
  {
    "id": 27,
    "text": "Wa ja'alnaa feehaa rawaasiya shaamikhaatinw wa asqainaakum maaa'an furaataa"
  },
  {
    "id": 28,
    "text": "Wailuny yawma 'izil lilmukazzibeen"
  },
  {
    "id": 29,
    "text": "Intaliqooo ilaa maa kuntum bihee tukazziboon"
  },
  {
    "id": 30,
    "text": "Intaliqooo ilaa zillin zee salaasi shu'ab"
  },
  {
    "id": 31,
    "text": "Laa zaleelinw wa laa yughnee minal lahab"
  },
  {
    "id": 32,
    "text": "Innahaa tarmee bishararin kalqasr"
  },
  {
    "id": 33,
    "text": "Ka annahoo jimaalatun sufr"
  },
  {
    "id": 34,
    "text": "Wailuny yawma 'izil lilmukazibeen"
  },
  {
    "id": 35,
    "text": "Haazaa yawmu laa yantiqoon"
  },
  {
    "id": 36,
    "text": "Wa laa yu'zanu lahum fa ya'taziroon"
  },
  {
    "id": 37,
    "text": "Wailunw yawma 'izil lilmukazzibeen"
  },
  {
    "id": 38,
    "text": "Haaza yawmul fasli jama 'naakum wal awwaleen"
  },
  {
    "id": 39,
    "text": "Fa in kaana lakum kaidun fakeedoon"
  },
  {
    "id": 40,
    "text": "Wailuny yawma'izil lilmukazzibeen"
  },
  {
    "id": 41,
    "text": "Innal muttaqeena fee zilaalinw wa 'uyoon"
  },
  {
    "id": 42,
    "text": "Wa fawaakiha mimmaa yashtahoon"
  },
  {
    "id": 43,
    "text": "Kuloo washraboo haneee 'am bimaa kuntum ta'maloon"
  },
  {
    "id": 44,
    "text": "Innaa kazaalika najzil muhsineen"
  },
  {
    "id": 45,
    "text": "Wailuny yawma 'izil lil mukazzibeen"
  },
  {
    "id": 46,
    "text": "Kuloo wa tamatta'oo qaleelan innakum mujrimoon"
  },
  {
    "id": 47,
    "text": "Wailunny yawma 'izil lilmukazzibeen"
  },
  {
    "id": 48,
    "text": "Wa izaa qeela lahumur ka'oo laa yarka'oon"
  },
  {
    "id": 49,
    "text": "Wailunny yawma 'izil lilmukazzibeen"
  },
  {
    "id": 50,
    "text": "Fabi ayyi hadeesim ba'dahoo yu'minoon"
  }
];

export default en;
