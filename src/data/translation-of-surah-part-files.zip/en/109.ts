import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Qul yaaa-ayyuhal kaafiroon"
  },
  {
    "id": 2,
    "text": "Laaa a'budu maa t'abudoon"
  },
  {
    "id": 3,
    "text": "Wa laaa antum 'aabidoona maaa a'bud"
  },
  {
    "id": 4,
    "text": "Wa laaa ana 'abidum maa 'abattum"
  },
  {
    "id": 5,
    "text": "Wa laaa antum 'aabidoona maaa a'bud"
  },
  {
    "id": 6,
    "text": "Lakum deenukum wa liya deen."
  }
];

export default en;
