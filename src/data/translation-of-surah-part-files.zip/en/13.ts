import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Meeem-Raa; tilka Aayaatul Kitaab; wallazee unzila ilaika mir Rabbikal haqqu wa laakinna aksaran naasi laa yu'minoon"
  },
  {
    "id": 2,
    "text": "Allaahul lazee raf'as samaawaati bighairi 'amadin tarawnahaa summas tawaa 'alal 'Arshi wa sakhkharash shamsa walqamara kulluny yajree li ajalim musammaa; yudabbirul amra yufassilul Aayaati la'allakum biliqaaa'i Rabbikum tooqinoon"
  },
  {
    "id": 3,
    "text": "Wa Huwal lazee maddal arda wa ja'ala feehaa rawaasiya wa anhaaraa; wa min kullis samaraati ja'ala feehaa zawjain ithnayn; Yughshil lailan nahaar; inna fee zaalika la aayaatil liqawminy yatafakkaroon"
  },
  {
    "id": 4,
    "text": "Wa fil ardi qita'um muta jaawiraatunw wa jannaatum min a'naabinw wa zar'unw wa nakheelun sinwaanunw wa ghairu sinwaaniny yusqaa bimaaa'inw waahid; wa nufaddilu ba'dahaa 'alaa ba'din fil-ukul; inna fee zaalika la aayaatil liqawminy ya'qiloon"
  },
  {
    "id": 5,
    "text": "Wa in ta'jab fa'ajabun qawluhum 'a-izaa kunna turaaban 'a-inna lafee khalqin jadeed; ulaaa 'ikal lazeena kafaroo bi Rabbihim wa ulaaa'ikal aghlaalu feee a'naaqihim wa ulaaa'ika Ashaabun Naari hum feehaa khaalidoon"
  },
  {
    "id": 6,
    "text": "Wa yasta'jiloonaka bis saiyi'ati qablal hasanati wa qad khalat min qablihimul masulaat; wa inna Rabbaka lazoo maghfiratil linnaasi 'alaa zulmihim wa inna Rabbaka lashadeedul 'iqaab"
  },
  {
    "id": 7,
    "text": "Wa yaqoolul lazeena kafaroo law laaa unzila 'alaihi Aayatum mir Rabbih; innamaaa anta munzirunw wa likulli qawmin haad"
  },
  {
    "id": 8,
    "text": "Allaahu ya'lamu maa tahmilu kullu unsaa wa maa tagheedul arhaamu wa maa tazdaad, wa kullu shai'in 'indahoo bimiqdaar"
  },
  {
    "id": 9,
    "text": "'Aalimul Ghaibi wash shahaadatil Kaabeerul Muta'aal"
  },
  {
    "id": 10,
    "text": "Sawaaa'um minkum man asarral qawla wa man jahara bihee wa man huwa mustakhfim billaili wa saaribum binnahaar"
  },
  {
    "id": 11,
    "text": "Lahoo mu'aqqibaatum mim baini yadaihi wa min khalfihee yahfazoonahoo min amril laah; innal laaha laa yughaiyiru maa biqawmin hattaa yughaiyiroo maa bianfusihim; wa izaaa araadal laahu biqawmin sooo'an falaa maradda lah; wa maa lahum min dooniheeminw waal"
  },
  {
    "id": 12,
    "text": "Huwal lazee yureekumul barqa khawfanw wa tama'anw wa yunshi'us sahaabas siqaal"
  },
  {
    "id": 13,
    "text": "Wa yusabbihur ra'du bihamdihee walmalaaa'ikatu min kheefatihee wa yursilus sawaa'iqa fa yuseebu bihaa mai yashaaa'u wa hum yujaadiloona fil laahi wa Huwa shadeedul mihaal"
  },
  {
    "id": 14,
    "text": "Lahoo da'watul haqq; wallazeena yad'oona min doonihee laa yastajeeboona lahum bishai'in illaa kabaasiti kaffaihi ilal maaa'i liyablugha faahu wa maa huwa bibaalighih; wa maa du'aaa'ul kaafireena illaa fee dalaal"
  },
  {
    "id": 15,
    "text": "Wa lillaahi yasjudu man fis samaawaati wal ardi taw 'anw wa karhanw wa zilaaluhum bilghuduwwi wal aasaal"
  },
  {
    "id": 16,
    "text": "Qul mar Rabbus samaawaati wal ard; qulillaah; qul afattakhaztum min dooniheee awliyaaa'a laa yamlikoona li anfusihim naf'anw wa laa darraa; qul hal yastawil a'maa wal baseeru am hal tastawiz zulumaatu wannoor; am ja'aloo lillaahi shurakaaa'a khalaqoo kakhalqihee fatashaa bahal khalqu 'alaihim; qulil laahu Khaaliqu kulli shai'inw wa Huwal Waahidul Qahhar"
  },
  {
    "id": 17,
    "text": "Anzala minas samaaa'i maaa'an fasaalat awdiyatum biqadarihaa fahtamalas sailu zabadar raabiyaa; wa mimmmaa yooqidoona 'alaihi fin naarib tighaaa'a hilyatin aw mataa'in zabadum misluh; kazaalika yadribul laahul haqqa wal baatil; fa ammaz zabadu fa yazhabu jufaaa'aa; wa ammaa maa yanfa'un naasa fa yamkusu fil ard; kazaalika yadribul laahul amsaal"
  },
  {
    "id": 18,
    "text": "Lillazeenas tajaaboo lirabbihimul husnaa; wallazeena lam yastajeeboo lahoo law anna lahum maa fil ardi jamee'anw wa mislahoo ma'ahoo laftadaw bih; ulaaa'ika lahum sooo'ul hisaab; wa ma'waahum Jahannamu wa bi'sal mihaad"
  },
  {
    "id": 19,
    "text": "Afamai ya'lamu annamaaa unzila ilaika mir Rabbikal haqqu kaman huwa a'maa; innamaa yatazakkaru ulul albaab"
  },
  {
    "id": 20,
    "text": "Allazeena yoofoona bi'ahdil laahi wa laa yanqu doonal meesaaq"
  },
  {
    "id": 21,
    "text": "Wallazeena yasiloona maaa amaral laahu bihee ai yoosala wa yakhshawna Rabbahum wa yakhaafoona sooo'al hisaab"
  },
  {
    "id": 22,
    "text": "Wallazeena sabarub tighaaa'a Wajhi Rabbihim wa aqaamus Salaata wa anfaqoo mimmaa razaqnaahum sirranw wa 'alaaniyatanw wa yadra'oona bilhasanatis saiyi'ata ulaaa'ika lahum 'uqbad daar"
  },
  {
    "id": 23,
    "text": "Jannaatu 'adiny yadkhu loonahaa wa man salaha min aabaaa'ihim wa azwaajihim wa zurriyyaatihim walmalaaa'i katu yadkhuloona 'alaihim min kulli baab"
  },
  {
    "id": 24,
    "text": "Salaamun 'alaikum bimaa sabartum; fani'ma 'uqbad daar"
  },
  {
    "id": 25,
    "text": "Wallazeena yanqudoona 'Ahdal laahi mim ba'di meesaaqihee wa yaqta'oona maaa amaral laahu biheee ai yoosala wa yufsidoona fil ardi ulaaa'ika lahumul la'natu wa lahum sooo'ud daar"
  },
  {
    "id": 26,
    "text": "Allaahu yabsutur rizqa limai yashaaa'u wa yaqdir; wa farihoo bilhayaatid dunyaa wa mal hayaatud dunya fil Aakhirati illaa mataa'"
  },
  {
    "id": 27,
    "text": "Wa yaqoolul lazeena kafaroo law laaa unzila 'alaihi Aayatum mir Rabbih; qul innal laaha yudillu mai yashaa'u wa yahdeee ilaihi man anaab"
  },
  {
    "id": 28,
    "text": "Allazeena aamanoo wa tatma'innu quloobuhum bizikril laah; alaa bizikril laahi tatma'innul quloob"
  },
  {
    "id": 29,
    "text": "Allazeena aamanoo wa a'amilus saalihaati toobaa lahum wa husnu ma aab"
  },
  {
    "id": 30,
    "text": "Kazaalika arsalnaaka feee ummatin qad khalat min qablihaaa umamul litatluwa 'alaihimul lazeee awhainaaa ilaika wa hum yakfuroona bir Rahmaaan; qul Huwa Rabbee laaa ilaaha illaa Huwa 'alaihi tawakkaltu wa ilaihi mataab"
  },
  {
    "id": 31,
    "text": "Wa law anna Quraanan suyyirat bihil jibaalu aw qutti'at bihil ardu aw kullima bihil mawtaa; bal lillaahil amru jamee'aa; afalam yai'asil lazeena aamanooo al law yashaaa 'ullaahu lahadan naasa jamee'aa; wa laa yazaalul lazeena kafaroo tuseebuhum bimaa sana'oo qaari'atun aw tahullu qareebam min daarihim hatta ya'tiya wa'dul laah; innal laaha laa yukhliful mee'aad"
  },
  {
    "id": 32,
    "text": "Wa laqadis tuhzi'a bi Rusulim min qablika fa amlaitu lillazeena kafaroo summa akhaztuhum fakaifa kaana 'iqaab"
  },
  {
    "id": 33,
    "text": "Afaman Huwa qaaa'imun 'alaa kulli nafsim bimaa kasabat; wa ja'aloo lillaahi shurakaaa'a qul samoohum; am tunabbi'oona hoo bimaa laa ya'lamu fil ardi; am bizaahirim minal qawl; bal zuyyina lillazeena kafaroo makruhum wa suddoo 'anis sabeel; wa mai yudlilil laahu famaa lahoo min haad;"
  },
  {
    "id": 34,
    "text": "Lahum 'azaabun fil hayaatid dunyaa wa la'azaabul Aakhirati ashaq, wa maa lahum minal laahi min-waaq"
  },
  {
    "id": 35,
    "text": "Masalul Jannatil latee wu'idal muttaqoona tajree min tahtihal anhaaru ukuluhaa daaa'imunw wa zilluhaa; tilka uqbal lazeenat taqaw wa 'uqbal kafireenan Naar"
  },
  {
    "id": 36,
    "text": "Wallazeena aatainaa humul Kitaaba yafrahoona bimaa unzila ilaika wa minal Ahzaabi mai yunkiru ba'dah; qul innamaa umirtu an a'budal laaha wa laaa ushrika bih; ilaihi ad'oo wa ilaihi maab"
  },
  {
    "id": 37,
    "text": "Wa kazaalika anzalnaahu hukman 'Arabiyyaa; wa la'init taba'ta ahwaaa 'ahum ba'da maa jaaa'aka minal 'ilmi maa laka minal laahi minw waliyinw wa laa waaq"
  },
  {
    "id": 38,
    "text": "Wa laqad arsalnaa Rusulam min qablika wa ja'alnaa lahum azwaajanw wa zurriyyah; wa maa kaana lirasoolin ai ya'tiya bi aayatin illaa bi iznil laah; likulli ajalin kitaab"
  },
  {
    "id": 39,
    "text": "Yamhul laahu maa yashaaa'u wa yusbitu wa 'indahooo ummul Kitaab"
  },
  {
    "id": 40,
    "text": "Wa im maa nurriyannaka ba'dal lazee na'iduhum aw nata waffayannaka fa innamaa 'alaikal balaaghu wa 'alainal hisaab"
  },
  {
    "id": 41,
    "text": "Awalam yaraw annaa na'til arda nanqusuhaa min atraafihaa; wallaahu yahkumu laa mu'aqqiba lihukmih; wa Huwa saree'ul hisaab"
  },
  {
    "id": 42,
    "text": "Wa qad makaral lazeena min qablihim falillaahil makru jamee'aa; ya'lamu maa taksibu kullu nafs; wa sa ya'lamul kuffaaru liman 'uqbad daar"
  },
  {
    "id": 43,
    "text": "Wa yaqoolul lazeena kafaroo lasta mursalaa; qul kafaa billaahi shaheedam bainee wa bainakum wa man 'indahoo 'ilmul Kitaab"
  }
];

export default en;
