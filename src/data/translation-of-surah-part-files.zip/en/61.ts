import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Sabbaha lillaahi maa fisamaawaati wa maa fil ardi wa huwal 'Azeezul Hakeem"
  },
  {
    "id": 2,
    "text": "Yaa ayyuhal lazeena aamanoo lima taqooloona maa laa taf'aloon"
  },
  {
    "id": 3,
    "text": "Kabura maqtan 'indal laahi an taqooloo maa laa taf'aloon"
  },
  {
    "id": 4,
    "text": "Innal laaha yuhibbul lazeena yuqaatiloona fee sabeelihee saffan ka annahum bunyaanum marsoos"
  },
  {
    "id": 5,
    "text": "Wa iz qaala Moosa liqawmihee yaa qawmi lima tu'zoonanee wa qat ta'lamoona annee Rasoolul laahi ilaikum falammaa zaaghooo azaaghal laahu quloobahum; wallaahu laa yahdil qawmal faasiqeen"
  },
  {
    "id": 6,
    "text": "Wa iz qaala 'Eesab-nu-Maryama yaa Banee Israaa'eela innee Rasoolul laahi ilaikum musaddiqal limaa baina yadayya minat Tawraati wa mubashshiram bi Rasooliny yaatee mim ba'dis muhooo Ahmad; falammaa jaaa'ahum bil baiyinaati qaaloo haazaa sihrum mubeen"
  },
  {
    "id": 7,
    "text": "Wa man azlamu mimma nif taraa 'alal laahil kaziba wa huwa yud'aaa ilal Islaam; wallaahu laa yahdil qawmaz zaalimeen"
  },
  {
    "id": 8,
    "text": "Yureedoona liyutfi'oo nooral laahi bi afwaahihim wallaahu mutimmu noorihee wa law karihal kaafiroon"
  },
  {
    "id": 9,
    "text": "Huwal lazee arsala Rasoolahoo bilhudaa wa deenil haqqi liyuzhirahoo 'alad deeni kullihee wa law karihal mushrikoon"
  },
  {
    "id": 10,
    "text": "Yaaa ayyuhal lazeena aamanoo hal adullukum 'alaa tijaaratin tunjeekum min 'azaabin aleem"
  },
  {
    "id": 11,
    "text": "Tu'minoona billaahi wa Rasoolihee wa tujaahidoona fee sabeelil laahi bi amwaalikum wa anfusikum; zaalikum khairul lakum in kuntum ta'lamoon"
  },
  {
    "id": 12,
    "text": "Yaghfir lakum zunoobakum wa yudkhilkum Jannaatin tajree min tahtihal anhaaru wa masaakina taiyibatan fee Jannaati 'Adn; zaalikal fawzul 'Azeem"
  },
  {
    "id": 13,
    "text": "Wa ukhraa tuhibboonahaa nasrum minal laahi wa fat hun qareeb; wa bashshiril mu 'mineen"
  },
  {
    "id": 14,
    "text": "Yaaa ayyuhal lazeena aamanoo koonooo ansaaral laahi kamaa qaala 'Eesab-nu- Maryama lil Hawaariyyeena man ansaareee ilal laah; qaalal Hawaariyyoona nahnu ansaa rul laahi fa aamanat taaa'ifatum mim Banee Israaa'eela wa kafarat taaa'ifatun fa ayyadnal lazeena aamanoo 'alaa 'aduwwihim fa asbahoo zaahireen"
  }
];

export default en;
