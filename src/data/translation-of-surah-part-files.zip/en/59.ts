import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Sabbaha lillaahi maa fissamaawaati wa maa fil ardi wa Huwal 'Azeezul Hakeem"
  },
  {
    "id": 2,
    "text": "Huwal lazeee akharajal lazeena kafaroo min ahlil kitaabi min diyaarihim li awwalil Hashr; maa zanantum any yakhrujoo wa zannooo annahum maa ni'atuhum husoonuhum minal laahi faataahumul laahu min haisu lam yahtasiboo wa qazafa fee quloobihimur ru'ba yukhriboona bu yootahum bi aydeehim wa aydil mu'mineena fa'tabiroo yaaa ulil absaar"
  },
  {
    "id": 3,
    "text": "Wa law laaa an katabal laahu 'alaihimul jalaaa'a la'azzabahum fid dunyaa wa lahum fil Aakhirati 'azaabun Naar"
  },
  {
    "id": 4,
    "text": "Zaalika bi annahum shaaqqul laaha wa Rasoolahoo wa many yushaaaqqil laaha fa innal laaha shadeedul-'iqaab"
  },
  {
    "id": 5,
    "text": "Maa qata'tum mil leenatin aw taraktumoohaa qaaa'imatan'alaaa usoolihaa fabi iznil laahi wa liyukhziyal faasiqeen"
  },
  {
    "id": 6,
    "text": "Wa maaa afaaa'al laahu 'alaaa Rasoolihee minhum famaaa awjaftum 'alaihi min khailiinw wa laa rikaabinw wa laakinnal laaha yusallitu Rusulahoo 'alaa many yashaaa'; wallaahu 'alaa kulli shai'in Qadeer"
  },
  {
    "id": 7,
    "text": "Maaa afaaa'al laahu 'alaa Rasoolihee min ahlil quraa falillaahi wa lir Rasooli wa lizil qurbaa wal yataamaa walmasaakeeni wabnis sabeeli kai laa yakoona doolatam bainal aghniyaaa'i minkum; wa maaa aataakumur Rasoolu fakhuzoohu wa maa nahaakum 'anhu fantahoo; wattaqul laaha innal laaha shadeedul-'iqaab"
  },
  {
    "id": 8,
    "text": "Lilfuqaraaa'il Muhaaji reenal lazeena ukhrijoo min diyaarihim wa amwaalihim yabtaghoona fadlam minal laahi wa ridwaananw wa yansuroonal laaha wa Rasoolah; ulaaa'ika humus saadiqoon"
  },
  {
    "id": 9,
    "text": "Wallazeena tabawwa'ud daara wal eemaana min qablihim yuhibboona man haajara ilaihim wa laa yajidoona fee sudoorihim haajatam mimmaa ootoo wa yu'siroona 'alaa anfusihim wa law kaana bihim khasaasah; wa many yooqa shuhha nafsihee fa ulaaa'ika humul muflihoon"
  },
  {
    "id": 10,
    "text": "Wallazeena jaaa'oo min ba'dihim yaqooloona Rabbanagh fir lanaa wa li ikhwaani nal lazeena sabqoonaa bil eemaani wa laa taj'al fee quloobinaa ghillalil lazeena aamanoo rabbannaaa innaka Ra'oofur Raheem"
  },
  {
    "id": 11,
    "text": "Alam tara ilal lazeena naafaqoo yaqooloona li ikhwaanihimul lazeena kafaroo min ahlil kitaabi la'in ukhrijtum lanakhrujanna ma'akum wa laa nutee'u feekum ahadan abadanw- wa in qootiltum lanansuran nakum wallaahu yashhadu innahum lakaaziboon"
  },
  {
    "id": 12,
    "text": "La'in ukhrijoo laa yakhrujoona ma'ahum wa la'in qootiloo laa yansuroonahum wa la'in nasaroohum la yuwallunnal adbaara summa laa yunsaroon"
  },
  {
    "id": 13,
    "text": "La antum ashaddu rahbatan fee sudoorihim minal laah; zaalika bi annahum qawmul laa yafqahoon"
  },
  {
    "id": 14,
    "text": "Laa yuqaatiloonakum jamee'an illaa fee quram muhas sanatin aw minw waraaa'i judur; baasuhum bainahum shadeed; tahsabuhum jamee'anw-wa quloobuhum shatta; zaalika biannahum qawmul laa ya'qiloon"
  },
  {
    "id": 15,
    "text": "Kamasalil lazeena min qablihim qareeban zaaqoo wabaala amrihim wa lahum 'azaabun aleem"
  },
  {
    "id": 16,
    "text": "Kamasalish shaitaani izqaala lil insaanik fur falammaa kafara qaala innee bareee'um minka inneee akhaaful laaha rabbal 'aalameen"
  },
  {
    "id": 17,
    "text": "Fakaana 'aaqibatahumaaa annahumaa fin naari khaalidaini feehaa; wa zaalika jazaaa'uz zaalimeen"
  },
  {
    "id": 18,
    "text": "Yaaa ayyuhal lazeena aamanut taqul-laaha; waltanzur nafsum maa qaddamat lighadiw wattaqul laah; innal laaha khabeerum bimaa ta'maloon"
  },
  {
    "id": 19,
    "text": "Wa laa takoonoo kallazeena nasul laaha fa ansaahum anfusahum; ulaaa'ika humul faasiqoon"
  },
  {
    "id": 20,
    "text": "Laa yastaweee as-haabun naari wa ashaabul jannah; as haabul jannati humul faaa'izoon"
  },
  {
    "id": 21,
    "text": "Law anzalnaa haazal quraana 'alaa jabilil lara aytahoo khaashi'am muta saddi'am min khashiyatil laah; wa tilkal amsaalu nadribuhaa linnaasi la'allahum yatafakkaroon"
  },
  {
    "id": 22,
    "text": "Huwal-laahul-lazee laaa Ilaaha illaa Huwa 'Aalimul Ghaibi wash-shahaada; Huwar Rahmaanur-Raheem"
  },
  {
    "id": 23,
    "text": "Huwal-laahul-lazee laaa Ilaaha illaa Huwal-Malikul Quddoosus-Salaamul Muminul Muhaiminul-'aAzeezul Jabbaarul-Mutakabbir; Subhaanal laahi 'Ammaa yushrikoon"
  },
  {
    "id": 24,
    "text": "Huwal Laahul Khaaliqul Baari 'ul Musawwir; lahul Asmaaa'ul Husnaa; yusabbihu lahoo maa fis samaawaati wal ardi wa Huwal 'Azeezul Hakeem"
  }
];

export default en;
