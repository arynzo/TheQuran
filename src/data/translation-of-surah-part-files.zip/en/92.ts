import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wallaili izaa yaghshaa"
  },
  {
    "id": 2,
    "text": "Wannahaari izaa tajalla"
  },
  {
    "id": 3,
    "text": "Wa maa khalaqaz zakara wal unthaa"
  },
  {
    "id": 4,
    "text": "Inna sa'yakum lashattaa"
  },
  {
    "id": 5,
    "text": "Fa ammaa man a'taa wattaqaa"
  },
  {
    "id": 6,
    "text": "Wa saddaqa bil husnaa"
  },
  {
    "id": 7,
    "text": "Fasanu yassiruhoo lilyusraa"
  },
  {
    "id": 8,
    "text": "Wa ammaa man bakhila wastaghnaa"
  },
  {
    "id": 9,
    "text": "Wa kazzaba bil husnaa"
  },
  {
    "id": 10,
    "text": "Fasanu yassiruhoo lil'usraa"
  },
  {
    "id": 11,
    "text": "Wa maa yughnee 'anhu maaluhooo izaa taraddaa"
  },
  {
    "id": 12,
    "text": "Inna 'alainaa lal hudaa"
  },
  {
    "id": 13,
    "text": "Wa inna lanaa lal Aakhirata wal oolaa"
  },
  {
    "id": 14,
    "text": "Fa anzartukum naaran talazzaa"
  },
  {
    "id": 15,
    "text": "Laa yaslaahaaa illal ashqaa"
  },
  {
    "id": 16,
    "text": "Allazee kazzaba wa tawallaa"
  },
  {
    "id": 17,
    "text": "Wa sa yujannnabuhal atqaa"
  },
  {
    "id": 18,
    "text": "Allazee yu'tee maalahoo yatazakkaa"
  },
  {
    "id": 19,
    "text": "Wa maa li ahadin 'indahoo min ni'matin tujzaaa"
  },
  {
    "id": 20,
    "text": "Illab tighaaa'a wajhi rabbihil a 'laa"
  },
  {
    "id": 21,
    "text": "Wa lasawfa yardaa"
  }
];

export default en;
