import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Ar Rahmaan"
  },
  {
    "id": 2,
    "text": "'Allamal Quran"
  },
  {
    "id": 3,
    "text": "Khalaqal insaan"
  },
  {
    "id": 4,
    "text": "'Allamahul bayaan"
  },
  {
    "id": 5,
    "text": "Ashshamsu walqamaru bihusbaan"
  },
  {
    "id": 6,
    "text": "Wannajmu washshajaru yasjudan"
  },
  {
    "id": 7,
    "text": "Wassamaaa'a rafa'ahaa wa wada'al Meezan"
  },
  {
    "id": 8,
    "text": "Allaa tatghaw fil meezaan"
  },
  {
    "id": 9,
    "text": "Wa aqeemul wazna bilqisti wa laa tukhsirul meezaan"
  },
  {
    "id": 10,
    "text": "Wal arda wada'ahaa lilanaam"
  },
  {
    "id": 11,
    "text": "Feehaa faakihatunw wan nakhlu zaatul akmaam"
  },
  {
    "id": 12,
    "text": "Walhabbu zul 'asfi war Raihaan"
  },
  {
    "id": 13,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan"
  },
  {
    "id": 14,
    "text": "Khalaqal insaana min salsaalin kalfakhkhaar"
  },
  {
    "id": 15,
    "text": "Wa khalaqal jaaan mim maarijim min naar"
  },
  {
    "id": 16,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan"
  },
  {
    "id": 17,
    "text": "Rabbul mashriqayni wa Rabbul maghribayn"
  },
  {
    "id": 18,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan"
  },
  {
    "id": 19,
    "text": "Marajal bahrayni yalta qiyaan"
  },
  {
    "id": 20,
    "text": "Bainahumaa barzakhul laa yabghiyaan"
  },
  {
    "id": 21,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan"
  },
  {
    "id": 22,
    "text": "Yakhruju minhumal lu 'lu u wal marjaan"
  },
  {
    "id": 23,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan"
  },
  {
    "id": 24,
    "text": "Wa lahul jawaaril mun sha'aatu fil bahri kal a'laam"
  },
  {
    "id": 25,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 26,
    "text": "Kullu man 'alaihaa faan"
  },
  {
    "id": 27,
    "text": "Wa yabqaa wajhu rabbika zul jalaali wal ikraam"
  },
  {
    "id": 28,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 29,
    "text": "Yas'aluhoo man fissamaawaati walard; kulla yawmin huwa fee shaan"
  },
  {
    "id": 30,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 31,
    "text": "Sanafrughu lakum ayyuhas saqalaan"
  },
  {
    "id": 32,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 33,
    "text": "Yaa ma'sharal jinni wal insi inis tata'tum an tanfuzoo min aqtaaris samaawaati wal ardi fanfuzoo; laa tanfuzoona illaa bisultaan"
  },
  {
    "id": 34,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 35,
    "text": "Yursalu 'alaikumaa shuwaazum min naarinw-wa nuhaasun falaa tantasiraan"
  },
  {
    "id": 36,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 37,
    "text": "Fa-izan shaqqatis samaaa'u fakaanat wardatan kaddihaan"
  },
  {
    "id": 38,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 39,
    "text": "Fa-yawma'izil laa yus'alu 'an zambiheee insunw wa laa jaann"
  },
  {
    "id": 40,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 41,
    "text": "Yu'raful mujrimoona biseemaahum fa'yu'khazu binna waasi wal aqdaam"
  },
  {
    "id": 42,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 43,
    "text": "Haazihee jahannamul latee yukazzibu bihal mujrimoon"
  },
  {
    "id": 44,
    "text": "Yatoofoona bainahaa wa baina hameemim aan"
  },
  {
    "id": 45,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 46,
    "text": "Wa liman khaafa maqaama rabbihee jannataan"
  },
  {
    "id": 47,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 48,
    "text": "Zawaataaa afnaan"
  },
  {
    "id": 49,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 50,
    "text": "Feehimaa 'aynaani tajriyaan"
  },
  {
    "id": 51,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 52,
    "text": "Feehimaa min kulli faakihatin zawjaan"
  },
  {
    "id": 53,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 54,
    "text": "Muttaki'eena 'alaa furushim bataaa'inuhaa min istabraq; wajanal jannataini daan"
  },
  {
    "id": 55,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 56,
    "text": "Feehinna qaasiratut tarfi lam yatmishunna insun qablahum wa laa jaaann"
  },
  {
    "id": 57,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 58,
    "text": "Ka annahunnal yaaqootu wal marjaan"
  },
  {
    "id": 59,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 60,
    "text": "Hal jazaaa'ul ihsaani illal ihsaan"
  },
  {
    "id": 61,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 62,
    "text": "Wa min doonihimaa jannataan"
  },
  {
    "id": 63,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 64,
    "text": "Mudhaaammataan"
  },
  {
    "id": 65,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 66,
    "text": "Feehimaa 'aynaani nad daakhataan"
  },
  {
    "id": 67,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 68,
    "text": "Feehimaa faakihatunw wa nakhlunw wa rummaan"
  },
  {
    "id": 69,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 70,
    "text": "Feehinna khairaatun hisaan"
  },
  {
    "id": 71,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 72,
    "text": "Hoorum maqsooraatun fil khiyaam"
  },
  {
    "id": 73,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 74,
    "text": "Lam yatmis hunna insun qablahum wa laa jaaann"
  },
  {
    "id": 75,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 76,
    "text": "Muttaki'eena 'alaa rafrafin khudrinw wa 'abqariyyin hisaan"
  },
  {
    "id": 77,
    "text": "Fabi ayyi aalaaa'i Rabbikumaa tukazzibaan."
  },
  {
    "id": 78,
    "text": "Tabaarakasmu Rabbika Zil-Jalaali wal-Ikraam"
  }
];

export default en;
