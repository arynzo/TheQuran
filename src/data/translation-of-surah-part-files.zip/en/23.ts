import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Qad aflahal mu'minoon"
  },
  {
    "id": 2,
    "text": "Allazeena hum fee Salaatihim khaashi'oon"
  },
  {
    "id": 3,
    "text": "Wallazeena hum 'anillaghwimu'ridoon"
  },
  {
    "id": 4,
    "text": "Wallazeena hum liz Zakaati faa'iloon"
  },
  {
    "id": 5,
    "text": "Wallazeena hum lifuroo jihim haafizoon"
  },
  {
    "id": 6,
    "text": "Illaa 'alaaa azwaajihim aw maa malakat aimaanuhum fa innahum ghairu maloomeen"
  },
  {
    "id": 7,
    "text": "Famanib taghaa waraaa'a zaalika fa ulaaa'ika humul 'aadoon"
  },
  {
    "id": 8,
    "text": "Wallazeena hum li amaanaatihim wa 'ahdihim raa'oon"
  },
  {
    "id": 9,
    "text": "Wallazeena hum 'alaa Salawaatihim yuhaafizoon"
  },
  {
    "id": 10,
    "text": "Ulaaa'ika humul waarisoon"
  },
  {
    "id": 11,
    "text": "Allazeena yarisoonal Firdawsa hum feehaa khaalidoon"
  },
  {
    "id": 12,
    "text": "Wa laqad khalaqnal insaana min sulaalatim minteen"
  },
  {
    "id": 13,
    "text": "Summa ja'alnaahu nutfatan fee qaraarim makeen"
  },
  {
    "id": 14,
    "text": "Summa khalaqnan nutfata 'alaqatan fakhalaqnal 'alaqata mudghatan fakhalaq nal mudghata 'izaaman fakasawnal 'izaama lahman summa anshaanaahu khalqan aakhar; fatabaarakal laahu ahsanul khaaliqeen"
  },
  {
    "id": 15,
    "text": "Summa innakum ba'da zaalika la maiyitoon"
  },
  {
    "id": 16,
    "text": "Summa innakum Yawmal Qiyaamati tub'asoon"
  },
  {
    "id": 17,
    "text": "Wa laqad khalaqnaa fawqakum sab'a taraaa'iqa wa maa kunnaa 'anil khalqi ghaafileen"
  },
  {
    "id": 18,
    "text": "Wa anzalnaa minas samaaa'i maaa'am biqadarin fa-askannaahu fil ardi wa innaa 'alaa zahaabim bihee laqaa diroon"
  },
  {
    "id": 19,
    "text": "Fa anshaanaa lakum bihee Jannaatim min nakheelinw wa a'naab; lakum feehaa fawaakihu kaseeratunw wa minhaa taakuloon"
  },
  {
    "id": 20,
    "text": "Wa shajaratan takhruju min Toori Sainaaa'a tambutu bidduhni wa sibghil lil aakileen"
  },
  {
    "id": 21,
    "text": "Wa inna lakum fil an'aami la'ibrah; nusqeekum mimmaa fee butoonihaa wa lakum feehaa manaafi'u kaseeratunw wa minhaa taakuloon"
  },
  {
    "id": 22,
    "text": "Wa 'alaihaa wa'alal fulki tuhmaloon"
  },
  {
    "id": 23,
    "text": "Wa laqad arsalnaa Noohan ilaa qawmihee faqaala yaa qawmi'budul laaha maa lakum min ilahin ghairuhoo afalaa tattaqoon"
  },
  {
    "id": 24,
    "text": "Faqaalal mala'ul lazeena kafaroo min qawmihee maa haazaaa illaa basharum mislukum yureedu ai yatafaddala 'alaikum wa law shaaa'al laahu la anzala malaaa'ikatam maa sami'naa bihaazaa feee aabaaa'inal awwaleen"
  },
  {
    "id": 25,
    "text": "In huwa illaa rajulum bihee jinnatun fatarabbasoo bihee hatta heen"
  },
  {
    "id": 26,
    "text": "Qaala Rabbin surnee bimaa kazzaboon"
  },
  {
    "id": 27,
    "text": "Fa awhainaaa ilaihi anis na'il fulka bi a'yuninaa wa wahyinaa fa izaa jaaa'a amrunaa wa faarat tannooru fasluk feehaa min kullin zawjainis naini wa ahlaka illaa man sabaqa 'alaihil qawlu minhum walaa tukhaatibnee fil lazeena zalamooo innaahum mughraqoon"
  },
  {
    "id": 28,
    "text": "Fa izas tawaita anta wa mam ma'aka 'alal fulki faqulil hamdu lillaahil lazee najjaanaa minal qawmiz zalimeen"
  },
  {
    "id": 29,
    "text": "Wa qur Rabbi anzilnee munzalam mubaarakanw wa Anta khairul munzileen"
  },
  {
    "id": 30,
    "text": "Inna fee zaalika la Aayaatinw wa in kunnaa lamubtaleen"
  },
  {
    "id": 31,
    "text": "Summaa anshaana mim ba'dihim qarnan aakhareen"
  },
  {
    "id": 32,
    "text": "Fa arsalnaa feehim Rasoolam minhum ani'budul laaha maa lakum min ilaahin ghairuhoo afalaa tattaqoon"
  },
  {
    "id": 33,
    "text": "Wa qaalal mala-u min qawmihil lazeena kafaroo wa kazzaboo bi liqaaa'il Aakhirati wa atrafnaahum fil hayaatid dunyaa maa haazaaa illaa basharum mislukum yaakulu mimmaa taakuloona minhu wa yashrabu mimmaa tashraboon"
  },
  {
    "id": 34,
    "text": "Wa la'in at'atum basharam mislakum innakum izal lakhaasiroon"
  },
  {
    "id": 35,
    "text": "A-Ya'idukum annakum izaa mittum wa kuntum turaabanw wa izaaman annakum mukhrajoon"
  },
  {
    "id": 36,
    "text": "Haihaata haihaata limaa too'adoon"
  },
  {
    "id": 37,
    "text": "In hiya illaa hayaatunad dunyaa namootu wa nahyaa wa maa nahnu bimab'ooseen"
  },
  {
    "id": 38,
    "text": "In huwa illaa rajulunif taraa 'alal laahi kazibanw wa maa nahnuu lahoo bimu'mineen"
  },
  {
    "id": 39,
    "text": "Qaala Rabbin surnee bimaa kazzaboon"
  },
  {
    "id": 40,
    "text": "Qaala 'ammaa qaleelil la yusbihunna naadimeen"
  },
  {
    "id": 41,
    "text": "Fa akhazat humus saihatu bilhaqqi faja'alnaahum ghusaaa'aa; fabu'dal lilqaw miz zaalimeen"
  },
  {
    "id": 42,
    "text": "Summa anshaanaa mim ba'dihim quroonan aakhareen"
  },
  {
    "id": 43,
    "text": "Maa tasbiqu min ummatin ajalahaa wa maa yastaakhiroon"
  },
  {
    "id": 44,
    "text": "Summa arsalnaa Rusulanaa tatraa kulla maa jaaa'a ummatar Rasooluhaa kazzabooh; fa atba'naa ba'dahum ba'danw wa ja'alnaahum ahaadees; fabu'dal liqawmil laa yu'minoon"
  },
  {
    "id": 45,
    "text": "Summa arsalnaa Moosaa wa akhaahu Haaroona bi Aayaatinaa wa sultaanim mubeen"
  },
  {
    "id": 46,
    "text": "Ilaa Fir'awna wa mala'ihee fastakbaroo wa kaanoo qawman 'aaleen"
  },
  {
    "id": 47,
    "text": "Faqaaloo annu'minu libasharaini mislinaa wa qawmuhumaa lanaa 'aabidoon"
  },
  {
    "id": 48,
    "text": "Fakazzaboohumaa fakaanoo minal muhlakeen"
  },
  {
    "id": 49,
    "text": "Wa laqad aatainaa Moosal Kitaaba la'allahum yahtadoon"
  },
  {
    "id": 50,
    "text": "Wa ja'alnab na Maryama wa ummahooo aayatannw wa aawainaahumaaa ilaa rabwatin zaati qaraarinw wa ma'een"
  },
  {
    "id": 51,
    "text": "Yaaa aiyuhar Rusulu kuloo minat taiyibaati wa'maloo saalihan innee bimaa ta'maloona 'Aleem"
  },
  {
    "id": 52,
    "text": "Wa inna haaziheee ummatukum ummatanw waahidatanw wa Ana Rabbukum fattaqoon"
  },
  {
    "id": 53,
    "text": "Fataqatta'ooo amrahum bainahum zuburaa; kullu hizbim bimaa ladaihim farihoon"
  },
  {
    "id": 54,
    "text": "Fazarhum fee ghamratihim hattaa heen"
  },
  {
    "id": 55,
    "text": "A-yahsaboona annnamaa numidduhum bihee mimmaalinw wa baneen"
  },
  {
    "id": 56,
    "text": "Nusaari'u lahum fil khairaat; bal laa yash'uroon"
  },
  {
    "id": 57,
    "text": "Innal lazeena hum min khashyati Rabbihim mushfiqoon"
  },
  {
    "id": 58,
    "text": "Wallazeena hum bi Aayaati Rabbihim yu'minoon"
  },
  {
    "id": 59,
    "text": "Wallazeena hum bi Rabbihim laa yushrikoon"
  },
  {
    "id": 60,
    "text": "Wallazeena yu'toona maaa aataw wa quloobuhum wajilatun annahum ilaa Rabbihim raaji'oon"
  },
  {
    "id": 61,
    "text": "Ulaaa'ika yusaari'oona fil khairaati wa hum lahaa saabiqoon"
  },
  {
    "id": 62,
    "text": "Wa laa nukallifu nafsan illaa wus'ahaa wa ladainaa kitaabuny yantiqu bilhaqqi wa hum la yuzlamoon"
  },
  {
    "id": 63,
    "text": "Bal quloobuhum fee ghamratim min haazaa wa lahum a'maalum min dooni zaalika hum lahaa 'aamiloon"
  },
  {
    "id": 64,
    "text": "Hattaaa izaaa akhaznaa mutrafeehim bil'azaabi izaa hum yaj'aroon"
  },
  {
    "id": 65,
    "text": "Laa taj'arul yawma innakum minnaa laa tunsaroon"
  },
  {
    "id": 66,
    "text": "Qad kaanat Aayaatee tutlaa 'alaikum fakuntum 'alaaa a'qaabikum tankisoon"
  },
  {
    "id": 67,
    "text": "Mustakbireena bihee saamiran tahjuroon"
  },
  {
    "id": 68,
    "text": "Afalam yaddabbarrul qawla am jaaa'ahum maa lam yaati aabaaa'ahumul awwaleen"
  },
  {
    "id": 69,
    "text": "Am lam ya'rifoo Rasoolahum fahum lahoo munkiroon"
  },
  {
    "id": 70,
    "text": "Am yaqooloona bihee jinnnah; bal jaaa'ahum bilhaqqi wa aksaruhum lil haqqi kaarihoon"
  },
  {
    "id": 71,
    "text": "Wa lawit taba'al haqqu ahwaaa'ahum lafasadatis samaawaatu wal ardu wa man feehinnn; bal atainaahum bizikrihim fahum 'an zikrihim mu'ridoon"
  },
  {
    "id": 72,
    "text": "Am tas'aluhum kharjan fakharaaju Rabbika khairunw wa Huwa khairur raaziqeen"
  },
  {
    "id": 73,
    "text": "Wa innaka latad'oohum ilaa Siraatim Mustaqeem"
  },
  {
    "id": 74,
    "text": "Wa innnal lazeena laa yu'minoona bil Aakhirati 'anis siraati lanaakiboon"
  },
  {
    "id": 75,
    "text": "Wa law rahimnaahum wa kashafnaa maa bihim min durril lalajjoo fee tughyaanihim ya'mahoon"
  },
  {
    "id": 76,
    "text": "Wa laqad akhaznaahum bil'azaabi famastakaanoo li Rabbihim wa maa yatadarra'oon"
  },
  {
    "id": 77,
    "text": "Hattaaa izaa fatahnaa 'alaihim baaban zaa 'azaabin shadeedin izaa hum feehi mublisoon"
  },
  {
    "id": 78,
    "text": "Wa Huwal lazeee ansha a-lakumus sam'a wal absaara wal af'idah; qaleelam maa tashkuroon"
  },
  {
    "id": 79,
    "text": "Wa Huwal lazee zara akum fil ardi wa ilaihi tuhsharoon"
  },
  {
    "id": 80,
    "text": "Wa Huwal lazee yuhyee wa yumeetu wa lahukh tilaaful laili wannahaar; afalaa ta'qiloon"
  },
  {
    "id": 81,
    "text": "Bal qaaloo misla maa qaalal awwaloon"
  },
  {
    "id": 82,
    "text": "Qaalooo 'a-izaa mitnaa wa kunnaa turaabanw wa 'izaaman 'a-innaa lamab 'oosoon"
  },
  {
    "id": 83,
    "text": "Laqad wu'idnaa nahnu wa aabaaa'unaa haazaa min qablu in haazaaa illaaa asaateerul awwaleen"
  },
  {
    "id": 84,
    "text": "Qul limanil ardu wa man feehaaa in kuntum ta'lamoon"
  },
  {
    "id": 85,
    "text": "Sa-yaqooloona lillaah; qul afalaa tazakkkaroon"
  },
  {
    "id": 86,
    "text": "Qul mar Rabbus samaawaatis sab'i wa Rabbul 'Arshil 'Azeem"
  },
  {
    "id": 87,
    "text": "Sa yaqooloona lillaah; qul afalaa tattaqoon"
  },
  {
    "id": 88,
    "text": "Qul mam bi yadihee malakootu kulli shai'inw wa Huwa yujeeru wa laa yujaaru 'alaihi in kuntum ta'lamoon"
  },
  {
    "id": 89,
    "text": "Sa yaqooloona lillaah; qul fa annaa tus haroon"
  },
  {
    "id": 90,
    "text": "Bal atainaahum bil haqqi wa innahum lakaaziboon"
  },
  {
    "id": 91,
    "text": "Mat takhazal laahu minw waladinw wa maa kaana ma'ahoo min ilaah; izal lazahaba kullu ilaahim bimaa khalaqa wa la'alaa ba'duhum 'alaa ba'd; Subhaannal laahi 'ammaa yasifoon"
  },
  {
    "id": 92,
    "text": "'Aalimil Ghaibi wash shahhaadati fata'aalaa 'ammaa yushrikoon"
  },
  {
    "id": 93,
    "text": "Qur Rabbi immmaa turiyannee maa yoo'adoon"
  },
  {
    "id": 94,
    "text": "Rabbi falaa taj'alnee fil qawmiz zaalimeen"
  },
  {
    "id": 95,
    "text": "Wa innaa 'alaaa an nuriyaka maa na'iduhum laqaadiroon"
  },
  {
    "id": 96,
    "text": "Idfa' billate hiya ahsanus saiyi'ah; nahnu a'lamu bimaa yasifoon"
  },
  {
    "id": 97,
    "text": "Wa qur Rabbi a'oozu bika min hamazaatish Shayaateen"
  },
  {
    "id": 98,
    "text": "Wa a'oozu bika Rabbi ai-yahduroon"
  },
  {
    "id": 99,
    "text": "Hattaaa izaa jaaa'a ahada humul mawtu qaala Rabbir ji'oon"
  },
  {
    "id": 100,
    "text": "La'alleee a'malu saalihan feemaa taraktu kallaa; innahaa kalimatun huwa qaaa'iluhaa wa minw waraaa'ihim barzakhun ilaa Yawmi yub'asoon"
  },
  {
    "id": 101,
    "text": "Fa izaa nufikha fis Soori falaaa ansaaba bainahum yawma'izinw wa laa yatasaaa'aloon"
  },
  {
    "id": 102,
    "text": "Faman saqulat mawaazee nuhoo fa ulaaa'ika humul muflihoon"
  },
  {
    "id": 103,
    "text": "Wa man khaffat mawaa zeenuhoo fa ulaaa'ikal lazeena khasiroo 'anfusahum fee Jahannama khaalidoon"
  },
  {
    "id": 104,
    "text": "Talfahu wujoohahumun Naaru wa hum feehaa kaalihoon"
  },
  {
    "id": 105,
    "text": "Alam takun Aayaatee tutlaa 'alaikum fakuntum bihaa tukazziboon"
  },
  {
    "id": 106,
    "text": "Qaaloo Rabbanaa ghalabat 'alainaa shiqwatunaa wa kunnaa qawman daaalleen"
  },
  {
    "id": 107,
    "text": "Rabbanaa akhrijnaa minhaa fa in 'udnaa fa innaa zaalimoon"
  },
  {
    "id": 108,
    "text": "Qaalakh sa'oo feehaa wa laa tukallimoon"
  },
  {
    "id": 109,
    "text": "Innahoo kaana fareequm min 'ibaadee yaqooloona Rabbanaaa aamannaa faghfir lanaa warhamnaa wa Anta khairur raahimeen"
  },
  {
    "id": 110,
    "text": "Fattakhaztumoohum sikhriyyan hattaaa ansawkum zikree wa kuntum minhum tadhakoon"
  },
  {
    "id": 111,
    "text": "Inee jazaituhumul Yawma bimaa sabarooo annahum humul faaa'izoon"
  },
  {
    "id": 112,
    "text": "Qaala kam labistum fil ardi 'adada sineen"
  },
  {
    "id": 113,
    "text": "Qaaloo labisnaa yawman aw ba'da yawmin fas'alil 'aaaddeen"
  },
  {
    "id": 114,
    "text": "Qaala il labistum illaa qaleelal law annakum kuntum ta'lamoon"
  },
  {
    "id": 115,
    "text": "Afahasibtum annamaa khalaqnaakum 'abasanw wa annakum ilainaa laa turja'oon"
  },
  {
    "id": 116,
    "text": "Fata'aalal laahul Malikul Haqq; laaa ilaaha illaa Huwa Rabbul 'Arshil Kareem"
  },
  {
    "id": 117,
    "text": "Wa mai yad'u ma'allaahi ilaahan aakhara laa burhaana lahoo bihee fa inna maa hisaabuhoo 'inda Rabbih; innahoo laa yuflihul kaafiroon"
  },
  {
    "id": 118,
    "text": "Wa qur Rabbigh fir warham wa Anta khairur raahimeen"
  }
];

export default en;
