import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Izas samaaa'un fatarat"
  },
  {
    "id": 2,
    "text": "Wa izal kawaakibun tasarat"
  },
  {
    "id": 3,
    "text": "Wa izal bihaaru fujjirat"
  },
  {
    "id": 4,
    "text": "Wa izal qubooru bu'sirat"
  },
  {
    "id": 5,
    "text": "'Alimat nafsum maa qaddamat wa akhkharat"
  },
  {
    "id": 6,
    "text": "Yaaa ayyuhal insaaanu maa gharraka bi Rabbikal kareem"
  },
  {
    "id": 7,
    "text": "Allazee khalaqaka fasaw waaka fa'adalak"
  },
  {
    "id": 8,
    "text": "Feee ayye sooratim maa shaaa'a rakkabak"
  },
  {
    "id": 9,
    "text": "Kalla bal tukazziboona bid deen"
  },
  {
    "id": 10,
    "text": "Wa inna 'alaikum lahaa fizeen"
  },
  {
    "id": 11,
    "text": "Kiraaman kaatibeen"
  },
  {
    "id": 12,
    "text": "Ya'lamoona ma taf'aloon"
  },
  {
    "id": 13,
    "text": "Innal abraara lafee na'eem"
  },
  {
    "id": 14,
    "text": "Wa innal fujjaara lafee jaheem"
  },
  {
    "id": 15,
    "text": "Yaslawnahaa Yawmad Deen"
  },
  {
    "id": 16,
    "text": "Wa maa hum 'anhaa bighaaa 'ibeen"
  },
  {
    "id": 17,
    "text": "Wa maaa adraaka maa Yawmud Deen"
  },
  {
    "id": 18,
    "text": "Summa maaa adraaka maa Yawmud Deen"
  },
  {
    "id": 19,
    "text": "Yawma laa tamliku nafsul linafsin shai'anw walamru yawma'izil lillaah"
  }
];

export default en;
