import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Waz-zaariyaati zarwaa"
  },
  {
    "id": 2,
    "text": "Falhaamilaati wiqraa"
  },
  {
    "id": 3,
    "text": "Faljaariyaati yusraa"
  },
  {
    "id": 4,
    "text": "Falmuqassimaati amraa"
  },
  {
    "id": 5,
    "text": "Innamaa too'adoona la-saadiq"
  },
  {
    "id": 6,
    "text": "Wa innad deena la waaqi'"
  },
  {
    "id": 7,
    "text": "Wassamaaa'i zaatil hubuk"
  },
  {
    "id": 8,
    "text": "Innakum lafee qawlim mukhtalif"
  },
  {
    "id": 9,
    "text": "Yu'faku 'anhu man ufik"
  },
  {
    "id": 10,
    "text": "Qutilal kharraasoon"
  },
  {
    "id": 11,
    "text": "Allazeena hum fee ghamratin saahoon"
  },
  {
    "id": 12,
    "text": "Yas'aloona ayyaana yawmud Deen"
  },
  {
    "id": 13,
    "text": "Yawma hum 'alan naari yuftanoon"
  },
  {
    "id": 14,
    "text": "Zooqoo fitnatakum haa zal lazee kuntum bihee tas ta'jiloon"
  },
  {
    "id": 15,
    "text": "Innal muttaqeena fee jannaatinw wa 'uyoon"
  },
  {
    "id": 16,
    "text": "Aakhizeena maaa aataahum Rabbuhum; innahum kaanoo qabla zaalika muhsineen"
  },
  {
    "id": 17,
    "text": "kaanoo qaleelam minal laili maa yahja'oon"
  },
  {
    "id": 18,
    "text": "Wa bil as haari hum yastaghfiroon"
  },
  {
    "id": 19,
    "text": "Wa feee amwaalihim haqqul lissaaa'ili walmahroom"
  },
  {
    "id": 20,
    "text": "Wa fil ardi aayaatul lilmooqineen"
  },
  {
    "id": 21,
    "text": "Wa feee anfusikum; afalaa tubsiroon"
  },
  {
    "id": 22,
    "text": "Wa fissamaaa'i rizqukum wa maa too'adoon"
  },
  {
    "id": 23,
    "text": "Fawa Rabbis samaaa'i wal ardi innahoo lahaqqum misla maa annakum tantiqoon"
  },
  {
    "id": 24,
    "text": "Hal ataaka hadeesu daifi Ibraaheemal mukrameen"
  },
  {
    "id": 25,
    "text": "Iz dakhaloo 'alaihi faqaaloo salaaman qaala salaamun qawmum munkaroon"
  },
  {
    "id": 26,
    "text": "Faraagha ilaaa ahlihee fajaaa'a bi'ijlin sameen"
  },
  {
    "id": 27,
    "text": "Faqarrabahooo ilaihim qaala alaa taakuloon"
  },
  {
    "id": 28,
    "text": "Fa awjasa minhum khee fatan qaaloo laa takhaf wa bashsharoohu bighulaamin 'aleem"
  },
  {
    "id": 29,
    "text": "Fa aqbalatim ra-atuhoo fee sarratin fasakkat wajhahaa wa qaalat 'ajoozun 'aqeem"
  },
  {
    "id": 30,
    "text": "Qaaloo kazaaliki qaala Rabbuki innahoo huwal hakeemul 'aleem"
  },
  {
    "id": 31,
    "text": "Qaala famaa khatbukum ayyuhal mursaloon"
  },
  {
    "id": 32,
    "text": "Qaalooo innaaa ursilnaaa ilaa qawmim mujrimeen"
  },
  {
    "id": 33,
    "text": "Linursila 'alaihim hijaa ratam min teen"
  },
  {
    "id": 34,
    "text": "Musawwamatan 'inda rabbika lilmusrifeen"
  },
  {
    "id": 35,
    "text": "Fa akhrajnaa man kaana feehaa minal mu'mineen"
  },
  {
    "id": 36,
    "text": "Famaa wajadnaa feehaa ghaira baitim minal muslimeen"
  },
  {
    "id": 37,
    "text": "Wa taraknaa feehaaa aayatal lillazeena yakhaafoonal 'azaabal aleem"
  },
  {
    "id": 38,
    "text": "Wa fee Moosaaa iz arsalnaahu ilaa Fir'awna bisultaa nim mubeen"
  },
  {
    "id": 39,
    "text": "Fatawalla biruknihee wa qaala saahirun aw majnoon"
  },
  {
    "id": 40,
    "text": "Fa akhaznaahu wa junoo dahoo fanabaznaahum fil yammi wa huwa muleem"
  },
  {
    "id": 41,
    "text": "Wa fee 'Aadin iz arsalnaa 'alaihimur reehal'aqeem"
  },
  {
    "id": 42,
    "text": "Maa tazaru min shai'in atat 'alaihi illaa ja'alat hu karrameem"
  },
  {
    "id": 43,
    "text": "Wa fee Samooda iz qeela lahum tamatta''oo hattaa heen"
  },
  {
    "id": 44,
    "text": "Fa'ataw 'an amri Rabbihim fa akhazat humus saa'iqatu wa hum yanzuroon"
  },
  {
    "id": 45,
    "text": "Famas tataa'oo min qiyaaminw wa maa kaanoo muntasireen"
  },
  {
    "id": 46,
    "text": "Wa qawma Noohim min qablu innahum kaano qawman faasiqeen"
  },
  {
    "id": 47,
    "text": "Wassamaaa'a banainaa haa bi aydinw wa innaa lamoosi'oon"
  },
  {
    "id": 48,
    "text": "Wal arda farashnaahaa fani'mal maahidoon"
  },
  {
    "id": 49,
    "text": "Wa min kulli shai'in khalaqnaa zawjaini la'allakum tazakkaroon"
  },
  {
    "id": 50,
    "text": "Fafirrooo ilal laahi innee lakum minhu nazeerum mubeen"
  },
  {
    "id": 51,
    "text": "Wa laa taj'aloo ma'al laahi ilaahan aakhara innee lakum minhu nazeerum mubeen"
  },
  {
    "id": 52,
    "text": "Kazaalika maaa atal lazeena min qablihim mir Rasoolin illaa qaaloo saahirun aw majnoon"
  },
  {
    "id": 53,
    "text": "Atawaasaw bih; bal hum qawmun taaghoon"
  },
  {
    "id": 54,
    "text": "Fatawalla 'anhum famaaa anta bimaloom"
  },
  {
    "id": 55,
    "text": "Wa zakkir fa innaz zikraa tanfa'ul mu'mineen"
  },
  {
    "id": 56,
    "text": "Wa maa khalaqtul jinna wal insa illaa liya'budoon"
  },
  {
    "id": 57,
    "text": "Maaa ureedu minhum mir rizqinw wa maaa ureedu anyyut'imoon"
  },
  {
    "id": 58,
    "text": "Innal laaha Huwar Razzaaqu Zul Quwwatil Mateen"
  },
  {
    "id": 59,
    "text": "Fa inna lillazeena zalamoo zanoobam misla zanoobi ashaabihim falaa yasta'jiloon"
  },
  {
    "id": 60,
    "text": "Fawailul lillazeena kafaroo miny yawmihimul lazee yoo'adoon"
  }
];

export default en;
