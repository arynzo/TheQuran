import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Tanzeelul Kitaabi minal laahil 'Azeezil Hakeem"
  },
  {
    "id": 2,
    "text": "Innaaa anzalnaaa ilaikal Kitaaba bilhaqqi fa'budil laaha mukhlisal lahud deen"
  },
  {
    "id": 3,
    "text": "Alaa lillaahid deenul khaalis; wallazeenat takhazoo min dooniheee awliyaaa'a maa na'buduhum illaa liyuqar riboonaaa ilal laahi zulfaa; innal laaha yahkumu baina hum fee maa hum feehi yakhtalifoon; innal laaha laa yahdee man huwa kaazibun kaffaar"
  },
  {
    "id": 4,
    "text": "Law araadal laahu aiyattakhiza waladal lastafaa mimmaa yakhluqu maa yashaaa'; Subhaanahoo Huwal laahul Waahidul Qahhaar"
  },
  {
    "id": 5,
    "text": "Khalaqas samaawaati wal arda bilhaqq; yukawwirul laila 'alan nahaari wa yukawwirun nahaara 'alaal laili wa sakhkharash shamsa walqamara kulluny yajree li ajalim musammaa; alaa Huwal 'Azeezul Ghaffaar"
  },
  {
    "id": 6,
    "text": "Khalaqakum min nafsinw waahidatin summa ja'ala minhaa zawjahaa wa anzala lakum minal-an'aami samaani yata azwaaj; yakhlu qukum fee butooni ummahaatikum khalqam mim ba'di khalqin fee zulumaatin salaas; zaalikumul laahu Rabbukum lahul mulk; laaa ilaaha illaa Huwa fa annaa tusrafoon"
  },
  {
    "id": 7,
    "text": "In takfuroo fa innal laaha ghaniyyun 'ankum; wa laa yardaa li'ibaadihil kufra wa in tashkuroo yardahu lakum; wa laa taziru waaziratunw wizra ukhraa; summa ilaa Rabikum marji'ukum fa-yunabbi'ukum bimaa kuntum ta'maloon; innahoo 'aleemum bizaatissudoor"
  },
  {
    "id": 8,
    "text": "Wa izaa massal insaana durrun da'aa Rabbahoo muneeban ilaihi summa izaa khawwalahoo ni'matam minhu nasiya maa kaana yad'ooo ilaihi min qablu wa ja'ala lillaahi andaadal liyudilla 'ansabeelih; qul tamatta' bikufrika qaleelan innaka min Ashaabin Naar;"
  },
  {
    "id": 9,
    "text": "Amman huwa qaanitun aanaaa'al laili saajidanw wa qaaa'imai yahzarul Aakhirata wa yarjoo rahmata Rabbih; qul hal yastawil lazeena ya'lamoona wallazeena laa ya'lamoon; innamaa yatazakkaru ulul albaab"
  },
  {
    "id": 10,
    "text": "Qul yaa 'ibaadil lazeena aamanut taqoo Rabbakum; lillazeena ahsanoo fee haazihid dunyaa hasanah; wa ardul laahi waasi'ah; innamaa yuwaffas saabiroona ajrahum bighayri hisab"
  },
  {
    "id": 11,
    "text": "Qul inneee umirtu an a'budal laaha mukhlisal lahud deen"
  },
  {
    "id": 12,
    "text": "Wa umirtu li an akoona awwalal muslimeen"
  },
  {
    "id": 13,
    "text": "Qul inneee akhaafu in 'asaitu Rabbee 'azaaba Yawmin 'azeem"
  },
  {
    "id": 14,
    "text": "Qulil laaha a'budu mukhlisal lahoo deenee"
  },
  {
    "id": 15,
    "text": "Fa'budoo maa shi'tum min doonih; qul innal khaasireenal lazeena khasirooo anfusahum wa ahleehim yawmal qiyaamah; alaa zaalika huwal khusraanul mubeen"
  },
  {
    "id": 16,
    "text": "Lahum min fawqihim zulalum minan Naari wa min tahtihim zulal; zaalika yukhaw wiful laahu bihee 'ibaadah; yaa 'ibaadi fattaqoon"
  },
  {
    "id": 17,
    "text": "Wallazeenaj tanabut Taaghoota ai ya'budoohaa wa anaabooo ilal laahi lahumul bushraa; fabashshir 'ibaad"
  },
  {
    "id": 18,
    "text": "Allazeena yastami'oonal qawla fayattabi'oona ahsanah; ulaaa'ikal lazeena hadaahumul laahu wa ulaaa'ika hum ulul albaab"
  },
  {
    "id": 19,
    "text": "Afaman haqqa 'alaihi kalimatul 'azaab; afa anta tunqizu man fin Naar"
  },
  {
    "id": 20,
    "text": "Laakinil lazeenat taqaw Rabbahum lahum ghurafum min fawqihaa ghurafum mabniyyatun tajree min tahtihal anhaar; wa'dal laah; laa yukhliful laahul mee'aad"
  },
  {
    "id": 21,
    "text": "Alam tara annal laaha anzala minas samaaa'i maaa'an fasalakahoo yanaabee'a fil ardi summa yukhriju bihee zar'am mukhtalifan alwaanuhoo summa yaheeju fatarahu musfarran summa yaj'aluhoo hutaamaa; inna fee zaalika lazikraa li ulil albaab"
  },
  {
    "id": 22,
    "text": "Afaman sharahal laahu sadrahoo lil Islaami fahuwa 'alaa noorim mir Rabbih; fa wailul lilqaasiyati quloobuhum min zikril laah; ulaaa'ika fee dalaalim mubeen"
  },
  {
    "id": 23,
    "text": "Allahu nazzala ahsanal hadeesi Kitaabam mutashaa biham masaaniy taqsha'irru minhu juloodul lazeena yakhshawna Rabbahum summa taleenu julooduhum wa quloo buhum ilaa zikril laah; zaalika hudal laahi yahdee bihee mai yashaaa'; wa mai yudlilil laahu famaa lahoo min haad"
  },
  {
    "id": 24,
    "text": "Afamai yattaqee biwaj hihee sooo'al 'azaabi Yawmal Qiyaamah; wa qeela lizzaali meena zooqoo maa kuntum taksiboon"
  },
  {
    "id": 25,
    "text": "Kazzabal lazeena min qablihim fa ataahumul 'azaabu min haisu laa yash'uroon"
  },
  {
    "id": 26,
    "text": "Fa azaaqahumul laahul khizya fil hayaatid dunyaa wa la'azaabul Aakhirati akbar; law kaanoo ya'lamoon"
  },
  {
    "id": 27,
    "text": "Wa laqad darabnaa linnaasi fee haazal Qur-aani min kulli masalil la'allahum yatazakkaroon"
  },
  {
    "id": 28,
    "text": "Qur-aanan 'Arabiyyan ghaira zee 'iwajil la'allahum yattaqoon"
  },
  {
    "id": 29,
    "text": "Darabal laahu masalar rajulan feehi shurakaaa'u mutashaakisoona wa rajulan salamal lirajulin hal yastawi yaani masalaa; alhamdu lillaah; bal aksaruhum laa ya'lamoon"
  },
  {
    "id": 30,
    "text": "Innaka maiyitunw wa inna hum maiyitoon"
  },
  {
    "id": 31,
    "text": "Summa innakum Yawmal Qiyaamati 'inda Rabbikum takhtasimoon  (End Juz"
  },
  {
    "id": 32,
    "text": "Faman azlamu mimman kazaba 'alal laahi wa kazzaba bissidqi iz jaaa'ah; alaisa fee Jahannama maswal lilkaafireen"
  },
  {
    "id": 33,
    "text": "Wallazee jaaa'a bissidqi wa saddaqa biheee ulaaa'ika humul muttaqoon"
  },
  {
    "id": 34,
    "text": "Lahum maa yashaaa'oona 'inda Rabbihim; zaalika jazaaa'ul muhsineen"
  },
  {
    "id": 35,
    "text": "Liyukaffiral laahu 'anhum aswa allazee 'amiloo wa yajziyahum ajrahum bi ahsanil lazee kaano ya'maloon"
  },
  {
    "id": 36,
    "text": "Alaisal laahu bikaafin 'abdahoo wa yukhawwi foonaka billazeena min doonih; wa mai yudlilil laahu famaa lahoo min haad"
  },
  {
    "id": 37,
    "text": "Wa mai yahdil laahu famaa lahoo min mudil; alai sal laahu bi'azeezin zin tiqaam"
  },
  {
    "id": 38,
    "text": "Wa la'in sa altahum man khalaqas samaawaati wal arda la yaqoolunal laah; qul afara'aitum maa tad'oona min doonil laahi in araadaniyal laahu bidurrin hal hunna kaashi faatu durriheee aw araadanee birahmatin hal hunna mumsikaatu rahmatih; qul hasbiyal laahu 'alaihi yatawakkalul mutawakkiloon"
  },
  {
    "id": 39,
    "text": "Qul yaa qawmi'maloo 'alaa makaanatikum innee 'aamilun fasawfa ta'lamoon"
  },
  {
    "id": 40,
    "text": "Mai yaateehi 'azaabuny yukhzeehi wa yahillu 'alaihi 'azaabum muqeem"
  },
  {
    "id": 41,
    "text": "Innaa anzalnaa 'alaikal Kitaaba linnaasi bilhaqq; famanih tadaa falinafsihee wa man dalla fa innamaa yadillu 'alaihaa wa maaa anta 'alaihim biwakeel"
  },
  {
    "id": 42,
    "text": "Allaahu yatawaffal anfusa heena mawtihaa wallatee lam tamut fee manaamihaa fa yumsikul latee qadaa 'alaihal mawta wa yursilul ukhraaa ilaaa ajalim musammaa; inna fee zaalika la Aayaatil liqawmai yatafakkarroon"
  },
  {
    "id": 43,
    "text": "Amit takhazoo min doonillaahi shufa'aaa'; qul awalaw kaanoo laa yamlikoona shai'aw wa laa ya'qiloon"
  },
  {
    "id": 44,
    "text": "Qul lillaahish shafaa'atu jamee'aa; lahoo mulkus samaawaati wal ardi summa ilaihi turja'oon"
  },
  {
    "id": 45,
    "text": "Wa izaa zukiral laahu wahdahush ma azzat quloobul lazeena laa yu'minoona bil Aakhirati wa izaa zukiral lazeena min dooniheee izaa hum yastabshiroon"
  },
  {
    "id": 46,
    "text": "Qulil laahumma faatiras samaawaati wal ardi 'Aalimal Ghaibi washshahaadati Anta tahkumu baina 'ibaadika fee maa kaanoo feehee yakhtalifoon"
  },
  {
    "id": 47,
    "text": "Wa law anna lillazeena zalamoo maa fil ardi jamee'anw wa mislahoo ma'ahoo laftadaw bihee min sooo'il azaabi Yawmal Qiyaamah; wa badaa lahum minal laahi maa lam yakoonoo yahtasiboon"
  },
  {
    "id": 48,
    "text": "Wa badaa lahum saiyiaatu maa kasaboo wa haaqa bihim maa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 49,
    "text": "Fa izaa massal insaana durrun da'aanaa summa izaa khawwalnaahu ni'matam minna qaala innamaaa ootee tuhoo 'alaa 'ilm; bal hiya fitna tunw wa laakinna aksarahum laa ya'lamoon"
  },
  {
    "id": 50,
    "text": "Qad qaalahal lazeena min qablihim famaaa aghnaa 'anhum maa kaanoo yaksiboon"
  },
  {
    "id": 51,
    "text": "Fa asaabahum saiyi aatu maa kasaboo; wallazeena zalamoo min haaa'ulaaa'i sa yuseebuhum saiyi aatu maa kasaboo wa maa hum bimu'jizeen"
  },
  {
    "id": 52,
    "text": "Awalam ya'lamooo annal laaha yabsutur rizqa limai yashaaa'u wa yaqdir; inna fee zaalika la Aayaatil liqawminy yu'minoon"
  },
  {
    "id": 53,
    "text": "Qul yaa'ibaadiyal lazeena asrafoo 'alaaa anfusihim laa taqnatoo mirrahmatil laah; innal laaha yaghfiruz zunooba jamee'aa; innahoo Huwal Ghafoorur Raheem"
  },
  {
    "id": 54,
    "text": "Wa aneebooo ilaa Rabbikum wa aslimoo lahoo min qabli any yaatiyakumul 'azaabu summa laa tunsaroon"
  },
  {
    "id": 55,
    "text": "Wattabi'ooo ahsana maaa unzila ilaikum mir Rabbikum min qabli aiyaatiyakumal 'azaabu baghtatanw wa antum laa tash'uroon"
  },
  {
    "id": 56,
    "text": "An taqoola nafsuny yaahasrataa 'alaa maa farrattu fee jambil laahi wa in kuntu laminas saakhireen"
  },
  {
    "id": 57,
    "text": "Aw taqoola law annal laaha hadaanee lakuntu minal muttaqeen"
  },
  {
    "id": 58,
    "text": "Aw taqoola heena taral 'azaaba law anna lee karratan fa akoona minal muhsineen"
  },
  {
    "id": 59,
    "text": "Balaa qad jaaa'atka aayaatee fa kazzabta bihaa wa stakbarta wa kunta minal kaafireen"
  },
  {
    "id": 60,
    "text": "Wa Yawmal Qiyaamati taral lazeena kazaboo 'alallaahi wujoohuhum muswaddah; alaisa fee Jahannama maswal lilmutakabbireen"
  },
  {
    "id": 61,
    "text": "Wa yunajjil laahul lazee nat taqaw bimafaazatihim laa yamassuhumus sooo'u wa laa hum yahzanoon"
  },
  {
    "id": 62,
    "text": "Allaahu khaaliqu kulli shai'inw wa Huwa 'alaa kulli shai'inw Wakeel"
  },
  {
    "id": 63,
    "text": "Lahoo maqaaleedus sa maawaati wal ard; wallazeena kafaroo bi ayaatil laahi ulaaa'ika humul khaasiroon"
  },
  {
    "id": 64,
    "text": "Qul afaghairal laahi taamurooonneee a'budu ayyuhal jaahiloon"
  },
  {
    "id": 65,
    "text": "Wa laqad oohiya ilaika wa ilal lazeena min qablika la in ashrakta la yahbatanna 'amalu ka wa latakoonanna minal khaasireen"
  },
  {
    "id": 66,
    "text": "Balil laahha fa'bud wa kum minash shaakireen"
  },
  {
    "id": 67,
    "text": "Wa maa qadarul laaha haqqa qadrihee wal ardu jamee 'an qabdatuhoo Yawmal Qiyaamati wassamaawaatu matwiyyaatum biyameenih; Subhaanahoo wa Ta'aalaa 'amma yushrikoon"
  },
  {
    "id": 68,
    "text": "Wa nufikha fis Soori fasa'iqa man fis samaawaati wa man fil ardi illaa man shaa'al lahu summa nufikha feehi ukhraa fa izaa hum qiyaamuny yanzuroon"
  },
  {
    "id": 69,
    "text": "Wa ashraqatil ardu binoori Rabbihaa wa wudi'al Kitaabu wa jeee'a bin nabiyyeena wash shuhadaaa'i wa qudiya bainahum bilhaqqi wa hum laa yuzlamoon"
  },
  {
    "id": 70,
    "text": "Wa wuffiyat kullu nafsim maa 'amilat wa Huwa a'lamu bimaa yaf'aloon"
  },
  {
    "id": 71,
    "text": "Wa seeqal lazeena kafaroo ilaa jahannama zumaraa hattaaa izaa jaaa'oohaa futihat abwaabuhaa wa qaala lahum khazanatuhaaa alam ya'tikum Rusulun minkum yatloona 'alaikum Aayaati Rabbikum wa yunziroonakum liqaaa'a Yawmikum haazaa; qaaloo balaa wa laakin haqqat kalimatul 'azaabi 'alal kaafireen"
  },
  {
    "id": 72,
    "text": "Qeelad khuloo abwaaba jahannama khaalideena feeha fabi'sa maswal mutakabbireen"
  },
  {
    "id": 73,
    "text": "Wa seeqal lazeenat taqaw Rabbahum ilal Jannati zumaraa hattaaa izaa jaaa'oohaa wa futihat abwaabuhaa wa qaala lahum khazanatuhaa salaamun 'alaikum tibtum fadkhuloohaa khaalideen"
  },
  {
    "id": 74,
    "text": "Wa qaalull hamdulillaahil lazee sadaqanaa wa'dahoo wa awrasanal arda natabaw wa-u minal jannati haisu nashaaa'u fani'ma ajrul 'aamileen"
  },
  {
    "id": 75,
    "text": "Wa taral malaaa'ikata haaaffeena min hawlil 'Arshi yusabbihoona bihamdi Rabbihim wa qudiya bainahum bilhaqqi wa qeelal hamdu lillaahi Rabbil 'aalameen"
  }
];

export default en;
