import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Wal'aadi yaati dabha"
  },
  {
    "id": 2,
    "text": "Fal moori yaati qadha"
  },
  {
    "id": 3,
    "text": "Fal mugheeraati subha"
  },
  {
    "id": 4,
    "text": "Fa atharna bihee naq'a"
  },
  {
    "id": 5,
    "text": "Fawa satna bihee jam'a"
  },
  {
    "id": 6,
    "text": "Innal-insana lirabbihee lakanood"
  },
  {
    "id": 7,
    "text": "Wa innahu 'alaa zaalika la shaheed"
  },
  {
    "id": 8,
    "text": "Wa innahu lihubbil khairi la shadeed"
  },
  {
    "id": 9,
    "text": "Afala ya'lamu iza b'uthira ma filquboor"
  },
  {
    "id": 10,
    "text": "Wa hussila maa fis sudoor"
  },
  {
    "id": 11,
    "text": "Inna rabbahum bihim yauma 'izil lakhabeer"
  }
];

export default en;
