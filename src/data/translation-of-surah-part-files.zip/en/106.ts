import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Li-eelaafi quraish"
  },
  {
    "id": 2,
    "text": "Eelaafihim rihlatash shitaaa'i wassaif"
  },
  {
    "id": 3,
    "text": "Faly'abudoo rabba haazal-bait"
  },
  {
    "id": 4,
    "text": "Allazeee at'amahum min joo'inw-wa-aamanahum min khawf"
  }
];

export default en;
