import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Alif-Laaam-Raa; tilka Aayaatul Kitaabil Hakeem"
  },
  {
    "id": 2,
    "text": "'A kaana linnaasi 'ajaaban 'an 'awhainaaa 'ilaa rajulin minhum 'an anzirin naasa wa bashshiril lazeena 'aamanoo 'anna lahum qadama sidqin 'inda Rabbihim; qaalal kaafiroona 'inna haazaa la saahirun mubeen"
  },
  {
    "id": 3,
    "text": "Inna Rabbakumul laahul lazee khalaqas samaawaati wal arda fee sittati aiyaamin thummas tawaa 'alal 'Arshi yudabbirul amra maa min shafee'in illaa min ba'di iznih; zalikumul laahu Rabbukum fa'budooh; afalaa tazakkaroon"
  },
  {
    "id": 4,
    "text": "Ilaihi marji'ukum jamee 'anw wa'dal laahi haqqaa; innahoo yabda'ul khalqa thumma yu'eeduhoo liyajziyal lazeena aamanoo wa 'amilus saalihaati bilqist; wallazeena kafaroo lahum sharaabun min hamee minw wa 'azaabun 'aleemun bimaa kaanoo yakfuroon"
  },
  {
    "id": 5,
    "text": "Huwal lazee ja'alash shamsa diyaaa'anw walqamara nooranw wa qaddarahoo manaazila li ta'lamoo 'adadas sineena walhisaab; maa khalaqal laahu zaalika illa bilhaqq; yufassilul aayaati li qawminy ya'lamoon"
  },
  {
    "id": 6,
    "text": "Inna fikh tilaafil laili wannahaari wa maa khalaqal laahu fis samaawaati wal ardi la aayaatin liqawminy yattaqoon"
  },
  {
    "id": 7,
    "text": "Innal lazeena laa yarjoona liqaaa'anaa wa radoo bilhayaatid dunyaa watma' annoo bihaa wallazeena hum 'an Aayaatinaa ghaafiloon"
  },
  {
    "id": 8,
    "text": "Ulaaa'ika ma'waahumun Naaru bimaa kaanoo yaksiboon"
  },
  {
    "id": 9,
    "text": "Innal lazeena aamanoo wa 'amilus saalihaati yahdeehim Rabbuhum bi eemaanihim tajree min tahtihimul anhaaru fee jannaatin Na'eem"
  },
  {
    "id": 10,
    "text": "Da'waahum feehaa Subhaanakal laahumma wa tahiyyatuhum feehaa salaam; wa aakhiru da'waahum anil hamdu lillaahi Rabbil 'aalameen"
  },
  {
    "id": 11,
    "text": "Wa law yu'ajjilul laahu linnaasish sharra sti' jaalahum bil khairi laqudiya ilaihim 'ajaluhum fa nazarul lazeena laa yarjoona liqaaa'anaa fee tughyaanihim ya'mahoon"
  },
  {
    "id": 12,
    "text": "Wa izaa massal insaanad durru da'aanaa li jambiheee aw qaa'idan aw qaaa'iman falammaa kashafnaa 'anhu durrahoo marra ka an lam yad'unaaa ilaa durrin massah; kazaalika zuyyina lilmusrifeena maa kaanoo ya'maloon"
  },
  {
    "id": 13,
    "text": "Wa laqad ahlaknal quroona min qablikum lammaa zalamoo wa jaaa'at hum Rusuluhum bil baiyinaati wa maa kaanoo liyu'minoo; kazaalika najzil qawmal mujrimeen"
  },
  {
    "id": 14,
    "text": "Thumma ja'alnaakum khalaaa'ifa fil ardi min ba'dihim li nanzura kaifa ta'maloon"
  },
  {
    "id": 15,
    "text": "Wa izaa tutlaa 'alaihim aayaatunaa baiyinaatin qaalal lazeena laa yarjoona liqaaa'a na'ti bi Qur'aanin ghairi haazaaa aw baddilh; qul maa yakoonu leee 'an 'ubaddilahoo min tilqaaa'i nafsee in attabi'u illaa maa yoohaaa ilaiya inneee akhaafu in 'asaytu Rabbee 'azaaba Yawmin 'Azeem"
  },
  {
    "id": 16,
    "text": "Qul law shaaa'al laahu maa talawtuhoo 'alaikum wa laaa adraakum bihee faqad labistu feekum 'umuran min qablih; afalaa ta'qiloon"
  },
  {
    "id": 17,
    "text": "Faman azlamu mimmanif taraa 'alal laahi kaziban aw kazzaba bi Aayaatih; innahoo laa yuflihul mujrimoon"
  },
  {
    "id": 18,
    "text": "Wa ya'budoona min doonil laahi maa laa yadurruhum wa laa yanfa'uhum wa yaqooloona haaa'ulaaa'i shufa'aaa 'unaa 'indal laah; qul 'a tunabbi 'oonal laaha bi maa laa ya'lamu fis samaawaati wa laa fil ard; subhaanahoo wa Ta'aalaa 'ammaa yushrikoon"
  },
  {
    "id": 19,
    "text": "Wa maa kaanan naasu illaaa ummatanw waahidatan fa khtalafoo; wa law laa kalimatun sabaqat mir Rabbika laqudiya bainahum fee maa feehi yakhtalifoon"
  },
  {
    "id": 20,
    "text": "Wa yaqooloona law laaa unzila 'alaihi aayatun mir Rabbihee faqul innamal ghaibu lillaahi fantaziroo innee ma'akum minal muntazireen"
  },
  {
    "id": 21,
    "text": "Wa izaaa azaqnan naasa rahmatan min ba'di darraaa'a massat hum izaa lahum makrun feee aayaatinaa; qulil laahu asra'u makraa; inna rusulanaa yaktuboona maa tamkuroon"
  },
  {
    "id": 22,
    "text": "Huwal lazee yusayyirukum fil barri walbahri hattaaa izaa kuntum fil fulki wa jaraina bihim bi reehin tayyibatinw wa farihoo bihaa jaaa'at haa reehun 'aasifunw wa jaaa'ahumul mawju min kulli makaaninw wa zannooo 'annahum 'uheeta bihim da'a wullaaha mukhliseena lahud deena la'in anjaitanaa min haazihee la nakoonanna minash shaakireen"
  },
  {
    "id": 23,
    "text": "Falammaaa anjaahum izaa hum yabghoona fil ardi bighairil haqq; yaaa aiyuhannaasu innamaa bagh yukum 'alaaa anfusikum mataa'al hayaatid dunyaa thumma ilainaa marji'ukum fanunabbi 'ukum bimaa kuntum ta'maloon"
  },
  {
    "id": 24,
    "text": "Innamaa masalul hayaatid dunyaa ka maaa'in anzalnaahu minas samaaa'i fakhtalata bihee nabaatul ardi mimmaa ya'kulun naasu wal an'aam; hattaaa izaaa akhazatil ardu zukhrufahaa wazzayyanat wa zanna ahluhaaa annahum qaadiroona 'alaihaaa ataahaaa amrunaa lailan aw nahaaran faja'alnaahaa haseedan ka 'an lam taghna bil-ams; kazaalika nufassilul aayaati liqawminy yatafakkaroon"
  },
  {
    "id": 25,
    "text": "Wallaahu yad'ooo ilaa daaris salaami wa yahdee many yashaaa'u ilaa Siraatin Mustaqeem"
  },
  {
    "id": 26,
    "text": "Lil lazeena ahsanul husnaa wa ziyaadatunw wa laa yarhaqu wujoohahum qatarunw wa laa zillah; ulaaa'ika ashaabul jannati hum feehaa khaalidoon"
  },
  {
    "id": 27,
    "text": "Wallazeena kasabus saiyi aati jazaaa'u saiyi'atin bimislihaa wa tarhaquhum zillah; maa lahum minal laahi min 'aasimin ka annamaaa ughshiyat wujoohuhum qita'an minal laili muzlimaa; ulaaa'ika Ashaabun Naari hum feeha khaalidoon"
  },
  {
    "id": 28,
    "text": "Wa yawma nahshuruhum jamee'an thumma naqoolu lil lazeena ashrakoo makaanakum antum wa shurakaaa'ukum; fazaiyalnaa bainahum wa qaala shurakaaa'uhum maa kuntum iyyaanaa ta'budoon"
  },
  {
    "id": 29,
    "text": "Fakafaa billaahi shaheedan bainanaa wa bainakum in kunnaa 'an 'ibaadatikum laghaafileen"
  },
  {
    "id": 30,
    "text": "Hunaalika tabloo kullu nafsin maaa 'aslafat; wa ruddoo ilal laahi mawlaahumul haqqi wa dalla 'anhum maa kaanoo yaftaroon"
  },
  {
    "id": 31,
    "text": "Qul mai yarzuqukum minas samaaa'i wal ardi ammany yamlikus sam'a wal absaara wa mai yukhrijul haiya minal maiyiti wa yukhrijul maiyita minal haiyi wa mai yudabbirul amr; fasa yaqooloonal laah; faqul afalaa tattaqoon"
  },
  {
    "id": 32,
    "text": "Fazaalikumul laahu Rabbukumul haqq; famaazaa ba'dal haqqi illad dalaalu fa anna tusrafoon"
  },
  {
    "id": 33,
    "text": "Kazaalika haqqat Kalimatu Rabbika 'alal lazeena fasaqooo annahum laa yu'minoon"
  },
  {
    "id": 34,
    "text": "Qul hal min shurakaaa 'ikum mai yabda'ul khalqa thumma yu'eeduh; qulil laahu yabda'ul khalqa thumma yu'eeduhoo fa annaa tu'fakoon"
  },
  {
    "id": 35,
    "text": "Qul hal min shurakaaa 'ikum mai yahdeee ilal haqq; qulil laahu yahdee lilhaqq; afamai yahdeee ilal haqqi ahaqqu ai yuttaba'a ammal laa yahiddeee illaaa ai yuhdaa famaa lakum kaifa tahkumoon"
  },
  {
    "id": 36,
    "text": "Wa maa yattabi'u aksaruhum illaa zannaa; innaz zanna laa yughnee minal haqqi shai'aa; innal laaha 'Aleemun bimaa yaf'aloon"
  },
  {
    "id": 37,
    "text": "Wa maa kaana haazal Qur'aanu ai yuftaraa min doonil laahi wa laakin tasdeeqal lazee baina yadaihi wa tafseelal Kitaabi laa raiba feehee mir Rabbil 'aalameen"
  },
  {
    "id": 38,
    "text": "'Am yaqooloonaf taraahu qul fa'too bi sooratin mislihee wad'oo manis tata'tum min doonil laahi in kuntum saadiqeen"
  },
  {
    "id": 39,
    "text": "Bal kazzaboo bimaa lam yuheetoo bi'ilmihee wa lammaa ya'tihim ta'weeluh; kazaalika kazzabal lazeena min qablihim fanzur kaifa kaana 'aaqibatuz zaalimeen"
  },
  {
    "id": 40,
    "text": "Wa minhum mai yu 'minu bihee wa minhum mal laa yu'minu bih; wa Rabbuka a'lamu bilmufsideen"
  },
  {
    "id": 41,
    "text": "Wa in kazzabooka faqul lee 'amalee wa lakum 'amalukum antum bareee'oona mimmaaa a'malu wa ana bareee'um mimmaa ta'maloon"
  },
  {
    "id": 42,
    "text": "Wa minhum mai yastami'oona ilaik; afa anta tusmi'us summa wa law kaanoo laa ya'qiloon"
  },
  {
    "id": 43,
    "text": "Wa minhum mai yanzuru ilaik; afa anta tahdil 'umya wa law kaanoo laa yubsiroon"
  },
  {
    "id": 44,
    "text": "Innal laaha laa yazlimun naasa shai'anw wa laakin nannaasa anfusahum yazlimoon"
  },
  {
    "id": 45,
    "text": "Wa Yawma yahshuruhum ka 'an lam yalbasooo illaa saa'atan minan nahaari yata'aarafoona bainahum; qad khasiral lazeena kazzaboo bi liqaaa'il laahi wa maa kaanoo muhtadeen"
  },
  {
    "id": 46,
    "text": "Wa imma nuriyannaka ba'dal lazee na'iduhum aw natawaffayannaka fa ilainaa marji'uhum thummal laahu shaheedun 'alaa maa yaf'aloon"
  },
  {
    "id": 47,
    "text": "Wa likulli ummatir Rasoolun fa izaa jaaa'a Rasooluhum qudiya bainahum bilqisti wa hum laa yuzlamoon"
  },
  {
    "id": 48,
    "text": "Wa yaqooloona mataa haazal wa'du in kuntum saadiqeen"
  },
  {
    "id": 49,
    "text": "Qul laaa amliku linafsee darranw wa laa naf'an illaa maa shaaa'al laah; likulli ummatin ajalun izaa jaaa'a ajaluhum fa laaa yasta'khiroona saa'atanw wa laa yastaqdimoon"
  },
  {
    "id": 50,
    "text": "Qul 'a ra'aytum in ataakum 'azaabuhoo bayaatan aw nahaaran maazaa yasta'jilu minhul mujrimoon"
  },
  {
    "id": 51,
    "text": "'A thumma izaa maa waqa'a aamantum bih; aaal 'aana wa qad kuntum bihee tasta'jiloon"
  },
  {
    "id": 52,
    "text": "Thumma qeela lil lazeena zalamoo zooqoo 'azaabal khuldi hal tujzawna illaa bimaa kuntum taksiboon"
  },
  {
    "id": 53,
    "text": "Wa yastanbi'oonaka 'a haqqun huwa qul ee wa Rabbeee innahoo lahaqq; wa maaa antum bimu'jizeen"
  },
  {
    "id": 54,
    "text": "Wa law anna likulli nafsin zalamat maa fil ardi laftadat bih; wa asarrun nadaamata lammaa ra awul 'azaab, wa qudiya bainahum bilqist; wa hum laa yuzlamoon"
  },
  {
    "id": 55,
    "text": "Alaaa inna lillaahi maa fis samaawaati wal ard; alaaa inna wa'dal laahi haqqunw wa laakinna aksarahum laa ya'lamoon"
  },
  {
    "id": 56,
    "text": "Huwa yuhyee wa yumeetu wa ilaihi turja'oon"
  },
  {
    "id": 57,
    "text": "Yaaa aiyuhan naasu qad jaaa'atkum maw'izatun mir Rabbikum wa shifaaa'ul limaa fis sudoori wa hudanw wa rahmatul lil mu'mineen"
  },
  {
    "id": 58,
    "text": "Qul bi fadlil laahi wa bi rahmatihee fa bi zaalika fal yafrahoo huwa khairun mimmaa yajma'oon"
  },
  {
    "id": 59,
    "text": "Qul ara'aitum maaa anzalal laahu lakum mir rizqin faja'altum minhu haraamanw wa halaalan qul aaallaahu azina lakum; am 'alal laahi taftaroon"
  },
  {
    "id": 60,
    "text": "Wa maa zannul lazeena yaftaroona 'alal laahil kaziba Yawmal Qiyaamah; innal laaha lazoo fadlin 'alan naasi wa laakinna aksarahum laa yashkuroon"
  },
  {
    "id": 61,
    "text": "Wa maa takoonu fee sha'ninw wa maa tatloo minhu min qur'aaninw wa laa ta'maloona min 'amalin illaa kunnaa 'alaikum shuhoodan iz tufeedoona feeh; wa maa ya'zubu 'ar Rabbika min misqaali zarratin fil ardi wa laa fis samaaa'i wa laaa asghara min zaalika wa laaa akbara illaa fee Kitaabin Mubeen"
  },
  {
    "id": 62,
    "text": "Alaa innaa awliyaaa'al laahi laa khawfun 'alaihim wa laa hum yahzanoon"
  },
  {
    "id": 63,
    "text": "Allazeena aamanoo wa kaanoo yattaqoon"
  },
  {
    "id": 64,
    "text": "Lahumul bushraa fil hayaatid dunyaa wa fil Aakhirah; laa tabdeela li kalimaatil laah; zaalika huwal fawzul 'azeem"
  },
  {
    "id": 65,
    "text": "Wa laa yahzunka qawluhum; innal 'izzata lillaahi jamee'aa; Huwas Samee'ul 'Aleem"
  },
  {
    "id": 66,
    "text": "Alaaa inna lillaahi man fis samaawaati wa man fil ard; wa maa yattabi'ul lazeena yad'oona min doonil laahi shurakaaa'; iny yattabi'oona illaz zanna wa in hum illaa yakhrusoon"
  },
  {
    "id": 67,
    "text": "Huwal lazee ja'ala lakumul laila litaskunoo feehi wannahaara mubsiraa; inna fee zaalika la Aayaatil li qawminy yasma'oon"
  },
  {
    "id": 68,
    "text": "Qaalut takhazal laahu waladan Subhaanahoo Huwal Ghaniyyu lahoo maa fis samaawaati wa maa fil ard; in 'indakum min sultaanin bihaazaaa; a' taqooloona 'al allaahi maa laa ta'lamoon"
  },
  {
    "id": 69,
    "text": "Qul innal lazeena yaftaroona 'al allaahil kaziba laa yuflihoon"
  },
  {
    "id": 70,
    "text": "Mataa'un fiddunyaa thumma ilainaa marji'uhum thumma nuzeequhumul 'azaabash shadeeda bimaa kaanoo yakfuroon"
  },
  {
    "id": 71,
    "text": "Watlu 'alaihim naba-a-Noohin iz qaala liqawmihee yaa qawmi in kaana kabura 'alaikum maqaamee wa tazkeeree bi Aayaatil laahi fa'alal laahi tawakkaltu fa ajmi'ooo amrakum wa shurakaaa'akum thumma laa yakun amrukum 'alaikum ghummatan thummaq dooo ilaiya wa laa tunziroon"
  },
  {
    "id": 72,
    "text": "Fa in tawallaitum famaa sa altukum min ajrin; in ajriya illaa 'al allaahi wa umirtu an akoona minal muslimeen"
  },
  {
    "id": 73,
    "text": "Fa kazzaboohu fa najjainaahu wa man ma'ahoo fil fulki wa ja'alnaahum khalaaa'ifa wa aghraqnal lazeena kazzaboo bi aayaatinaa fanzur kaifa kaana 'aaqibatul munzareen"
  },
  {
    "id": 74,
    "text": "Thumma ba'asnaa min ba'dihee Rusulan ilaa qawmihim fajaaa'oohum bil baiyinaati famaa kaanoo liyu'minoo bimaa kazzaboo bihee min qabl; kazaalika natba'u 'alaa quloobil mu'tadeen"
  },
  {
    "id": 75,
    "text": "Thumma ba'asnaa min ba'dihim Moosaa Wa Haaroona ilaa Fir'awna wa mala'ihee bi aayaatinaa fastakbaroo wa kaanoo qawman mujrimeen"
  },
  {
    "id": 76,
    "text": "Falammaa jaaa'ahumul haqqu min 'indinaa qaalooo inna haazaa la sihrun mubeen"
  },
  {
    "id": 77,
    "text": "Qaalaa Moosaaa 'a taqooloona lil haqqi lammmaa jaaa'a kum 'a sihrun haazaa wa laa yuflihus saahiroon"
  },
  {
    "id": 78,
    "text": "Qaaloo aji'tanaa litalfitanaa 'ammaa wajadnaa 'alaihi aabaaa'anaa wa takoona lakumal kibriyaaa'u fil ardi wa maa nahnu lakumaa bi mu'mineen"
  },
  {
    "id": 79,
    "text": "Wa qaala Fir'awnu' toonee bikulli saahirin 'aleem"
  },
  {
    "id": 80,
    "text": "Falammaa jaaa'assa haratu qaala lahum Moosaaa alqoo maaa antum mulqoon"
  },
  {
    "id": 81,
    "text": "Falammaaa alqaw qaala Moosaa maa ji'tum bihis sihr; innal laaha sa yubtiluhoo; innal laaha laa yuslihu 'amalal mufsideen"
  },
  {
    "id": 82,
    "text": "Wa yuhiqqul laahul haqqa bi Kalimaatihee wa law karihal mujrimoon"
  },
  {
    "id": 83,
    "text": "Famaaa aamana li-Moosaaa illaa zurriyyatun min qawmihee 'alaa khawfin min Fir'awna wa mala'ihim 'any yaftinahum; wa inna Fir'awna la'aalin fil ardi wa innahoo laminal musrifeen"
  },
  {
    "id": 84,
    "text": "Wa qaala Moosaa yaa qawmi in kuntum aamantum billaahi fa'alaihi tawakkalooo in kuntum muslimeen"
  },
  {
    "id": 85,
    "text": "Faqaaloo 'alal laahi tawakkalnaa Rabbanaa laa taj'alnaa fitnatal lilqawmiz zaalimeen"
  },
  {
    "id": 86,
    "text": "Wa najjinaa birahmatika minal qawmil kaafireen"
  },
  {
    "id": 87,
    "text": "Wa awhainaaa ilaa Moosaa wa akheehi an tabaw wa aali qawmikuma bi Misra buyootanw waj'aloo buyootakum qiblatanw wa aqeemus Salaah; wa bashshiril mu'mineen"
  },
  {
    "id": 88,
    "text": "Wa qaala Moosaa Rabbanaaa innaka aataita Fir'awna wa mala ahoo zeenatanw wa amwaalan fil hayaatid dunyaa Rabbanaa liyudillo 'ansabeelika Rabbanat mis 'alaaa amwaalihim washdud 'alaa quloobihim falaa yu'minoo hatta yarawul 'azaabal aleem"
  },
  {
    "id": 89,
    "text": "Qaala qad ujeebad da'watukumaa fastaqeemaa wa laa tattabi'aaanni sabeelal lazeena laa ya'lamoon"
  },
  {
    "id": 90,
    "text": "Wa jaawaznaa bi Baneee Israaa'eelal bahra fa atba'ahum Fir'awnu wa junooduhoo baghyanw wa 'adwaa; hattaaa izaaa adrakahul gharaqu qaala aamantu annahoo laaa ilaaha illal lazeee aamanat bihee Banooo Israaa'eela wa ana minal muslimeen"
  },
  {
    "id": 91,
    "text": "Aaal 'aana wa qad 'asaita qablu wa kunta minal mufsideen"
  },
  {
    "id": 92,
    "text": "Falyawma nunajjeeka bibadanika litakoona liman khalfaka Aayah; wa inna kaseeran minan naasi 'an aayaatinaa laghaafiloon"
  },
  {
    "id": 93,
    "text": "Wa laqad bawwa'naa Baneee Israaa'eela mubawwa 'a sidqinw wa razaqnaahum minat taiyibaati fa makhtalafoo hattaa jaaa'ahmul 'ilm; inna Rabbaka yaqdee bainahum Yawmal Qiyaamati feemaa kaanoo feehi yakhtalifoon"
  },
  {
    "id": 94,
    "text": "Fa in kunta fee shakkin mimmaaa anzalnaaa ilaika fas'alil lazeena yaqra'oonal Kitaaba min qablik; laqad jaaa'akal haqqu mir Rabbika fa laa takoonanna minal mumtareen"
  },
  {
    "id": 95,
    "text": "Wa laa takoonanna minal lazeena kazzaboo bi Aayaatil laahi fatakoona minal khaasireen"
  },
  {
    "id": 96,
    "text": "Innal lazeena haqqat 'alaihim Kalimatu Rabbika laa yu'minoon"
  },
  {
    "id": 97,
    "text": "Wa law jaaa'at hum kullu Aayatin hattaa yarawul 'azaabal aleem"
  },
  {
    "id": 98,
    "text": "Falaw laa kaanat qaryatun aamanat fa nafa'ahaaa eemaanuhaaa illaa qawma Yoonusa lammaaa aamanoo kashafnaa 'anhum 'azaabal khizyi fil hayaatid dunyaa wa matta'naahum ilaa heen"
  },
  {
    "id": 99,
    "text": "Wa law shaaa'a Rabbuka la aamana man fil ardi kulluhum jamee'aa; afa anta tukrihun naasa hattaa yakoonoo mu'mineen"
  },
  {
    "id": 100,
    "text": "Wa maa kaana linafsin an tu'mina illaa bi iznil laah; wa yaj'alur rijsa 'alal lazeena laa ya'qiloon"
  },
  {
    "id": 101,
    "text": "Qulin zuroo maazaa fissamaawaati wal ard; wa maa tughnil Aayaatu wannuzuru 'an qawmil laa yu'minoon"
  },
  {
    "id": 102,
    "text": "Fahal yantaziroona illaa misla ayyaamil lazeena khalaw min qablihim; qul fantazirooo innee ma'akum minal muntazireen"
  },
  {
    "id": 103,
    "text": "Thumma nunajjee Rusulana wallazeena aamanoo; kazaalika haqqan 'alainaa nunjil mu'mineen"
  },
  {
    "id": 104,
    "text": "Qul yaaa ayyuhan naasu in kuntum fee shakk-in min deenee fa laa a'budul lazeena ta'budoona min doonil laahi wa laakin a'budul laahal lazee yatawaffaakum wa umirtu an akoona minal mu'mineen"
  },
  {
    "id": 105,
    "text": "Wa an aqim wajhaka liddeeni Haneefanw wa laa takoonanna minal mushrikeen"
  },
  {
    "id": 106,
    "text": "Wa laa tad'u min doonil laahi maa laa yanfa'uka wa laa yadurruk; fa in fa'alta fa innaka izam minaz zaalimeen"
  },
  {
    "id": 107,
    "text": "Wa iny yamsaskal laahu bidurrin falaa kaashifa lahoo illaa hoo;wa iny yuridka bikhairin falaa raaadda lifadlih; yuseebu bihee many yashaaa'u min 'ibaadih; wa huwal Ghafoorur Raheem"
  },
  {
    "id": 108,
    "text": "Qul yaaa ayyuhan naasu qad jaaa'akumul haqqu mir Rabbikum; famanih tadaa fa innamaa yahtadee li nafsih; wa man dalla fa innamaa yadillu 'alaihaa; wa maaa ana 'alaikum bi wakeel"
  },
  {
    "id": 109,
    "text": "Wattabi' maa yoohaaa ilaika wasbir hattaa yahkumal laah; wa Huwa khairul haakimeen"
  }
];

export default en;
