import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Al haaaqqah"
  },
  {
    "id": 2,
    "text": "Mal haaaqqah"
  },
  {
    "id": 3,
    "text": "Wa maaa adraaka mal haaaqqah"
  },
  {
    "id": 4,
    "text": "Kazzabat samoodu wa 'Aadum bil qaari'ah"
  },
  {
    "id": 5,
    "text": "Fa-ammaa Samoodu fa uhlikoo bittaaghiyah"
  },
  {
    "id": 6,
    "text": "Wa ammaa 'Aadun fa uhlikoo bi reehin sarsarin 'aatiyah"
  },
  {
    "id": 7,
    "text": "Sakkhara haa 'alaihim sab'a la yaalinw wa samaaniyata ayyaamin husooman fataral qawma feehaa sar'aa ka annahum a'jaazu nakhlin khaawiyah"
  },
  {
    "id": 8,
    "text": "Fahal taraa lahum min baaqiyah"
  },
  {
    "id": 9,
    "text": "Wa jaaa'a Firawnu wa man qablahoo wal mu'tafikaatu bil khaati'ah"
  },
  {
    "id": 10,
    "text": "Fa 'asaw Rasoola Rabbihim fa akhazahum akhzatar raabiyah"
  },
  {
    "id": 11,
    "text": "Innaa lammaa taghal maaa'u hamalnaakum fil jaariyah"
  },
  {
    "id": 12,
    "text": "Li naj'alahaa lakum tazki ratanw-wa ta'iyahaa uzununw waa'iyah"
  },
  {
    "id": 13,
    "text": "Fa izaa nufikha fis soori nafkhatunw waahidah"
  },
  {
    "id": 14,
    "text": "Wa humilatil ardu wal jibaalu fadukkataa dakkatanw waahidah"
  },
  {
    "id": 15,
    "text": "Fa yawma'izinw waqa'atil waaqi'ah"
  },
  {
    "id": 16,
    "text": "Wanshaqqatis samaaa'u fahiya yawma 'izinw-waahiyah"
  },
  {
    "id": 17,
    "text": "Wal malaku 'alaaa arjaaa'ihaa; wa yahmilu 'Arsha Rabbika fawqahum yawma'izin samaaniyah"
  },
  {
    "id": 18,
    "text": "Yawma'izin tu'radoona laa takhfaa min kum khaafiyah"
  },
  {
    "id": 19,
    "text": "Fa ammaa man ootiya kitaabahoo biyameenihee fa yaqoolu haaa'umuq ra'oo kitaabiyah"
  },
  {
    "id": 20,
    "text": "Innee zannantu annee mulaaqin hisaabiyah"
  },
  {
    "id": 21,
    "text": "Fahuwa fee 'eeshatir raadiyah"
  },
  {
    "id": 22,
    "text": "Fee jannnatin 'aaliyah"
  },
  {
    "id": 23,
    "text": "Qutoofuhaa daaniyah"
  },
  {
    "id": 24,
    "text": "Kuloo washraboo haneee'am bimaaa aslaftum fil ayyaamil khaliyah"
  },
  {
    "id": 25,
    "text": "Wa ammaa man ootiya kitaabahoo bishimaalihee fa yaqoolu yaalaitanee lam oota kitaaabiyah"
  },
  {
    "id": 26,
    "text": "Wa lam adri maa hisaabiyah"
  },
  {
    "id": 27,
    "text": "Yaa laitahaa kaanatil qaadiyah"
  },
  {
    "id": 28,
    "text": "Maaa aghnaa 'annee maaliyah"
  },
  {
    "id": 29,
    "text": "Halaka 'annee sultaaniyah"
  },
  {
    "id": 30,
    "text": "Khuzoohu faghullooh"
  },
  {
    "id": 31,
    "text": "Summal Jaheema sallooh"
  },
  {
    "id": 32,
    "text": "Summa fee silsilatin zar'uhaa sab'oona ziraa'an faslukooh"
  },
  {
    "id": 33,
    "text": "Innahoo kaana laa yu'minu billaahil 'Azeem"
  },
  {
    "id": 34,
    "text": "Wa laa yahuddu 'alaa ta'aamil miskeen"
  },
  {
    "id": 35,
    "text": "Falaysa lahul yawma haahunaa hameem"
  },
  {
    "id": 36,
    "text": "Wa laa ta'aamun illaa min ghisleen"
  },
  {
    "id": 37,
    "text": "Laa ya'kuluhooo illal khaati'oon"
  },
  {
    "id": 38,
    "text": "Falaaa uqsimu bimaa tubsiroon"
  },
  {
    "id": 39,
    "text": "Wa maa laa tubsiroon"
  },
  {
    "id": 40,
    "text": "Innahoo laqawlu Rasoolin kareem"
  },
  {
    "id": 41,
    "text": "Wa maa huwa biqawli shaa'ir; qaleelan maa tu'minoon"
  },
  {
    "id": 42,
    "text": "Wa laa biqawli kaahin; qaleelan maa tazakkaroon"
  },
  {
    "id": 43,
    "text": "Tanzeelum mir rabbil 'aalameen"
  },
  {
    "id": 44,
    "text": "Wa law taqawwala 'alainaa ba'dal aqaaweel"
  },
  {
    "id": 45,
    "text": "La-akhaznaa minhu bilyameen"
  },
  {
    "id": 46,
    "text": "Summa laqata'naa minhul wateen"
  },
  {
    "id": 47,
    "text": "Famaa minkum min ahadin'anhu haajizeen"
  },
  {
    "id": 48,
    "text": "Wa innahoo latazkiratul lilmuttaqeen"
  },
  {
    "id": 49,
    "text": "Wa inna lana'lamu anna minkum mukazzibeen"
  },
  {
    "id": 50,
    "text": "Wa innahu lahasratun 'alal kaafireen"
  },
  {
    "id": 51,
    "text": "Wa innahoo lahaqqul yaqeen"
  },
  {
    "id": 52,
    "text": "Fassabbih bismi Rabbikal 'Azeem"
  }
];

export default en;
