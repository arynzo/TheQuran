import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yaaa ayyuhan nabiyyu izaa tallaqtummun nisaaa'a fatalliqoohunna li'iddatihinna wa ahsul'iddata wattaqul laaha rabbakum; laa tukhri joohunna min bu-yootihinna wa laa yakhrujna illaaa any ya'teena bifaahishatim mubaiyinah; wa tilka hudoodul laah; wa many yata'adda hudoodal laahi faqad zalama nafsah; laa tadree la'allal laaha yuhdisu ba'dazaalika amraa"
  },
  {
    "id": 2,
    "text": "Fa izaa balaghna ajalahunna fa amsikoohunna bima'roofin aw faariqoohunna bima'roofinw wa ashhidoo zawai 'adlim minkum wa aqeemush shahaadata lillaah; zaalikum yoo'azu bihee man kaana yu'minu billaahi wal yawmil aakhir; wa many yattaqil laaha yaj'al lahoo makhrajaa"
  },
  {
    "id": 3,
    "text": "Wa yarzuqhu min haisu laa yahtasib; wa many yatawakkal 'alal laahi fahuwa hasbuh; innal laaha baalighu amrih; qad ja'alal laahu likulli shai'in qadraa"
  },
  {
    "id": 4,
    "text": "Wallaaa'ee ya'isna minal maheedi min nisaaa 'ikum inir tabtum fa'iddatuhunna salaasatu ashhurinw wallaaa'ee lam yahidn; wa ulaatul ahmaali ajaluhunna any yada'na hamlahun; wa many yattaqil laaha yaj'al lahoo min amrihee yusraa"
  },
  {
    "id": 5,
    "text": "Zaalika amrul laahi anzalahoo ilaikum; wa many yattaqil laaha yukaffir 'anhu saiyi aatihee wa yu'zim lahoo ajraa"
  },
  {
    "id": 6,
    "text": "Askinoohunna min haisu sakantum minw wujdikum wa laa tudaaarroohunna litudaiyiqoo 'alaihinn; wa in kunna ulaati hamlin fa anfiqoo 'alaihinna hattaa yada'na hamlahunn; fain arda'na lakum fa aatoo hunna ujoorahunn; wa'tamiroo bainakum bima'roofinw wa in ta'aasartum fasaturdi'u lahooo ukhraa"
  },
  {
    "id": 7,
    "text": "Liyunfiq zoo sa'atim min sa'atih; wa man qudira 'alaihi rizquhoo falyunfiq mimmaaa aataahul laah; laa yukalliful laahu nafsan illaa maaa aataahaa; sa yaj'alul laahu ba'da'usriny yusraa"
  },
  {
    "id": 8,
    "text": "Wa ka ayyim min qaryatin 'atat 'an amri Rabbihaa wa Rusulihee fahaasabnaahaa hisaaban shadeedanw wa 'azzabnaahaa 'azaaban nukraa"
  },
  {
    "id": 9,
    "text": "Fazaaqat wabbala amrihaa wa kaana 'aaqibatu amrihaa khusraa"
  },
  {
    "id": 10,
    "text": "A'addal laahu lahum 'azaaban shadeeda; fattaqul laaha yaaa ulil albaab illazeena aammanoo; qad anzalal laahu ilaikum zikraa"
  },
  {
    "id": 11,
    "text": "Rasoolany yatloo 'alaikum aayaatil laahi mubaiyinaatil liyukhrijal lazeena aamanoo wa 'amilus saalihaati minaz zulumaati ilan noor; wa many yu'min billaahi wa ya'mal saalihany yudkhilhu jannaatin tajree min tahtihal anhaaru khaalideena feehaa abadaa qad ahsanal laahu lahoo rizqaa"
  },
  {
    "id": 12,
    "text": "Allaahul lazee khalaqa Sab'a Samaawaatinw wa minal ardi mislahunna yatanazzalul amru bainahunna lita'lamooo annal laaha 'alaa kulli shai'in Qadeerunw wa annal laaha qad ahaata bikulli shai'in 'ilmaa"
  }
];

export default en;
