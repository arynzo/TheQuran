import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Haa-Meeem"
  },
  {
    "id": 2,
    "text": "Tanzeelul Kitaabi minal laahil Azeezil 'Aleem"
  },
  {
    "id": 3,
    "text": "Ghaafiriz zambi wa qaabilit tawbi shadeedil 'iqaabi zit tawli laaa ilaaha illaa Huwa ilaihil maseer"
  },
  {
    "id": 4,
    "text": "Maa yujaadilu feee Aayaatil laahi illal lazeena kafaroo falaa yaghrurka taqallubuhum fil bilaad"
  },
  {
    "id": 5,
    "text": "Kazzabat qablahum qawmu Noohinw wal Ahzaabu min ba'dihim wa hammat kullu ummatin bi Rasoolihim li ya'khuzoohu wa jaadaloo bilbaatili li yud hidoo bihil haqqa fa akhaztuhum fa kaifa kaana 'iqaab"
  },
  {
    "id": 6,
    "text": "Wa kazaalika haqqat Kalimatu Rabbika 'alal lazeena kafarooo annahum Ashaabun Naar"
  },
  {
    "id": 7,
    "text": "Allazeena yahmiloonal 'Arsha wa man hawlahoo yusabbihoona bihamdi Rabbihim wa yu'minoona bihee wa yastaghfiroona lillazeena aamanoo Rabbanaa wasi'ta kulla shai'ir rahmatanw wa 'ilman faghfir lillazeena taaboo wattaba'oo sabeelaka wa qihim 'azaabal Jaheem"
  },
  {
    "id": 8,
    "text": "Rabbanaa wa adkhilhum Jannaati 'adninil latee wa'attahum wa man salaha min aabaaa'ihim wa azwaajihim wa zurriyyaatihim; innaka Antal 'Azeezul Hakeem"
  },
  {
    "id": 9,
    "text": "Wa qihimus saiyi-aat; wa man taqis saiyi-aati Yawma'izin faqad rahimtah; wa zaalika huwal fawzul 'azeem"
  },
  {
    "id": 10,
    "text": "Innal lazeena kafaroo yunaadawna lamaqtul laahi akbaru mim maqtikum anfusakum iz tud'awna ilal eemaani fatakfuroon"
  },
  {
    "id": 11,
    "text": "Qaaloo Rabbanaaa amat tanasnataini wa ahyaitanas nataini fa'tarafnaa bizunoo binaa fahal ilaa khuroojim min sabeel"
  },
  {
    "id": 12,
    "text": "Zaalikum bi annahooo izaa du'iyal laahu wahdahoo kafartum wa iny yushrak bihee tu'minoo; falhukmu lillaahil 'Aliyyil Kabeer"
  },
  {
    "id": 13,
    "text": "Huwal lazee yureekum Aayaatihee wa yunazzilu lakum minas samaaa'i rizqaa; wa maa yatazakkaru illaa mai yuneeb"
  },
  {
    "id": 14,
    "text": "Fad'ul laaha mukhliseena lahud deena wa law karihal kaafiroon"
  },
  {
    "id": 15,
    "text": "Rafee'ud darajaati zul 'Arshi yulqir rooha min amrihee 'alaa mai yashaaa'u min 'ibaadihee liyunzira yawmat talaaq"
  },
  {
    "id": 16,
    "text": "Yawma hum baarizoona laa yakhfaa 'alal laahi minhum shai; limanil mulkul Yawma lillaahil Waahidil Qahaar"
  },
  {
    "id": 17,
    "text": "Al-Yawma tujzaa kullu nafsim bimaa kasabat; laa zulmal Yawm; innal laaha saree'ul hisaab"
  },
  {
    "id": 18,
    "text": "Wa anzirhum yawmal aazifati izil quloobu ladal hanaajiri kaazimeen; maa lizzaalimeena min hameeminw wa laa shafee'iny-yutaa'"
  },
  {
    "id": 19,
    "text": "Ya'lamu khaaa'inatal a'yuni wa maa tukhfis sudoor"
  },
  {
    "id": 20,
    "text": "Wallaahu yaqdee bilhaqq, wallazeena yad'oona min doonihee laa yaqdoona bishai'; innal laaha Huwas Samee'ul Baseer"
  },
  {
    "id": 21,
    "text": "Awalam yaseeroo fil ardi fa yanzuroo kaifa kaana 'aaqibatul lazeena kaanoo min qablihim; kaanoo hum ashadda minhum quwwatanw wa aasaaran fil ardi fa akhazahumul laahu bizunoobihim wa maa kaana lahum minal laahi minw waaq"
  },
  {
    "id": 22,
    "text": "Zaalika bi annahum kaanat taateehim Rusuluhum bilbaiyinaati fakafaroo fa akhazahumul laah; innahoo qawiyyun shadeedul 'iqaab"
  },
  {
    "id": 23,
    "text": "Wa laqad arsalnaa Moosaa bi Aayaatinaa wa sultaanim mubeen"
  },
  {
    "id": 24,
    "text": "Ilaa Fir'awna wa Haamaana wa Qaaroona faqaaloo saahirun kazzaab"
  },
  {
    "id": 25,
    "text": "Falamma jaaa'ahum bil haqqi min 'indinaa qaaluq tulooo abnaaa'al lazeena aamanoo ma'ahoo wastahyoo nisaaa'ahum; wa maa kaidul kaafireena illaa fee dalaal"
  },
  {
    "id": 26,
    "text": "Wa qaala Fir'awnu zarooneee aqtul Moosaa walyad'u Rabbahoo inneee akhaafu ai yubaddila deenakum aw ai yuzhira fil ardil fasaad"
  },
  {
    "id": 27,
    "text": "Wa qaala Moosaaaa innee 'uztu bi Rabbee wa Rabbikum min kulli mutakabbiril laayu'minu bi Yawmil Hisaab"
  },
  {
    "id": 28,
    "text": "Wa qaala rajulum mu'minummin Aali Fir'awna yaktumu eemaanahooo ataqtuloona rajulan ai yaqoola Rabbi yal laahu wa qad jaaa'akum bil baiyinaati mir Rabbikum wa iny yaku kaaziban fa'alaihi kazibuh wa iny yaku saadiqany yasibkum ba'dul lazee ya'idukum innal laaha laa yahdee man huwa musrifun kazzaab"
  },
  {
    "id": 29,
    "text": "Yaa qawmi lakumul mulkul yawma zaahireena fil ardi famai yansurunaa mim baasil laahi in jaaa'anaa; qaala Fir'awnu maaa ureekum illaa maaa araa wa maaa ahdeekum illaa sabeelar Rashaad"
  },
  {
    "id": 30,
    "text": "Wa qaalal lazee aamana yaa qawmi inneee akhaafu 'alaikum misla yawmil Ahzaab"
  },
  {
    "id": 31,
    "text": "Misla daabi qawmi Noohinw wa 'aadinw wa Samooda wallazeena mim ba'dihim; wa mal laahu yureedu zulmal lil'ibaad"
  },
  {
    "id": 32,
    "text": "Wa yaa qawmi inneee akhaafu 'alaikum yawmat tanaad"
  },
  {
    "id": 33,
    "text": "Yawma tuwalloona mud bireena maa lakum minal laahi min 'aasim; wa mai yudlilil laahu famaa lahoo min haad"
  },
  {
    "id": 34,
    "text": "Wa laqad jaaa'akum Yoosufu min qablu bil baiyinaati famaa ziltum fee shakkim mimmaa jaaa'akum bihee hattaaa izaa halaka qultum lai yab asal laahu mim ba'dihee Rasoolaa; kazaalika yudillul laahu man huwa Musrifum murtaab"
  },
  {
    "id": 35,
    "text": "Allazeena yujaadiloona feee Aaayaatil laahi bighairi sultaanin ataahum kabura maqtan 'indal laahi wa 'indal lazeena aamanoo; kazaalika yatbahul laahu 'alaa kulli qalbi mutakabbirin jabbaar"
  },
  {
    "id": 36,
    "text": "Wa qaala Fir'awnu yaa Haamaanub-ni lee sarhal la'alleee ablughul asbaab"
  },
  {
    "id": 37,
    "text": "Asbaabas samaawaati faattali'a ilaaa ilaahi Moosaa wa innee la azunnuhoo kaazibaa; wa kazaalika zuyyina li-Fir'awna sooo'u 'amalihee wa sudda 'anis sabeel; wa maa kaidu Fir'awna illaa fee tabaab"
  },
  {
    "id": 38,
    "text": "Wa qaalal lazeee aamana yaa qawmit tabi'ooni ahdikum sabeelar rashaad"
  },
  {
    "id": 39,
    "text": "Yaa qawmi innamaa haazihil hayaatud dunyaa mataa'unw wa innal Aakhirata hiya daarul qaraar"
  },
  {
    "id": 40,
    "text": "Man 'amila saiyi'atan falaa yujzaaa illaa mislahaa wa man 'amila saaliham min zakarin aw unsaa wa huwa mu'minun fa ulaaa'ika yadkhuloonal Jannata yurzaqoona feehaa bighairi hisaab"
  },
  {
    "id": 41,
    "text": "Wa yaa qawmi maa leee ad'ookum ilan najaati wa tad'oonaneee ilan Naar"
  },
  {
    "id": 42,
    "text": "Tad'oonanee li-akfura billaahi wa ushrika bihee maa laisa lee bihee 'ilmunw wa ana ad'ookum ilal'Azeezil Ghaffaar"
  },
  {
    "id": 43,
    "text": "Laa jarama annamaa tad'oonanee ilaihi laisa lahoo da'watun fid dunyaa wa laa fil Aakhirati wa anna maraddanaaa ilal laahi wa annal musrifeenahum Ashaabun Naar"
  },
  {
    "id": 44,
    "text": "Fasatazkuroona maaa aqoolu lakum; wa ufawwidu amreee ilal laah; innallaaha baseerum bil'ibaad"
  },
  {
    "id": 45,
    "text": "Fa waqaahul laahu saiyiaati maa makaroo wa haaqa bi Aali-Fir'awna sooo'ul 'azaab"
  },
  {
    "id": 46,
    "text": "An Naaru yu'radoona 'alaihaa ghuduwwanw wa 'ashiyyanw wa Yawma taqoomus Saa'aatu adkhilooo Aala Fir'awna ashaddal 'azaab"
  },
  {
    "id": 47,
    "text": "Wa iz yatahaaajjoona fin Naari fa-yaqoolud du'afaaa'u lillazeenas takbarooo innaa kunnaa lakum taba'an fahal antum mughnoona annaa naseebam minan Naar"
  },
  {
    "id": 48,
    "text": "Qaalal lazeenas takbarooo innaa kullun feehaaa innal laaha qad hakama baynal'ibaad"
  },
  {
    "id": 49,
    "text": "Wa qaalal lazeena fin Naari likhazanati Jahannamad-'oo Rabbakum yukhaffif 'annaa yawmam minal 'azaab"
  },
  {
    "id": 50,
    "text": "Qaalooo awalam taku taateekum Rusulukum bilbaiyinaati qaaloo balaa' qaaloo fad'oo; wa maa du'aaa'ul kaafireena illaa fee dalaal"
  },
  {
    "id": 51,
    "text": "Innaa lanansuru Rusulanaa wallazeena aamanoo fil hayaatid dunyaa wa Yawma yaqoomul ashhaad"
  },
  {
    "id": 52,
    "text": "Yawma laa yanfa'uz zaalimeena ma'ziratuhum wa lahumul la'natu wa lahum soooud daar"
  },
  {
    "id": 53,
    "text": "Wa laqad aatainaa Moosal hudaa wa awrasnaa Baneee Israaa 'eelal Kitaab"
  },
  {
    "id": 54,
    "text": "Hudanw wa zikraa li ulil albaab"
  },
  {
    "id": 55,
    "text": "Fasbir inna wa'dal laahi haqqunw wastaghfir lizambika wa sabbih bihamdi Rabbika bil'ashiyyi wal ibkaar"
  },
  {
    "id": 56,
    "text": "Innal lazeena yujaadi loona feee Aayaatil laahi bighairi sultaanin ataahum in fee sudoorihim illaa kibrum maa hum bibaaligheeh; fasta'iz billaahi innahoo Huwas Samee'ul Baseer"
  },
  {
    "id": 57,
    "text": "Lakhalqus samaawaati wal ardi akbaru min khalqin naasi wa laakinna aksaran naasi laa ya'lamoon"
  },
  {
    "id": 58,
    "text": "Wa maa yastawil a'maa walbaseeru wallazeena aamanoo wa 'amilus saalihaati wa lal museee'; qaleelam maa tatazakkaroon"
  },
  {
    "id": 59,
    "text": "Innas Saa'ata la aatiyatul laa raiba feehaa wa laakinna aksaran naasi laa yu'minoon"
  },
  {
    "id": 60,
    "text": "Wa qaala Rabbukumud 'ooneee astajib lakum; innal lazeena yastakbiroona an 'ibaadatee sa yadkhuloona jahannama daakhireen"
  },
  {
    "id": 61,
    "text": "Allaahul lazee ja'ala lakumul laila littaskunoo feehi wannahaara mubsiraa; innal laaha lazoo fadlin 'alan naasi wa laakinna aksaran naasi laa yashkuroon"
  },
  {
    "id": 62,
    "text": "Zaalikumul laahu Rabbukum khaaliqu kulli shai'in; laaa ilaaha illaa Huwa fa annaa tu'fakoon"
  },
  {
    "id": 63,
    "text": "Kazaalika yu'fakul lazeena kaanoo bi Aayaatil laahi yajhadoon"
  },
  {
    "id": 64,
    "text": "Allaahul lazee ja'ala lakumul arda qaraaranw wassa maaa'a binaaa'anw wa sawwarakum fa ahsana suwarakum wa razaqakum minat taiyibaat; zaalikumul laahu Rabbukum fatabaarakal laahu Rabbul 'aalameen"
  },
  {
    "id": 65,
    "text": "Huwal Hayyu laaa ilaaha illaa Huwa fad'oohu mukh liseena lahud-deen; alhamdu lillaahi Rabbil 'aalameen"
  },
  {
    "id": 66,
    "text": "Qul innee nuheetu an a'budal lazeena tad'oona min doonil laahi lammaa jaaa'a niyal baiyinaatu mir Rabbee wa umirtu an uslima li Rabbil 'aalameen"
  },
  {
    "id": 67,
    "text": "Huwal lazee khalaqakum min turaabin summa min nutfatin summa min 'alaqatin summa yukhrijukum tiflan summa litablughooo ashuddakum summa litakoonoo shuyookhaa; wa minkum mai yutawaffaa min qablu wa litablughooo ajalam musam manw-wa la'allakum ta'qiloon"
  },
  {
    "id": 68,
    "text": "Huwal lazee yuhyee wa yumeetu fa izaa qadaaa amran fa innamaa yaqoolu lahoo kun fa yakoon"
  },
  {
    "id": 69,
    "text": "Alam tara ilal lazeena yujaadiloona feee Aayaatil laahi annaa yusrafoon"
  },
  {
    "id": 70,
    "text": "Allazeena kazzaboo bil Kitaabi wa bimaa arsalnaa bihee Rusulanaa fasawfa ya'lamoon"
  },
  {
    "id": 71,
    "text": "Izil aghlaalu feee a'naaqi-him wassalaasilu yushaboon"
  },
  {
    "id": 72,
    "text": "Fil hameemi summa fin Naari Yasjaroon"
  },
  {
    "id": 73,
    "text": "Summaa qeela lahum ayna maa kuntum tushrikoon"
  },
  {
    "id": 74,
    "text": "Min doonil laahi qaaloo dalloo 'annaa bal lam nakun nad'oo min qablu shai'aa; kazaalika yudillul laahul kaafireen"
  },
  {
    "id": 75,
    "text": "Zaalikum bimaa kuntum tafrahoona fil ardi bighairil haqqi wa bimaa kuntum tamrahoon"
  },
  {
    "id": 76,
    "text": "Udkhulooo abwaaba Jahannama khaalideena feehaa fabi'sa maswal mutakabbireen"
  },
  {
    "id": 77,
    "text": "Fasbir inna wa'dal laahi haqq; fa immaa nuriyannak ba'dal lazee na'i duhum aw natawaffayannaka fa ilainaa yurja'oon"
  },
  {
    "id": 78,
    "text": "Wa laqad arsalnaa Rusulam min qablika minhum man qasasnaa 'alaika wa minhum mal lam naqsus 'alaik; wa maa kaana li Rasoolin any yaatiya bi Aayatin illaa bi iznil laah; fa izaa jaaa'a amrul laahi qudiya bilhaqqi wa khasira hunaalikal mubtiloon"
  },
  {
    "id": 79,
    "text": "Allaahul lazee ja'ala lakumul an'aama litarkaboo minhaa wa minhaa taakuloon"
  },
  {
    "id": 80,
    "text": "Wa lakum feehaa manaafi'u wa litablughoo 'alaihaa haajatan fee sudoorikum wa 'alaihaa wa 'alal fulki tuhmaloon"
  },
  {
    "id": 81,
    "text": "Wa yureekum Aayaatihee fa ayya Aayaatil laahi tunkiroon"
  },
  {
    "id": 82,
    "text": "Afalam yaseeroo fil ardi fa yanzuroo kaifa kaana 'aaqibatul lazeena min qablihim; kaanoo aksara minhum wa ashadda quwwatanw wa aasaaran fil ardi famaaa aghnaa 'anhum maa kaanoo yaksiboon"
  },
  {
    "id": 83,
    "text": "Falammaa jaaa'at hum Rusuluhum bilbaiyinaati farihoo bimaa 'indahum minal 'ilmi wa haaqa bihim maa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 84,
    "text": "Falammaa ra aw baasanaa qaalooo aamannaa billaahi wahdahoo wa kafarnaa bimaa kunnaa bihee mushrikeen"
  },
  {
    "id": 85,
    "text": "Falam yaku yanfa 'uhum eemaanuhum lammaa ra-aw ba'sana sunnatal laahil latee qad khalat fee 'ibaadihee wa khasira hunaalikal kaafiroon"
  }
];

export default en;
