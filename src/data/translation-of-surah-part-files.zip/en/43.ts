import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Haa-Meeem"
  },
  {
    "id": 2,
    "text": "Wal Kitaabil Mubeen"
  },
  {
    "id": 3,
    "text": "Innaa ja'alnaahu Quraanan 'Arabiyyal la'allakum ta'qiloon"
  },
  {
    "id": 4,
    "text": "Wa innahoo feee Ummil Kitaabi Ladainaa la'aliyyun hakeem"
  },
  {
    "id": 5,
    "text": "Afa nadribu 'ankumuz Zikra safhan an kuntum qawman musrifeen"
  },
  {
    "id": 6,
    "text": "Wa kam arsalnaa min Nabiyyin fil awwaleen"
  },
  {
    "id": 7,
    "text": "Wa maa yaateehim min Nabiyyin illaa kaanoo bihee yastahzi'oon"
  },
  {
    "id": 8,
    "text": "Fa ahlaknaaa ashadda minhum batshanw wa madaa masalul awwaleen"
  },
  {
    "id": 9,
    "text": "Wa la'in sa altahum man khalaqas samaawaati wal arda la yaqoolunna khalaqa hunnal 'Azeezul 'Aleem"
  },
  {
    "id": 10,
    "text": "Allazee ja'ala lakumul arda mahdanw wa ja'ala lakum feehaa subulan la'allakum tahtadoon"
  },
  {
    "id": 11,
    "text": "Wallazee nazzala minas samaaa'i maaa'am biqadarin fa ansharnaa bihee baldatam maitaa' kazaalika tukhrajoon"
  },
  {
    "id": 12,
    "text": "Wallazee khalaqal azwaaja kullahaa wa ja'ala lakum minal fulki wal-an'aami maa tarkaboon"
  },
  {
    "id": 13,
    "text": "Litastawoo 'alaa zuhoorihee summa tazkuroo ni'mata Rabbikum izastawaitum 'alaihi wa taqooloo Subhaanal lazee sakhkhara lana haaza wa maa kunnaa lahoo muqrineen"
  },
  {
    "id": 14,
    "text": "Wa innaaa ilaa Rabbinaa lamunqaliboon"
  },
  {
    "id": 15,
    "text": "Wa ja'aloo lahoo min 'ibaadihee juz'aa; innal insaana la kafoorun mubeen"
  },
  {
    "id": 16,
    "text": "Amit takhaza mimmaa yakhluqu banaatinw wa asfaakum bilbaneen"
  },
  {
    "id": 17,
    "text": "Wa izaa bushshira ahaduhum bimaa daraba lir Rahmaani masalan zalla wajhuhoo muswaddanw wa huwa kazeem"
  },
  {
    "id": 18,
    "text": "Awa mai yunashsha'u fil hilyati wa huwa fil khisaami ghairu mubeen"
  },
  {
    "id": 19,
    "text": "Wa ja'alul malaaa'ikatal lazeena hum 'ibaadur Rahmaani inaasaa; 'a shahidoo khalqahum; satuktabu shahaadatuhum wa yus'aloon"
  },
  {
    "id": 20,
    "text": "Wa qaaloo law shaaa'ar Rahmaanu maa 'abadnaahum; maa lahum bizaalika min 'ilmin in hum illaa yakhrusoon"
  },
  {
    "id": 21,
    "text": "Am aatainaahum Kitaaban min qablihee fahum bihee mustamsikoon"
  },
  {
    "id": 22,
    "text": "Bal qaalooo innaa wajadnaaa aabaaa'anaa 'alaaa ummatinw wa innaa 'alaaa aasaarihim muhtadoon"
  },
  {
    "id": 23,
    "text": "Wa kazaalika maaa arsalnaa min qablika fee qaryatim min nazeerin illaa qaala mutrafoohaaa innaa wajadnaaa aabaaa'anaa 'alaaa ummatinw wa innaa 'alaaa aasaarihim muqtadoon"
  },
  {
    "id": 24,
    "text": "Qaala awa law ji'tukum bi ahdaa mimmaa wajatdtum 'alaihi aabaaa'akum qaalooo innaa bimaaa ursiltum bihee kaafiroon"
  },
  {
    "id": 25,
    "text": "Fantaqamnaa minhum fanzur kaifa kaana 'aaqibatul mukazzibeen"
  },
  {
    "id": 26,
    "text": "Wa iz qaala Ibraaheemu liabeehi wa qawmiheee innane baraaa'um mimmaa ta'budoon"
  },
  {
    "id": 27,
    "text": "Illal lazee fataranee fa innahoo sa yahdeen"
  },
  {
    "id": 28,
    "text": "Wa ja'alahaa kalimatan baaqiyatan fee 'aqibihee la 'allahum yarji'oon"
  },
  {
    "id": 29,
    "text": "Bal matta'tu haaa'ulaaa'i wa aabaaa'ahum hattaa jaaa'a humul haqqu wa Rasoolun mubeen"
  },
  {
    "id": 30,
    "text": "Wa lammaa jaaa'ahumul haqqu qaaloo haazaa sihrunw wa innaa bihee kaafiroon"
  },
  {
    "id": 31,
    "text": "Wa qaaloo law laa nuzzila haazal Quraanu 'alaa rajulin minal qaryataini 'azeem"
  },
  {
    "id": 32,
    "text": "'A hum yaqsimoona rahmata Rabbik; Nahnu qasamnaa bainahum ma'eeshatahum fil hayaatid dunyaa wa rafa'naa ba'dahum fawqa ba'din darajaatin li yattakhiza ba'duhum ba'dan sukhriyyaa; wa rahmatu Rabbika khairun mimmaa yajma'oon"
  },
  {
    "id": 33,
    "text": "Wa law laaa any yakoonan naasu ummatanw waahidatan laja'alnaa limany yakfuru bir Rahmaani li buyootihim suqufan min fiddatinw wa ma'aarija 'alaihaa yazharoon"
  },
  {
    "id": 34,
    "text": "Wa li buyootihim abwaabanw wa sururan 'alaihaa yattaki'oon"
  },
  {
    "id": 35,
    "text": "Wa zukhrufaa; wa in kullu zaalika lammaa mataa'ul hayaatid dunyaa; wal aakhiratu 'inda Rabbika lilmuttaqeen"
  },
  {
    "id": 36,
    "text": "Wa mai ya'shu 'an zikrir Rahmaani nuqaiyid lahoo Shaitaanan fahuwa lahoo qareen"
  },
  {
    "id": 37,
    "text": "Wa innahum la yasuddoo nahum 'anis sabeeli wa yahsaboona annahum muhtadoon"
  },
  {
    "id": 38,
    "text": "Hattaaa izaa jaaa'anaa qaala yaa laita bainee wa bainaka bu'dal mashriqaini fabi'sal qareen"
  },
  {
    "id": 39,
    "text": "Wa lai yanfa'akumul Yawma iz zalamtum annakum fil 'azaabi mushtarikoon"
  },
  {
    "id": 40,
    "text": "Afa anta tusmi'us summa aw tahdil 'umya wa man kaana fee dalaalin mubeen"
  },
  {
    "id": 41,
    "text": "Fa immaa nazhabanna bika fa innaa minhum muntaqimoon"
  },
  {
    "id": 42,
    "text": "Aw nuriyannakal lazee wa'adnaahum fa innaa 'alaihim muqtadiroon"
  },
  {
    "id": 43,
    "text": "Fastamsik billazeee oohiya ilaika innaka 'alaa Siraatin Mustaqeem"
  },
  {
    "id": 44,
    "text": "Wa innahoo la zikrun laka wa liqawmika wa sawfa tus'aloon"
  },
  {
    "id": 45,
    "text": "Was'al man arsalnaa min qablika mir Rusulinaaa 'a ja'alnaa min doonir Rahmaani aalihatany yu'badoon"
  },
  {
    "id": 46,
    "text": "Wa laqad arsalnaa Moosaa bi aayaatinaaa ilaa Fir'awna wa mala'ihee faqaala innee Rasoolu Rabbil 'aalameen"
  },
  {
    "id": 47,
    "text": "Falamma jaaa'ahum bi aayaatinaaa izaa hum minhaa yadhakoon"
  },
  {
    "id": 48,
    "text": "Wa maa nureehim min aayatin illaa hiya akbaru min ukhtihaa wa akhaznaahum bil'azaabi la'allahum yarji'oon"
  },
  {
    "id": 49,
    "text": "Wa qaaloo yaaa ayyuhas saahirud'u lanaa Rabbaka bimaa 'ahida 'indaka innanaa lamuhtadoon"
  },
  {
    "id": 50,
    "text": "Falammaa kashafnaa 'anhumul 'azaaba izaa hum yankusoon"
  },
  {
    "id": 51,
    "text": "Wa naadaa Fir'awnu fee qawmihee qaala yaa qawmi alaisa lee mulku Misra wa haazihil anhaaru tajree min tahtee afalaa tubsiroon"
  },
  {
    "id": 52,
    "text": "Am ana khairun min haazal lazee huwa maheenunw wa laa yakaadu yubeen"
  },
  {
    "id": 53,
    "text": "Falaw laa ulqiya 'alaihi aswiratun min zahabin aw jaaa'a ma'ahul malaaa'ikatu muqtarineen"
  },
  {
    "id": 54,
    "text": "Fastakhaffa qawmahoo fa ataa'ooh; innahum kaanoo qawman faasiqeen"
  },
  {
    "id": 55,
    "text": "Falammaaa aasafoonan taqamnaa minhum fa aghraqnaahum ajma'een"
  },
  {
    "id": 56,
    "text": "Faja'alnaahum salafanw wa masalan lil aakhireen"
  },
  {
    "id": 57,
    "text": "Wa lammaa duribab nu Maryama masalan izaa qawmuka minhu yasiddoon"
  },
  {
    "id": 58,
    "text": "Wa qaalooo 'a-aalihatunaa khairun am hoo; maa daraboohu laka illaa jadalaa; balhum qawmun khasimoon"
  },
  {
    "id": 59,
    "text": "In huwa illaa 'abdun an'amnaa 'alaihi wa ja'alnaahu masalan li Baneee Israaa'eel"
  },
  {
    "id": 60,
    "text": "Wa law nashaaa'u laja'alnaa minkum malaaa'ikatan fil ardi yakhlufoon"
  },
  {
    "id": 61,
    "text": "Wa innahoo la 'ilmun lis Saa'ati fa laa tamtarunna bihaa wattabi'oon; haazaa Siraatun Mustaqeem"
  },
  {
    "id": 62,
    "text": "Wa laa yasuddan nakumush Shaitaanu innahoo lakum 'aduwwun mubeen"
  },
  {
    "id": 63,
    "text": "Wa lammaa jaaa'a 'Eesaa bilbaiyinaati qaala qad ji'tukum bil Hikmati wa li-ubaiyina lakum ba'dal lazee takhtalifoona feehi fattaqul laaha wa atee'oon"
  },
  {
    "id": 64,
    "text": "Innal laaha Huwa Rabbee wa Rabbukum fa'budooh; haaza Siraatum Mustaqeem"
  },
  {
    "id": 65,
    "text": "Fakhtalafal ahzaabu min bainihim fa wailun lil lazeena zalamoo min 'azaabi Yawmin aleem"
  },
  {
    "id": 66,
    "text": "Hal yanzuroona illas Saa'ata an ta'tiyahum baghtatanw wa hum laa yash'uroon"
  },
  {
    "id": 67,
    "text": "Al akhillaaa'u Yawma'izin ba'duhum liba'din 'aduwwun illal muttaqeen"
  },
  {
    "id": 68,
    "text": "Yaa 'ibaadi laa khawfun 'alaikumul Yawma wa laaa antum tahzanoon"
  },
  {
    "id": 69,
    "text": "Allazeena aamanoo bi Aayaatinaa wa kaanoo muslimeen"
  },
  {
    "id": 70,
    "text": "Udkhulul Jannata antum wa azwaajukum tuhbaroon"
  },
  {
    "id": 71,
    "text": "Yutaafu 'alaihim bisihaa fim min zahabinw wa akwaab, wa feehaa maatashtaheehil anfusu wa talazzul a'yunu wa antum feehaa khaalidoon"
  },
  {
    "id": 72,
    "text": "Wa tilkal jannatul lateee ooristumoohaa bimaa kuntum ta'maloon"
  },
  {
    "id": 73,
    "text": "Lakum feehaa faakihatun kaseeratun minhaa ta'kuloon"
  },
  {
    "id": 74,
    "text": "Innal mujrimeena fee 'azaabi jahannama khaalidoon"
  },
  {
    "id": 75,
    "text": "Laa yufattaru 'anhum wa hum feehi mublisoon"
  },
  {
    "id": 76,
    "text": "Wa maa zalamnaahum wa laakin kaanoo humuz zaalimeen"
  },
  {
    "id": 77,
    "text": "Wa naadaw yaa Maaliku liyaqdi 'alainaa Rabbuka qaala innakum maakithoon"
  },
  {
    "id": 78,
    "text": "Laqad ji'naakum bilhaqqi wa laakinna aksarakum lil haqqi kaarihoon"
  },
  {
    "id": 79,
    "text": "Am abramooo amran fainnaa mubrimoon"
  },
  {
    "id": 80,
    "text": "Am yahsaboona annaa laa nasma'u sirrahum wa najwaahum; balaa wa Rusulunaa ladaihim yaktuboon"
  },
  {
    "id": 81,
    "text": "Qul in kaana lir Rahmaani walad; fa-ana awwalul 'aabideen"
  },
  {
    "id": 82,
    "text": "Subhaana Rabbis samaawaati wal ardi Rabbil Arshi 'ammaa yasifoon"
  },
  {
    "id": 83,
    "text": "Fazarhum yakhoodoo wa yal'aboo hattaa yulaaqoo Yawmahumul lazee yoo'adoon"
  },
  {
    "id": 84,
    "text": "Wa Huwal lazee fissamaaa'i ilaahunw wa fil ardi ilaah; wa Huwal Hakeemul 'Aleem"
  },
  {
    "id": 85,
    "text": "Wa tabaarakal lazee lahoo mulkus samaawaati wal ardi wa maa bainahumaa wa 'indahoo 'ilmus Saa'ati wa ilaihi turja'oon"
  },
  {
    "id": 86,
    "text": "Wa laa yamlikul lazeena yad'oona min doonihish shafaa'ata illaa man shahida bilhaqqi wa hum ya'lamoon"
  },
  {
    "id": 87,
    "text": "Wa la'in sa altahum man khalaqahum la yaqoolun nallaahu fa annaa yu'fakoon"
  },
  {
    "id": 88,
    "text": "Wa qeelihee yaa Rabbi inna haaa'ulaaa'i qawmul laa yu'minoon"
  },
  {
    "id": 89,
    "text": "Fasfah 'anhum wa qul salaam; fasawfa ya'lamoon"
  }
];

export default en;
