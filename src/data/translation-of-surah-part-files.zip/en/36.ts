import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Yaa-Seeen"
  },
  {
    "id": 2,
    "text": "Wal-Qur-aanil-Hakeem"
  },
  {
    "id": 3,
    "text": "Innaka laminal mursaleen"
  },
  {
    "id": 4,
    "text": "'Alaa Siraatim Mustaqeem"
  },
  {
    "id": 5,
    "text": "Tanzeelal 'Azeezir Raheem"
  },
  {
    "id": 6,
    "text": "Litunzira qawmam maaa unzira aabaaa'uhum fahum ghaafiloon"
  },
  {
    "id": 7,
    "text": "Laqad haqqal qawlu 'alaaa aksarihim fahum laa yu'minoon"
  },
  {
    "id": 8,
    "text": "Innaa ja'alnaa feee a'naaqihim aghlaalan fahiya ilal azqaani fahum muqmahoon"
  },
  {
    "id": 9,
    "text": "Wa ja'alnaa min baini aydeehim saddanw-wa min khalfihim saddan fa aghshai naahum fahum laa yubsiroon"
  },
  {
    "id": 10,
    "text": "Wa sawaaa'un 'alaihim 'a-anzartahum am lam tunzirhum laa yu'minoon"
  },
  {
    "id": 11,
    "text": "Innamaa tunziru manit taba 'az-Zikra wa khashiyar Rahmaana bilghaib, fabashshirhu bimaghfiratinw-wa ajrin kareem"
  },
  {
    "id": 12,
    "text": "Innaa Nahnu nuhyil mawtaa wa naktubu maa qaddamoo wa aasaarahum; wa kulla shai'in ahsainaahu feee Imaamim Mubeen"
  },
  {
    "id": 13,
    "text": "Wadrib lahum masalan Ashaabal Qaryatih; iz jaaa'ahal mursaloon"
  },
  {
    "id": 14,
    "text": "Iz arsalnaaa ilaihimusnaini fakazzaboohumaa fa'azzaznaa bisaalisin faqaalooo innaaa ilaikum mursaloon"
  },
  {
    "id": 15,
    "text": "Qaaloo maaa antum illaa basharum mislunaa wa maaa anzalar Rahmaanu min shai'in in antum illaa takziboon"
  },
  {
    "id": 16,
    "text": "Qaaloo Rabbunaa ya'lamu innaaa ilaikum lamursaloon"
  },
  {
    "id": 17,
    "text": "Wa maa 'alainaaa illal balaaghul mubeen"
  },
  {
    "id": 18,
    "text": "Qaaloo innaa tataiyarnaa bikum la'il-lam tantahoo lanar jumannakum wa la-yamassan nakum minnaa 'azaabun aleem"
  },
  {
    "id": 19,
    "text": "Qaaloo taaa'irukum ma'akum; a'in zukkirtum; bal antum qawmum musrifoon"
  },
  {
    "id": 20,
    "text": "Wa jaaa'a min aqsal madeenati rajuluny yas'aa qaala yaa qawmit tabi'ul mursaleen"
  },
  {
    "id": 21,
    "text": "Ittabi'oo mal-laa yas'alukum ajranw-wa hum muhtadoon"
  },
  {
    "id": 22,
    "text": "Wa maa liya laaa a'budul lazee fataranee wa ilaihi turja'oon"
  },
  {
    "id": 23,
    "text": "'A-attakhizu min dooniheee aalihatan iny-yuridnir Rahmaanu bidurril-laa tughni 'annee shafaa 'atuhum shai 'anw-wa laa yunqizoon"
  },
  {
    "id": 24,
    "text": "Inneee izal-lafee dalaa-lim-mubeen"
  },
  {
    "id": 25,
    "text": "Inneee aamantu bi Rabbikum fasma'oon"
  },
  {
    "id": 26,
    "text": "Qeelad khulil Jannnah; qaala yaa laita qawmee ya'lamoon"
  },
  {
    "id": 27,
    "text": "Bimaa ghafara lee Rabbee wa ja'alanee minal mukrameen"
  },
  {
    "id": 28,
    "text": "Wa maaa anzalnaa 'alaa qawmihee mim ba'dihee min jundim minas-samaaa'i wa maa kunnaa munzileen"
  },
  {
    "id": 29,
    "text": "In kaanat illaa saihatanw waahidatan fa-izaa hum khaamidoon"
  },
  {
    "id": 30,
    "text": "Yaa hasratan 'alal 'ibaaad; maa ya'teehim mir Rasoolin illaa kaanoo bihee yastahzi 'oon"
  },
  {
    "id": 31,
    "text": "Alam yaraw kam ahlak naa qablahum minal qurooni annahum ilaihim laa yarji'oon"
  },
  {
    "id": 32,
    "text": "Wa in kullul lammaa jamee'ul-ladainaa muhdaroon"
  },
  {
    "id": 33,
    "text": "Wa Aayatul lahumul ardul maitatu ahyainaahaa wa akhrajnaa minhaa habban faminhu ya'kuloon"
  },
  {
    "id": 34,
    "text": "Wa ja'alnaa feehaa jannaatim min nakheelinw wa a'naabinw wa fajjarnaa feeha minal 'uyoon"
  },
  {
    "id": 35,
    "text": "Li ya'kuloo min samarihee wa maa 'amilat-hu aideehim; afalaa yashkuroon"
  },
  {
    "id": 36,
    "text": "Subhaanal lazee khalaqal azwaaja kullahaa mimmaa tumbitul ardu wa min anfusihim wa mimmaa laa ya'lamoon"
  },
  {
    "id": 37,
    "text": "Wa Aayatul lahumul lailu naslakhu minhun nahaara fa-izaa hum muzlimoon"
  },
  {
    "id": 38,
    "text": "Wash-shamsu tajree limustaqarril lahaa; zaalika taqdeerul 'Azeezil Aleem"
  },
  {
    "id": 39,
    "text": "Walqamara qaddarnaahu manaazila hattaa 'aada kal'ur joonil qadeem"
  },
  {
    "id": 40,
    "text": "Lash shamsu yambaghee lahaaa an tudrikal qamara walal lailu saabiqun nahaar; wa kullun fee falaki yasbahoon"
  },
  {
    "id": 41,
    "text": "Wa Aayatul lahum annaa hamalnaa zurriyatahum fil fulkil mashhoon"
  },
  {
    "id": 42,
    "text": "Wa khalaqnaa lahum mim-mislihee maa yarkaboon"
  },
  {
    "id": 43,
    "text": "Wa in nashaa nughriqhum falaa sareekha lahum wa laa hum yunqazoon"
  },
  {
    "id": 44,
    "text": "Illaa rahmatam minnaa wa mataa'an ilaa heen"
  },
  {
    "id": 45,
    "text": "Wa izaa qeela lahumuttaqoo maa baina aideekum wa maa khalfakum la'allakum turhamoon"
  },
  {
    "id": 46,
    "text": "Wa maa ta'teehim min aayatim min Aayaati Rabbihim illaa kaanoo 'anhaa mu'rideen"
  },
  {
    "id": 47,
    "text": "Wa izaa qeela lahum anfiqoo mimmaa razaqakumul laahu qaalal lazeena kafaroo lillazeena aamanooo anut'imu mal-law yashaaa'ul laahu at'amahooo in antum illaa fee dalaalim mubeen"
  },
  {
    "id": 48,
    "text": "Wa yaqooloona mataa haazal wa'du in kuntum saadiqeen"
  },
  {
    "id": 49,
    "text": "Maa yanzuroona illaa saihatanw waahidatan ta'khuzuhum wa hum yakhissimoon"
  },
  {
    "id": 50,
    "text": "Falaa yastatee'oona taw siyatanw-wa laaa ilaaa ahlihim yarji'oon"
  },
  {
    "id": 51,
    "text": "Wa nufikha fis-soori faizaa hum minal ajdaasi ilaa Rabbihim yansiloon"
  },
  {
    "id": 52,
    "text": "Qaaloo yaa wailanaa mam ba'asanaa mim marqadinaa; haaza maa wa'adar Rahmanu wa sadaqal mursaloon"
  },
  {
    "id": 53,
    "text": "In kaanat illaa saihatanw waahidatan fa-izaa hum jamee'ul ladainaa muhdaroon"
  },
  {
    "id": 54,
    "text": "Fal-Yawma laa tuzlamu nafsun shai'anw-wa laa tujzawna illaa maa kuntum ta'maloon"
  },
  {
    "id": 55,
    "text": "Inna Ashaabal jannatil Yawma fee shughulin faakihoon"
  },
  {
    "id": 56,
    "text": "Hum wa azwaajuhum fee zilaalin 'alal araaa'iki muttaki'oon"
  },
  {
    "id": 57,
    "text": "Lahum feehaa faakiha tunw-wa lahum maa yadda'oon"
  },
  {
    "id": 58,
    "text": "Salaamun qawlam mir Rabbir Raheem"
  },
  {
    "id": 59,
    "text": "Wamtaazul Yawma ayyuhal mujrimoon"
  },
  {
    "id": 60,
    "text": "Alam a'had ilaikum yaa Baneee Aadama al-laa ta'budush Shaitaana innahoo lakum 'aduwwum mubeen"
  },
  {
    "id": 61,
    "text": "Wa ani'budoonee; haazaa Siraatum Mustaqeem"
  },
  {
    "id": 62,
    "text": "Wa laqad adalla minkum jibillan kaseeraa; afalam takoonoo ta'qiloon"
  },
  {
    "id": 63,
    "text": "Haazihee Jahannamul latee kuntum too'adoon"
  },
  {
    "id": 64,
    "text": "Islawhal Yawma bimaa kuntum takfuroon"
  },
  {
    "id": 65,
    "text": "Al-Yawma nakhtimu 'alaaa afwaahihim wa tukallimunaaa aideehim wa tashhadu arjuluhum bimaa kaanoo yaksiboon"
  },
  {
    "id": 66,
    "text": "Wa law nashaaa'u lata masna 'alaaa aiyunihim fasta baqus-siraata fa-annaa yubsiroon"
  },
  {
    "id": 67,
    "text": "Wa law nashaaa'u lamasakhnaahum 'alaa makaanatihim famas-tataa'oo mudiyyanw-wa laa yarji'oon"
  },
  {
    "id": 68,
    "text": "Wa man nu 'ammirhu nunakkishu fil-khalq; afalaa ya'qiloon"
  },
  {
    "id": 69,
    "text": "Wa maa 'allamnaahush shi'ra wa maa yambaghee lah; in huwa illaa zikrunw-wa Qur- aanum mubeen"
  },
  {
    "id": 70,
    "text": "Liyunzira man kaana haiyanw-wa yahiqqal qawlu 'alal-kaafireen"
  },
  {
    "id": 71,
    "text": "Awalam yaraw annaa khalaqnaa lahum mimmaa 'amilat aideenaaa an'aaman fahum lahaa maalikoon"
  },
  {
    "id": 72,
    "text": "Wa zallalnaahaa lahum faminhaa rakoobuhum wa minhaa ya'kuloon"
  },
  {
    "id": 73,
    "text": "Wa lahum feehaa manaa fi'u wa mashaarib; afalaa yashkuroon"
  },
  {
    "id": 74,
    "text": "Wattakhazoo min doonil laahi aalihatal la'allahum yunsaroon"
  },
  {
    "id": 75,
    "text": "Laa yastatee'oona nasrahum wa hum lahum jundum muhdaroon"
  },
  {
    "id": 76,
    "text": "Falaa yahzunka qawluhum; innaa na'lamu maa yusirroona wa maa yu'linoon"
  },
  {
    "id": 77,
    "text": "Awalam yaral insaanu annaa khalaqnaahu min nutfatin fa-izaa huwa khaseemum mubeen"
  },
  {
    "id": 78,
    "text": "Wa daraba lanaa maslanw-wa nasiya khalqahoo qaala mai-yuhyil'izaama wa hiya rameem"
  },
  {
    "id": 79,
    "text": "Qul yuh yeehal lazeee ansha ahaaa awwala marrah; wa Huwa bikulli khalqin 'Aleem"
  },
  {
    "id": 80,
    "text": "Allazee ja'ala lakum minash shajaril akhdari naaran fa-izaaa antum minhu tooqidoon"
  },
  {
    "id": 81,
    "text": "Awa laisal lazee khalaqas samaawaati wal arda biqaadirin 'alaaa ai-yakhluqa mislahum; balaa wa Huwal Khallaaqul 'Aleem"
  },
  {
    "id": 82,
    "text": "Innamaa amruhooo izaaa araada shai'an ai-yaqoola lahoo kun fa-yakoon"
  },
  {
    "id": 83,
    "text": "Fa Subhaanal lazee biyadihee malakootu kulli shai-inw-wa ilaihi turja'oon"
  }
];

export default en;
