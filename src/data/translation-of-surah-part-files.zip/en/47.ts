import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Allazeena kafaroo wa saddoo'an sabeelil laahi adalla a'maalahum"
  },
  {
    "id": 2,
    "text": "Wallazeena aamanoo wa 'amilus saalihaati wa aamanoo bimaa nuzzila 'alaa Muhammadinw-wa huwal haqqu mir Rabbihim kaffara 'anhum saiyiaatihim wa aslaha baalahum"
  },
  {
    "id": 3,
    "text": "Zaalika bi annal lazeena kafarut taba'ul baatila wa annal lazeena aamanut taba'ul haqqa mir Rabbihim; kazaalika yadribul laahu linnaasi amsaalahum"
  },
  {
    "id": 4,
    "text": "Fa-izaa laqeetumul lazeena kafaroo fadarbar riqaabi, hattaaa izaa askhan tumoohum fashuddul wasaaqa, fa immaa mannnam ba'du wa immaa fidaaa'an hattaa tada'al harbu awzaarahaa; zaalika wa law yashaaa'ul laahu lantasara minhum wa laakin li yabluwa ba'dakum bi ba'd; wallazeena qutiloo fee sabeelil laahi falany yudilla a'maalahum"
  },
  {
    "id": 5,
    "text": "Sa-yahdeehim wa yuslihu baalahum"
  },
  {
    "id": 6,
    "text": "Wa yudkhiluhumul jannata 'arrafahaa lahum"
  },
  {
    "id": 7,
    "text": "Yaaa ayyuhal lazeena aamanooo in tansurul laaha yansurkum wa yusabbit aqdaamakum"
  },
  {
    "id": 8,
    "text": "Wallazeena kafaroo fata' sal lahum wa adalla a'maalahum"
  },
  {
    "id": 9,
    "text": "Zaalika bi annahum karihoo maaa anzal allaahu fa ahbata a'maalahum"
  },
  {
    "id": 10,
    "text": "Afalam yaseeroo fil ardi fayanzuroo kaifa kaana 'aaqibatul lazeena min qablihim; dammaral laahu 'alaihim wa lilkaafireena amsaaluhaa"
  },
  {
    "id": 11,
    "text": "Zaalika bi annal laaha mawlal lazeena aamanoo wa annal kaafireena laa mawlaa lahum"
  },
  {
    "id": 12,
    "text": "Innal-laaha yudkhilul lazeena aamanoo wa 'amilus saalihaati Jannaatin tajree min tahtihal anhaaru wallazeena kafaroo yatamatta'oona wa ya'kuloona kamaa ta'kulul an'aamu wan Naaru maswan lahum"
  },
  {
    "id": 13,
    "text": "Wa ka ayyim min qaryatin hiya ashaddu quwwatam min qaryatikal lateee akhrajatka ahlaknaahum falaa naasira lahum"
  },
  {
    "id": 14,
    "text": "Afaman kaana 'alaa baiyinatim mir Rabbihee kaman zuyyina lahoo sooo'u 'amalihee wattaba'ooo ahwaaa'ahum"
  },
  {
    "id": 15,
    "text": "Masalul jannatil latee wu'idal muttaqoona feehaaa anhaarum min maaa'in ghayri aasininw wa anhaarum mil labanil lam yataghaiyar ta'muhoo wa anhaarum min khamril lazzatin li shaaribeena wa anhaarum min 'asalim musaffanw wa lahum feeha min kullis samaraati wa maghfiratum mir Rabbihim kaman huwa khaalidun fin naari wa suqoo maaa'an hameeman faqatta'a am'aaa'ahum"
  },
  {
    "id": 16,
    "text": "Wa minhum mai yastami'u ilaika hattaaa izaa kharajoo min 'indika qaaloo lil lazeena ootul 'ilma maazaa qaala aanifaa; ulaaa'ikal lazeena taba'al laahu 'alaa quloobihim wattaba'ooo ahwaaa'ahum"
  },
  {
    "id": 17,
    "text": "Wallazeenah tadaw zaadahum hudanw wa aataahum taqwaahum"
  },
  {
    "id": 18,
    "text": "Fahal yanzuroona illas Saa'ata an ta'tiyahum baghtatan faqad jaaa'a ashraatuhaa; fa annaa lahum izaa jaaa'at hum zikraahum"
  },
  {
    "id": 19,
    "text": "Fa'lam annahoo laaa ilaaha illal laahu wastaghfir lizambika wa lilmu'mineena walmu'minaat; wallaahu ya'lamu mutaqallabakum wa maswaakum"
  },
  {
    "id": 20,
    "text": "Wa yaqoolul lazeena aamanoo law laa nuzzilat Sooratun fa izaaa unzilat Sooratum Muhkamatunw wa zukira feehal qitaalu ra aytal lazeena fee quloobihim maraduny yanzuroona ilaika nazaral maghshiyyi 'alaihi minal mawti fa'awlaa lahum"
  },
  {
    "id": 21,
    "text": "Taa'atunw wa qawlum ma'roof; fa izaa 'azamal amru falaw sadaqul laaha lakaana khairal lahum"
  },
  {
    "id": 22,
    "text": "Fahal 'asaitum in tawallaitum an tufsidoo fil ardi wa tuqatti'ooo arhaamakum"
  },
  {
    "id": 23,
    "text": "Ulaaa'ikal lazeena la'anahumul laahu fa asammahum wa a'maaa absaarahum"
  },
  {
    "id": 24,
    "text": "Afalaa yatadabbaroonal Qur-aana am 'alaa quloobin aqfaaluhaa"
  },
  {
    "id": 25,
    "text": "Innal lazeenar taddoo 'alaaa adbaarihim min ba'di maa tabaiyana lahumul hudash Shaitaanu sawwala lahum wa amlaa lahum"
  },
  {
    "id": 26,
    "text": "Zaalika bi annahum qaaloo lillazeena karihoo maa nazzalal laahu sanutee'ukum fee ba'dil amri wallaahu ya'lamu israarahum"
  },
  {
    "id": 27,
    "text": "Fakaifa izaa tawaffat humul malaaa'ikatu yadriboona wujoohahum wa adbaa rahum"
  },
  {
    "id": 28,
    "text": "Zaalika bi annahumut taba'oo maaa askhatal laaha wa karihoo ridwaanahoo fa ahbata a'maalahum"
  },
  {
    "id": 29,
    "text": "Am hasibal lazeena fee quloobihim maradun al lany yukhrijal laahu adghaanahum"
  },
  {
    "id": 30,
    "text": "Wa law nashaaa'u la-arainaakahum fala 'araftahum bi seemaahum; wa lata'rifan nahum fee lahnil qawl; wallaahu ya'lamu a'maalakum"
  },
  {
    "id": 31,
    "text": "Wa lanabluwannakum hattaa na'lamal mujaahideena minkum wassaabireena wa nabluwa akhbaarakum"
  },
  {
    "id": 32,
    "text": "Innal lazeena kafaroo wa saddoo 'an sabeelil laahi wa shaaaqqur Rasoola min ba'di maa tabaiyana lahumul hudaa lany yadurrul laaha shai'anw wa sa yuhbitu a'maalahum"
  },
  {
    "id": 33,
    "text": "Yaaa ayyuhal lazeena aamanoo atee'ul laaha wa atee'ur Rasoola wa laa tubtilooo a'maalakum"
  },
  {
    "id": 34,
    "text": "Innal lazeena kafaroo wa saddoo 'an sabeelil laahi summa maatoo wa hum kuffaarun falany yaghfirallaahu lahum"
  },
  {
    "id": 35,
    "text": "Falaa tahinoo wa tad'ooo ilas salmi wa antumul a'lawna wallaahu ma'akum wa lany yatirakum a'maalakum"
  },
  {
    "id": 36,
    "text": "Innamal hayaatud dunyaa la'ibunw wa lahw; wa in tu'minoo wa tattaqoo yu'tikum ujoorakum wa laa yas'alkum amwaalakum"
  },
  {
    "id": 37,
    "text": "Iny yas'alkumoohaa fa yuhfikum tabkhaloo wa yukhrij adghaanakum"
  },
  {
    "id": 38,
    "text": "Haaa antum haaa'ulaaa'i tud'awna litunfiqoo fee sabeelillaahi faminkum many yabkhalu wa many yabkhal fa innamaa yabkhalu 'an nafsih; wallaahu Ghaniyyu wa antumul fuqaraaa'; wa in tatawallaw yastabdil qawman ghairakum summa laa yakoonooo amsaalakum"
  }
];

export default en;
