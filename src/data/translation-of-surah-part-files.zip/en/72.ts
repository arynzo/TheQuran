import type { TranslationType } from "./type";

const en: TranslationType[] = [
  {
    "id": 1,
    "text": "Qul oohiya ilaiya annna hustama'a nafarum minal jinni faqaalooo innaa sami'naa quraanan ajaba"
  },
  {
    "id": 2,
    "text": "Yahdeee ilar rushdi fa aamannaa bihee wa lan nushrika bi rabbinaaa 'ahada"
  },
  {
    "id": 3,
    "text": "Wa annahoo Ta'aalaa jaddu Rabbinaa mat'takhaza saahibatanw wa laa walada"
  },
  {
    "id": 4,
    "text": "Wa annahoo kaana yaqoolu safeehunaa 'al allahi shatata"
  },
  {
    "id": 5,
    "text": "Wa annaa zanannaaa al lan taqoolal insu wal jinnu 'al allahi kaziba"
  },
  {
    "id": 6,
    "text": "Wa annahoo kaana rijaalum minal insi ya'oozoona bi rijaalim minal jinni fa zaadoohum rahaqa"
  },
  {
    "id": 7,
    "text": "Wa annahum zannoo kamaa zanantum al lany yab'asal laahu 'ahada"
  },
  {
    "id": 8,
    "text": "Wa annaa lamasnas samaaa'a fa wajadnaahaa muli'at harasan shadeedanw wa shuhuba"
  },
  {
    "id": 9,
    "text": "Wa annaa kunnaa naq'udu minhaa maqaa'ida lis'sam'i famany yastami'il 'aana yajid lahoo shihaabar rasada"
  },
  {
    "id": 10,
    "text": "Wa annaa laa nadreee asharrun ureeda biman fil ardi 'am 'araada bihim rabbuhum rashada"
  },
  {
    "id": 11,
    "text": "Wa annaa minnas saalihoona wa minnaa doona zaalika kunnaa taraaa'iqa qidada"
  },
  {
    "id": 12,
    "text": "Wa annaa zanan naaa al lan nu'jizal laaha fil ardi wa lan nu'jizahoo haraba"
  },
  {
    "id": 13,
    "text": "Wa annaa lammaa sami'nal hudaaa aamannaa bihee famany yu'min bi rabbihee falaa yakhaafu bakhsanw wa laa rahaqa"
  },
  {
    "id": 14,
    "text": "Wa annaa minnal muslimoona wa minnal qaasitoona faman aslama fa ulaaa'ika taharraw rashada"
  },
  {
    "id": 15,
    "text": "Wa ammal qaasitoona fa kaanoo li jahannama hataba"
  },
  {
    "id": 16,
    "text": "Wa alla wis taqaamoo 'alat tareeqati la asqaynaahum maa'an ghadaqa"
  },
  {
    "id": 17,
    "text": "Linaftinahum feeh; wa many yu'rid 'an zikri rabbihee yasluk hu 'azaaban sa'ada"
  },
  {
    "id": 18,
    "text": "Wa annal masaajida lil laahi falaa tad'oo ma'al laahi 'ahada"
  },
  {
    "id": 19,
    "text": "Wa annahoo lammaa qaama 'abdul laahi yad'oohu kaadoo yakoonoona 'alaihi libada"
  },
  {
    "id": 20,
    "text": "Qul innamaaa ad'oo rabbee wa laaa ushriku biheee 'ahada"
  },
  {
    "id": 21,
    "text": "Qul innee laaa amliku lakum darranw wa laa rashada"
  },
  {
    "id": 22,
    "text": "Qul innee lany yujeeranee minal laahi 'ahadunw, wa lan ajida min doonihee multahada"
  },
  {
    "id": 23,
    "text": "Illaa balaagham minal laahi wa risaalaatih; wa many ya'sil laaha wa rasoolahoo fa inna lahoo naara jahannama khaalideena feehaaa 'abada"
  },
  {
    "id": 24,
    "text": "Hattaaa izaa ra aw maa yoo'adoona fasaya'lamoona man ad'afu naasiranw wa aqallu 'adada"
  },
  {
    "id": 25,
    "text": "Qul in adreee a qareebum maa too'adoona am yaj'alu lahoo rabbeee 'amada"
  },
  {
    "id": 26,
    "text": "'Aalimul ghaibi falaa yuzhiru alaa ghaibiheee 'ahada"
  },
  {
    "id": 27,
    "text": "Illaa manir tadaa mir rasoolin fa innahoo yasluku min baini yadaihi wa min khalfihee rasada"
  },
  {
    "id": 28,
    "text": "Liya'lama an qad ablaghoo risaalaati rabbihim wa ahaata bi maa ladaihim wa ahsaa kulla shai'in 'adada"
  }
];

export default en;
