import type { TranslationType } from "./type";

const ar: TranslationType[] = [
  {
    "id": 1,
    "text": "لِإِيلَٰفِ قُرَيۡشٍ"
  },
  {
    "id": 2,
    "text": "إِۦلَٰفِهِمۡ رِحۡلَةَ ٱلشِّتَآءِ وَٱلصَّيۡفِ"
  },
  {
    "id": 3,
    "text": "فَلۡيَعۡبُدُواْ رَبَّ هَٰذَا ٱلۡبَيۡتِ"
  },
  {
    "id": 4,
    "text": "ٱلَّذِيٓ أَطۡعَمَهُم مِّن جُوعٖ وَءَامَنَهُم مِّنۡ خَوۡفِۭ"
  }
];

export default ar;
