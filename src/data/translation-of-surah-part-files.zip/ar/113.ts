import type { TranslationType } from "./type";

const ar: TranslationType[] = [
  {
    "id": 1,
    "text": "قُلۡ أَعُوذُ بِرَبِّ ٱلۡفَلَقِ"
  },
  {
    "id": 2,
    "text": "مِن شَرِّ مَا خَلَقَ"
  },
  {
    "id": 3,
    "text": "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ"
  },
  {
    "id": 4,
    "text": "وَمِن شَرِّ ٱلنَّفَّـٰثَٰتِ فِي ٱلۡعُقَدِ"
  },
  {
    "id": 5,
    "text": "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ"
  }
];

export default ar;
