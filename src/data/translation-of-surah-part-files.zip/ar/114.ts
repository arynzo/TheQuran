import type { TranslationType } from "./type";

const ar: TranslationType[] = [
  {
    "id": 1,
    "text": "قُلۡ أَعُوذُ بِرَبِّ ٱلنَّاسِ"
  },
  {
    "id": 2,
    "text": "مَلِكِ ٱلنَّاسِ"
  },
  {
    "id": 3,
    "text": "إِلَٰهِ ٱلنَّاسِ"
  },
  {
    "id": 4,
    "text": "مِن شَرِّ ٱلۡوَسۡوَاسِ ٱلۡخَنَّاسِ"
  },
  {
    "id": 5,
    "text": "ٱلَّذِي يُوَسۡوِسُ فِي صُدُورِ ٱلنَّاسِ"
  },
  {
    "id": 6,
    "text": "مِنَ ٱلۡجِنَّةِ وَٱلنَّاسِ"
  }
];

export default ar;
