import type { TranslationType } from "./type";

const ar: TranslationType[] = [
  {
    "id": 1,
    "text": "وَٱلۡعَصۡرِ"
  },
  {
    "id": 2,
    "text": "إِنَّ ٱلۡإِنسَٰنَ لَفِي خُسۡرٍ"
  },
  {
    "id": 3,
    "text": "إِلَّا ٱلَّذِينَ ءَامَنُواْ وَعَمِلُواْ ٱلصَّـٰلِحَٰتِ وَتَوَاصَوۡاْ بِٱلۡحَقِّ وَتَوَاصَوۡاْ بِٱلصَّبۡرِ"
  }
];

export default ar;
