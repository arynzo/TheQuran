import type { TranslationType } from "./type";

const ar: TranslationType[] = [
  {
    "id": 1,
    "text": "قُلۡ هُوَ ٱللَّهُ أَحَدٌ"
  },
  {
    "id": 2,
    "text": "ٱللَّهُ ٱلصَّمَدُ"
  },
  {
    "id": 3,
    "text": "لَمۡ يَلِدۡ وَلَمۡ يُولَدۡ"
  },
  {
    "id": 4,
    "text": "وَلَمۡ يَكُن لَّهُۥ كُفُوًا أَحَدُۢ"
  }
];

export default ar;
