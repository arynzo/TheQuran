import type { meanType } from "./type";

const bn: meanType[] = [
  {
    id: 1,
    text: "নিশ্চয় আমি আপনাকে কাওসার দান করেছি।",
  },
  {
    id: 2,
    text: "অতএব আপনার পালনকর্তার উদ্দেশ্যে নামায পড়ুন এবং কোরবানী করুন।",
  },
  {
    id: 3,
    text: "যে আপনার শত্রু, সেই তো লেজকাটা, নির্বংশ।",
  },
];

export default bn;
