import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Those who disbelieved among the People of the Scripture and the polytheists were not to be parted [from misbelief] until there came to them clear evidence"
  },
  {
    "id": 2,
    "text": "A Messenger from Allah, reciting purified scriptures"
  },
  {
    "id": 3,
    "text": "Within which are correct writings"
  },
  {
    "id": 4,
    "text": "Nor did those who were given the Scripture become divided until after there had come to them clear evidence"
  },
  {
    "id": 5,
    "text": "And they were not commanded except to worship Allah, [being] sincere to Him in religion, inclining to truth, and to establish prayer and to give zakah. And that is the correct religion"
  },
  {
    "id": 6,
    "text": "Indeed, they who disbelieved among the People of the Scripture and the polytheists will be in the fire of Hell, abiding eternally therein. Those are the worst of creatures"
  },
  {
    "id": 7,
    "text": "Indeed, they who have believed and done righteous deeds - those are the best of creatures"
  },
  {
    "id": 8,
    "text": "Their reward with Allah will be gardens of perpetual residence beneath which rivers flow, wherein they will abide forever, Allah being pleased with them and they with Him. That is for whoever has feared his Lord"
  }
]

export default en
