import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Alif, Lam, Ra. These are the verses of the wise Book"
  },
  {
    "id": 2,
    "text": "Have the people been amazed that We revealed [revelation] to a man from among them, [saying], \"Warn mankind and give good tidings to those who believe that they will have a [firm] precedence of honor with their Lord\"? [But] the disbelievers say, \"Indeed, this is an obvious magician"
  },
  {
    "id": 3,
    "text": "Indeed, your Lord is Allah, who created the heavens and the earth in six days and then established Himself above the Throne, arranging the matter [of His creation]. There is no intercessor except after His permission. That is Allah, your Lord, so worship Him. Then will you not remember"
  },
  {
    "id": 4,
    "text": "To Him is your return all together. [It is] the promise of Allah [which is] truth. Indeed, He begins the [process of] creation and then repeats it that He may reward those who have believed and done righteous deeds, in justice. But those who disbelieved will have a drink of scalding water and a painful punishment for what they used to deny"
  },
  {
    "id": 5,
    "text": "It is He who made the sun a shining light and the moon a derived light and determined for it phases - that you may know the number of years and account [of time]. Allah has not created this except in truth. He details the signs for a people who know"
  },
  {
    "id": 6,
    "text": "Indeed, in the alternation of the night and the day and [in] what Allah has created in the heavens and the earth are signs for a people who fear Allah"
  },
  {
    "id": 7,
    "text": "Indeed, those who do not expect the meeting with Us and are satisfied with the life of this world and feel secure therein and those who are heedless of Our signs"
  },
  {
    "id": 8,
    "text": "For those their refuge will be the Fire because of what they used to earn"
  },
  {
    "id": 9,
    "text": "Indeed, those who have believed and done righteous deeds - their Lord will guide them because of their faith. Beneath them rivers will flow in the Gardens of Pleasure"
  },
  {
    "id": 10,
    "text": "Their call therein will be, \"Exalted are You, O Allah,\" and their greeting therein will be, \"Peace.\" And the last of their call will be, \"Praise to Allah, Lord of the worlds"
  },
  {
    "id": 11,
    "text": "And if Allah was to hasten for the people the evil [they invoke] as He hastens for them the good, their term would have been ended for them. But We leave the ones who do not expect the meeting with Us, in their transgression, wandering blindly"
  },
  {
    "id": 12,
    "text": "And when affliction touches man, he calls upon Us, whether lying on his side or sitting or standing; but when We remove from him his affliction, he continues [in disobedience] as if he had never called upon Us to [remove] an affliction that touched him. Thus is made pleasing to the transgressors that which they have been doing"
  },
  {
    "id": 13,
    "text": "And We had already destroyed generations before you when they wronged, and their messengers had come to them with clear proofs, but they were not to believe. Thus do We recompense the criminal people"
  },
  {
    "id": 14,
    "text": "Then We made you successors in the land after them so that We may observe how you will do"
  },
  {
    "id": 15,
    "text": "And when Our verses are recited to them as clear evidences, those who do not expect the meeting with Us say, \"Bring us a Qur'an other than this or change it.\" Say, [O Muhammad], \"It is not for me to change it on my own accord. I only follow what is revealed to me. Indeed I fear, if I should disobey my Lord, the punishment of a tremendous Day"
  },
  {
    "id": 16,
    "text": "Say, \"If Allah had willed, I would not have recited it to you, nor would He have made it known to you, for I had remained among you a lifetime before it. Then will you not reason"
  },
  {
    "id": 17,
    "text": "So who is more unjust than he who invents a lie about Allah or denies His signs? Indeed, the criminals will not succeed"
  },
  {
    "id": 18,
    "text": "And they worship other than Allah that which neither harms them nor benefits them, and they say, \"These are our intercessors with Allah \" Say, \"Do you inform Allah of something He does not know in the heavens or on the earth?\" Exalted is He and high above what they associate with Him"
  },
  {
    "id": 19,
    "text": "And mankind was not but one community [united in religion], but [then] they differed. And if not for a word that preceded from your Lord, it would have been judged between them [immediately] concerning that over which they differ"
  },
  {
    "id": 20,
    "text": "And they say, \"Why is a sign not sent down to him from his Lord?\" So say, \"The unseen is only for Allah [to administer], so wait; indeed, I am with you among those who wait"
  },
  {
    "id": 21,
    "text": "And when We give the people a taste of mercy after adversity has touched them, at once they conspire against Our verses. Say, \"Allah is swifter in strategy.\" Indeed, Our messengers record that which you conspire"
  },
  {
    "id": 22,
    "text": "It is He who enables you to travel on land and sea until, when you are in ships and they sail with them by a good wind and they rejoice therein, there comes a storm wind and the waves come upon them from everywhere and they assume that they are surrounded, supplicating Allah, sincere to Him in religion, \"If You should save us from this, we will surely be among the thankful"
  },
  {
    "id": 23,
    "text": "But when He saves them, at once they commit injustice upon the earth without right. O mankind, your injustice is only against yourselves, [being merely] the enjoyment of worldly life. Then to Us is your return, and We will inform you of what you used to do"
  },
  {
    "id": 24,
    "text": "The example of [this] worldly life is but like rain which We have sent down from the sky that the plants of the earth absorb - [those] from which men and livestock eat - until, when the earth has taken on its adornment and is beautified and its people suppose that they have capability over it, there comes to it Our command by night or by day, and We make it as a harvest, as if it had not flourished yesterday. Thus do We explain in detail the signs for a people who give thought"
  },
  {
    "id": 25,
    "text": "And Allah invites to the Home of Peace and guides whom He wills to a straight path"
  },
  {
    "id": 26,
    "text": "For them who have done good is the best [reward] and extra. No darkness will cover their faces, nor humiliation. Those are companions of Paradise; they will abide therein eternally"
  },
  {
    "id": 27,
    "text": "But they who have earned [blame for] evil doings - the recompense of an evil deed is its equivalent, and humiliation will cover them. They will have from Allah no protector. It will be as if their faces are covered with pieces of the night - so dark [are they]. Those are the companions of the Fire; they will abide therein eternally"
  },
  {
    "id": 28,
    "text": "And [mention, O Muhammad], the Day We will gather them all together - then We will say to those who associated others with Allah, \"[Remain in] your place, you and your 'partners.' \" Then We will separate them, and their \"partners\" will say, \"You did not used to worship us"
  },
  {
    "id": 29,
    "text": "And sufficient is Allah as a witness between us and you that we were of your worship unaware"
  },
  {
    "id": 30,
    "text": "There, [on that Day], every soul will be put to trial for what it did previously, and they will be returned to Allah, their master, the Truth, and lost from them is whatever they used to invent"
  },
  {
    "id": 31,
    "text": "Say, \"Who provides for you from the heaven and the earth? Or who controls hearing and sight and who brings the living out of the dead and brings the dead out of the living and who arranges [every] matter?\" They will say, \"Allah,\" so say, \"Then will you not fear Him"
  },
  {
    "id": 32,
    "text": "For that is Allah, your Lord, the Truth. And what can be beyond truth except error? So how are you averted"
  },
  {
    "id": 33,
    "text": "Thus the word of your Lord has come into effect upon those who defiantly disobeyed - that they will not believe"
  },
  {
    "id": 34,
    "text": "Say, \"Are there of your 'partners' any who begins creation and then repeats it?\" Say, \"Allah begins creation and then repeats it, so how are you deluded"
  },
  {
    "id": 35,
    "text": "Say, \"Are there of your 'partners' any who guides to the truth?\" Say, \"Allah guides to the truth. So is He who guides to the truth more worthy to be followed or he who guides not unless he is guided? Then what is [wrong] with you - how do you judge"
  },
  {
    "id": 36,
    "text": "And most of them follow not except assumption. Indeed, assumption avails not against the truth at all. Indeed, Allah is Knowing of what they do"
  },
  {
    "id": 37,
    "text": "And it was not [possible] for this Qur'an to be produced by other than Allah, but [it is] a confirmation of what was before it and a detailed explanation of the [former] Scripture, about which there is no doubt, from the Lord of the worlds"
  },
  {
    "id": 38,
    "text": "Or do they say [about the Prophet], \"He invented it?\" Say, \"Then bring forth a surah like it and call upon [for assistance] whomever you can besides Allah, if you should be truthful"
  },
  {
    "id": 39,
    "text": "Rather, they have denied that which they encompass not in knowledge and whose interpretation has not yet come to them. Thus did those before them deny. Then observe how was the end of the wrongdoers"
  },
  {
    "id": 40,
    "text": "And of them are those who believe in it, and of them are those who do not believe in it. And your Lord is most knowing of the corrupters"
  },
  {
    "id": 41,
    "text": "And if they deny you, [O Muhammad], then say, \"For me are my deeds, and for you are your deeds. You are disassociated from what I do, and I am disassociated from what you do"
  },
  {
    "id": 42,
    "text": "And among them are those who listen to you. But can you cause the deaf to hear, although they will not use reason"
  },
  {
    "id": 43,
    "text": "And among them are those who look at you. But can you guide the blind although they will not [attempt to] see"
  },
  {
    "id": 44,
    "text": "Indeed, Allah does not wrong the people at all, but it is the people who are wronging themselves"
  },
  {
    "id": 45,
    "text": "And on the Day when He will gather them, [it will be] as if they had not remained [in the world] but an hour of the day, [and] they will know each other. Those will have lost who denied the meeting with Allah and were not guided"
  },
  {
    "id": 46,
    "text": "And whether We show you some of what We promise them, [O Muhammad], or We take you in death, to Us is their return; then, [either way], Allah is a witness concerning what they are doing"
  },
  {
    "id": 47,
    "text": "And for every nation is a messenger. So when their messenger comes, it will be judged between them in justice, and they will not be wronged"
  },
  {
    "id": 48,
    "text": "And they say, \"When is [the fulfillment of] this promise, if you should be truthful"
  },
  {
    "id": 49,
    "text": "Say, \"I possess not for myself any harm or benefit except what Allah should will. For every nation is a [specified] term. When their time has come, then they will not remain behind an hour, nor will they precede [it]"
  },
  {
    "id": 50,
    "text": "Say, \"Have you considered: if His punishment should come to you by night or by day - for which [aspect] of it would the criminals be impatient"
  },
  {
    "id": 51,
    "text": "Then is it that when it has [actually] occurred you will believe in it? Now? And you were [once] for it impatient"
  },
  {
    "id": 52,
    "text": "Then it will be said to those who had wronged, \"Taste the punishment of eternity; are you being recompensed except for what you used to earn"
  },
  {
    "id": 53,
    "text": "And they ask information of you, [O Muhammad], \"Is it true?\" Say, \"Yes, by my Lord. Indeed, it is truth; and you will not cause failure [to Allah]"
  },
  {
    "id": 54,
    "text": "And if each soul that wronged had everything on earth, it would offer it in ransom. And they will confide regret when they see the punishment; and they will be judged in justice, and they will not be wronged"
  },
  {
    "id": 55,
    "text": "Unquestionably, to Allah belongs whatever is in the heavens and the earth. Unquestionably, the promise of Allah is truth, but most of them do not know"
  },
  {
    "id": 56,
    "text": "He gives life and causes death, and to Him you will be returned"
  },
  {
    "id": 57,
    "text": "O mankind, there has to come to you instruction from your Lord and healing for what is in the breasts and guidance and mercy for the believers"
  },
  {
    "id": 58,
    "text": "Say, \"In the bounty of Allah and in His mercy - in that let them rejoice; it is better than what they accumulate"
  },
  {
    "id": 59,
    "text": "Say, \"Have you seen what Allah has sent down to you of provision of which you have made [some] lawful and [some] unlawful?\" Say, \"Has Allah permitted you [to do so], or do you invent [something] about Allah"
  },
  {
    "id": 60,
    "text": "And what will be the supposition of those who invent falsehood about Allah on the Day of Resurrection? Indeed, Allah is full of bounty to the people, but most of them are not grateful"
  },
  {
    "id": 61,
    "text": "And, [O Muhammad], you are not [engaged] in any matter or recite any of the Qur'an and you [people] do not do any deed except that We are witness over you when you are involved in it. And not absent from your Lord is any [part] of an atom's weight within the earth or within the heaven or [anything] smaller than that or greater but that it is in a clear register"
  },
  {
    "id": 62,
    "text": "Unquestionably, [for] the allies of Allah there will be no fear concerning them, nor will they grieve"
  },
  {
    "id": 63,
    "text": "Those who believed and were fearing Allah"
  },
  {
    "id": 64,
    "text": "For them are good tidings in the worldly life and in the Hereafter. No change is there in the words of Allah. That is what is the great attainment"
  },
  {
    "id": 65,
    "text": "And let not their speech grieve you. Indeed, honor [due to power] belongs to Allah entirely. He is the Hearing, the Knowing"
  },
  {
    "id": 66,
    "text": "Unquestionably, to Allah belongs whoever is in the heavens and whoever is on the earth. And those who invoke other than Allah do not [actually] follow [His] \"partners.\" They follow not except assumption, and they are not but falsifying"
  },
  {
    "id": 67,
    "text": "It is He who made for you the night to rest therein and the day, giving sight. Indeed in that are signs for a people who listen"
  },
  {
    "id": 68,
    "text": "They have said, \"Allah has taken a son.\" Exalted is He; He is the [one] Free of need. To Him belongs whatever is in the heavens and whatever is in the earth. You have no authority for this [claim]. Do you say about Allah that which you do not know"
  },
  {
    "id": 69,
    "text": "Say, \"Indeed, those who invent falsehood about Allah will not succeed"
  },
  {
    "id": 70,
    "text": "[For them is brief] enjoyment in this world; then to Us is their return; then We will make them taste the severe punishment because they used to disbelieve"
  },
  {
    "id": 71,
    "text": "And recite to them the news of Noah, when he said to his people, \"O my people, if my residence and my reminding of the signs of Allah has become burdensome upon you - then I have relied upon Allah. So resolve upon your plan and [call upon] your associates. Then let not your plan be obscure to you. Then carry it out upon me and do not give me respite"
  },
  {
    "id": 72,
    "text": "And if you turn away [from my advice] then no payment have I asked of you. My reward is only from Allah, and I have been commanded to be of the Muslims"
  },
  {
    "id": 73,
    "text": "And they denied him, so We saved him and those with him in the ship and made them successors, and We drowned those who denied Our signs. Then see how was the end of those who were warned"
  },
  {
    "id": 74,
    "text": "Then We sent after him messengers to their peoples, and they came to them with clear proofs. But they were not to believe in that which they had denied before. Thus We seal over the hearts of the transgressors"
  },
  {
    "id": 75,
    "text": "Then We sent after them Moses and Aaron to Pharaoh and his establishment with Our signs, but they behaved arrogantly and were a criminal people"
  },
  {
    "id": 76,
    "text": "So when there came to them the truth from Us, they said, \"Indeed, this is obvious magic"
  },
  {
    "id": 77,
    "text": "Moses said, \"Do you say [thus] about the truth when it has come to you? Is this magic? But magicians will not succeed"
  },
  {
    "id": 78,
    "text": "They said, \"Have you come to us to turn us away from that upon which we found our fathers and so that you two may have grandeur in the land? And we are not believers in you"
  },
  {
    "id": 79,
    "text": "And Pharaoh said, \"Bring to me every learned magician"
  },
  {
    "id": 80,
    "text": "So when the magicians came, Moses said to them, \"Throw down whatever you will throw"
  },
  {
    "id": 81,
    "text": "And when they had thrown, Moses said, \"What you have brought is [only] magic. Indeed, Allah will expose its worthlessness. Indeed, Allah does not amend the work of corrupters"
  },
  {
    "id": 82,
    "text": "And Allah will establish the truth by His words, even if the criminals dislike it"
  },
  {
    "id": 83,
    "text": "But no one believed Moses, except [some] youths among his people, for fear of Pharaoh and his establishment that they would persecute them. And indeed, Pharaoh was haughty within the land, and indeed, he was of the transgressors"
  },
  {
    "id": 84,
    "text": "And Moses said, \"O my people, if you have believed in Allah, then rely upon Him, if you should be Muslims"
  },
  {
    "id": 85,
    "text": "So they said, \"Upon Allah do we rely. Our Lord, make us not [objects of] trial for the wrongdoing people"
  },
  {
    "id": 86,
    "text": "And save us by Your mercy from the disbelieving people"
  },
  {
    "id": 87,
    "text": "And We inspired to Moses and his brother, \"Settle your people in Egypt in houses and make your houses [facing the] qiblah and establish prayer and give good tidings to the believers"
  },
  {
    "id": 88,
    "text": "And Moses said, \"Our Lord, indeed You have given Pharaoh and his establishment splendor and wealth in the worldly life, our Lord, that they may lead [men] astray from Your way. Our Lord, obliterate their wealth and harden their hearts so that they will not believe until they see the painful punishment"
  },
  {
    "id": 89,
    "text": "[Allah] said, \"Your supplication has been answered.\" So remain on a right course and follow not the way of those who do not know"
  },
  {
    "id": 90,
    "text": "And We took the Children of Israel across the sea, and Pharaoh and his soldiers pursued them in tyranny and enmity until, when drowning overtook him, he said, \"I believe that there is no deity except that in whom the Children of Israel believe, and I am of the Muslims"
  },
  {
    "id": 91,
    "text": "Now? And you had disobeyed [Him] before and were of the corrupters"
  },
  {
    "id": 92,
    "text": "So today We will save you in body that you may be to those who succeed you a sign. And indeed, many among the people, of Our signs, are heedless"
  },
  {
    "id": 93,
    "text": "And We had certainty settled the Children of Israel in an agreeable settlement and provided them with good things. And they did not differ until [after] knowledge had come to them. Indeed, your Lord will judge between them on the Day of Resurrection concerning that over which they used to differ"
  },
  {
    "id": 94,
    "text": "So if you are in doubt, [O Muhammad], about that which We have revealed to you, then ask those who have been reading the Scripture before you. The truth has certainly come to you from your Lord, so never be among the doubters"
  },
  {
    "id": 95,
    "text": "And never be of those who deny the signs of Allah and [thus] be among the losers"
  },
  {
    "id": 96,
    "text": "Indeed, those upon whom the word of your Lord has come into effect will not believe"
  },
  {
    "id": 97,
    "text": "Even if every sign should come to them, until they see the painful punishment"
  },
  {
    "id": 98,
    "text": "Then has there not been a [single] city that believed so its faith benefited it except the people of Jonah? When they believed, We removed from them the punishment of disgrace in worldly life and gave them enjoyment for a time"
  },
  {
    "id": 99,
    "text": "And had your Lord willed, those on earth would have believed - all of them entirely. Then, [O Muhammad], would you compel the people in order that they become believers"
  },
  {
    "id": 100,
    "text": "And it is not for a soul to believe except by permission of Allah, and He will place defilement upon those who will not use reason"
  },
  {
    "id": 101,
    "text": "Say, \"Observe what is in the heavens and earth.\" But of no avail will be signs or warners to a people who do not believe"
  },
  {
    "id": 102,
    "text": "So do they wait except for like [what occurred in] the days of those who passed on before them? Say, \"Then wait; indeed, I am with you among those who wait"
  },
  {
    "id": 103,
    "text": "Then We will save our messengers and those who have believed. Thus, it is an obligation upon Us that We save the believers"
  },
  {
    "id": 104,
    "text": "Say, [O Muhammad], \"O people, if you are in doubt as to my religion - then I do not worship those which you worship besides Allah; but I worship Allah, who causes your death. And I have been commanded to be of the believers"
  },
  {
    "id": 105,
    "text": "And [commanded], 'Direct your face toward the religion, inclining to truth, and never be of those who associate others with Allah"
  },
  {
    "id": 106,
    "text": "And do not invoke besides Allah that which neither benefits you nor harms you, for if you did, then indeed you would be of the wrongdoers"
  },
  {
    "id": 107,
    "text": "And if Allah should touch you with adversity, there is no remover of it except Him; and if He intends for you good, then there is no repeller of His bounty. He causes it to reach whom He wills of His servants. And He is the Forgiving, the Merciful"
  },
  {
    "id": 108,
    "text": "Say, \"O mankind, the truth has come to you from your Lord, so whoever is guided is only guided for [the benefit of] his soul, and whoever goes astray only goes astray [in violation] against it. And I am not over you a manager"
  },
  {
    "id": 109,
    "text": "And follow what is revealed to you, [O Muhammad], and be patient until Allah will judge. And He is the best of judges"
  }
]

export default en
