import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Alif, Lam, Meem"
  },
  {
    "id": 2,
    "text": "This is the Book about which there is no doubt, a guidance for those conscious of Allah"
  },
  {
    "id": 3,
    "text": "Who believe in the unseen, establish prayer, and spend out of what We have provided for them"
  },
  {
    "id": 4,
    "text": "And who believe in what has been revealed to you, [O Muhammad], and what was revealed before you, and of the Hereafter they are certain [in faith]"
  },
  {
    "id": 5,
    "text": "Those are upon [right] guidance from their Lord, and it is those who are the successful"
  },
  {
    "id": 6,
    "text": "Indeed, those who disbelieve - it is all the same for them whether you warn them or do not warn them - they will not believe"
  },
  {
    "id": 7,
    "text": "Allah has set a seal upon their hearts and upon their hearing, and over their vision is a veil. And for them is a great punishment"
  },
  {
    "id": 8,
    "text": "And of the people are some who say, \"We believe in Allah and the Last Day,\" but they are not believers"
  },
  {
    "id": 9,
    "text": "They [think to] deceive Allah and those who believe, but they deceive not except themselves and perceive [it] not"
  },
  {
    "id": 10,
    "text": "In their hearts is disease, so Allah has increased their disease; and for them is a painful punishment because they [habitually] used to lie"
  },
  {
    "id": 11,
    "text": "And when it is said to them, \"Do not cause corruption on the earth,\" they say, \"We are but reformers"
  },
  {
    "id": 12,
    "text": "Unquestionably, it is they who are the corrupters, but they perceive [it] not"
  },
  {
    "id": 13,
    "text": "And when it is said to them, \"Believe as the people have believed,\" they say, \"Should we believe as the foolish have believed?\" Unquestionably, it is they who are the foolish, but they know [it] not"
  },
  {
    "id": 14,
    "text": "And when they meet those who believe, they say, \"We believe\"; but when they are alone with their evil ones, they say, \"Indeed, we are with you; we were only mockers"
  },
  {
    "id": 15,
    "text": "[But] Allah mocks them and prolongs them in their transgression [while] they wander blindly"
  },
  {
    "id": 16,
    "text": "Those are the ones who have purchased error [in exchange] for guidance, so their transaction has brought no profit, nor were they guided"
  },
  {
    "id": 17,
    "text": "Their example is that of one who kindled a fire, but when it illuminated what was around him, Allah took away their light and left them in darkness [so] they could not see"
  },
  {
    "id": 18,
    "text": "Deaf, dumb and blind - so they will not return [to the right path]"
  },
  {
    "id": 19,
    "text": "Or [it is] like a rainstorm from the sky within which is darkness, thunder and lightning. They put their fingers in their ears against the thunderclaps in dread of death. But Allah is encompassing of the disbelievers"
  },
  {
    "id": 20,
    "text": "The lightning almost snatches away their sight. Every time it lights [the way] for them, they walk therein; but when darkness comes over them, they stand [still]. And if Allah had willed, He could have taken away their hearing and their sight. Indeed, Allah is over all things competent"
  },
  {
    "id": 21,
    "text": "O mankind, worship your Lord, who created you and those before you, that you may become righteous"
  },
  {
    "id": 22,
    "text": "[He] who made for you the earth a bed [spread out] and the sky a ceiling and sent down from the sky, rain and brought forth thereby fruits as provision for you. So do not attribute to Allah equals while you know [that there is nothing similar to Him]"
  },
  {
    "id": 23,
    "text": "And if you are in doubt about what We have sent down upon Our Servant [Muhammad], then produce a surah the like thereof and call upon your witnesses other than Allah, if you should be truthful"
  },
  {
    "id": 24,
    "text": "But if you do not - and you will never be able to - then fear the Fire, whose fuel is men and stones, prepared for the disbelievers"
  },
  {
    "id": 25,
    "text": "And give good tidings to those who believe and do righteous deeds that they will have gardens [in Paradise] beneath which rivers flow. Whenever they are provided with a provision of fruit therefrom, they will say, \"This is what we were provided with before.\" And it is given to them in likeness. And they will have therein purified spouses, and they will abide therein eternally"
  },
  {
    "id": 26,
    "text": "Indeed, Allah is not timid to present an example - that of a mosquito or what is smaller than it. And those who have believed know that it is the truth from their Lord. But as for those who disbelieve, they say, \"What did Allah intend by this as an example?\" He misleads many thereby and guides many thereby. And He misleads not except the defiantly disobedient"
  },
  {
    "id": 27,
    "text": "Who break the covenant of Allah after contracting it and sever that which Allah has ordered to be joined and cause corruption on earth. It is those who are the losers"
  },
  {
    "id": 28,
    "text": "How can you disbelieve in Allah when you were lifeless and He brought you to life; then He will cause you to die, then He will bring you [back] to life, and then to Him you will be returned"
  },
  {
    "id": 29,
    "text": "It is He who created for you all of that which is on the earth. Then He directed Himself to the heaven, [His being above all creation], and made them seven heavens, and He is Knowing of all things"
  },
  {
    "id": 30,
    "text": "And [mention, O Muhammad], when your Lord said to the angels, \"Indeed, I will make upon the earth a successive authority.\" They said, \"Will You place upon it one who causes corruption therein and sheds blood, while we declare Your praise and sanctify You?\" Allah said, \"Indeed, I know that which you do not know"
  },
  {
    "id": 31,
    "text": "And He taught Adam the names - all of them. Then He showed them to the angels and said, \"Inform Me of the names of these, if you are truthful"
  },
  {
    "id": 32,
    "text": "They said, \"Exalted are You; we have no knowledge except what You have taught us. Indeed, it is You who is the Knowing, the Wise"
  },
  {
    "id": 33,
    "text": "He said, \"O Adam, inform them of their names.\" And when he had informed them of their names, He said, \"Did I not tell you that I know the unseen [aspects] of the heavens and the earth? And I know what you reveal and what you have concealed"
  },
  {
    "id": 34,
    "text": "And [mention] when We said to the angels, \"Prostrate before Adam\"; so they prostrated, except for Iblees. He refused and was arrogant and became of the disbelievers"
  },
  {
    "id": 35,
    "text": "And We said, \"O Adam, dwell, you and your wife, in Paradise and eat therefrom in [ease and] abundance from wherever you will. But do not approach this tree, lest you be among the wrongdoers"
  },
  {
    "id": 36,
    "text": "But Satan caused them to slip out of it and removed them from that [condition] in which they had been. And We said, \"Go down, [all of you], as enemies to one another, and you will have upon the earth a place of settlement and provision for a time"
  },
  {
    "id": 37,
    "text": "Then Adam received from his Lord [some] words, and He accepted his repentance. Indeed, it is He who is the Accepting of repentance, the Merciful"
  },
  {
    "id": 38,
    "text": "We said, \"Go down from it, all of you. And when guidance comes to you from Me, whoever follows My guidance - there will be no fear concerning them, nor will they grieve"
  },
  {
    "id": 39,
    "text": "And those who disbelieve and deny Our signs - those will be companions of the Fire; they will abide therein eternally"
  },
  {
    "id": 40,
    "text": "O Children of Israel, remember My favor which I have bestowed upon you and fulfill My covenant [upon you] that I will fulfill your covenant [from Me], and be afraid of [only] Me"
  },
  {
    "id": 41,
    "text": "And believe in what I have sent down confirming that which is [already] with you, and be not the first to disbelieve in it. And do not exchange My signs for a small price, and fear [only] Me"
  },
  {
    "id": 42,
    "text": "And do not mix the truth with falsehood or conceal the truth while you know [it]"
  },
  {
    "id": 43,
    "text": "And establish prayer and give zakah and bow with those who bow [in worship and obedience]"
  },
  {
    "id": 44,
    "text": "Do you order righteousness of the people and forget yourselves while you recite the Scripture? Then will you not reason"
  },
  {
    "id": 45,
    "text": "And seek help through patience and prayer, and indeed, it is difficult except for the humbly submissive [to Allah]"
  },
  {
    "id": 46,
    "text": "Who are certain that they will meet their Lord and that they will return to Him"
  },
  {
    "id": 47,
    "text": "O Children of Israel, remember My favor that I have bestowed upon you and that I preferred you over the worlds"
  },
  {
    "id": 48,
    "text": "And fear a Day when no soul will suffice for another soul at all, nor will intercession be accepted from it, nor will compensation be taken from it, nor will they be aided"
  },
  {
    "id": 49,
    "text": "And [recall] when We saved your forefathers from the people of Pharaoh, who afflicted you with the worst torment, slaughtering your [newborn] sons and keeping your females alive. And in that was a great trial from your Lord"
  },
  {
    "id": 50,
    "text": "And [recall] when We parted the sea for you and saved you and drowned the people of Pharaoh while you were looking on"
  },
  {
    "id": 51,
    "text": "And [recall] when We made an appointment with Moses for forty nights. Then you took [for worship] the calf after him, while you were wrongdoers"
  },
  {
    "id": 52,
    "text": "Then We forgave you after that so perhaps you would be grateful"
  },
  {
    "id": 53,
    "text": "And [recall] when We gave Moses the Scripture and criterion that perhaps you would be guided"
  },
  {
    "id": 54,
    "text": "And [recall] when Moses said to his people, \"O my people, indeed you have wronged yourselves by your taking of the calf [for worship]. So repent to your Creator and kill yourselves. That is best for [all of] you in the sight of your Creator.\" Then He accepted your repentance; indeed, He is the Accepting of repentance, the Merciful"
  },
  {
    "id": 55,
    "text": "And [recall] when you said, \"O Moses, we will never believe you until we see Allah outright\"; so the thunderbolt took you while you were looking on"
  },
  {
    "id": 56,
    "text": "Then We revived you after your death that perhaps you would be grateful"
  },
  {
    "id": 57,
    "text": "And We shaded you with clouds and sent down to you manna and quails, [saying], \"Eat from the good things with which We have provided you.\" And they wronged Us not - but they were [only] wronging themselves"
  },
  {
    "id": 58,
    "text": "And [recall] when We said, \"Enter this city and eat from it wherever you will in [ease and] abundance, and enter the gate bowing humbly and say, 'Relieve us of our burdens.' We will [then] forgive your sins for you, and We will increase the doers of good [in goodness and reward]"
  },
  {
    "id": 59,
    "text": "But those who wronged changed [those words] to a statement other than that which had been said to them, so We sent down upon those who wronged a punishment from the sky because they were defiantly disobeying"
  },
  {
    "id": 60,
    "text": "And [recall] when Moses prayed for water for his people, so We said, \"Strike with your staff the stone.\" And there gushed forth from it twelve springs, and every people knew its watering place. \"Eat and drink from the provision of Allah, and do not commit abuse on the earth, spreading corruption"
  },
  {
    "id": 61,
    "text": "And [recall] when you said, \"O Moses, we can never endure one [kind of] food. So call upon your Lord to bring forth for us from the earth its green herbs and its cucumbers and its garlic and its lentils and its onions.\" [Moses] said, \"Would you exchange what is better for what is less? Go into [any] settlement and indeed, you will have what you have asked.\" And they were covered with humiliation and poverty and returned with anger from Allah [upon them]. That was because they [repeatedly] disbelieved in the signs of Allah and killed the prophets without right. That was because they disobeyed and were [habitually] transgressing"
  },
  {
    "id": 62,
    "text": "Indeed, those who believed and those who were Jews or Christians or Sabeans [before Prophet Muhammad] - those [among them] who believed in Allah and the Last Day and did righteousness - will have their reward with their Lord, and no fear will there be concerning them, nor will they grieve"
  },
  {
    "id": 63,
    "text": "And [recall] when We took your covenant, [O Children of Israel, to abide by the Torah] and We raised over you the mount, [saying], \"Take what We have given you with determination and remember what is in it that perhaps you may become righteous"
  },
  {
    "id": 64,
    "text": "Then you turned away after that. And if not for the favor of Allah upon you and His mercy, you would have been among the losers"
  },
  {
    "id": 65,
    "text": "And you had already known about those who transgressed among you concerning the sabbath, and We said to them, \"Be apes, despised"
  },
  {
    "id": 66,
    "text": "And We made it a deterrent punishment for those who were present and those who succeeded [them] and a lesson for those who fear Allah"
  },
  {
    "id": 67,
    "text": "And [recall] when Moses said to his people, \"Indeed, Allah commands you to slaughter a cow.\" They said, \"Do you take us in ridicule?\" He said, \"I seek refuge in Allah from being among the ignorant"
  },
  {
    "id": 68,
    "text": "They said, \"Call upon your Lord to make clear to us what it is.\" [Moses] said, \"[Allah] says, 'It is a cow which is neither old nor virgin, but median between that,' so do what you are commanded"
  },
  {
    "id": 69,
    "text": "They said, \"Call upon your Lord to show us what is her color.\" He said, \"He says, 'It is a yellow cow, bright in color - pleasing to the observers"
  },
  {
    "id": 70,
    "text": "They said, \"Call upon your Lord to make clear to us what it is. Indeed, [all] cows look alike to us. And indeed we, if Allah wills, will be guided"
  },
  {
    "id": 71,
    "text": "He said, \"He says, 'It is a cow neither trained to plow the earth nor to irrigate the field, one free from fault with no spot upon her.' \" They said, \"Now you have come with the truth.\" So they slaughtered her, but they could hardly do it"
  },
  {
    "id": 72,
    "text": "And [recall] when you slew a man and disputed over it, but Allah was to bring out that which you were concealing"
  },
  {
    "id": 73,
    "text": "So, We said, \"Strike the slain man with part of it.\" Thus does Allah bring the dead to life, and He shows you His signs that you might reason"
  },
  {
    "id": 74,
    "text": "Then your hearts became hardened after that, being like stones or even harder. For indeed, there are stones from which rivers burst forth, and there are some of them that split open and water comes out, and there are some of them that fall down for fear of Allah. And Allah is not unaware of what you do"
  },
  {
    "id": 75,
    "text": "Do you covet [the hope, O believers], that they would believe for you while a party of them used to hear the words of Allah and then distort the Torah after they had understood it while they were knowing"
  },
  {
    "id": 76,
    "text": "And when they meet those who believe, they say, \"We have believed\"; but when they are alone with one another, they say, \"Do you talk to them about what Allah has revealed to you so they can argue with you about it before your Lord?\" Then will you not reason"
  },
  {
    "id": 77,
    "text": "But do they not know that Allah knows what they conceal and what they declare"
  },
  {
    "id": 78,
    "text": "And among them are unlettered ones who do not know the Scripture except in wishful thinking, but they are only assuming"
  },
  {
    "id": 79,
    "text": "So woe to those who write the \"scripture\" with their own hands, then say, \"This is from Allah,\" in order to exchange it for a small price. Woe to them for what their hands have written and woe to them for what they earn"
  },
  {
    "id": 80,
    "text": "And they say, \"Never will the Fire touch us, except for a few days.\" Say, \"Have you taken a covenant with Allah? For Allah will never break His covenant. Or do you say about Allah that which you do not know"
  },
  {
    "id": 81,
    "text": "Yes, whoever earns evil and his sin has encompassed him - those are the companions of the Fire; they will abide therein eternally"
  },
  {
    "id": 82,
    "text": "But they who believe and do righteous deeds - those are the companions of Paradise; they will abide therein eternally"
  },
  {
    "id": 83,
    "text": "And [recall] when We took the covenant from the Children of Israel, [enjoining upon them], \"Do not worship except Allah; and to parents do good and to relatives, orphans, and the needy. And speak to people good [words] and establish prayer and give zakah.\" Then you turned away, except a few of you, and you were refusing"
  },
  {
    "id": 84,
    "text": "And [recall] when We took your covenant, [saying], \"Do not shed each other's blood or evict one another from your homes.\" Then you acknowledged [this] while you were witnessing"
  },
  {
    "id": 85,
    "text": "Then, you are those [same ones who are] killing one another and evicting a party of your people from their homes, cooperating against them in sin and aggression. And if they come to you as captives, you ransom them, although their eviction was forbidden to you. So do you believe in part of the Scripture and disbelieve in part? Then what is the recompense for those who do that among you except disgrace in worldly life; and on the Day of Resurrection they will be sent back to the severest of punishment. And Allah is not unaware of what you do"
  },
  {
    "id": 86,
    "text": "Those are the ones who have bought the life of this world [in exchange] for the Hereafter, so the punishment will not be lightened for them, nor will they be aided"
  },
  {
    "id": 87,
    "text": "And We did certainly give Moses the Torah and followed up after him with messengers. And We gave Jesus, the son of Mary, clear proofs and supported him with the Pure Spirit. But is it [not] that every time a messenger came to you, [O Children of Israel], with what your souls did not desire, you were arrogant? And a party [of messengers] you denied and another party you killed"
  },
  {
    "id": 88,
    "text": "And they said, \"Our hearts are wrapped.\" But, [in fact], Allah has cursed them for their disbelief, so little is it that they believe"
  },
  {
    "id": 89,
    "text": "And when there came to them a Book from Allah confirming that which was with them - although before they used to pray for victory against those who disbelieved - but [then] when there came to them that which they recognized, they disbelieved in it; so the curse of Allah will be upon the disbelievers"
  },
  {
    "id": 90,
    "text": "How wretched is that for which they sold themselves - that they would disbelieve in what Allah has revealed through [their] outrage that Allah would send down His favor upon whom He wills from among His servants. So they returned having [earned] wrath upon wrath. And for the disbelievers is a humiliating punishment"
  },
  {
    "id": 91,
    "text": "And when it is said to them, \"Believe in what Allah has revealed,\" they say, \"We believe [only] in what was revealed to us.\" And they disbelieve in what came after it, while it is the truth confirming that which is with them. Say, \"Then why did you kill the prophets of Allah before, if you are [indeed] believers"
  },
  {
    "id": 92,
    "text": "And Moses had certainly brought you clear proofs. Then you took the calf [in worship] after that, while you were wrongdoers"
  },
  {
    "id": 93,
    "text": "And [recall] when We took your covenant and raised over you the mount, [saying], \"Take what We have given you with determination and listen.\" They said [instead], \"We hear and disobey.\" And their hearts absorbed [the worship of] the calf because of their disbelief. Say, \"How wretched is that which your faith enjoins upon you, if you should be believers"
  },
  {
    "id": 94,
    "text": "Say, [O Muhammad], \"If the home of the Hereafter with Allah is for you alone and not the [other] people, then wish for death, if you should be truthful"
  },
  {
    "id": 95,
    "text": "But they will never wish for it, ever, because of what their hands have put forth. And Allah is Knowing of the wrongdoers"
  },
  {
    "id": 96,
    "text": "And you will surely find them the most greedy of people for life - [even] more than those who associate others with Allah. One of them wishes that he could be granted life a thousand years, but it would not remove him in the least from the [coming] punishment that he should be granted life. And Allah is Seeing of what they do"
  },
  {
    "id": 97,
    "text": "Say, \"Whoever is an enemy to Gabriel - it is [none but] he who has brought the Qur'an down upon your heart, [O Muhammad], by permission of Allah, confirming that which was before it and as guidance and good tidings for the believers"
  },
  {
    "id": 98,
    "text": "Whoever is an enemy to Allah and His angels and His messengers and Gabriel and Michael - then indeed, Allah is an enemy to the disbelievers"
  },
  {
    "id": 99,
    "text": "And We have certainly revealed to you verses [which are] clear proofs, and no one would deny them except the defiantly disobedient"
  },
  {
    "id": 100,
    "text": "Is it not [true] that every time they took a covenant a party of them threw it away? But, [in fact], most of them do not believe"
  },
  {
    "id": 101,
    "text": "And when a messenger from Allah came to them confirming that which was with them, a party of those who had been given the Scripture threw the Scripture of Allah behind their backs as if they did not know [what it contained]"
  },
  {
    "id": 102,
    "text": "And they followed [instead] what the devils had recited during the reign of Solomon. It was not Solomon who disbelieved, but the devils disbelieved, teaching people magic and that which was revealed to the two angels at Babylon, Harut and Marut. But the two angels do not teach anyone unless they say, \"We are a trial, so do not disbelieve [by practicing magic].\" And [yet] they learn from them that by which they cause separation between a man and his wife. But they do not harm anyone through it except by permission of Allah. And the people learn what harms them and does not benefit them. But the Children of Israel certainly knew that whoever purchased the magic would not have in the Hereafter any share. And wretched is that for which they sold themselves, if they only knew"
  },
  {
    "id": 103,
    "text": "And if they had believed and feared Allah, then the reward from Allah would have been [far] better, if they only knew"
  },
  {
    "id": 104,
    "text": "O you who have believed, say not [to Allah 's Messenger], \"Ra'ina\" but say, \"Unthurna\" and listen. And for the disbelievers is a painful punishment"
  },
  {
    "id": 105,
    "text": "Neither those who disbelieve from the People of the Scripture nor the polytheists wish that any good should be sent down to you from your Lord. But Allah selects for His mercy whom He wills, and Allah is the possessor of great bounty"
  },
  {
    "id": 106,
    "text": "We do not abrogate a verse or cause it to be forgotten except that We bring forth [one] better than it or similar to it. Do you not know that Allah is over all things competent"
  },
  {
    "id": 107,
    "text": "Do you not know that to Allah belongs the dominion of the heavens and the earth and [that] you have not besides Allah any protector or any helper"
  },
  {
    "id": 108,
    "text": "Or do you intend to ask your Messenger as Moses was asked before? And whoever exchanges faith for disbelief has certainly strayed from the soundness of the way"
  },
  {
    "id": 109,
    "text": "Many of the People of the Scripture wish they could turn you back to disbelief after you have believed, out of envy from themselves [even] after the truth has become clear to them. So pardon and overlook until Allah delivers His command. Indeed, Allah is over all things competent"
  },
  {
    "id": 110,
    "text": "And establish prayer and give zakah, and whatever good you put forward for yourselves - you will find it with Allah. Indeed, Allah of what you do, is Seeing"
  },
  {
    "id": 111,
    "text": "And they say, \"None will enter Paradise except one who is a Jew or a Christian.\" That is [merely] their wishful thinking, Say, \"Produce your proof, if you should be truthful"
  },
  {
    "id": 112,
    "text": "Yes [on the contrary], whoever submits his face in Islam to Allah while being a doer of good will have his reward with his Lord. And no fear will there be concerning them, nor will they grieve"
  },
  {
    "id": 113,
    "text": "The Jews say \"The Christians have nothing [true] to stand on,\" and the Christians say, \"The Jews have nothing to stand on,\" although they [both] recite the Scripture. Thus the polytheists speak the same as their words. But Allah will judge between them on the Day of Resurrection concerning that over which they used to differ"
  },
  {
    "id": 114,
    "text": "And who are more unjust than those who prevent the name of Allah from being mentioned in His mosques and strive toward their destruction. It is not for them to enter them except in fear. For them in this world is disgrace, and they will have in the Hereafter a great punishment"
  },
  {
    "id": 115,
    "text": "And to Allah belongs the east and the west. So wherever you [might] turn, there is the Face of Allah. Indeed, Allah is all-Encompassing and Knowing"
  },
  {
    "id": 116,
    "text": "They say, \"Allah has taken a son.\" Exalted is He! Rather, to Him belongs whatever is in the heavens and the earth. All are devoutly obedient to Him"
  },
  {
    "id": 117,
    "text": "Originator of the heavens and the earth. When He decrees a matter, He only says to it, \"Be,\" and it is"
  },
  {
    "id": 118,
    "text": "Those who do not know say, \"Why does Allah not speak to us or there come to us a sign?\" Thus spoke those before them like their words. Their hearts resemble each other. We have shown clearly the signs to a people who are certain [in faith]"
  },
  {
    "id": 119,
    "text": "Indeed, We have sent you, [O Muhammad], with the truth as a bringer of good tidings and a warner, and you will not be asked about the companions of Hellfire"
  },
  {
    "id": 120,
    "text": "And never will the Jews or the Christians approve of you until you follow their religion. Say, \"Indeed, the guidance of Allah is the [only] guidance.\" If you were to follow their desires after what has come to you of knowledge, you would have against Allah no protector or helper"
  },
  {
    "id": 121,
    "text": "Those to whom We have given the Book recite it with its true recital. They [are the ones who] believe in it. And whoever disbelieves in it - it is they who are the losers"
  },
  {
    "id": 122,
    "text": "O Children of Israel, remember My favor which I have bestowed upon you and that I preferred you over the worlds"
  },
  {
    "id": 123,
    "text": "And fear a Day when no soul will suffice for another soul at all, and no compensation will be accepted from it, nor will any intercession benefit it, nor will they be aided"
  },
  {
    "id": 124,
    "text": "And [mention, O Muhammad], when Abraham was tried by his Lord with commands and he fulfilled them. [Allah] said, \"Indeed, I will make you a leader for the people.\" [Abraham] said, \"And of my descendants?\" [Allah] said, \"My covenant does not include the wrongdoers"
  },
  {
    "id": 125,
    "text": "And [mention] when We made the House a place of return for the people and [a place of] security. And take, [O believers], from the standing place of Abraham a place of prayer. And We charged Abraham and Ishmael, [saying], \"Purify My House for those who perform Tawaf and those who are staying [there] for worship and those who bow and prostrate [in prayer]"
  },
  {
    "id": 126,
    "text": "And [mention] when Abraham said, \"My Lord, make this a secure city and provide its people with fruits - whoever of them believes in Allah and the Last Day.\" [Allah] said. \"And whoever disbelieves - I will grant him enjoyment for a little; then I will force him to the punishment of the Fire, and wretched is the destination"
  },
  {
    "id": 127,
    "text": "And [mention] when Abraham was raising the foundations of the House and [with him] Ishmael, [saying], \"Our Lord, accept [this] from us. Indeed You are the Hearing, the Knowing"
  },
  {
    "id": 128,
    "text": "Our Lord, and make us Muslims [in submission] to You and from our descendants a Muslim nation [in submission] to You. And show us our rites and accept our repentance. Indeed, You are the Accepting of repentance, the Merciful"
  },
  {
    "id": 129,
    "text": "Our Lord, and send among them a messenger from themselves who will recite to them Your verses and teach them the Book and wisdom and purify them. Indeed, You are the Exalted in Might, the Wise"
  },
  {
    "id": 130,
    "text": "And who would be averse to the religion of Abraham except one who makes a fool of himself. And We had chosen him in this world, and indeed he, in the Hereafter, will be among the righteous"
  },
  {
    "id": 131,
    "text": "When his Lord said to him, \"Submit\", he said \"I have submitted [in Islam] to the Lord of the worlds"
  },
  {
    "id": 132,
    "text": "And Abraham instructed his sons [to do the same] and [so did] Jacob, [saying], \"O my sons, indeed Allah has chosen for you this religion, so do not die except while you are Muslims"
  },
  {
    "id": 133,
    "text": "Or were you witnesses when death approached Jacob, when he said to his sons, \"What will you worship after me?\" They said, \"We will worship your God and the God of your fathers, Abraham and Ishmael and Isaac - one God. And we are Muslims [in submission] to Him"
  },
  {
    "id": 134,
    "text": "That was a nation which has passed on. It will have [the consequence of] what it earned, and you will have what you have earned. And you will not be asked about what they used to do"
  },
  {
    "id": 135,
    "text": "They say, \"Be Jews or Christians [so] you will be guided.\" Say, \"Rather, [we follow] the religion of Abraham, inclining toward truth, and he was not of the polytheists"
  },
  {
    "id": 136,
    "text": "Say, [O believers], \"We have believed in Allah and what has been revealed to us and what has been revealed to Abraham and Ishmael and Isaac and Jacob and the Descendants and what was given to Moses and Jesus and what was given to the prophets from their Lord. We make no distinction between any of them, and we are Muslims [in submission] to Him"
  },
  {
    "id": 137,
    "text": "So if they believe in the same as you believe in, then they have been [rightly] guided; but if they turn away, they are only in dissension, and Allah will be sufficient for you against them. And He is the Hearing, the Knowing"
  },
  {
    "id": 138,
    "text": "[And say, \"Ours is] the religion of Allah. And who is better than Allah in [ordaining] religion? And we are worshippers of Him"
  },
  {
    "id": 139,
    "text": "Say, [O Muhammad], \"Do you argue with us about Allah while He is our Lord and your Lord? For us are our deeds, and for you are your deeds. And we are sincere [in deed and intention] to Him"
  },
  {
    "id": 140,
    "text": "Or do you say that Abraham and Ishmael and Isaac and Jacob and the Descendants were Jews or Christians? Say, \"Are you more knowing or is Allah?\" And who is more unjust than one who conceals a testimony he has from Allah? And Allah is not unaware of what you do"
  },
  {
    "id": 141,
    "text": "That is a nation which has passed on. It will have [the consequence of] what it earned, and you will have what you have earned. And you will not be asked about what they used to do"
  },
  {
    "id": 142,
    "text": "The foolish among the people will say, \"What has turned them away from their qiblah, which they used to face?\" Say, \"To Allah belongs the east and the west. He guides whom He wills to a straight path"
  },
  {
    "id": 143,
    "text": "And thus we have made you a just community that you will be witnesses over the people and the Messenger will be a witness over you. And We did not make the qiblah which you used to face except that We might make evident who would follow the Messenger from who would turn back on his heels. And indeed, it is difficult except for those whom Allah has guided. And never would Allah have caused you to lose your faith. Indeed Allah is, to the people, Kind and Merciful"
  },
  {
    "id": 144,
    "text": "We have certainly seen the turning of your face, [O Muhammad], toward the heaven, and We will surely turn you to a qiblah with which you will be pleased. So turn your face toward al-Masjid al-Haram. And wherever you [believers] are, turn your faces toward it [in prayer]. Indeed, those who have been given the Scripture well know that it is the truth from their Lord. And Allah is not unaware of what they do"
  },
  {
    "id": 145,
    "text": "And if you brought to those who were given the Scripture every sign, they would not follow your qiblah. Nor will you be a follower of their qiblah. Nor would they be followers of one another's qiblah. So if you were to follow their desires after what has come to you of knowledge, indeed, you would then be among the wrongdoers"
  },
  {
    "id": 146,
    "text": "Those to whom We gave the Scripture know him as they know their own sons. But indeed, a party of them conceal the truth while they know [it]"
  },
  {
    "id": 147,
    "text": "The truth is from your Lord, so never be among the doubters"
  },
  {
    "id": 148,
    "text": "For each [religious following] is a direction toward which it faces. So race to [all that is] good. Wherever you may be, Allah will bring you forth [for judgement] all together. Indeed, Allah is over all things competent"
  },
  {
    "id": 149,
    "text": "So from wherever you go out [for prayer, O Muhammad] turn your face toward al- Masjid al-Haram, and indeed, it is the truth from your Lord. And Allah is not unaware of what you do"
  },
  {
    "id": 150,
    "text": "And from wherever you go out [for prayer], turn your face toward al-Masjid al-Haram. And wherever you [believers] may be, turn your faces toward it in order that the people will not have any argument against you, except for those of them who commit wrong; so fear them not but fear Me. And [it is] so I may complete My favor upon you and that you may be guided"
  },
  {
    "id": 151,
    "text": "Just as We have sent among you a messenger from yourselves reciting to you Our verses and purifying you and teaching you the Book and wisdom and teaching you that which you did not know"
  },
  {
    "id": 152,
    "text": "So remember Me; I will remember you. And be grateful to Me and do not deny Me"
  },
  {
    "id": 153,
    "text": "O you who have believed, seek help through patience and prayer. Indeed, Allah is with the patient"
  },
  {
    "id": 154,
    "text": "And do not say about those who are killed in the way of Allah, \"They are dead.\" Rather, they are alive, but you perceive [it] not"
  },
  {
    "id": 155,
    "text": "And We will surely test you with something of fear and hunger and a loss of wealth and lives and fruits, but give good tidings to the patient"
  },
  {
    "id": 156,
    "text": "Who, when disaster strikes them, say, \"Indeed we belong to Allah, and indeed to Him we will return"
  },
  {
    "id": 157,
    "text": "Those are the ones upon whom are blessings from their Lord and mercy. And it is those who are the [rightly] guided"
  },
  {
    "id": 158,
    "text": "Indeed, as-Safa and al-Marwah are among the symbols of Allah. So whoever makes Hajj to the House or performs 'umrah - there is no blame upon him for walking between them. And whoever volunteers good - then indeed, Allah is appreciative and Knowing"
  },
  {
    "id": 159,
    "text": "Indeed, those who conceal what We sent down of clear proofs and guidance after We made it clear for the people in the Scripture - those are cursed by Allah and cursed by those who curse"
  },
  {
    "id": 160,
    "text": "Except for those who repent and correct themselves and make evident [what they concealed]. Those - I will accept their repentance, and I am the Accepting of repentance, the Merciful"
  },
  {
    "id": 161,
    "text": "Indeed, those who disbelieve and die while they are disbelievers - upon them will be the curse of Allah and of the angels and the people, all together"
  },
  {
    "id": 162,
    "text": "Abiding eternally therein. The punishment will not be lightened for them, nor will they be reprieved"
  },
  {
    "id": 163,
    "text": "And your god is one God. There is no deity [worthy of worship] except Him, the Entirely Merciful, the Especially Merciful"
  },
  {
    "id": 164,
    "text": "Indeed, in the creation of the heavens and earth, and the alternation of the night and the day, and the [great] ships which sail through the sea with that which benefits people, and what Allah has sent down from the heavens of rain, giving life thereby to the earth after its lifelessness and dispersing therein every [kind of] moving creature, and [His] directing of the winds and the clouds controlled between the heaven and the earth are signs for a people who use reason"
  },
  {
    "id": 165,
    "text": "And [yet], among the people are those who take other than Allah as equals [to Him]. They love them as they [should] love Allah. But those who believe are stronger in love for Allah. And if only they who have wronged would consider [that] when they see the punishment, [they will be certain] that all power belongs to Allah and that Allah is severe in punishment"
  },
  {
    "id": 166,
    "text": "[And they should consider that] when those who have been followed disassociate themselves from those who followed [them], and they [all] see the punishment, and cut off from them are the ties [of relationship]"
  },
  {
    "id": 167,
    "text": "Those who followed will say, \"If only we had another turn [at worldly life] so we could disassociate ourselves from them as they have disassociated themselves from us.\" Thus will Allah show them their deeds as regrets upon them. And they are never to emerge from the Fire"
  },
  {
    "id": 168,
    "text": "O mankind, eat from whatever is on earth [that is] lawful and good and do not follow the footsteps of Satan. Indeed, he is to you a clear enemy"
  },
  {
    "id": 169,
    "text": "He only orders you to evil and immorality and to say about Allah what you do not know"
  },
  {
    "id": 170,
    "text": "And when it is said to them, \"Follow what Allah has revealed,\" they say, \"Rather, we will follow that which we found our fathers doing.\" Even though their fathers understood nothing, nor were they guided"
  },
  {
    "id": 171,
    "text": "The example of those who disbelieve is like that of one who shouts at what hears nothing but calls and cries cattle or sheep - deaf, dumb and blind, so they do not understand"
  },
  {
    "id": 172,
    "text": "O you who have believed, eat from the good things which We have provided for you and be grateful to Allah if it is [indeed] Him that you worship"
  },
  {
    "id": 173,
    "text": "He has only forbidden to you dead animals, blood, the flesh of swine, and that which has been dedicated to other than Allah. But whoever is forced [by necessity], neither desiring [it] nor transgressing [its limit], there is no sin upon him. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 174,
    "text": "Indeed, they who conceal what Allah has sent down of the Book and exchange it for a small price - those consume not into their bellies except the Fire. And Allah will not speak to them on the Day of Resurrection, nor will He purify them. And they will have a painful punishment"
  },
  {
    "id": 175,
    "text": "Those are the ones who have exchanged guidance for error and forgiveness for punishment. How patient they are in pursuit of the Fire"
  },
  {
    "id": 176,
    "text": "That is [deserved by them] because Allah has sent down the Book in truth. And indeed, those who differ over the Book are in extreme dissension"
  },
  {
    "id": 177,
    "text": "Righteousness is not that you turn your faces toward the east or the west, but [true] righteousness is [in] one who believes in Allah, the Last Day, the angels, the Book, and the prophets and gives wealth, in spite of love for it, to relatives, orphans, the needy, the traveler, those who ask [for help], and for freeing slaves; [and who] establishes prayer and gives zakah; [those who] fulfill their promise when they promise; and [those who] are patient in poverty and hardship and during battle. Those are the ones who have been true, and it is those who are the righteous"
  },
  {
    "id": 178,
    "text": "O you who have believed, prescribed for you is legal retribution for those murdered - the free for the free, the slave for the slave, and the female for the female. But whoever overlooks from his brother anything, then there should be a suitable follow-up and payment to him with good conduct. This is an alleviation from your Lord and a mercy. But whoever transgresses after that will have a painful punishment"
  },
  {
    "id": 179,
    "text": "And there is for you in legal retribution [saving of] life, O you [people] of understanding, that you may become righteous"
  },
  {
    "id": 180,
    "text": "Prescribed for you when death approaches [any] one of you if he leaves wealth [is that he should make] a bequest for the parents and near relatives according to what is acceptable - a duty upon the righteous"
  },
  {
    "id": 181,
    "text": "Then whoever alters the bequest after he has heard it - the sin is only upon those who have altered it. Indeed, Allah is Hearing and Knowing"
  },
  {
    "id": 182,
    "text": "But if one fears from the bequeather [some] error or sin and corrects that which is between them, there is no sin upon him. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 183,
    "text": "O you who have believed, decreed upon you is fasting as it was decreed upon those before you that you may become righteous"
  },
  {
    "id": 184,
    "text": "[Fasting for] a limited number of days. So whoever among you is ill or on a journey [during them] - then an equal number of days [are to be made up]. And upon those who are able [to fast, but with hardship] - a ransom [as substitute] of feeding a poor person [each day]. And whoever volunteers excess - it is better for him. But to fast is best for you, if you only knew"
  },
  {
    "id": 185,
    "text": "The month of Ramadhan [is that] in which was revealed the Qur'an, a guidance for the people and clear proofs of guidance and criterion. So whoever sights [the new moon of] the month, let him fast it; and whoever is ill or on a journey - then an equal number of other days. Allah intends for you ease and does not intend for you hardship and [wants] for you to complete the period and to glorify Allah for that [to] which He has guided you; and perhaps you will be grateful"
  },
  {
    "id": 186,
    "text": "And when My servants ask you, [O Muhammad], concerning Me - indeed I am near. I respond to the invocation of the supplicant when he calls upon Me. So let them respond to Me [by obedience] and believe in Me that they may be [rightly] guided"
  },
  {
    "id": 187,
    "text": "It has been made permissible for you the night preceding fasting to go to your wives [for sexual relations]. They are clothing for you and you are clothing for them. Allah knows that you used to deceive yourselves, so He accepted your repentance and forgave you. So now, have relations with them and seek that which Allah has decreed for you. And eat and drink until the white thread of dawn becomes distinct to you from the black thread [of night]. Then complete the fast until the sunset. And do not have relations with them as long as you are staying for worship in the mosques. These are the limits [set by] Allah, so do not approach them. Thus does Allah make clear His ordinances to the people that they may become righteous"
  },
  {
    "id": 188,
    "text": "And do not consume one another's wealth unjustly or send it [in bribery] to the rulers in order that [they might aid] you [to] consume a portion of the wealth of the people in sin, while you know [it is unlawful]"
  },
  {
    "id": 189,
    "text": "They ask you, [O Muhammad], about the new moons. Say, \"They are measurements of time for the people and for Hajj.\" And it is not righteousness to enter houses from the back, but righteousness is [in] one who fears Allah. And enter houses from their doors. And fear Allah that you may succeed"
  },
  {
    "id": 190,
    "text": "Fight in the way of Allah those who fight you but do not transgress. Indeed. Allah does not like transgressors"
  },
  {
    "id": 191,
    "text": "And kill them wherever you overtake them and expel them from wherever they have expelled you, and fitnah is worse than killing. And do not fight them at al-Masjid al- Haram until they fight you there. But if they fight you, then kill them. Such is the recompense of the disbelievers"
  },
  {
    "id": 192,
    "text": "And if they cease, then indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 193,
    "text": "Fight them until there is no [more] fitnah and [until] worship is [acknowledged to be] for Allah. But if they cease, then there is to be no aggression except against the oppressors"
  },
  {
    "id": 194,
    "text": "[Fighting in] the sacred month is for [aggression committed in] the sacred month, and for [all] violations is legal retribution. So whoever has assaulted you, then assault him in the same way that he has assaulted you. And fear Allah and know that Allah is with those who fear Him"
  },
  {
    "id": 195,
    "text": "And spend in the way of Allah and do not throw [yourselves] with your [own] hands into destruction [by refraining]. And do good; indeed, Allah loves the doers of good"
  },
  {
    "id": 196,
    "text": "And complete the Hajj and 'umrah for Allah. But if you are prevented, then [offer] what can be obtained with ease of sacrificial animals. And do not shave your heads until the sacrificial animal has reached its place of slaughter. And whoever among you is ill or has an ailment of the head [making shaving necessary must offer] a ransom of fasting [three days] or charity or sacrifice. And when you are secure, then whoever performs 'umrah [during the Hajj months] followed by Hajj [offers] what can be obtained with ease of sacrificial animals. And whoever cannot find [or afford such an animal] - then a fast of three days during Hajj and of seven when you have returned [home]. Those are ten complete [days]. This is for those whose family is not in the area of al-Masjid al-Haram. And fear Allah and know that Allah is severe in penalty"
  },
  {
    "id": 197,
    "text": "Hajj is [during] well-known months, so whoever has made Hajj obligatory upon himself therein [by entering the state of ihram], there is [to be for him] no sexual relations and no disobedience and no disputing during Hajj. And whatever good you do - Allah knows it. And take provisions, but indeed, the best provision is fear of Allah. And fear Me, O you of understanding"
  },
  {
    "id": 198,
    "text": "There is no blame upon you for seeking bounty from your Lord [during Hajj]. But when you depart from 'Arafat, remember Allah at al- Mash'ar al-Haram. And remember Him, as He has guided you, for indeed, you were before that among those astray"
  },
  {
    "id": 199,
    "text": "Then depart from the place from where [all] the people depart and ask forgiveness of Allah. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 200,
    "text": "And when you have completed your rites, remember Allah like your [previous] remembrance of your fathers or with [much] greater remembrance. And among the people is he who says, \"Our Lord, give us in this world,\" and he will have in the Hereafter no share"
  },
  {
    "id": 201,
    "text": "But among them is he who says, \"Our Lord, give us in this world [that which is] good and in the Hereafter [that which is] good and protect us from the punishment of the Fire"
  },
  {
    "id": 202,
    "text": "Those will have a share of what they have earned, and Allah is swift in account"
  },
  {
    "id": 203,
    "text": "And remember Allah during [specific] numbered days. Then whoever hastens [his departure] in two days - there is no sin upon him; and whoever delays [until the third] - there is no sin upon him - for him who fears Allah. And fear Allah and know that unto Him you will be gathered"
  },
  {
    "id": 204,
    "text": "And of the people is he whose speech pleases you in worldly life, and he calls Allah to witness as to what is in his heart, yet he is the fiercest of opponents"
  },
  {
    "id": 205,
    "text": "And when he goes away, he strives throughout the land to cause corruption therein and destroy crops and animals. And Allah does not like corruption"
  },
  {
    "id": 206,
    "text": "And when it is said to him, \"Fear Allah,\" pride in the sin takes hold of him. Sufficient for him is Hellfire, and how wretched is the resting place"
  },
  {
    "id": 207,
    "text": "And of the people is he who sells himself, seeking means to the approval of Allah. And Allah is kind to [His] servants"
  },
  {
    "id": 208,
    "text": "O you who have believed, enter into Islam completely [and perfectly] and do not follow the footsteps of Satan. Indeed, he is to you a clear enemy"
  },
  {
    "id": 209,
    "text": "But if you deviate after clear proofs have come to you, then know that Allah is Exalted in Might and Wise"
  },
  {
    "id": 210,
    "text": "Do they await but that Allah should come to them in covers of clouds and the angels [as well] and the matter is [then] decided? And to Allah [all] matters are returned"
  },
  {
    "id": 211,
    "text": "Ask the Children of Israel how many a sign of evidence We have given them. And whoever exchanges the favor of Allah [for disbelief] after it has come to him - then indeed, Allah is severe in penalty"
  },
  {
    "id": 212,
    "text": "Beautified for those who disbelieve is the life of this world, and they ridicule those who believe. But those who fear Allah are above them on the Day of Resurrection. And Allah gives provision to whom He wills without account"
  },
  {
    "id": 213,
    "text": "Mankind was [of] one religion [before their deviation]; then Allah sent the prophets as bringers of good tidings and warners and sent down with them the Scripture in truth to judge between the people concerning that in which they differed. And none differed over the Scripture except those who were given it - after the clear proofs came to them - out of jealous animosity among themselves. And Allah guided those who believed to the truth concerning that over which they had differed, by His permission. And Allah guides whom He wills to a straight path"
  },
  {
    "id": 214,
    "text": "Or do you think that you will enter Paradise while such [trial] has not yet come to you as came to those who passed on before you? They were touched by poverty and hardship and were shaken until [even their] messenger and those who believed with him said, \"When is the help of Allah?\" Unquestionably, the help of Allah is near"
  },
  {
    "id": 215,
    "text": "They ask you, [O Muhammad], what they should spend. Say, \"Whatever you spend of good is [to be] for parents and relatives and orphans and the needy and the traveler. And whatever you do of good - indeed, Allah is Knowing of it"
  },
  {
    "id": 216,
    "text": "Fighting has been enjoined upon you while it is hateful to you. But perhaps you hate a thing and it is good for you; and perhaps you love a thing and it is bad for you. And Allah Knows, while you know not"
  },
  {
    "id": 217,
    "text": "They ask you about the sacred month - about fighting therein. Say, \"Fighting therein is great [sin], but averting [people] from the way of Allah and disbelief in Him and [preventing access to] al-Masjid al-Haram and the expulsion of its people therefrom are greater [evil] in the sight of Allah. And fitnah is greater than killing.\" And they will continue to fight you until they turn you back from your religion if they are able. And whoever of you reverts from his religion [to disbelief] and dies while he is a disbeliever - for those, their deeds have become worthless in this world and the Hereafter, and those are the companions of the Fire, they will abide therein eternally"
  },
  {
    "id": 218,
    "text": "Indeed, those who have believed and those who have emigrated and fought in the cause of Allah - those expect the mercy of Allah. And Allah is Forgiving and Merciful"
  },
  {
    "id": 219,
    "text": "They ask you about wine and gambling. Say, \"In them is great sin and [yet, some] benefit for people. But their sin is greater than their benefit.\" And they ask you what they should spend. Say, \"The excess [beyond needs].\" Thus Allah makes clear to you the verses [of revelation] that you might give thought"
  },
  {
    "id": 220,
    "text": "To this world and the Hereafter. And they ask you about orphans. Say, \"Improvement for them is best. And if you mix your affairs with theirs - they are your brothers. And Allah knows the corrupter from the amender. And if Allah had willed, He could have put you in difficulty. Indeed, Allah is Exalted in Might and Wise"
  },
  {
    "id": 221,
    "text": "And do not marry polytheistic women until they believe. And a believing slave woman is better than a polytheist, even though she might please you. And do not marry polytheistic men [to your women] until they believe. And a believing slave is better than a polytheist, even though he might please you. Those invite [you] to the Fire, but Allah invites to Paradise and to forgiveness, by His permission. And He makes clear His verses to the people that perhaps they may remember"
  },
  {
    "id": 222,
    "text": "And they ask you about menstruation. Say, \"It is harm, so keep away from wives during menstruation. And do not approach them until they are pure. And when they have purified themselves, then come to them from where Allah has ordained for you. Indeed, Allah loves those who are constantly repentant and loves those who purify themselves"
  },
  {
    "id": 223,
    "text": "Your wives are a place of sowing of seed for you, so come to your place of cultivation however you wish and put forth [righteousness] for yourselves. And fear Allah and know that you will meet Him. And give good tidings to the believers"
  },
  {
    "id": 224,
    "text": "And do not make [your oath by] Allah an excuse against being righteous and fearing Allah and making peace among people. And Allah is Hearing and Knowing"
  },
  {
    "id": 225,
    "text": "Allah does not impose blame upon you for what is unintentional in your oaths, but He imposes blame upon you for what your hearts have earned. And Allah is Forgiving and Forbearing"
  },
  {
    "id": 226,
    "text": "For those who swear not to have sexual relations with their wives is a waiting time of four months, but if they return [to normal relations] - then indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 227,
    "text": "And if they decide on divorce - then indeed, Allah is Hearing and Knowing"
  },
  {
    "id": 228,
    "text": "Divorced women remain in waiting for three periods, and it is not lawful for them to conceal what Allah has created in their wombs if they believe in Allah and the Last Day. And their husbands have more right to take them back in this [period] if they want reconciliation. And due to the wives is similar to what is expected of them, according to what is reasonable. But the men have a degree over them [in responsibility and authority]. And Allah is Exalted in Might and Wise"
  },
  {
    "id": 229,
    "text": "Divorce is twice. Then, either keep [her] in an acceptable manner or release [her] with good treatment. And it is not lawful for you to take anything of what you have given them unless both fear that they will not be able to keep [within] the limits of Allah. But if you fear that they will not keep [within] the limits of Allah, then there is no blame upon either of them concerning that by which she ransoms herself. These are the limits of Allah, so do not transgress them. And whoever transgresses the limits of Allah - it is those who are the wrongdoers"
  },
  {
    "id": 230,
    "text": "And if he has divorced her [for the third time], then she is not lawful to him afterward until [after] she marries a husband other than him. And if the latter husband divorces her [or dies], there is no blame upon the woman and her former husband for returning to each other if they think that they can keep [within] the limits of Allah. These are the limits of Allah, which He makes clear to a people who know"
  },
  {
    "id": 231,
    "text": "And when you divorce women and they have [nearly] fulfilled their term, either retain them according to acceptable terms or release them according to acceptable terms, and do not keep them, intending harm, to transgress [against them]. And whoever does that has certainly wronged himself. And do not take the verses of Allah in jest. And remember the favor of Allah upon you and what has been revealed to you of the Book and wisdom by which He instructs you. And fear Allah and know that Allah is Knowing of all things"
  },
  {
    "id": 232,
    "text": "And when you divorce women and they have fulfilled their term, do not prevent them from remarrying their [former] husbands if they agree among themselves on an acceptable basis. That is instructed to whoever of you believes in Allah and the Last Day. That is better for you and purer, and Allah knows and you know not"
  },
  {
    "id": 233,
    "text": "Mothers may breastfeed their children two complete years for whoever wishes to complete the nursing [period]. Upon the father is the mothers' provision and their clothing according to what is acceptable. No person is charged with more than his capacity. No mother should be harmed through her child, and no father through his child. And upon the [father's] heir is [a duty] like that [of the father]. And if they both desire weaning through mutual consent from both of them and consultation, there is no blame upon either of them. And if you wish to have your children nursed by a substitute, there is no blame upon you as long as you give payment according to what is acceptable. And fear Allah and know that Allah is Seeing of what you do"
  },
  {
    "id": 234,
    "text": "And those who are taken in death among you and leave wives behind - they, [the wives, shall] wait four months and ten [days]. And when they have fulfilled their term, then there is no blame upon you for what they do with themselves in an acceptable manner. And Allah is [fully] Acquainted with what you do"
  },
  {
    "id": 235,
    "text": "There is no blame upon you for that to which you [indirectly] allude concerning a proposal to women or for what you conceal within yourselves. Allah knows that you will have them in mind. But do not promise them secretly except for saying a proper saying. And do not determine to undertake a marriage contract until the decreed period reaches its end. And know that Allah knows what is within yourselves, so beware of Him. And know that Allah is Forgiving and Forbearing"
  },
  {
    "id": 236,
    "text": "There is no blame upon you if you divorce women you have not touched nor specified for them an obligation. But give them [a gift of] compensation - the wealthy according to his capability and the poor according to his capability - a provision according to what is acceptable, a duty upon the doers of good"
  },
  {
    "id": 237,
    "text": "And if you divorce them before you have touched them and you have already specified for them an obligation, then [give] half of what you specified - unless they forego the right or the one in whose hand is the marriage contract foregoes it. And to forego it is nearer to righteousness. And do not forget graciousness between you. Indeed Allah, of whatever you do, is Seeing"
  },
  {
    "id": 238,
    "text": "Maintain with care the [obligatory] prayers and [in particular] the middle prayer and stand before Allah, devoutly obedient"
  },
  {
    "id": 239,
    "text": "And if you fear [an enemy, then pray] on foot or riding. But when you are secure, then remember Allah [in prayer], as He has taught you that which you did not [previously] know"
  },
  {
    "id": 240,
    "text": "And those who are taken in death among you and leave wives behind - for their wives is a bequest: maintenance for one year without turning [them] out. But if they leave [of their own accord], then there is no blame upon you for what they do with themselves in an acceptable way. And Allah is Exalted in Might and Wise"
  },
  {
    "id": 241,
    "text": "And for divorced women is a provision according to what is acceptable - a duty upon the righteous"
  },
  {
    "id": 242,
    "text": "Thus does Allah make clear to you His verses that you might use reason"
  },
  {
    "id": 243,
    "text": "Have you not considered those who left their homes in many thousands, fearing death? Allah said to them, \"Die\"; then He restored them to life. And Allah is full of bounty to the people, but most of the people do not show gratitude"
  },
  {
    "id": 244,
    "text": "And fight in the cause of Allah and know that Allah is Hearing and Knowing"
  },
  {
    "id": 245,
    "text": "Who is it that would loan Allah a goodly loan so He may multiply it for him many times over? And it is Allah who withholds and grants abundance, and to Him you will be returned"
  },
  {
    "id": 246,
    "text": "Have you not considered the assembly of the Children of Israel after [the time of] Moses when they said to a prophet of theirs, \"Send to us a king, and we will fight in the way of Allah \"? He said, \"Would you perhaps refrain from fighting if fighting was prescribed for you?\" They said, \"And why should we not fight in the cause of Allah when we have been driven out from our homes and from our children?\" But when fighting was prescribed for them, they turned away, except for a few of them. And Allah is Knowing of the wrongdoers"
  },
  {
    "id": 247,
    "text": "And their prophet said to them, \"Indeed, Allah has sent to you Saul as a king.\" They said, \"How can he have kingship over us while we are more worthy of kingship than him and he has not been given any measure of wealth?\" He said, \"Indeed, Allah has chosen him over you and has increased him abundantly in knowledge and stature. And Allah gives His sovereignty to whom He wills. And Allah is all-Encompassing [in favor] and Knowing"
  },
  {
    "id": 248,
    "text": "And their prophet said to them, \"Indeed, a sign of his kingship is that the chest will come to you in which is assurance from your Lord and a remnant of what the family of Moses and the family of Aaron had left, carried by the angels. Indeed in that is a sign for you, if you are believers"
  },
  {
    "id": 249,
    "text": "And when Saul went forth with the soldiers, he said, \"Indeed, Allah will be testing you with a river. So whoever drinks from it is not of me, and whoever does not taste it is indeed of me, excepting one who takes [from it] in the hollow of his hand.\" But they drank from it, except a [very] few of them. Then when he had crossed it along with those who believed with him, they said, \"There is no power for us today against Goliath and his soldiers.\" But those who were certain that they would meet Allah said, \"How many a small company has overcome a large company by permission of Allah. And Allah is with the patient"
  },
  {
    "id": 250,
    "text": "And when they went forth to [face] Goliath and his soldiers, they said, \"Our Lord, pour upon us patience and plant firmly our feet and give us victory over the disbelieving people"
  },
  {
    "id": 251,
    "text": "So they defeated them by permission of Allah, and David killed Goliath, and Allah gave him the kingship and prophethood and taught him from that which He willed. And if it were not for Allah checking [some] people by means of others, the earth would have been corrupted, but Allah is full of bounty to the worlds"
  },
  {
    "id": 252,
    "text": "These are the verses of Allah which We recite to you, [O Muhammad], in truth. And indeed, you are from among the messengers"
  },
  {
    "id": 253,
    "text": "Those messengers - some of them We caused to exceed others. Among them were those to whom Allah spoke, and He raised some of them in degree. And We gave Jesus, the Son of Mary, clear proofs, and We supported him with the Pure Spirit. If Allah had willed, those [generations] succeeding them would not have fought each other after the clear proofs had come to them. But they differed, and some of them believed and some of them disbelieved. And if Allah had willed, they would not have fought each other, but Allah does what He intends"
  },
  {
    "id": 254,
    "text": "O you who have believed, spend from that which We have provided for you before there comes a Day in which there is no exchange and no friendship and no intercession. And the disbelievers - they are the wrongdoers"
  },
  {
    "id": 255,
    "text": "Allah - there is no deity except Him, the Ever-Living, the Sustainer of [all] existence. Neither drowsiness overtakes Him nor sleep. To Him belongs whatever is in the heavens and whatever is on the earth. Who is it that can intercede with Him except by His permission? He knows what is [presently] before them and what will be after them, and they encompass not a thing of His knowledge except for what He wills. His Kursi extends over the heavens and the earth, and their preservation tires Him not. And He is the Most High, the Most Great"
  },
  {
    "id": 256,
    "text": "There shall be no compulsion in [acceptance of] the religion. The right course has become clear from the wrong. So whoever disbelieves in Taghut and believes in Allah has grasped the most trustworthy handhold with no break in it. And Allah is Hearing and Knowing"
  },
  {
    "id": 257,
    "text": "Allah is the ally of those who believe. He brings them out from darknesses into the light. And those who disbelieve - their allies are Taghut. They take them out of the light into darknesses. Those are the companions of the Fire; they will abide eternally therein"
  },
  {
    "id": 258,
    "text": "Have you not considered the one who argued with Abraham about his Lord [merely] because Allah had given him kingship? When Abraham said, \"My Lord is the one who gives life and causes death,\" he said, \"I give life and cause death.\" Abraham said, \"Indeed, Allah brings up the sun from the east, so bring it up from the west.\" So the disbeliever was overwhelmed [by astonishment], and Allah does not guide the wrongdoing people"
  },
  {
    "id": 259,
    "text": "Or [consider such an example] as the one who passed by a township which had fallen into ruin. He said, \"How will Allah bring this to life after its death?\" So Allah caused him to die for a hundred years; then He revived him. He said, \"How long have you remained?\" The man said, \"I have remained a day or part of a day.\" He said, \"Rather, you have remained one hundred years. Look at your food and your drink; it has not changed with time. And look at your donkey; and We will make you a sign for the people. And look at the bones [of this donkey] - how We raise them and then We cover them with flesh.\" And when it became clear to him, he said, \"I know that Allah is over all things competent"
  },
  {
    "id": 260,
    "text": "And [mention] when Abraham said, \"My Lord, show me how You give life to the dead.\" [Allah] said, \"Have you not believed?\" He said, \"Yes, but [I ask] only that my heart may be satisfied.\" [Allah] said, \"Take four birds and commit them to yourself. Then [after slaughtering them] put on each hill a portion of them; then call them - they will come [flying] to you in haste. And know that Allah is Exalted in Might and Wise"
  },
  {
    "id": 261,
    "text": "The example of those who spend their wealth in the way of Allah is like a seed [of grain] which grows seven spikes; in each spike is a hundred grains. And Allah multiplies [His reward] for whom He wills. And Allah is all-Encompassing and Knowing"
  },
  {
    "id": 262,
    "text": "Those who spend their wealth in the way of Allah and then do not follow up what they have spent with reminders [of it] or [other] injury will have their reward with their Lord, and there will be no fear concerning them, nor will they grieve"
  },
  {
    "id": 263,
    "text": "Kind speech and forgiveness are better than charity followed by injury. And Allah is Free of need and Forbearing"
  },
  {
    "id": 264,
    "text": "O you who have believed, do not invalidate your charities with reminders or injury as does one who spends his wealth [only] to be seen by the people and does not believe in Allah and the Last Day. His example is like that of a [large] smooth stone upon which is dust and is hit by a downpour that leaves it bare. They are unable [to keep] anything of what they have earned. And Allah does not guide the disbelieving people"
  },
  {
    "id": 265,
    "text": "And the example of those who spend their wealth seeking means to the approval of Allah and assuring [reward for] themselves is like a garden on high ground which is hit by a downpour - so it yields its fruits in double. And [even] if it is not hit by a downpour, then a drizzle [is sufficient]. And Allah, of what you do, is Seeing"
  },
  {
    "id": 266,
    "text": "Would one of you like to have a garden of palm trees and grapevines underneath which rivers flow in which he has from every fruit? But he is afflicted with old age and has weak offspring, and it is hit by a whirlwind containing fire and is burned. Thus does Allah make clear to you [His] verses that you might give thought"
  },
  {
    "id": 267,
    "text": "O you who have believed, spend from the good things which you have earned and from that which We have produced for you from the earth. And do not aim toward the defective therefrom, spending [from that] while you would not take it [yourself] except with closed eyes. And know that Allah is Free of need and Praiseworthy"
  },
  {
    "id": 268,
    "text": "Satan threatens you with poverty and orders you to immorality, while Allah promises you forgiveness from Him and bounty. And Allah is all-Encompassing and Knowing"
  },
  {
    "id": 269,
    "text": "He gives wisdom to whom He wills, and whoever has been given wisdom has certainly been given much good. And none will remember except those of understanding"
  },
  {
    "id": 270,
    "text": "And whatever you spend of expenditures or make of vows - indeed, Allah knows of it. And for the wrongdoers there are no helpers"
  },
  {
    "id": 271,
    "text": "If you disclose your charitable expenditures, they are good; but if you conceal them and give them to the poor, it is better for you, and He will remove from you some of your misdeeds [thereby]. And Allah, with what you do, is [fully] Acquainted"
  },
  {
    "id": 272,
    "text": "Not upon you, [O Muhammad], is [responsibility for] their guidance, but Allah guides whom He wills. And whatever good you [believers] spend is for yourselves, and you do not spend except seeking the countenance of Allah. And whatever you spend of good - it will be fully repaid to you, and you will not be wronged"
  },
  {
    "id": 273,
    "text": "[Charity is] for the poor who have been restricted for the cause of Allah, unable to move about in the land. An ignorant [person] would think them self-sufficient because of their restraint, but you will know them by their [characteristic] sign. They do not ask people persistently [or at all]. And whatever you spend of good - indeed, Allah is Knowing of it"
  },
  {
    "id": 274,
    "text": "Those who spend their wealth [in Allah 's way] by night and by day, secretly and publicly - they will have their reward with their Lord. And no fear will there be concerning them, nor will they grieve"
  },
  {
    "id": 275,
    "text": "Those who consume interest cannot stand [on the Day of Resurrection] except as one stands who is being beaten by Satan into insanity. That is because they say, \"Trade is [just] like interest.\" But Allah has permitted trade and has forbidden interest. So whoever has received an admonition from his Lord and desists may have what is past, and his affair rests with Allah. But whoever returns to [dealing in interest or usury] - those are the companions of the Fire; they will abide eternally therein"
  },
  {
    "id": 276,
    "text": "Allah destroys interest and gives increase for charities. And Allah does not like every sinning disbeliever"
  },
  {
    "id": 277,
    "text": "Indeed, those who believe and do righteous deeds and establish prayer and give zakah will have their reward with their Lord, and there will be no fear concerning them, nor will they grieve"
  },
  {
    "id": 278,
    "text": "O you who have believed, fear Allah and give up what remains [due to you] of interest, if you should be believers"
  },
  {
    "id": 279,
    "text": "And if you do not, then be informed of a war [against you] from Allah and His Messenger. But if you repent, you may have your principal - [thus] you do no wrong, nor are you wronged"
  },
  {
    "id": 280,
    "text": "And if someone is in hardship, then [let there be] postponement until [a time of] ease. But if you give [from your right as] charity, then it is better for you, if you only knew"
  },
  {
    "id": 281,
    "text": "And fear a Day when you will be returned to Allah. Then every soul will be compensated for what it earned, and they will not be treated unjustly"
  },
  {
    "id": 282,
    "text": "O you who have believed, when you contract a debt for a specified term, write it down. And let a scribe write [it] between you in justice. Let no scribe refuse to write as Allah has taught him. So let him write and let the one who has the obligation dictate. And let him fear Allah, his Lord, and not leave anything out of it. But if the one who has the obligation is of limited understanding or weak or unable to dictate himself, then let his guardian dictate in justice. And bring to witness two witnesses from among your men. And if there are not two men [available], then a man and two women from those whom you accept as witnesses - so that if one of the women errs, then the other can remind her. And let not the witnesses refuse when they are called upon. And do not be [too] weary to write it, whether it is small or large, for its [specified] term. That is more just in the sight of Allah and stronger as evidence and more likely to prevent doubt between you, except when it is an immediate transaction which you conduct among yourselves. For [then] there is no blame upon you if you do not write it. And take witnesses when you conclude a contract. Let no scribe be harmed or any witness. For if you do so, indeed, it is [grave] disobedience in you. And fear Allah. And Allah teaches you. And Allah is Knowing of all things"
  },
  {
    "id": 283,
    "text": "And if you are on a journey and cannot find a scribe, then a security deposit [should be] taken. And if one of you entrusts another, then let him who is entrusted discharge his trust [faithfully] and let him fear Allah, his Lord. And do not conceal testimony, for whoever conceals it - his heart is indeed sinful, and Allah is Knowing of what you do"
  },
  {
    "id": 284,
    "text": "To Allah belongs whatever is in the heavens and whatever is in the earth. Whether you show what is within yourselves or conceal it, Allah will bring you to account for it. Then He will forgive whom He wills and punish whom He wills, and Allah is over all things competent"
  },
  {
    "id": 285,
    "text": "The Messenger has believed in what was revealed to him from his Lord, and [so have] the believers. All of them have believed in Allah and His angels and His books and His messengers, [saying], \"We make no distinction between any of His messengers.\" And they say, \"We hear and we obey. [We seek] Your forgiveness, our Lord, and to You is the [final] destination"
  },
  {
    "id": 286,
    "text": "Allah does not charge a soul except [with that within] its capacity. It will have [the consequence of] what [good] it has gained, and it will bear [the consequence of] what [evil] it has earned. \"Our Lord, do not impose blame upon us if we have forgotten or erred. Our Lord, and lay not upon us a burden like that which You laid upon those before us. Our Lord, and burden us not with that which we have no ability to bear. And pardon us; and forgive us; and have mercy upon us. You are our protector, so give us victory over the disbelieving people"
  }
]

export default en
