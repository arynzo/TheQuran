import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Certainly will the believers have succeeded"
  },
  {
    "id": 2,
    "text": "They who are during their prayer humbly submissive"
  },
  {
    "id": 3,
    "text": "And they who turn away from ill speech"
  },
  {
    "id": 4,
    "text": "And they who are observant of zakah"
  },
  {
    "id": 5,
    "text": "And they who guard their private parts"
  },
  {
    "id": 6,
    "text": "Except from their wives or those their right hands possess, for indeed, they will not be blamed"
  },
  {
    "id": 7,
    "text": "But whoever seeks beyond that, then those are the transgressors"
  },
  {
    "id": 8,
    "text": "And they who are to their trusts and their promises attentive"
  },
  {
    "id": 9,
    "text": "And they who carefully maintain their prayers"
  },
  {
    "id": 10,
    "text": "Those are the inheritors"
  },
  {
    "id": 11,
    "text": "Who will inherit al-Firdaus. They will abide therein eternally"
  },
  {
    "id": 12,
    "text": "And certainly did We create man from an extract of clay"
  },
  {
    "id": 13,
    "text": "Then We placed him as a sperm-drop in a firm lodging"
  },
  {
    "id": 14,
    "text": "Then We made the sperm-drop into a clinging clot, and We made the clot into a lump [of flesh], and We made [from] the lump, bones, and We covered the bones with flesh; then We developed him into another creation. So blessed is Allah, the best of creators"
  },
  {
    "id": 15,
    "text": "Then indeed, after that you are to die"
  },
  {
    "id": 16,
    "text": "Then indeed you, on the Day of Resurrection, will be resurrected"
  },
  {
    "id": 17,
    "text": "And We have created above you seven layered heavens, and never have We been of [Our] creation unaware"
  },
  {
    "id": 18,
    "text": "And We have sent down rain from the sky in a measured amount and settled it in the earth. And indeed, We are Able to take it away"
  },
  {
    "id": 19,
    "text": "And We brought forth for you thereby gardens of palm trees and grapevines in which for you are abundant fruits and from which you eat"
  },
  {
    "id": 20,
    "text": "And [We brought forth] a tree issuing from Mount Sinai which produces oil and food for those who eat"
  },
  {
    "id": 21,
    "text": "And indeed, for you in livestock is a lesson. We give you drink from that which is in their bellies, and for you in them are numerous benefits, and from them you eat"
  },
  {
    "id": 22,
    "text": "And upon them and on ships you are carried"
  },
  {
    "id": 23,
    "text": "And We had certainly sent Noah to his people, and he said, \"O my people, worship Allah; you have no deity other than Him; then will you not fear Him"
  },
  {
    "id": 24,
    "text": "But the eminent among those who disbelieved from his people said, \"This is not but a man like yourselves who wishes to take precedence over you; and if Allah had willed [to send a messenger], He would have sent down angels. We have not heard of this among our forefathers"
  },
  {
    "id": 25,
    "text": "He is not but a man possessed with madness, so wait concerning him for a time"
  },
  {
    "id": 26,
    "text": "[Noah] said, \"My Lord, support me because they have denied me"
  },
  {
    "id": 27,
    "text": "So We inspired to him, \"Construct the ship under Our observation, and Our inspiration, and when Our command comes and the oven overflows, put into the ship from each [creature] two mates and your family, except those for whom the decree [of destruction] has proceeded. And do not address Me concerning those who have wronged; indeed, they are to be drowned"
  },
  {
    "id": 28,
    "text": "And when you have boarded the ship, you and those with you, then say, 'Praise to Allah who has saved us from the wrongdoing people"
  },
  {
    "id": 29,
    "text": "And say, 'My Lord, let me land at a blessed landing place, and You are the best to accommodate [us]"
  },
  {
    "id": 30,
    "text": "Indeed in that are signs, and indeed, We are ever testing [Our servants]"
  },
  {
    "id": 31,
    "text": "Then We produced after them a generation of others"
  },
  {
    "id": 32,
    "text": "And We sent among them a messenger from themselves, [saying], \"Worship Allah; you have no deity other than Him; then will you not fear Him"
  },
  {
    "id": 33,
    "text": "And the eminent among his people who disbelieved and denied the meeting of the Hereafter while We had given them luxury in the worldly life said, \"This is not but a man like yourselves. He eats of that from which you eat and drinks of what you drink"
  },
  {
    "id": 34,
    "text": "And if you should obey a man like yourselves, indeed, you would then be losers"
  },
  {
    "id": 35,
    "text": "Does he promise you that when you have died and become dust and bones that you will be brought forth [once more]"
  },
  {
    "id": 36,
    "text": "How far, how far, is that which you are promised"
  },
  {
    "id": 37,
    "text": "Life is not but our worldly life - we die and live, but we will not be resurrected"
  },
  {
    "id": 38,
    "text": "He is not but a man who has invented a lie about Allah, and we will not believe him"
  },
  {
    "id": 39,
    "text": "He said, \"My Lord, support me because they have denied me"
  },
  {
    "id": 40,
    "text": "[Allah] said, \"After a little, they will surely become regretful"
  },
  {
    "id": 41,
    "text": "So the shriek seized them in truth, and We made them as [plant] stubble. Then away with the wrongdoing people"
  },
  {
    "id": 42,
    "text": "Then We produced after them other generations"
  },
  {
    "id": 43,
    "text": "No nation will precede its time [of termination], nor will they remain [thereafter]"
  },
  {
    "id": 44,
    "text": "Then We sent Our messengers in succession. Every time there came to a nation its messenger, they denied him, so We made them follow one another [to destruction], and We made them narrations. So away with a people who do not believe"
  },
  {
    "id": 45,
    "text": "Then We sent Moses and his brother Aaron with Our signs and a clear authority"
  },
  {
    "id": 46,
    "text": "To Pharaoh and his establishment, but they were arrogant and were a haughty people"
  },
  {
    "id": 47,
    "text": "They said, \"Should we believe two men like ourselves while their people are for us in servitude"
  },
  {
    "id": 48,
    "text": "So they denied them and were of those destroyed"
  },
  {
    "id": 49,
    "text": "And We certainly gave Moses the Scripture that perhaps they would be guided"
  },
  {
    "id": 50,
    "text": "And We made the son of Mary and his mother a sign and sheltered them within a high ground having level [areas] and flowing water"
  },
  {
    "id": 51,
    "text": "[Allah said], \"O messengers, eat from the good foods and work righteousness. Indeed, I, of what you do, am Knowing"
  },
  {
    "id": 52,
    "text": "And indeed this, your religion, is one religion, and I am your Lord, so fear Me"
  },
  {
    "id": 53,
    "text": "But the people divided their religion among them into sects - each faction, in what it has, rejoicing"
  },
  {
    "id": 54,
    "text": "So leave them in their confusion for a time"
  },
  {
    "id": 55,
    "text": "Do they think that what We extend to them of wealth and children"
  },
  {
    "id": 56,
    "text": "Is [because] We hasten for them good things? Rather, they do not perceive"
  },
  {
    "id": 57,
    "text": "Indeed, they who are apprehensive from fear of their Lord"
  },
  {
    "id": 58,
    "text": "And they who believe in the signs of their Lord"
  },
  {
    "id": 59,
    "text": "And they who do not associate anything with their Lord"
  },
  {
    "id": 60,
    "text": "And they who give what they give while their hearts are fearful because they will be returning to their Lord"
  },
  {
    "id": 61,
    "text": "It is those who hasten to good deeds, and they outstrip [others] therein"
  },
  {
    "id": 62,
    "text": "And We charge no soul except [with that within] its capacity, and with Us is a record which speaks with truth; and they will not be wronged"
  },
  {
    "id": 63,
    "text": "But their hearts are covered with confusion over this, and they have [evil] deeds besides disbelief which they are doing"
  },
  {
    "id": 64,
    "text": "Until when We seize their affluent ones with punishment, at once they are crying [to Allah] for help"
  },
  {
    "id": 65,
    "text": "Do not cry out today. Indeed, by Us you will not be helped"
  },
  {
    "id": 66,
    "text": "My verses had already been recited to you, but you were turning back on your heels"
  },
  {
    "id": 67,
    "text": "In arrogance regarding it, conversing by night, speaking evil"
  },
  {
    "id": 68,
    "text": "Then have they not reflected over the Qur'an, or has there come to them that which had not come to their forefathers"
  },
  {
    "id": 69,
    "text": "Or did they not know their Messenger, so they are toward him disacknowledging"
  },
  {
    "id": 70,
    "text": "Or do they say, \"In him is madness?\" Rather, he brought them the truth, but most of them, to the truth, are averse"
  },
  {
    "id": 71,
    "text": "But if the Truth had followed their inclinations, the heavens and the earth and whoever is in them would have been ruined. Rather, We have brought them their message, but they, from their message, are turning away"
  },
  {
    "id": 72,
    "text": "Or do you, [O Muhammad], ask them for payment? But the reward of your Lord is best, and He is the best of providers"
  },
  {
    "id": 73,
    "text": "And indeed, you invite them to a straight path"
  },
  {
    "id": 74,
    "text": "But indeed, those who do not believe in the Hereafter are deviating from the path"
  },
  {
    "id": 75,
    "text": "And even if We gave them mercy and removed what was upon them of affliction, they would persist in their transgression, wandering blindly"
  },
  {
    "id": 76,
    "text": "And We had gripped them with suffering [as a warning], but they did not yield to their Lord, nor did they humbly supplicate, [and will continue thus]"
  },
  {
    "id": 77,
    "text": "Until when We have opened before them a door of severe punishment, immediately they will be therein in despair"
  },
  {
    "id": 78,
    "text": "And it is He who produced for you hearing and vision and hearts; little are you grateful"
  },
  {
    "id": 79,
    "text": "And it is He who has multiplied you throughout the earth, and to Him you will be gathered"
  },
  {
    "id": 80,
    "text": "And it is He who gives life and causes death, and His is the alternation of the night and the day. Then will you not reason"
  },
  {
    "id": 81,
    "text": "Rather, they say like what the former peoples said"
  },
  {
    "id": 82,
    "text": "They said, \"When we have died and become dust and bones, are we indeed to be resurrected"
  },
  {
    "id": 83,
    "text": "We have been promised this, we and our forefathers, before; this is not but legends of the former peoples"
  },
  {
    "id": 84,
    "text": "Say, [O Muhammad], \"To whom belongs the earth and whoever is in it, if you should know"
  },
  {
    "id": 85,
    "text": "They will say, \"To Allah.\" Say, \"Then will you not remember"
  },
  {
    "id": 86,
    "text": "Say, \"Who is Lord of the seven heavens and Lord of the Great Throne"
  },
  {
    "id": 87,
    "text": "They will say, \"[They belong] to Allah.\" Say, \"Then will you not fear Him"
  },
  {
    "id": 88,
    "text": "Say, \"In whose hand is the realm of all things - and He protects while none can protect against Him - if you should know"
  },
  {
    "id": 89,
    "text": "They will say, \"[All belongs] to Allah.\" Say, \"Then how are you deluded"
  },
  {
    "id": 90,
    "text": "Rather, We have brought them the truth, and indeed they are liars"
  },
  {
    "id": 91,
    "text": "Allah has not taken any son, nor has there ever been with Him any deity. [If there had been], then each deity would have taken what it created, and some of them would have sought to overcome others. Exalted is Allah above what they describe [concerning Him]"
  },
  {
    "id": 92,
    "text": "[He is] Knower of the unseen and the witnessed, so high is He above what they associate [with Him]"
  },
  {
    "id": 93,
    "text": "Say, [O Muhammad], \"My Lord, if You should show me that which they are promised"
  },
  {
    "id": 94,
    "text": "My Lord, then do not place me among the wrongdoing people"
  },
  {
    "id": 95,
    "text": "And indeed, We are able to show you what We have promised them"
  },
  {
    "id": 96,
    "text": "Repel, by [means of] what is best, [their] evil. We are most knowing of what they describe"
  },
  {
    "id": 97,
    "text": "And say, \"My Lord, I seek refuge in You from the incitements of the devils"
  },
  {
    "id": 98,
    "text": "And I seek refuge in You, my Lord, lest they be present with me"
  },
  {
    "id": 99,
    "text": "[For such is the state of the disbelievers], until, when death comes to one of them, he says, \"My Lord, send me back"
  },
  {
    "id": 100,
    "text": "That I might do righteousness in that which I left behind.\" No! It is only a word he is saying; and behind them is a barrier until the Day they are resurrected"
  },
  {
    "id": 101,
    "text": "So when the Horn is blown, no relationship will there be among them that Day, nor will they ask about one another"
  },
  {
    "id": 102,
    "text": "And those whose scales are heavy [with good deeds] - it is they who are the successful"
  },
  {
    "id": 103,
    "text": "But those whose scales are light - those are the ones who have lost their souls, [being] in Hell, abiding eternally"
  },
  {
    "id": 104,
    "text": "The Fire will sear their faces, and they therein will have taut smiles"
  },
  {
    "id": 105,
    "text": "[It will be said]. \"Were not My verses recited to you and you used to deny them"
  },
  {
    "id": 106,
    "text": "They will say, \"Our Lord, our wretchedness overcame us, and we were a people astray"
  },
  {
    "id": 107,
    "text": "Our Lord, remove us from it, and if we were to return [to evil], we would indeed be wrongdoers"
  },
  {
    "id": 108,
    "text": "He will say, \"Remain despised therein and do not speak to Me"
  },
  {
    "id": 109,
    "text": "Indeed, there was a party of My servants who said, 'Our Lord, we have believed, so forgive us and have mercy upon us, and You are the best of the merciful"
  },
  {
    "id": 110,
    "text": "But you took them in mockery to the point that they made you forget My remembrance, and you used to laugh at them"
  },
  {
    "id": 111,
    "text": "Indeed, I have rewarded them this Day for their patient endurance - that they are the attainers [of success]"
  },
  {
    "id": 112,
    "text": "[Allah] will say, \"How long did you remain on earth in number of years"
  },
  {
    "id": 113,
    "text": "They will say, \"We remained a day or part of a day; ask those who enumerate"
  },
  {
    "id": 114,
    "text": "He will say, \"You stayed not but a little - if only you had known"
  },
  {
    "id": 115,
    "text": "Then did you think that We created you uselessly and that to Us you would not be returned"
  },
  {
    "id": 116,
    "text": "So exalted is Allah, the Sovereign, the Truth; there is no deity except Him, Lord of the Noble Throne"
  },
  {
    "id": 117,
    "text": "And whoever invokes besides Allah another deity for which he has no proof - then his account is only with his Lord. Indeed, the disbelievers will not succeed"
  },
  {
    "id": 118,
    "text": "And, [O Muhammad], say, \"My Lord, forgive and have mercy, and You are the best of the merciful"
  }
]

export default en
