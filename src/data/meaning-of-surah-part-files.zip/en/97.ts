import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Indeed, We sent the Qur'an down during the Night of Decree"
  },
  {
    "id": 2,
    "text": "And what can make you know what is the Night of Decree"
  },
  {
    "id": 3,
    "text": "The Night of Decree is better than a thousand months"
  },
  {
    "id": 4,
    "text": "The angels and the Spirit descend therein by permission of their Lord for every matter"
  },
  {
    "id": 5,
    "text": "Peace it is until the emergence of dawn"
  }
]

export default en
