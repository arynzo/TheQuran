import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Alif, Lam, Meem"
  },
  {
    "id": 2,
    "text": "[This is] the revelation of the Book about which there is no doubt from the Lord of the worlds"
  },
  {
    "id": 3,
    "text": "Or do they say, \"He invented it\"? Rather, it is the truth from your Lord, [O Muhammad], that you may warn a people to whom no warner has come before you [so] perhaps they will be guided"
  },
  {
    "id": 4,
    "text": "It is Allah who created the heavens and the earth and whatever is between them in six days; then He established Himself above the Throne. You have not besides Him any protector or any intercessor; so will you not be reminded"
  },
  {
    "id": 5,
    "text": "He arranges [each] matter from the heaven to the earth; then it will ascend to Him in a Day, the extent of which is a thousand years of those which you count"
  },
  {
    "id": 6,
    "text": "That is the Knower of the unseen and the witnessed, the Exalted in Might, the Merciful"
  },
  {
    "id": 7,
    "text": "Who perfected everything which He created and began the creation of man from clay"
  },
  {
    "id": 8,
    "text": "Then He made his posterity out of the extract of a liquid disdained"
  },
  {
    "id": 9,
    "text": "Then He proportioned him and breathed into him from His [created] soul and made for you hearing and vision and hearts; little are you grateful"
  },
  {
    "id": 10,
    "text": "And they say, \"When we are lost within the earth, will we indeed be [recreated] in a new creation?\" Rather, they are, in [the matter of] the meeting with their Lord, disbelievers"
  },
  {
    "id": 11,
    "text": "Say, \"The angel of death will take you who has been entrusted with you. Then to your Lord you will be returned"
  },
  {
    "id": 12,
    "text": "If you could but see when the criminals are hanging their heads before their Lord, [saying], \"Our Lord, we have seen and heard, so return us [to the world]; we will work righteousness. Indeed, we are [now] certain"
  },
  {
    "id": 13,
    "text": "And if We had willed, We could have given every soul its guidance, but the word from Me will come into effect [that] \"I will surely fill Hell with jinn and people all together"
  },
  {
    "id": 14,
    "text": "So taste [punishment] because you forgot the meeting of this, your Day; indeed, We have [accordingly] forgotten you. And taste the punishment of eternity for what you used to do"
  },
  {
    "id": 15,
    "text": "Only those believe in Our verses who, when they are reminded by them, fall down in prostration and exalt [Allah] with praise of their Lord, and they are not arrogant"
  },
  {
    "id": 16,
    "text": "They arise from [their] beds; they supplicate their Lord in fear and aspiration, and from what We have provided them, they spend"
  },
  {
    "id": 17,
    "text": "And no soul knows what has been hidden for them of comfort for eyes as reward for what they used to do"
  },
  {
    "id": 18,
    "text": "Then is one who was a believer like one who was defiantly disobedient? They are not equal"
  },
  {
    "id": 19,
    "text": "As for those who believed and did righteous deeds, for them will be the Gardens of Refuge as accommodation for what they used to do"
  },
  {
    "id": 20,
    "text": "But as for those who defiantly disobeyed, their refuge is the Fire. Every time they wish to emerge from it, they will be returned to it while it is said to them, \"Taste the punishment of the Fire which you used to deny"
  },
  {
    "id": 21,
    "text": "And we will surely let them taste the nearer punishment short of the greater punishment that perhaps they will repent"
  },
  {
    "id": 22,
    "text": "And who is more unjust than one who is reminded of the verses of his Lord; then he turns away from them? Indeed We, from the criminals, will take retribution"
  },
  {
    "id": 23,
    "text": "And We certainly gave Moses the Scripture, so do not be in doubt over his meeting. And we made the Torah guidance for the Children of Israel"
  },
  {
    "id": 24,
    "text": "And We made from among them leaders guiding by Our command when they were patient and [when] they were certain of Our signs"
  },
  {
    "id": 25,
    "text": "Indeed, your Lord will judge between them on the Day of Resurrection concerning that over which they used to differ"
  },
  {
    "id": 26,
    "text": "Has it not become clear to them how many generations We destroyed before them, [as] they walk among their dwellings? Indeed in that are signs; then do they not hear"
  },
  {
    "id": 27,
    "text": "Have they not seen that We drive the water [in clouds] to barren land and bring forth thereby crops from which their livestock eat and [they] themselves? Then do they not see"
  },
  {
    "id": 28,
    "text": "And they say, \"When will be this conquest, if you should be truthful"
  },
  {
    "id": 29,
    "text": "Say, [O Muhammad], \"On the Day of Conquest the belief of those who had disbelieved will not benefit them, nor will they be reprieved"
  },
  {
    "id": 30,
    "text": "So turn away from them and wait. Indeed, they are waiting"
  }
]

export default en
