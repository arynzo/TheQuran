import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Ha, Meem"
  },
  {
    "id": 2,
    "text": "By the clear Book"
  },
  {
    "id": 3,
    "text": "Indeed, We have made it an Arabic Qur'an that you might understand"
  },
  {
    "id": 4,
    "text": "And indeed it is, in the Mother of the Book with Us, exalted and full of wisdom"
  },
  {
    "id": 5,
    "text": "Then should We turn the message away, disregarding you, because you are a transgressing people"
  },
  {
    "id": 6,
    "text": "And how many a prophet We sent among the former peoples"
  },
  {
    "id": 7,
    "text": "But there would not come to them a prophet except that they used to ridicule him"
  },
  {
    "id": 8,
    "text": "And We destroyed greater than them in [striking] power, and the example of the former peoples has preceded"
  },
  {
    "id": 9,
    "text": "And if you should ask them, \"Who has created the heavens and the earth?\" they would surely say, \"They were created by the Exalted in Might, the Knowing"
  },
  {
    "id": 10,
    "text": "[The one] who has made for you the earth a bed and made for you upon it roads that you might be guided"
  },
  {
    "id": 11,
    "text": "And who sends down rain from the sky in measured amounts, and We revive thereby a dead land - thus will you be brought forth"
  },
  {
    "id": 12,
    "text": "And who created the species, all of them, and has made for you of ships and animals those which you mount"
  },
  {
    "id": 13,
    "text": "That you may settle yourselves upon their backs and then remember the favor of your Lord when you have settled upon them and say. \"Exalted is He who has subjected this to us, and we could not have [otherwise] subdued it"
  },
  {
    "id": 14,
    "text": "And indeed we, to our Lord, will [surely] return"
  },
  {
    "id": 15,
    "text": "But they have attributed to Him from His servants a portion. Indeed, man is clearly ungrateful"
  },
  {
    "id": 16,
    "text": "Or has He taken, out of what He has created, daughters and chosen you for [having] sons"
  },
  {
    "id": 17,
    "text": "And when one of them is given good tidings of that which he attributes to the Most Merciful in comparison, his face becomes dark, and he suppresses grief"
  },
  {
    "id": 18,
    "text": "So is one brought up in ornaments while being during conflict unevident [attributed to Allah]"
  },
  {
    "id": 19,
    "text": "And they have made the angels, who are servants of the Most Merciful, females. Did they witness their creation? Their testimony will be recorded, and they will be questioned"
  },
  {
    "id": 20,
    "text": "And they said, \"If the Most Merciful had willed, we would not have worshipped them.\" They have of that no knowledge. They are not but falsifying"
  },
  {
    "id": 21,
    "text": "Or have We given them a book before the Qur'an to which they are adhering"
  },
  {
    "id": 22,
    "text": "Rather, they say, \"Indeed, we found our fathers upon a religion, and we are in their footsteps [rightly] guided"
  },
  {
    "id": 23,
    "text": "And similarly, We did not send before you any warner into a city except that its affluent said, \"Indeed, we found our fathers upon a religion, and we are, in their footsteps, following"
  },
  {
    "id": 24,
    "text": "[Each warner] said, \"Even if I brought you better guidance than that [religion] upon which you found your fathers?\" They said, \"Indeed we, in that with which you were sent, are disbelievers"
  },
  {
    "id": 25,
    "text": "So we took retribution from them; then see how was the end of the deniers"
  },
  {
    "id": 26,
    "text": "And [mention, O Muhammad], when Abraham said to his father and his people, \"Indeed, I am disassociated from that which you worship"
  },
  {
    "id": 27,
    "text": "Except for He who created me; and indeed, He will guide me"
  },
  {
    "id": 28,
    "text": "And he made it a word remaining among his descendants that they might return [to it]"
  },
  {
    "id": 29,
    "text": "However, I gave enjoyment to these [people of Makkah] and their fathers until there came to them the truth and a clear Messenger"
  },
  {
    "id": 30,
    "text": "But when the truth came to them, they said, \"This is magic, and indeed we are, concerning it, disbelievers"
  },
  {
    "id": 31,
    "text": "And they said, \"Why was this Qur'an not sent down upon a great man from [one of] the two cities"
  },
  {
    "id": 32,
    "text": "Do they distribute the mercy of your Lord? It is We who have apportioned among them their livelihood in the life of this world and have raised some of them above others in degrees [of rank] that they may make use of one another for service. But the mercy of your Lord is better than whatever they accumulate"
  },
  {
    "id": 33,
    "text": "And if it were not that the people would become one community [of disbelievers], We would have made for those who disbelieve in the Most Merciful - for their houses - ceilings and stairways of silver upon which to mount"
  },
  {
    "id": 34,
    "text": "And for their houses - doors and couches [of silver] upon which to recline"
  },
  {
    "id": 35,
    "text": "And gold ornament. But all that is not but the enjoyment of worldly life. And the Hereafter with your Lord is for the righteous"
  },
  {
    "id": 36,
    "text": "And whoever is blinded from remembrance of the Most Merciful - We appoint for him a devil, and he is to him a companion"
  },
  {
    "id": 37,
    "text": "And indeed, the devils avert them from the way [of guidance] while they think that they are [rightly] guided"
  },
  {
    "id": 38,
    "text": "Until, when he comes to Us [at Judgement], he says [to his companion], \"Oh, I wish there was between me and you the distance between the east and west - how wretched a companion"
  },
  {
    "id": 39,
    "text": "And never will it benefit you that Day, when you have wronged, that you are [all] sharing in the punishment"
  },
  {
    "id": 40,
    "text": "Then will you make the deaf hear, [O Muhammad], or guide the blind or he who is in clear error"
  },
  {
    "id": 41,
    "text": "And whether [or not] We take you away [in death], indeed, We will take retribution upon them"
  },
  {
    "id": 42,
    "text": "Or whether [or not] We show you that which We have promised them, indeed, We are Perfect in Ability"
  },
  {
    "id": 43,
    "text": "So adhere to that which is revealed to you. Indeed, you are on a straight path"
  },
  {
    "id": 44,
    "text": "And indeed, it is a remembrance for you and your people, and you [all] are going to be questioned"
  },
  {
    "id": 45,
    "text": "And ask those We sent before you of Our messengers; have We made besides the Most Merciful deities to be worshipped"
  },
  {
    "id": 46,
    "text": "And certainly did We send Moses with Our signs to Pharaoh and his establishment, and he said, \"Indeed, I am the messenger of the Lord of the worlds"
  },
  {
    "id": 47,
    "text": "But when he brought them Our signs, at once they laughed at them"
  },
  {
    "id": 48,
    "text": "And We showed them not a sign except that it was greater than its sister, and We seized them with affliction that perhaps they might return [to faith]"
  },
  {
    "id": 49,
    "text": "And they said [to Moses], \"O magician, invoke for us your Lord by what He has promised you. Indeed, we will be guided"
  },
  {
    "id": 50,
    "text": "But when We removed from them the affliction, at once they broke their word"
  },
  {
    "id": 51,
    "text": "And Pharaoh called out among his people; he said, \"O my people, does not the kingdom of Egypt belong to me, and these rivers flowing beneath me; then do you not see"
  },
  {
    "id": 52,
    "text": "Or am I [not] better than this one who is insignificant and hardly makes himself clear"
  },
  {
    "id": 53,
    "text": "Then why have there not been placed upon him bracelets of gold or come with him the angels in conjunction"
  },
  {
    "id": 54,
    "text": "So he bluffed his people, and they obeyed him. Indeed, they were [themselves] a people defiantly disobedient [of Allah]"
  },
  {
    "id": 55,
    "text": "And when they angered Us, We took retribution from them and drowned them all"
  },
  {
    "id": 56,
    "text": "And We made them a precedent and an example for the later peoples"
  },
  {
    "id": 57,
    "text": "And when the son of Mary was presented as an example, immediately your people laughed aloud"
  },
  {
    "id": 58,
    "text": "And they said, \"Are your gods better, or is he?\" They did not present the comparison except for [mere] argument. But, [in fact], they are a people prone to dispute"
  },
  {
    "id": 59,
    "text": "Jesus was not but a servant upon whom We bestowed favor, and We made him an example for the Children of Israel"
  },
  {
    "id": 60,
    "text": "And if We willed, We could have made [instead] of you angels succeeding [one another] on the earth"
  },
  {
    "id": 61,
    "text": "And indeed, Jesus will be [a sign for] knowledge of the Hour, so be not in doubt of it, and follow Me. This is a straight path"
  },
  {
    "id": 62,
    "text": "And never let Satan avert you. Indeed, he is to you a clear enemy"
  },
  {
    "id": 63,
    "text": "And when Jesus brought clear proofs, he said, \"I have come to you with wisdom and to make clear to you some of that over which you differ, so fear Allah and obey me"
  },
  {
    "id": 64,
    "text": "Indeed, Allah is my Lord and your Lord, so worship Him. This is a straight path"
  },
  {
    "id": 65,
    "text": "But the denominations from among them differed [and separated], so woe to those who have wronged from the punishment of a painful Day"
  },
  {
    "id": 66,
    "text": "Are they waiting except for the Hour to come upon them suddenly while they perceive not"
  },
  {
    "id": 67,
    "text": "Close friends, that Day, will be enemies to each other, except for the righteous"
  },
  {
    "id": 68,
    "text": "[To whom Allah will say], \"O My servants, no fear will there be concerning you this Day, nor will you grieve"
  },
  {
    "id": 69,
    "text": "[You] who believed in Our verses and were Muslims"
  },
  {
    "id": 70,
    "text": "Enter Paradise, you and your kinds, delighted"
  },
  {
    "id": 71,
    "text": "Circulated among them will be plates and vessels of gold. And therein is whatever the souls desire and [what] delights the eyes, and you will abide therein eternally"
  },
  {
    "id": 72,
    "text": "And that is Paradise which you are made to inherit for what you used to do"
  },
  {
    "id": 73,
    "text": "For you therein is much fruit from which you will eat"
  },
  {
    "id": 74,
    "text": "Indeed, the criminals will be in the punishment of Hell, abiding eternally"
  },
  {
    "id": 75,
    "text": "It will not be allowed to subside for them, and they, therein, are in despair"
  },
  {
    "id": 76,
    "text": "And We did not wrong them, but it was they who were the wrongdoers"
  },
  {
    "id": 77,
    "text": "And they will call, \"O Malik, let your Lord put an end to us!\" He will say, \"Indeed, you will remain"
  },
  {
    "id": 78,
    "text": "We had certainly brought you the truth, but most of you, to the truth, were averse"
  },
  {
    "id": 79,
    "text": "Or have they devised [some] affair? But indeed, We are devising [a plan]"
  },
  {
    "id": 80,
    "text": "Or do they think that We hear not their secrets and their private conversations? Yes, [We do], and Our messengers are with them recording"
  },
  {
    "id": 81,
    "text": "Say, [O Muhammad], \"If the Most Merciful had a son, then I would be the first of [his] worshippers"
  },
  {
    "id": 82,
    "text": "Exalted is the Lord of the heavens and the earth, Lord of the Throne, above what they describe"
  },
  {
    "id": 83,
    "text": "So leave them to converse vainly and amuse themselves until they meet their Day which they are promised"
  },
  {
    "id": 84,
    "text": "And it is Allah who is [the only] deity in the heaven, and on the earth [the only] deity. And He is the Wise, the Knowing"
  },
  {
    "id": 85,
    "text": "And blessed is He to whom belongs the dominion of the heavens and the earth and whatever is between them and with whom is knowledge of the Hour and to whom you will be returned"
  },
  {
    "id": 86,
    "text": "And those they invoke besides Him do not possess [power of] intercession; but only those who testify to the truth [can benefit], and they know"
  },
  {
    "id": 87,
    "text": "And if you asked them who created them, they would surely say, \"Allah.\" So how are they deluded"
  },
  {
    "id": 88,
    "text": "And [Allah acknowledges] his saying, \"O my Lord, indeed these are a people who do not believe"
  },
  {
    "id": 89,
    "text": "So turn aside from them and say, \"Peace.\" But they are going to know"
  }
]

export default en
