import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "[All] praise is [due] to Allah, who created the heavens and the earth and made the darkness and the light. Then those who disbelieve equate [others] with their Lord"
  },
  {
    "id": 2,
    "text": "It is He who created you from clay and then decreed a term and a specified time [known] to Him; then [still] you are in dispute"
  },
  {
    "id": 3,
    "text": "And He is Allah, [the only deity] in the heavens and the earth. He knows your secret and what you make public, and He knows that which you earn"
  },
  {
    "id": 4,
    "text": "And no sign comes to them from the signs of their Lord except that they turn away therefrom"
  },
  {
    "id": 5,
    "text": "For they had denied the truth when it came to them, but there is going to reach them the news of what they used to ridicule"
  },
  {
    "id": 6,
    "text": "Have they not seen how many generations We destroyed before them which We had established upon the earth as We have not established you? And We sent [rain from] the sky upon them in showers and made rivers flow beneath them; then We destroyed them for their sins and brought forth after them a generation of others"
  },
  {
    "id": 7,
    "text": "And even if We had sent down to you, [O Muhammad], a written scripture on a page and they touched it with their hands, the disbelievers would say, \"This is not but obvious magic"
  },
  {
    "id": 8,
    "text": "And they say, \"Why was there not sent down to him an angel?\" But if We had sent down an angel, the matter would have been decided; then they would not be reprieved"
  },
  {
    "id": 9,
    "text": "And if We had made him an angel, We would have made him [appear as] a man, and We would have covered them with that in which they cover themselves"
  },
  {
    "id": 10,
    "text": "And already were messengers ridiculed before you, but those who mocked them were enveloped by that which they used to ridicule"
  },
  {
    "id": 11,
    "text": "Say, \"Travel through the land; then observe how was the end of the deniers"
  },
  {
    "id": 12,
    "text": "Say, \"To whom belongs whatever is in the heavens and earth?\" Say, \"To Allah.\" He has decreed upon Himself mercy. He will surely assemble you for the Day of Resurrection, about which there is no doubt. Those who will lose themselves [that Day] do not believe"
  },
  {
    "id": 13,
    "text": "And to Him belongs that which reposes by night and by day, and He is the Hearing, the Knowing"
  },
  {
    "id": 14,
    "text": "Say, \"Is it other than Allah I should take as a protector, Creator of the heavens and the earth, while it is He who feeds and is not fed?\" Say, [O Muhammad], \"Indeed, I have been commanded to be the first [among you] who submit [to Allah] and [was commanded], 'Do not ever be of the polytheists"
  },
  {
    "id": 15,
    "text": "Say, \"Indeed I fear, if I should disobey my Lord, the punishment of a tremendous Day"
  },
  {
    "id": 16,
    "text": "He from whom it is averted that Day - [Allah] has granted him mercy. And that is the clear attainment"
  },
  {
    "id": 17,
    "text": "And if Allah should touch you with adversity, there is no remover of it except Him. And if He touches you with good - then He is over all things competent"
  },
  {
    "id": 18,
    "text": "And He is the subjugator over His servants. And He is the Wise, the Acquainted [with all]"
  },
  {
    "id": 19,
    "text": "Say, \"What thing is greatest in testimony?\" Say, \"Allah is witness between me and you. And this Qur'an was revealed to me that I may warn you thereby and whomever it reaches. Do you [truly] testify that with Allah there are other deities?\" Say, \"I will not testify [with you].\" Say, \"Indeed, He is but one God, and indeed, I am free of what you associate [with Him]"
  },
  {
    "id": 20,
    "text": "Those to whom We have given the Scripture recognize it as they recognize their [own] sons. Those who will lose themselves [in the Hereafter] do not believe"
  },
  {
    "id": 21,
    "text": "And who is more unjust than one who invents about Allah a lie or denies His verses? Indeed, the wrongdoers will not succeed"
  },
  {
    "id": 22,
    "text": "And [mention, O Muhammad], the Day We will gather them all together; then We will say to those who associated others with Allah, \"Where are your 'partners' that you used to claim [with Him]"
  },
  {
    "id": 23,
    "text": "Then there will be no [excuse upon] examination except they will say, \"By Allah, our Lord, we were not those who associated"
  },
  {
    "id": 24,
    "text": "See how they will lie about themselves. And lost from them will be what they used to invent"
  },
  {
    "id": 25,
    "text": "And among them are those who listen to you, but We have placed over their hearts coverings, lest they understand it, and in their ears deafness. And if they should see every sign, they will not believe in it. Even when they come to you arguing with you, those who disbelieve say, \"This is not but legends of the former peoples"
  },
  {
    "id": 26,
    "text": "And they prevent [others] from him and are [themselves] remote from him. And they do not destroy except themselves, but they perceive [it] not"
  },
  {
    "id": 27,
    "text": "If you could but see when they are made to stand before the Fire and will say, \"Oh, would that we could be returned [to life on earth] and not deny the signs of our Lord and be among the believers"
  },
  {
    "id": 28,
    "text": "But what they concealed before has [now] appeared to them. And even if they were returned, they would return to that which they were forbidden; and indeed, they are liars"
  },
  {
    "id": 29,
    "text": "And they say, \"There is none but our worldly life, and we will not be resurrected"
  },
  {
    "id": 30,
    "text": "If you could but see when they will be made to stand before their Lord. He will say, \"Is this not the truth?\" They will say, \"Yes, by our Lord.\" He will [then] say, \"So taste the punishment because you used to disbelieve"
  },
  {
    "id": 31,
    "text": "Those will have lost who deny the meeting with Allah, until when the Hour [of resurrection] comes upon them unexpectedly, they will say, \"Oh, [how great is] our regret over what we neglected concerning it,\" while they bear their burdens on their backs. Unquestionably, evil is that which they bear"
  },
  {
    "id": 32,
    "text": "And the worldly life is not but amusement and diversion; but the home of the Hereafter is best for those who fear Allah, so will you not reason"
  },
  {
    "id": 33,
    "text": "We know that you, [O Muhammad], are saddened by what they say. And indeed, they do not call you untruthful, but it is the verses of Allah that the wrongdoers reject"
  },
  {
    "id": 34,
    "text": "And certainly were messengers denied before you, but they were patient over [the effects of] denial, and they were harmed until Our victory came to them. And none can alter the words of Allah. And there has certainly come to you some information about the [previous] messengers"
  },
  {
    "id": 35,
    "text": "And if their evasion is difficult for you, then if you are able to seek a tunnel into the earth or a stairway into the sky to bring them a sign, [then do so]. But if Allah had willed, He would have united them upon guidance. So never be of the ignorant"
  },
  {
    "id": 36,
    "text": "Only those who hear will respond. But the dead - Allah will resurrect them; then to Him they will be returned"
  },
  {
    "id": 37,
    "text": "And they say, \"Why has a sign not been sent down to him from his Lord?\" Say, \"Indeed, Allah is Able to send down a sign, but most of them do not know"
  },
  {
    "id": 38,
    "text": "And there is no creature on [or within] the earth or bird that flies with its wings except [that they are] communities like you. We have not neglected in the Register a thing. Then unto their Lord they will be gathered"
  },
  {
    "id": 39,
    "text": "But those who deny Our verses are deaf and dumb within darknesses. Whomever Allah wills - He leaves astray; and whomever He wills - He puts him on a straight path"
  },
  {
    "id": 40,
    "text": "Say, \"Have you considered: if there came to you the punishment of Allah or there came to you the Hour - is it other than Allah you would invoke, if you should be truthful"
  },
  {
    "id": 41,
    "text": "No, it is Him [alone] you would invoke, and He would remove that for which you invoked Him if He willed, and you would forget what you associate [with Him]"
  },
  {
    "id": 42,
    "text": "And We have already sent [messengers] to nations before you, [O Muhammad]; then We seized them with poverty and hardship that perhaps they might humble themselves [to Us]"
  },
  {
    "id": 43,
    "text": "Then why, when Our punishment came to them, did they not humble themselves? But their hearts became hardened, and Satan made attractive to them that which they were doing"
  },
  {
    "id": 44,
    "text": "So when they forgot that by which they had been reminded, We opened to them the doors of every [good] thing until, when they rejoiced in that which they were given, We seized them suddenly, and they were [then] in despair"
  },
  {
    "id": 45,
    "text": "So the people that committed wrong were eliminated. And praise to Allah, Lord of the worlds"
  },
  {
    "id": 46,
    "text": "Say, \"Have you considered: if Allah should take away your hearing and your sight and set a seal upon your hearts, which deity other than Allah could bring them [back] to you?\" Look how we diversify the verses; then they [still] turn away"
  },
  {
    "id": 47,
    "text": "Say, \"Have you considered: if the punishment of Allah should come to you unexpectedly or manifestly, will any be destroyed but the wrongdoing people"
  },
  {
    "id": 48,
    "text": "And We send not the messengers except as bringers of good tidings and warners. So whoever believes and reforms - there will be no fear concerning them, nor will they grieve"
  },
  {
    "id": 49,
    "text": "But those who deny Our verses - the punishment will touch them for their defiant disobedience"
  },
  {
    "id": 50,
    "text": "Say, [O Muhammad], \"I do not tell you that I have the depositories [containing the provision] of Allah or that I know the unseen, nor do I tell you that I am an angel. I only follow what is revealed to me.\" Say, \"Is the blind equivalent to the seeing? Then will you not give thought"
  },
  {
    "id": 51,
    "text": "And warn by the Qur'an those who fear that they will be gathered before their Lord - for them besides Him will be no protector and no intercessor - that they might become righteous"
  },
  {
    "id": 52,
    "text": "And do not send away those who call upon their Lord morning and afternoon, seeking His countenance. Not upon you is anything of their account and not upon them is anything of your account. So were you to send them away, you would [then] be of the wrongdoers"
  },
  {
    "id": 53,
    "text": "And thus We have tried some of them through others that the disbelievers might say, \"Is it these whom Allah has favored among us?\" Is not Allah most knowing of those who are grateful"
  },
  {
    "id": 54,
    "text": "And when those come to you who believe in Our verses, say, \"Peace be upon you. Your Lord has decreed upon Himself mercy: that any of you who does wrong out of ignorance and then repents after that and corrects himself - indeed, He is Forgiving and Merciful"
  },
  {
    "id": 55,
    "text": "And thus do We detail the verses, and [thus] the way of the criminals will become evident"
  },
  {
    "id": 56,
    "text": "Say, \"Indeed, I have been forbidden to worship those you invoke besides Allah.\" Say, \"I will not follow your desires, for I would then have gone astray, and I would not be of the [rightly] guided"
  },
  {
    "id": 57,
    "text": "Say, \"Indeed, I am on clear evidence from my Lord, and you have denied it. I do not have that for which you are impatient. The decision is only for Allah. He relates the truth, and He is the best of deciders"
  },
  {
    "id": 58,
    "text": "Say, \"If I had that for which you are impatient, the matter would have been decided between me and you, but Allah is most knowing of the wrongdoers"
  },
  {
    "id": 59,
    "text": "And with Him are the keys of the unseen; none knows them except Him. And He knows what is on the land and in the sea. Not a leaf falls but that He knows it. And no grain is there within the darknesses of the earth and no moist or dry [thing] but that it is [written] in a clear record"
  },
  {
    "id": 60,
    "text": "And it is He who takes your souls by night and knows what you have committed by day. Then He revives you therein that a specified term may be fulfilled. Then to Him will be your return; then He will inform you about what you used to do"
  },
  {
    "id": 61,
    "text": "And He is the subjugator over His servants, and He sends over you guardian-angels until, when death comes to one of you, Our messengers take him, and they do not fail [in their duties]"
  },
  {
    "id": 62,
    "text": "Then they His servants are returned to Allah, their true Lord. Unquestionably, His is the judgement, and He is the swiftest of accountants"
  },
  {
    "id": 63,
    "text": "Say, \"Who rescues you from the darknesses of the land and sea [when] you call upon Him imploring [aloud] and privately, 'If He should save us from this [crisis], we will surely be among the thankful"
  },
  {
    "id": 64,
    "text": "Say, \"It is Allah who saves you from it and from every distress; then you [still] associate others with Him"
  },
  {
    "id": 65,
    "text": "Say, \"He is the [one] Able to send upon you affliction from above you or from beneath your feet or to confuse you [so you become] sects and make you taste the violence of one another.\" Look how We diversify the signs that they might understand"
  },
  {
    "id": 66,
    "text": "But your people have denied it while it is the truth. Say, \"I am not over you a manager"
  },
  {
    "id": 67,
    "text": "For every happening is a finality; and you are going to know"
  },
  {
    "id": 68,
    "text": "And when you see those who engage in [offensive] discourse concerning Our verses, then turn away from them until they enter into another conversation. And if Satan should cause you to forget, then do not remain after the reminder with the wrongdoing people"
  },
  {
    "id": 69,
    "text": "And those who fear Allah are not held accountable for the disbelievers at all, but [only for] a reminder - that perhaps they will fear Him"
  },
  {
    "id": 70,
    "text": "And leave those who take their religion as amusement and diversion and whom the worldly life has deluded. But remind with the Qur'an, lest a soul be given up to destruction for what it earned; it will have other than Allah no protector and no intercessor. And if it should offer every compensation, it would not be taken from it. Those are the ones who are given to destruction for what they have earned. For them will be a drink of scalding water and a painful punishment because they used to disbelieve"
  },
  {
    "id": 71,
    "text": "Say, \"Shall we invoke instead of Allah that which neither benefits us nor harms us and be turned back on our heels after Allah has guided us? [We would then be] like one whom the devils enticed [to wander] upon the earth confused, [while] he has companions inviting him to guidance, [calling], 'Come to us.' \" Say, \"Indeed, the guidance of Allah is the [only] guidance; and we have been commanded to submit to the Lord of the worlds"
  },
  {
    "id": 72,
    "text": "And to establish prayer and fear Him.\" And it is He to whom you will be gathered"
  },
  {
    "id": 73,
    "text": "And it is He who created the heavens and earth in truth. And the day He says, \"Be,\" and it is, His word is the truth. And His is the dominion [on] the Day the Horn is blown. [He is] Knower of the unseen and the witnessed; and He is the Wise, the Acquainted"
  },
  {
    "id": 74,
    "text": "And [mention, O Muhammad], when Abraham said to his father Azar, \"Do you take idols as deities? Indeed, I see you and your people to be in manifest error"
  },
  {
    "id": 75,
    "text": "And thus did We show Abraham the realm of the heavens and the earth that he would be among the certain [in faith]"
  },
  {
    "id": 76,
    "text": "So when the night covered him [with darkness], he saw a star. He said, \"This is my lord.\" But when it set, he said, \"I like not those that disappear"
  },
  {
    "id": 77,
    "text": "And when he saw the moon rising, he said, \"This is my lord.\" But when it set, he said, \"Unless my Lord guides me, I will surely be among the people gone astray"
  },
  {
    "id": 78,
    "text": "And when he saw the sun rising, he said, \"This is my lord; this is greater.\" But when it set, he said, \"O my people, indeed I am free from what you associate with Allah"
  },
  {
    "id": 79,
    "text": "Indeed, I have turned my face toward He who created the heavens and the earth, inclining toward truth, and I am not of those who associate others with Allah"
  },
  {
    "id": 80,
    "text": "And his people argued with him. He said, \"Do you argue with me concerning Allah while He has guided me? And I fear not what you associate with Him [and will not be harmed] unless my Lord should will something. My Lord encompasses all things in knowledge; then will you not remember"
  },
  {
    "id": 81,
    "text": "And how should I fear what you associate while you do not fear that you have associated with Allah that for which He has not sent down to you any authority? So which of the two parties has more right to security, if you should know"
  },
  {
    "id": 82,
    "text": "They who believe and do not mix their belief with injustice - those will have security, and they are [rightly] guided"
  },
  {
    "id": 83,
    "text": "And that was Our [conclusive] argument which We gave Abraham against his people. We raise by degrees whom We will. Indeed, your Lord is Wise and Knowing"
  },
  {
    "id": 84,
    "text": "And We gave to Abraham, Isaac and Jacob - all [of them] We guided. And Noah, We guided before; and among his descendants, David and Solomon and Job and Joseph and Moses and Aaron. Thus do We reward the doers of good"
  },
  {
    "id": 85,
    "text": "And Zechariah and John and Jesus and Elias - and all were of the righteous"
  },
  {
    "id": 86,
    "text": "And Ishmael and Elisha and Jonah and Lot - and all [of them] We preferred over the worlds"
  },
  {
    "id": 87,
    "text": "And [some] among their fathers and their descendants and their brothers - and We chose them and We guided them to a straight path"
  },
  {
    "id": 88,
    "text": "That is the guidance of Allah by which He guides whomever He wills of His servants. But if they had associated others with Allah, then worthless for them would be whatever they were doing"
  },
  {
    "id": 89,
    "text": "Those are the ones to whom We gave the Scripture and authority and prophethood. But if the disbelievers deny it, then We have entrusted it to a people who are not therein disbelievers"
  },
  {
    "id": 90,
    "text": "Those are the ones whom Allah has guided, so from their guidance take an example. Say, \"I ask of you for this message no payment. It is not but a reminder for the worlds"
  },
  {
    "id": 91,
    "text": "And they did not appraise Allah with true appraisal when they said, \"Allah did not reveal to a human being anything.\" Say, \"Who revealed the Scripture that Moses brought as light and guidance to the people? You [Jews] make it into pages, disclosing [some of] it and concealing much. And you were taught that which you knew not - neither you nor your fathers.\" Say, \"Allah [revealed it].\" Then leave them in their [empty] discourse, amusing themselves"
  },
  {
    "id": 92,
    "text": "And this is a Book which We have sent down, blessed and confirming what was before it, that you may warn the Mother of Cities and those around it. Those who believe in the Hereafter believe in it, and they are maintaining their prayers"
  },
  {
    "id": 93,
    "text": "And who is more unjust than one who invents a lie about Allah or says, \"It has been inspired to me,\" while nothing has been inspired to him, and one who says, \"I will reveal [something] like what Allah revealed.\" And if you could but see when the wrongdoers are in the overwhelming pangs of death while the angels extend their hands, [saying], \"Discharge your souls! Today you will be awarded the punishment of [extreme] humiliation for what you used to say against Allah other than the truth and [that] you were, toward His verses, being arrogant"
  },
  {
    "id": 94,
    "text": "[It will be said to them], \"And you have certainly come to Us alone as We created you the first time, and you have left whatever We bestowed upon you behind you. And We do not see with you your 'intercessors' which you claimed that they were among you associates [of Allah]. It has [all] been severed between you, and lost from you is what you used to claim"
  },
  {
    "id": 95,
    "text": "Indeed, Allah is the cleaver of grain and date seeds. He brings the living out of the dead and brings the dead out of the living. That is Allah; so how are you deluded"
  },
  {
    "id": 96,
    "text": "[He is] the cleaver of daybreak and has made the night for rest and the sun and moon for calculation. That is the determination of the Exalted in Might, the Knowing"
  },
  {
    "id": 97,
    "text": "And it is He who placed for you the stars that you may be guided by them through the darknesses of the land and sea. We have detailed the signs for a people who know"
  },
  {
    "id": 98,
    "text": "And it is He who produced you from one soul and [gave you] a place of dwelling and of storage. We have detailed the signs for a people who understand"
  },
  {
    "id": 99,
    "text": "And it is He who sends down rain from the sky, and We produce thereby the growth of all things. We produce from it greenery from which We produce grains arranged in layers. And from the palm trees - of its emerging fruit are clusters hanging low. And [We produce] gardens of grapevines and olives and pomegranates, similar yet varied. Look at [each of] its fruit when it yields and [at] its ripening. Indeed in that are signs for a people who believe"
  },
  {
    "id": 100,
    "text": "But they have attributed to Allah partners - the jinn, while He has created them - and have fabricated for Him sons and daughters. Exalted is He and high above what they describe"
  },
  {
    "id": 101,
    "text": "[He is] Originator of the heavens and the earth. How could He have a son when He does not have a companion and He created all things? And He is, of all things, Knowing"
  },
  {
    "id": 102,
    "text": "That is Allah, your Lord; there is no deity except Him, the Creator of all things, so worship Him. And He is Disposer of all things"
  },
  {
    "id": 103,
    "text": "Vision perceives Him not, but He perceives [all] vision; and He is the Subtle, the Acquainted"
  },
  {
    "id": 104,
    "text": "There has come to you enlightenment from your Lord. So whoever will see does so for [the benefit of] his soul, and whoever is blind [does harm] against it. And [say], \"I am not a guardian over you"
  },
  {
    "id": 105,
    "text": "And thus do We diversify the verses so the disbelievers will say, \"You have studied,\" and so We may make the Qur'an clear for a people who know"
  },
  {
    "id": 106,
    "text": "Follow, [O Muhammad], what has been revealed to you from your Lord - there is no deity except Him - and turn away from those who associate others with Allah"
  },
  {
    "id": 107,
    "text": "But if Allah had willed, they would not have associated. And We have not appointed you over them as a guardian, nor are you a manager over them"
  },
  {
    "id": 108,
    "text": "And do not insult those they invoke other than Allah, lest they insult Allah in enmity without knowledge. Thus We have made pleasing to every community their deeds. Then to their Lord is their return, and He will inform them about what they used to do"
  },
  {
    "id": 109,
    "text": "And they swear by Allah their strongest oaths that if a sign came to them, they would surely believe in it. Say, \"The signs are only with Allah.\" And what will make you perceive that even if a sign came, they would not believe"
  },
  {
    "id": 110,
    "text": "And We will turn away their hearts and their eyes just as they refused to believe in it the first time. And We will leave them in their transgression, wandering blindly"
  },
  {
    "id": 111,
    "text": "And even if We had sent down to them the angels [with the message] and the dead spoke to them [of it] and We gathered together every [created] thing in front of them, they would not believe unless Allah should will. But most of them, [of that], are ignorant"
  },
  {
    "id": 112,
    "text": "And thus We have made for every prophet an enemy - devils from mankind and jinn, inspiring to one another decorative speech in delusion. But if your Lord had willed, they would not have done it, so leave them and that which they invent"
  },
  {
    "id": 113,
    "text": "And [it is] so the hearts of those who disbelieve in the Hereafter will incline toward it and that they will be satisfied with it and that they will commit that which they are committing"
  },
  {
    "id": 114,
    "text": "[Say], \"Then is it other than Allah I should seek as judge while it is He who has revealed to you the Book explained in detail?\" And those to whom We [previously] gave the Scripture know that it is sent down from your Lord in truth, so never be among the doubters"
  },
  {
    "id": 115,
    "text": "And the word of your Lord has been fulfilled in truth and in justice. None can alter His words, and He is the Hearing, the Knowing"
  },
  {
    "id": 116,
    "text": "And if you obey most of those upon the earth, they will mislead you from the way of Allah. They follow not except assumption, and they are not but falsifying"
  },
  {
    "id": 117,
    "text": "Indeed, your Lord is most knowing of who strays from His way, and He is most knowing of the [rightly] guided"
  },
  {
    "id": 118,
    "text": "So eat of that [meat] upon which the name of Allah has been mentioned, if you are believers in His verses"
  },
  {
    "id": 119,
    "text": "And why should you not eat of that upon which the name of Allah has been mentioned while He has explained in detail to you what He has forbidden you, excepting that to which you are compelled. And indeed do many lead [others] astray through their [own] inclinations without knowledge. Indeed, your Lord - He is most knowing of the transgressors"
  },
  {
    "id": 120,
    "text": "And leave what is apparent of sin and what is concealed thereof. Indeed, those who earn [blame for] sin will be recompensed for that which they used to commit"
  },
  {
    "id": 121,
    "text": "And do not eat of that upon which the name of Allah has not been mentioned, for indeed, it is grave disobedience. And indeed do the devils inspire their allies [among men] to dispute with you. And if you were to obey them, indeed, you would be associators [of others with Him]"
  },
  {
    "id": 122,
    "text": "And is one who was dead and We gave him life and made for him light by which to walk among the people like one who is in darkness, never to emerge therefrom? Thus it has been made pleasing to the disbelievers that which they were doing"
  },
  {
    "id": 123,
    "text": "And thus We have placed within every city the greatest of its criminals to conspire therein. But they conspire not except against themselves, and they perceive [it] not"
  },
  {
    "id": 124,
    "text": "And when a sign comes to them, they say, \"Never will we believe until we are given like that which was given to the messengers of Allah.\" Allah is most knowing of where He places His message. There will afflict those who committed crimes debasement before Allah and severe punishment for what they used to conspire"
  },
  {
    "id": 125,
    "text": "So whoever Allah wants to guide - He expands his breast to [contain] Islam; and whoever He wants to misguide - He makes his breast tight and constricted as though he were climbing into the sky. Thus does Allah place defilement upon those who do not believe"
  },
  {
    "id": 126,
    "text": "And this is the path of your Lord, [leading] straight. We have detailed the verses for a people who remember"
  },
  {
    "id": 127,
    "text": "For them will be the Home of Peace with their Lord. And He will be their protecting friend because of what they used to do"
  },
  {
    "id": 128,
    "text": "And [mention, O Muhammad], the Day when He will gather them together [and say], \"O company of jinn, you have [misled] many of mankind.\" And their allies among mankind will say, \"Our Lord, some of us made use of others, and we have [now] reached our term, which you appointed for us.\" He will say, \"The Fire is your residence, wherein you will abide eternally, except for what Allah wills. Indeed, your Lord is Wise and Knowing"
  },
  {
    "id": 129,
    "text": "And thus will We make some of the wrongdoers allies of others for what they used to earn"
  },
  {
    "id": 130,
    "text": "O company of jinn and mankind, did there not come to you messengers from among you, relating to you My verses and warning you of the meeting of this Day of yours?\" They will say, \"We bear witness against ourselves\"; and the worldly life had deluded them, and they will bear witness against themselves that they were disbelievers"
  },
  {
    "id": 131,
    "text": "That is because your Lord would not destroy the cities for wrongdoing while their people were unaware"
  },
  {
    "id": 132,
    "text": "And for all are degrees from what they have done. And your Lord is not unaware of what they do"
  },
  {
    "id": 133,
    "text": "And your Lord is the Free of need, the possessor of mercy. If He wills, he can do away with you and give succession after you to whomever He wills, just as He produced you from the descendants of another people"
  },
  {
    "id": 134,
    "text": "Indeed, what you are promised is coming, and you will not cause failure [to Allah]"
  },
  {
    "id": 135,
    "text": "Say, \"O my people, work according to your position; [for] indeed, I am working. And you are going to know who will have succession in the home. Indeed, the wrongdoers will not succeed"
  },
  {
    "id": 136,
    "text": "And the polytheists assign to Allah from that which He created of crops and livestock a share and say, \"This is for Allah,\" by their claim, \"and this is for our partners [associated with Him].\" But what is for their \"partners\" does not reach Allah, while what is for Allah - this reaches their \"partners.\" Evil is that which they rule"
  },
  {
    "id": 137,
    "text": "And likewise, to many of the polytheists their partners have made [to seem] pleasing the killing of their children in order to bring about their destruction and to cover them with confusion in their religion. And if Allah had willed, they would not have done so. So leave them and that which they invent"
  },
  {
    "id": 138,
    "text": "And they say, \"These animals and crops are forbidden; no one may eat from them except whom we will,\" by their claim. And there are those [camels] whose backs are forbidden [by them] and those upon which the name of Allah is not mentioned - [all of this] an invention of untruth about Him. He will punish them for what they were inventing"
  },
  {
    "id": 139,
    "text": "And they say, \"What is in the bellies of these animals is exclusively for our males and forbidden to our females. But if it is [born] dead, then all of them have shares therein.\" He will punish them for their description. Indeed, He is Wise and Knowing"
  },
  {
    "id": 140,
    "text": "Those will have lost who killed their children in foolishness without knowledge and prohibited what Allah had provided for them, inventing untruth about Allah. They have gone astray and were not [rightly] guided"
  },
  {
    "id": 141,
    "text": "And He it is who causes gardens to grow, [both] trellised and untrellised, and palm trees and crops of different [kinds of] food and olives and pomegranates, similar and dissimilar. Eat of [each of] its fruit when it yields and give its due [zakah] on the day of its harvest. And be not excessive. Indeed, He does not like those who commit excess"
  },
  {
    "id": 142,
    "text": "And of the grazing livestock are carriers [of burdens] and those [too] small. Eat of what Allah has provided for you and do not follow the footsteps of Satan. Indeed, he is to you a clear enemy"
  },
  {
    "id": 143,
    "text": "[They are] eight mates - of the sheep, two and of the goats, two. Say, \"Is it the two males He has forbidden or the two females or that which the wombs of the two females contain? Inform me with knowledge, if you should be truthful"
  },
  {
    "id": 144,
    "text": "And of the camels, two and of the cattle, two. Say, \"Is it the two males He has forbidden or the two females or that which the wombs of the two females contain? Or were you witnesses when Allah charged you with this? Then who is more unjust than one who invents a lie about Allah to mislead the people by [something] other than knowledge? Indeed, Allah does not guide the wrongdoing people"
  },
  {
    "id": 145,
    "text": "Say, \"I do not find within that which was revealed to me [anything] forbidden to one who would eat it unless it be a dead animal or blood spilled out or the flesh of swine - for indeed, it is impure - or it be [that slaughtered in] disobedience, dedicated to other than Allah. But whoever is forced [by necessity], neither desiring [it] nor transgressing [its limit], then indeed, your Lord is Forgiving and Merciful"
  },
  {
    "id": 146,
    "text": "And to those who are Jews We prohibited every animal of uncloven hoof; and of the cattle and the sheep We prohibited to them their fat, except what adheres to their backs or the entrails or what is joined with bone. [By] that We repaid them for their injustice. And indeed, We are truthful"
  },
  {
    "id": 147,
    "text": "So if they deny you, [O Muhammad], say, \"Your Lord is the possessor of vast mercy; but His punishment cannot be repelled from the people who are criminals"
  },
  {
    "id": 148,
    "text": "Those who associated with Allah will say, \"If Allah had willed, we would not have associated [anything] and neither would our fathers, nor would we have prohibited anything.\" Likewise did those before deny until they tasted Our punishment. Say, \"Do you have any knowledge that you can produce for us? You follow not except assumption, and you are not but falsifying"
  },
  {
    "id": 149,
    "text": "Say, \"With Allah is the far-reaching argument. If He had willed, He would have guided you all"
  },
  {
    "id": 150,
    "text": "Say, [O Muhammad], \"Bring forward your witnesses who will testify that Allah has prohibited this.\" And if they testify, do not testify with them. And do not follow the desires of those who deny Our verses and those who do not believe in the Hereafter, while they equate [others] with their Lord"
  },
  {
    "id": 151,
    "text": "Say, \"Come, I will recite what your Lord has prohibited to you. [He commands] that you not associate anything with Him, and to parents, good treatment, and do not kill your children out of poverty; We will provide for you and them. And do not approach immoralities - what is apparent of them and what is concealed. And do not kill the soul which Allah has forbidden [to be killed] except by [legal] right. This has He instructed you that you may use reason"
  },
  {
    "id": 152,
    "text": "And do not approach the orphan's property except in a way that is best until he reaches maturity. And give full measure and weight in justice. We do not charge any soul except [with that within] its capacity. And when you testify, be just, even if [it concerns] a near relative. And the covenant of Allah fulfill. This has He instructed you that you may remember"
  },
  {
    "id": 153,
    "text": "And, [moreover], this is My path, which is straight, so follow it; and do not follow [other] ways, for you will be separated from His way. This has He instructed you that you may become righteous"
  },
  {
    "id": 154,
    "text": "Then We gave Moses the Scripture, making complete [Our favor] upon the one who did good and as a detailed explanation of all things and as guidance and mercy that perhaps in [the matter of] the meeting with their Lord they would believe"
  },
  {
    "id": 155,
    "text": "And this [Qur'an] is a Book We have revealed [which is] blessed, so follow it and fear Allah that you may receive mercy"
  },
  {
    "id": 156,
    "text": "[We revealed it] lest you say, \"The Scripture was only sent down to two groups before us, but we were of their study unaware"
  },
  {
    "id": 157,
    "text": "Or lest you say, \"If only the Scripture had been revealed to us, we would have been better guided than they.\" So there has [now] come to you a clear evidence from your Lord and a guidance and mercy. Then who is more unjust than one who denies the verses of Allah and turns away from them? We will recompense those who turn away from Our verses with the worst of punishment for their having turned away"
  },
  {
    "id": 158,
    "text": "Do they [then] wait for anything except that the angels should come to them or your Lord should come or that there come some of the signs of your Lord? The Day that some of the signs of your Lord will come no soul will benefit from its faith as long as it had not believed before or had earned through its faith some good. Say, \"Wait. Indeed, we [also] are waiting"
  },
  {
    "id": 159,
    "text": "Indeed, those who have divided their religion and become sects - you, [O Muhammad], are not [associated] with them in anything. Their affair is only [left] to Allah; then He will inform them about what they used to do"
  },
  {
    "id": 160,
    "text": "Whoever comes [on the Day of Judgement] with a good deed will have ten times the like thereof [to his credit], and whoever comes with an evil deed will not be recompensed except the like thereof; and they will not be wronged"
  },
  {
    "id": 161,
    "text": "Say, \"Indeed, my Lord has guided me to a straight path - a correct religion - the way of Abraham, inclining toward truth. And he was not among those who associated others with Allah"
  },
  {
    "id": 162,
    "text": "Say, \"Indeed, my prayer, my rites of sacrifice, my living and my dying are for Allah, Lord of the worlds"
  },
  {
    "id": 163,
    "text": "No partner has He. And this I have been commanded, and I am the first [among you] of the Muslims"
  },
  {
    "id": 164,
    "text": "Say, \"Is it other than Allah I should desire as a lord while He is the Lord of all things? And every soul earns not [blame] except against itself, and no bearer of burdens will bear the burden of another. Then to your Lord is your return, and He will inform you concerning that over which you used to differ"
  },
  {
    "id": 165,
    "text": "And it is He who has made you successors upon the earth and has raised some of you above others in degrees [of rank] that He may try you through what He has given you. Indeed, your Lord is swift in penalty; but indeed, He is Forgiving and Merciful"
  }
]

export default en
