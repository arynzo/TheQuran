import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "[This is a declaration of] disassociation, from Allah and His Messenger, to those with whom you had made a treaty among the polytheists"
  },
  {
    "id": 2,
    "text": "So travel freely, [O disbelievers], throughout the land [during] four months but know that you cannot cause failure to Allah and that Allah will disgrace the disbelievers"
  },
  {
    "id": 3,
    "text": "And [it is] an announcement from Allah and His Messenger to the people on the day of the greater pilgrimage that Allah is disassociated from the disbelievers, and [so is] His Messenger. So if you repent, that is best for you; but if you turn away - then know that you will not cause failure to Allah. And give tidings to those who disbelieve of a painful punishment"
  },
  {
    "id": 4,
    "text": "Excepted are those with whom you made a treaty among the polytheists and then they have not been deficient toward you in anything or supported anyone against you; so complete for them their treaty until their term [has ended]. Indeed, Allah loves the righteous [who fear Him]"
  },
  {
    "id": 5,
    "text": "And when the sacred months have passed, then kill the polytheists wherever you find them and capture them and besiege them and sit in wait for them at every place of ambush. But if they should repent, establish prayer, and give zakah, let them [go] on their way. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 6,
    "text": "And if any one of the polytheists seeks your protection, then grant him protection so that he may hear the words of Allah. Then deliver him to his place of safety. That is because they are a people who do not know"
  },
  {
    "id": 7,
    "text": "How can there be for the polytheists a treaty in the sight of Allah and with His Messenger, except for those with whom you made a treaty at al-Masjid al-Haram? So as long as they are upright toward you, be upright toward them. Indeed, Allah loves the righteous [who fear Him]"
  },
  {
    "id": 8,
    "text": "How [can there be a treaty] while, if they gain dominance over you, they do not observe concerning you any pact of kinship or covenant of protection? They satisfy you with their mouths, but their hearts refuse [compliance], and most of them are defiantly disobedient"
  },
  {
    "id": 9,
    "text": "They have exchanged the signs of Allah for a small price and averted [people] from His way. Indeed, it was evil that they were doing"
  },
  {
    "id": 10,
    "text": "They do not observe toward a believer any pact of kinship or covenant of protection. And it is they who are the transgressors"
  },
  {
    "id": 11,
    "text": "But if they repent, establish prayer, and give zakah, then they are your brothers in religion; and We detail the verses for a people who know"
  },
  {
    "id": 12,
    "text": "And if they break their oaths after their treaty and defame your religion, then fight the leaders of disbelief, for indeed, there are no oaths [sacred] to them; [fight them that] they might cease"
  },
  {
    "id": 13,
    "text": "Would you not fight a people who broke their oaths and determined to expel the Messenger, and they had begun [the attack upon] you the first time? Do you fear them? But Allah has more right that you should fear Him, if you are [truly] believers"
  },
  {
    "id": 14,
    "text": "Fight them; Allah will punish them by your hands and will disgrace them and give you victory over them and satisfy the breasts of a believing people"
  },
  {
    "id": 15,
    "text": "And remove the fury in the believers' hearts. And Allah turns in forgiveness to whom He wills; and Allah is Knowing and Wise"
  },
  {
    "id": 16,
    "text": "Do you think that you will be left [as you are] while Allah has not yet made evident those among you who strive [for His cause] and do not take other than Allah, His Messenger and the believers as intimates? And Allah is Acquainted with what you do"
  },
  {
    "id": 17,
    "text": "It is not for the polytheists to maintain the mosques of Allah [while] witnessing against themselves with disbelief. [For] those, their deeds have become worthless, and in the Fire they will abide eternally"
  },
  {
    "id": 18,
    "text": "The mosques of Allah are only to be maintained by those who believe in Allah and the Last Day and establish prayer and give zakah and do not fear except Allah, for it is expected that those will be of the [rightly] guided"
  },
  {
    "id": 19,
    "text": "Have you made the providing of water for the pilgrim and the maintenance of al-Masjid al-Haram equal to [the deeds of] one who believes in Allah and the Last Day and strives in the cause of Allah? They are not equal in the sight of Allah. And Allah does not guide the wrongdoing people"
  },
  {
    "id": 20,
    "text": "The ones who have believed, emigrated and striven in the cause of Allah with their wealth and their lives are greater in rank in the sight of Allah. And it is those who are the attainers [of success]"
  },
  {
    "id": 21,
    "text": "Their Lord gives them good tidings of mercy from Him and approval and of gardens for them wherein is enduring pleasure"
  },
  {
    "id": 22,
    "text": "[They will be] abiding therein forever. Indeed, Allah has with Him a great reward"
  },
  {
    "id": 23,
    "text": "O you who have believed, do not take your fathers or your brothers as allies if they have preferred disbelief over belief. And whoever does so among you - then it is those who are the wrongdoers"
  },
  {
    "id": 24,
    "text": "Say, [O Muhammad], \"If your fathers, your sons, your brothers, your wives, your relatives, wealth which you have obtained, commerce wherein you fear decline, and dwellings with which you are pleased are more beloved to you than Allah and His Messenger and jihad in His cause, then wait until Allah executes His command. And Allah does not guide the defiantly disobedient people"
  },
  {
    "id": 25,
    "text": "Allah has already given you victory in many regions and [even] on the day of Hunayn, when your great number pleased you, but it did not avail you at all, and the earth was confining for you with its vastness; then you turned back, fleeing"
  },
  {
    "id": 26,
    "text": "Then Allah sent down His tranquillity upon His Messenger and upon the believers and sent down soldiers angels whom you did not see and punished those who disbelieved. And that is the recompense of the disbelievers"
  },
  {
    "id": 27,
    "text": "Then Allah will accept repentance after that for whom He wills; and Allah is Forgiving and Merciful"
  },
  {
    "id": 28,
    "text": "O you who have believed, indeed the polytheists are unclean, so let them not approach al-Masjid al-Haram after this, their [final] year. And if you fear privation, Allah will enrich you from His bounty if He wills. Indeed, Allah is Knowing and Wise"
  },
  {
    "id": 29,
    "text": "Fight those who do not believe in Allah or in the Last Day and who do not consider unlawful what Allah and His Messenger have made unlawful and who do not adopt the religion of truth from those who were given the Scripture - [fight] until they give the jizyah willingly while they are humbled"
  },
  {
    "id": 30,
    "text": "The Jews say, \"Ezra is the son of Allah \"; and the Christians say, \"The Messiah is the son of Allah.\" That is their statement from their mouths; they imitate the saying of those who disbelieved [before them]. May Allah destroy them; how are they deluded"
  },
  {
    "id": 31,
    "text": "They have taken their scholars and monks as lords besides Allah, and [also] the Messiah, the son of Mary. And they were not commanded except to worship one God; there is no deity except Him. Exalted is He above whatever they associate with Him"
  },
  {
    "id": 32,
    "text": "They want to extinguish the light of Allah with their mouths, but Allah refuses except to perfect His light, although the disbelievers dislike it"
  },
  {
    "id": 33,
    "text": "It is He who has sent His Messenger with guidance and the religion of truth to manifest it over all religion, although they who associate others with Allah dislike it"
  },
  {
    "id": 34,
    "text": "O you who have believed, indeed many of the scholars and the monks devour the wealth of people unjustly and avert [them] from the way of Allah. And those who hoard gold and silver and spend it not in the way of Allah - give them tidings of a painful punishment"
  },
  {
    "id": 35,
    "text": "The Day when it will be heated in the fire of Hell and seared therewith will be their foreheads, their flanks, and their backs, [it will be said], \"This is what you hoarded for yourselves, so taste what you used to hoard"
  },
  {
    "id": 36,
    "text": "Indeed, the number of months with Allah is twelve [lunar] months in the register of Allah [from] the day He created the heavens and the earth; of these, four are sacred. That is the correct religion, so do not wrong yourselves during them. And fight against the disbelievers collectively as they fight against you collectively. And know that Allah is with the righteous [who fear Him]"
  },
  {
    "id": 37,
    "text": "Indeed, the postponing [of restriction within sacred months] is an increase in disbelief by which those who have disbelieved are led [further] astray. They make it lawful one year and unlawful another year to correspond to the number made unlawful by Allah and [thus] make lawful what Allah has made unlawful. Made pleasing to them is the evil of their deeds; and Allah does not guide the disbelieving people"
  },
  {
    "id": 38,
    "text": "O you who have believed, what is [the matter] with you that, when you are told to go forth in the cause of Allah, you adhere heavily to the earth? Are you satisfied with the life of this world rather than the Hereafter? But what is the enjoyment of worldly life compared to the Hereafter except a [very] little"
  },
  {
    "id": 39,
    "text": "If you do not go forth, He will punish you with a painful punishment and will replace you with another people, and you will not harm Him at all. And Allah is over all things competent"
  },
  {
    "id": 40,
    "text": "If you do not aid the Prophet - Allah has already aided him when those who disbelieved had driven him out [of Makkah] as one of two, when they were in the cave and he said to his companion, \"Do not grieve; indeed Allah is with us.\" And Allah sent down his tranquillity upon him and supported him with angels you did not see and made the word of those who disbelieved the lowest, while the word of Allah - that is the highest. And Allah is Exalted in Might and Wise"
  },
  {
    "id": 41,
    "text": "Go forth, whether light or heavy, and strive with your wealth and your lives in the cause of Allah. That is better for you, if you only knew"
  },
  {
    "id": 42,
    "text": "Had it been an easy gain and a moderate trip, the hypocrites would have followed you, but distant to them was the journey. And they will swear by Allah, \"If we were able, we would have gone forth with you,\" destroying themselves [through false oaths], and Allah knows that indeed they are liars"
  },
  {
    "id": 43,
    "text": "May Allah pardon you, [O Muhammad]; why did you give them permission [to remain behind]? [You should not have] until it was evident to you who were truthful and you knew [who were] the liars"
  },
  {
    "id": 44,
    "text": "Those who believe in Allah and the Last Day would not ask permission of you to be excused from striving with their wealth and their lives. And Allah is Knowing of those who fear Him"
  },
  {
    "id": 45,
    "text": "Only those would ask permission of you who do not believe in Allah and the Last Day and whose hearts have doubted, and they, in their doubt, are hesitating"
  },
  {
    "id": 46,
    "text": "And if they had intended to go forth, they would have prepared for it [some] preparation. But Allah disliked their being sent, so He kept them back, and they were told, \"Remain [behind] with those who remain"
  },
  {
    "id": 47,
    "text": "Had they gone forth with you, they would not have increased you except in confusion, and they would have been active among you, seeking [to cause] you fitnah. And among you are avid listeners to them. And Allah is Knowing of the wrongdoers"
  },
  {
    "id": 48,
    "text": "They had already desired dissension before and had upset matters for you until the truth came and the ordinance of Allah appeared, while they were averse"
  },
  {
    "id": 49,
    "text": "And among them is he who says, \"Permit me [to remain at home] and do not put me to trial.\" Unquestionably, into trial they have fallen. And indeed, Hell will encompass the disbelievers"
  },
  {
    "id": 50,
    "text": "If good befalls you, it distresses them; but if disaster strikes you, they say, \"We took our matter [in hand] before,\" and turn away while they are rejoicing"
  },
  {
    "id": 51,
    "text": "Say, \"Never will we be struck except by what Allah has decreed for us; He is our protector.\" And upon Allah let the believers rely"
  },
  {
    "id": 52,
    "text": "Say, \"Do you await for us except one of the two best things while we await for you that Allah will afflict you with punishment from Himself or at our hands? So wait; indeed we, along with you, are waiting"
  },
  {
    "id": 53,
    "text": "Say, \"Spend willingly or unwillingly; never will it be accepted from you. Indeed, you have been a defiantly disobedient people"
  },
  {
    "id": 54,
    "text": "And what prevents their expenditures from being accepted from them but that they have disbelieved in Allah and in His Messenger and that they come not to prayer except while they are lazy and that they do not spend except while they are unwilling"
  },
  {
    "id": 55,
    "text": "So let not their wealth or their children impress you. Allah only intends to punish them through them in worldly life and that their souls should depart [at death] while they are disbelievers"
  },
  {
    "id": 56,
    "text": "And they swear by Allah that they are from among you while they are not from among you; but they are a people who are afraid"
  },
  {
    "id": 57,
    "text": "If they could find a refuge or some caves or any place to enter [and hide], they would turn to it while they run heedlessly"
  },
  {
    "id": 58,
    "text": "And among them are some who criticize you concerning the [distribution of] charities. If they are given from them, they approve; but if they are not given from them, at once they become angry"
  },
  {
    "id": 59,
    "text": "If only they had been satisfied with what Allah and His Messenger gave them and said, \"Sufficient for us is Allah; Allah will give us of His bounty, and [so will] His Messenger; indeed, we are desirous toward Allah,\" [it would have been better for them]"
  },
  {
    "id": 60,
    "text": "Zakah expenditures are only for the poor and for the needy and for those employed to collect [zakah] and for bringing hearts together [for Islam] and for freeing captives [or slaves] and for those in debt and for the cause of Allah and for the [stranded] traveler - an obligation [imposed] by Allah. And Allah is Knowing and Wise"
  },
  {
    "id": 61,
    "text": "And among them are those who abuse the Prophet and say, \"He is an ear.\" Say, \"[It is] an ear of goodness for you that believes in Allah and believes the believers and [is] a mercy to those who believe among you.\" And those who abuse the Messenger of Allah - for them is a painful punishment"
  },
  {
    "id": 62,
    "text": "They swear by Allah to you [Muslims] to satisfy you. But Allah and His Messenger are more worthy for them to satisfy, if they should be believers"
  },
  {
    "id": 63,
    "text": "Do they not know that whoever opposes Allah and His Messenger - that for him is the fire of Hell, wherein he will abide eternally? That is the great disgrace"
  },
  {
    "id": 64,
    "text": "They hypocrites are apprehensive lest a surah be revealed about them, informing them of what is in their hearts. Say, \"Mock [as you wish]; indeed, Allah will expose that which you fear"
  },
  {
    "id": 65,
    "text": "And if you ask them, they will surely say, \"We were only conversing and playing.\" Say, \"Is it Allah and His verses and His Messenger that you were mocking"
  },
  {
    "id": 66,
    "text": "Make no excuse; you have disbelieved after your belief. If We pardon one faction of you - We will punish another faction because they were criminals"
  },
  {
    "id": 67,
    "text": "The hypocrite men and hypocrite women are of one another. They enjoin what is wrong and forbid what is right and close their hands. They have forgotten Allah, so He has forgotten them [accordingly]. Indeed, the hypocrites - it is they who are the defiantly disobedient"
  },
  {
    "id": 68,
    "text": "Allah has promised the hypocrite men and hypocrite women and the disbelievers the fire of Hell, wherein they will abide eternally. It is sufficient for them. And Allah has cursed them, and for them is an enduring punishment"
  },
  {
    "id": 69,
    "text": "[You disbelievers are] like those before you; they were stronger than you in power and more abundant in wealth and children. They enjoyed their portion [of worldly enjoyment], and you have enjoyed your portion as those before you enjoyed their portion, and you have engaged [in vanities] like that in which they engaged. [It is] those whose deeds have become worthless in this world and in the Hereafter, and it is they who are the losers"
  },
  {
    "id": 70,
    "text": "Has there not reached them the news of those before them - the people of Noah and [the tribes of] 'Aad and Thamud and the people of Abraham and the companions of Madyan and the towns overturned? Their messengers came to them with clear proofs. And Allah would never have wronged them, but they were wronging themselves"
  },
  {
    "id": 71,
    "text": "The believing men and believing women are allies of one another. They enjoin what is right and forbid what is wrong and establish prayer and give zakah and obey Allah and His Messenger. Those - Allah will have mercy upon them. Indeed, Allah is Exalted in Might and Wise"
  },
  {
    "id": 72,
    "text": "Allah has promised the believing men and believing women gardens beneath which rivers flow, wherein they abide eternally, and pleasant dwellings in gardens of perpetual residence; but approval from Allah is greater. It is that which is the great attainment"
  },
  {
    "id": 73,
    "text": "O Prophet, fight against the disbelievers and the hypocrites and be harsh upon them. And their refuge is Hell, and wretched is the destination"
  },
  {
    "id": 74,
    "text": "They swear by Allah that they did not say [anything against the Prophet] while they had said the word of disbelief and disbelieved after their [pretense of] Islam and planned that which they were not to attain. And they were not resentful except [for the fact] that Allah and His Messenger had enriched them of His bounty. So if they repent, it is better for them; but if they turn away, Allah will punish them with a painful punishment in this world and the Hereafter. And there will not be for them on earth any protector or helper"
  },
  {
    "id": 75,
    "text": "And among them are those who made a covenant with Allah, [saying], \"If He should give us from His bounty, we will surely spend in charity, and we will surely be among the righteous"
  },
  {
    "id": 76,
    "text": "But when he gave them from His bounty, they were stingy with it and turned away while they refused"
  },
  {
    "id": 77,
    "text": "So He penalized them with hypocrisy in their hearts until the Day they will meet Him - because they failed Allah in what they promised Him and because they [habitually] used to lie"
  },
  {
    "id": 78,
    "text": "Did they not know that Allah knows their secrets and their private conversations and that Allah is the Knower of the unseen"
  },
  {
    "id": 79,
    "text": "Those who criticize the contributors among the believers concerning [their] charities and [criticize] the ones who find nothing [to spend] except their effort, so they ridicule them - Allah will ridicule them, and they will have a painful punishment"
  },
  {
    "id": 80,
    "text": "Ask forgiveness for them, [O Muhammad], or do not ask forgiveness for them. If you should ask forgiveness for them seventy times - never will Allah forgive them. That is because they disbelieved in Allah and His Messenger, and Allah does not guide the defiantly disobedient people"
  },
  {
    "id": 81,
    "text": "Those who remained behind rejoiced in their staying [at home] after [the departure of] the Messenger of Allah and disliked to strive with their wealth and their lives in the cause of Allah and said, \"Do not go forth in the heat.\" Say, \"The fire of Hell is more intensive in heat\" - if they would but understand"
  },
  {
    "id": 82,
    "text": "So let them laugh a little and [then] weep much as recompense for what they used to earn"
  },
  {
    "id": 83,
    "text": "If Allah should return you to a faction of them [after the expedition] and then they ask your permission to go out [to battle], say, \"You will not go out with me, ever, and you will never fight with me an enemy. Indeed, you were satisfied with sitting [at home] the first time, so sit [now] with those who stay behind"
  },
  {
    "id": 84,
    "text": "And do not pray [the funeral prayer, O Muhammad], over any of them who has died - ever - or stand at his grave. Indeed, they disbelieved in Allah and His Messenger and died while they were defiantly disobedient"
  },
  {
    "id": 85,
    "text": "And let not their wealth and their children impress you. Allah only intends to punish them through them in this world and that their souls should depart [at death] while they are disbelievers"
  },
  {
    "id": 86,
    "text": "And when a surah was revealed [enjoining them] to believe in Allah and to fight with His Messenger, those of wealth among them asked your permission [to stay back] and said, \"Leave us to be with them who sit [at home]"
  },
  {
    "id": 87,
    "text": "They were satisfied to be with those who stay behind, and their hearts were sealed over, so they do not understand"
  },
  {
    "id": 88,
    "text": "But the Messenger and those who believed with him fought with their wealth and their lives. Those will have [all that is] good, and it is those who are the successful"
  },
  {
    "id": 89,
    "text": "Allah has prepared for them gardens beneath which rivers flow, wherein they will abide eternally. That is the great attainment"
  },
  {
    "id": 90,
    "text": "And those with excuses among the bedouins came to be permitted [to remain], and they who had lied to Allah and His Messenger sat [at home]. There will strike those who disbelieved among them a painful punishment"
  },
  {
    "id": 91,
    "text": "There is not upon the weak or upon the ill or upon those who do not find anything to spend any discomfort when they are sincere to Allah and His Messenger. There is not upon the doers of good any cause [for blame]. And Allah is Forgiving and Merciful"
  },
  {
    "id": 92,
    "text": "Nor [is there blame] upon those who, when they came to you that you might give them mounts, you said, \"I can find nothing for you to ride upon.\" They turned back while their eyes overflowed with tears out of grief that they could not find something to spend [for the cause of Allah]"
  },
  {
    "id": 93,
    "text": "The cause [for blame] is only upon those who ask permission of you while they are rich. They are satisfied to be with those who stay behind, and Allah has sealed over their hearts, so they do not know"
  },
  {
    "id": 94,
    "text": "They will make excuses to you when you have returned to them. Say, \"Make no excuse - never will we believe you. Allah has already informed us of your news. And Allah will observe your deeds, and [so will] His Messenger; then you will be taken back to the Knower of the unseen and the witnessed, and He will inform you of what you used to do"
  },
  {
    "id": 95,
    "text": "They will swear by Allah to you when you return to them that you would leave them alone. So leave them alone; indeed they are evil; and their refuge is Hell as recompense for what they had been earning"
  },
  {
    "id": 96,
    "text": "They swear to you so that you might be satisfied with them. But if you should be satisfied with them - indeed, Allah is not satisfied with a defiantly disobedient people"
  },
  {
    "id": 97,
    "text": "The bedouins are stronger in disbelief and hypocrisy and more likely not to know the limits of what [laws] Allah has revealed to His Messenger. And Allah is Knowing and Wise"
  },
  {
    "id": 98,
    "text": "And among the bedouins are some who consider what they spend as a loss and await for you turns of misfortune. Upon them will be a misfortune of evil. And Allah is Hearing and Knowing"
  },
  {
    "id": 99,
    "text": "But among the bedouins are some who believe in Allah and the Last Day and consider what they spend as means of nearness to Allah and of [obtaining] invocations of the Messenger. Unquestionably, it is a means of nearness for them. Allah will admit them to His mercy. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 100,
    "text": "And the first forerunners [in the faith] among the Muhajireen and the Ansar and those who followed them with good conduct - Allah is pleased with them and they are pleased with Him, and He has prepared for them gardens beneath which rivers flow, wherein they will abide forever. That is the great attainment"
  },
  {
    "id": 101,
    "text": "And among those around you of the bedouins are hypocrites, and [also] from the people of Madinah. They have become accustomed to hypocrisy. You, [O Muhammad], do not know them, [but] We know them. We will punish them twice [in this world]; then they will be returned to a great punishment"
  },
  {
    "id": 102,
    "text": "And [there are] others who have acknowledged their sins. They had mixed a righteous deed with another that was bad. Perhaps Allah will turn to them in forgiveness. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 103,
    "text": "Take, [O, Muhammad], from their wealth a charity by which you purify them and cause them increase, and invoke [Allah 's blessings] upon them. Indeed, your invocations are reassurance for them. And Allah is Hearing and Knowing"
  },
  {
    "id": 104,
    "text": "Do they not know that it is Allah who accepts repentance from His servants and receives charities and that it is Allah who is the Accepting of repentance, the Merciful"
  },
  {
    "id": 105,
    "text": "And say, \"Do [as you will], for Allah will see your deeds, and [so, will] His Messenger and the believers. And you will be returned to the Knower of the unseen and the witnessed, and He will inform you of what you used to do"
  },
  {
    "id": 106,
    "text": "And [there are] others deferred until the command of Allah - whether He will punish them or whether He will forgive them. And Allah is Knowing and Wise"
  },
  {
    "id": 107,
    "text": "And [there are] those [hypocrites] who took for themselves a mosque for causing harm and disbelief and division among the believers and as a station for whoever had warred against Allah and His Messenger before. And they will surely swear, \"We intended only the best.\" And Allah testifies that indeed they are liars"
  },
  {
    "id": 108,
    "text": "Do not stand [for prayer] within it - ever. A mosque founded on righteousness from the first day is more worthy for you to stand in. Within it are men who love to purify themselves; and Allah loves those who purify themselves"
  },
  {
    "id": 109,
    "text": "Then is one who laid the foundation of his building on righteousness [with fear] from Allah and [seeking] His approval better or one who laid the foundation of his building on the edge of a bank about to collapse, so it collapsed with him into the fire of Hell? And Allah does not guide the wrongdoing people"
  },
  {
    "id": 110,
    "text": "Their building which they built will not cease to be a [cause of] skepticism in their hearts until their hearts are stopped. And Allah is Knowing and Wise"
  },
  {
    "id": 111,
    "text": "Indeed, Allah has purchased from the believers their lives and their properties [in exchange] for that they will have Paradise. They fight in the cause of Allah, so they kill and are killed. [It is] a true promise [binding] upon Him in the Torah and the Gospel and the Qur'an. And who is truer to his covenant than Allah? So rejoice in your transaction which you have contracted. And it is that which is the great attainment"
  },
  {
    "id": 112,
    "text": "[Such believers are] the repentant, the worshippers, the praisers [of Allah], the travelers [for His cause], those who bow and prostrate [in prayer], those who enjoin what is right and forbid what is wrong, and those who observe the limits [set by] Allah. And give good tidings to the believers"
  },
  {
    "id": 113,
    "text": "It is not for the Prophet and those who have believed to ask forgiveness for the polytheists, even if they were relatives, after it has become clear to them that they are companions of Hellfire"
  },
  {
    "id": 114,
    "text": "And the request of forgiveness of Abraham for his father was only because of a promise he had made to him. But when it became apparent to Abraham that his father was an enemy to Allah, he disassociated himself from him. Indeed was Abraham compassionate and patient"
  },
  {
    "id": 115,
    "text": "And Allah would not let a people stray after He has guided them until He makes clear to them what they should avoid. Indeed, Allah is Knowing of all things"
  },
  {
    "id": 116,
    "text": "Indeed, to Allah belongs the dominion of the heavens and the earth; He gives life and causes death. And you have not besides Allah any protector or any helper"
  },
  {
    "id": 117,
    "text": "Allah has already forgiven the Prophet and the Muhajireen and the Ansar who followed him in the hour of difficulty after the hearts of a party of them had almost inclined [to doubt], and then He forgave them. Indeed, He was to them Kind and Merciful"
  },
  {
    "id": 118,
    "text": "And [He also forgave] the three who were left behind [and regretted their error] to the point that the earth closed in on them in spite of its vastness and their souls confined them and they were certain that there is no refuge from Allah except in Him. Then He turned to them so they could repent. Indeed, Allah is the Accepting of repentance, the Merciful"
  },
  {
    "id": 119,
    "text": "O you who have believed, fear Allah and be with those who are true"
  },
  {
    "id": 120,
    "text": "It was not [proper] for the people of Madinah and those surrounding them of the bedouins that they remain behind after [the departure of] the Messenger of Allah or that they prefer themselves over his self. That is because they are not afflicted by thirst or fatigue or hunger in the cause of Allah, nor do they tread on any ground that enrages the disbelievers, nor do they inflict upon an enemy any infliction but that is registered for them as a righteous deed. Indeed, Allah does not allow to be lost the reward of the doers of good"
  },
  {
    "id": 121,
    "text": "Nor do they spend an expenditure, small or large, or cross a valley but that it is registered for them that Allah may reward them for the best of what they were doing"
  },
  {
    "id": 122,
    "text": "And it is not for the believers to go forth [to battle] all at once. For there should separate from every division of them a group [remaining] to obtain understanding in the religion and warn their people when they return to them that they might be cautious"
  },
  {
    "id": 123,
    "text": "O you who have believed, fight those adjacent to you of the disbelievers and let them find in you harshness. And know that Allah is with the righteous"
  },
  {
    "id": 124,
    "text": "And whenever a surah is revealed, there are among the hypocrites those who say, \"Which of you has this increased faith?\" As for those who believed, it has increased them in faith, while they are rejoicing"
  },
  {
    "id": 125,
    "text": "But as for those in whose hearts is disease, it has [only] increased them in evil [in addition] to their evil. And they will have died while they are disbelievers"
  },
  {
    "id": 126,
    "text": "Do they not see that they are tried every year once or twice but then they do not repent nor do they remember"
  },
  {
    "id": 127,
    "text": "And whenever a surah is revealed, they look at each other, [saying], \"Does anyone see you?\" and then they dismiss themselves. Allah has dismissed their hearts because they are a people who do not understand"
  },
  {
    "id": 128,
    "text": "There has certainly come to you a Messenger from among yourselves. Grievous to him is what you suffer; [he is] concerned over you and to the believers is kind and merciful"
  },
  {
    "id": 129,
    "text": "But if they turn away, [O Muhammad], say, \"Sufficient for me is Allah; there is no deity except Him. On Him I have relied, and He is the Lord of the Great Throne"
  }
]

export default en
