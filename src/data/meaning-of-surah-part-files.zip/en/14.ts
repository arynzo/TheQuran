import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Alif, Lam, Ra. [This is] a Book which We have revealed to you, [O Muhammad], that you might bring mankind out of darknesses into the light by permission of their Lord - to the path of the Exalted in Might, the Praiseworthy"
  },
  {
    "id": 2,
    "text": "Allah, to whom belongs whatever is in the heavens and whatever is on the earth. And woe to the disbelievers from a severe punishment"
  },
  {
    "id": 3,
    "text": "The ones who prefer the worldly life over the Hereafter and avert [people] from the way of Allah, seeking to make it (seem) deviant. Those are in extreme error"
  },
  {
    "id": 4,
    "text": "And We did not send any messenger except [speaking] in the language of his people to state clearly for them, and Allah sends astray [thereby] whom He wills and guides whom He wills. And He is the Exalted in Might, the Wise"
  },
  {
    "id": 5,
    "text": "And We certainly sent Moses with Our signs, [saying], \"Bring out your people from darknesses into the light and remind them of the days of Allah.\" Indeed in that are signs for everyone patient and grateful"
  },
  {
    "id": 6,
    "text": "And [recall, O Children of Israel], when Moses said to His people, \"Remember the favor of Allah upon you when He saved you from the people of Pharaoh, who were afflicting you with the worst torment and were slaughtering your [newborn] sons and keeping your females alive. And in that was a great trial from your Lord"
  },
  {
    "id": 7,
    "text": "And [remember] when your Lord proclaimed, 'If you are grateful, I will surely increase you [in favor]; but if you deny, indeed, My punishment is severe"
  },
  {
    "id": 8,
    "text": "And Moses said, \"If you should disbelieve, you and whoever is on the earth entirely - indeed, Allah is Free of need and Praiseworthy"
  },
  {
    "id": 9,
    "text": "Has there not reached you the news of those before you - the people of Noah and 'Aad and Thamud and those after them? No one knows them but Allah. Their messengers brought them clear proofs, but they returned their hands to their mouths and said, \"Indeed, we disbelieve in that with which you have been sent, and indeed we are, about that to which you invite us, in disquieting doubt"
  },
  {
    "id": 10,
    "text": "Their messengers said, \"Can there be doubt about Allah, Creator of the heavens and earth? He invites you that He may forgive you of your sins, and He delays your death for a specified term.\" They said, \"You are not but men like us who wish to avert us from what our fathers were worshipping. So bring us a clear authority"
  },
  {
    "id": 11,
    "text": "Their messengers said to them, \"We are only men like you, but Allah confers favor upon whom He wills of His servants. It has never been for us to bring you evidence except by permission of Allah. And upon Allah let the believers rely"
  },
  {
    "id": 12,
    "text": "And why should we not rely upon Allah while He has guided us to our [good] ways. And we will surely be patient against whatever harm you should cause us. And upon Allah let those who would rely [indeed] rely"
  },
  {
    "id": 13,
    "text": "And those who disbelieved said to their messengers, \"We will surely drive you out of our land, or you must return to our religion.\" So their Lord inspired to them, \"We will surely destroy the wrongdoers"
  },
  {
    "id": 14,
    "text": "And We will surely cause you to dwell in the land after them. That is for he who fears My position and fears My threat"
  },
  {
    "id": 15,
    "text": "And they requested victory from Allah, and disappointed, [therefore], was every obstinate tyrant"
  },
  {
    "id": 16,
    "text": "Before him is Hell, and he will be given a drink of purulent water"
  },
  {
    "id": 17,
    "text": "He will gulp it but will hardly [be able to] swallow it. And death will come to him from everywhere, but he is not to die. And before him is a massive punishment"
  },
  {
    "id": 18,
    "text": "The example of those who disbelieve in their Lord is [that] their deeds are like ashes which the wind blows forcefully on a stormy day; they are unable [to keep] from what they earned a [single] thing. That is what is extreme error"
  },
  {
    "id": 19,
    "text": "Have you not seen that Allah created the heavens and the earth in truth? If He wills, He can do away with you and produce a new creation"
  },
  {
    "id": 20,
    "text": "And that is not difficult for Allah"
  },
  {
    "id": 21,
    "text": "And they will come out [for judgement] before Allah all together, and the weak will say to those who were arrogant, \"Indeed, we were your followers, so can you avail us anything against the punishment of Allah?\" They will say, \"If Allah had guided us, we would have guided you. It is all the same for us whether we show intolerance or are patient: there is for us no place of escape"
  },
  {
    "id": 22,
    "text": "And Satan will say when the matter has been concluded, \"Indeed, Allah had promised you the promise of truth. And I promised you, but I betrayed you. But I had no authority over you except that I invited you, and you responded to me. So do not blame me; but blame yourselves. I cannot be called to your aid, nor can you be called to my aid. Indeed, I deny your association of me [with Allah] before. Indeed, for the wrongdoers is a painful punishment"
  },
  {
    "id": 23,
    "text": "And those who believed and did righteous deeds will be admitted to gardens beneath which rivers flow, abiding eternally therein by permission of their Lord; and their greeting therein will be, \"Peace"
  },
  {
    "id": 24,
    "text": "Have you not considered how Allah presents an example, [making] a good word like a good tree, whose root is firmly fixed and its branches [high] in the sky"
  },
  {
    "id": 25,
    "text": "It produces its fruit all the time, by permission of its Lord. And Allah presents examples for the people that perhaps they will be reminded"
  },
  {
    "id": 26,
    "text": "And the example of a bad word is like a bad tree, uprooted from the surface of the earth, not having any stability"
  },
  {
    "id": 27,
    "text": "Allah keeps firm those who believe, with the firm word, in worldly life and in the Hereafter. And Allah sends astray the wrongdoers. And Allah does what He wills"
  },
  {
    "id": 28,
    "text": "Have you not considered those who exchanged the favor of Allah for disbelief and settled their people [in] the home of ruin"
  },
  {
    "id": 29,
    "text": "[It is] Hell, which they will [enter to] burn, and wretched is the settlement"
  },
  {
    "id": 30,
    "text": "And they have attributed to Allah equals to mislead [people] from His way. Say, \"Enjoy yourselves, for indeed, your destination is the Fire"
  },
  {
    "id": 31,
    "text": "[O Muhammad], tell My servants who have believed to establish prayer and spend from what We have provided them, secretly and publicly, before a Day comes in which there will be no exchange, nor any friendships"
  },
  {
    "id": 32,
    "text": "It is Allah who created the heavens and the earth and sent down rain from the sky and produced thereby some fruits as provision for you and subjected for you the ships to sail through the sea by His command and subjected for you the rivers"
  },
  {
    "id": 33,
    "text": "And He subjected for you the sun and the moon, continuous [in orbit], and subjected for you the night and the day"
  },
  {
    "id": 34,
    "text": "And He gave you from all you asked of Him. And if you should count the favor of Allah, you could not enumerate them. Indeed, mankind is [generally] most unjust and ungrateful"
  },
  {
    "id": 35,
    "text": "And [mention, O Muhammad], when Abraham said, \"My Lord, make this city [Makkah] secure and keep me and my sons away from worshipping idols"
  },
  {
    "id": 36,
    "text": "My Lord, indeed they have led astray many among the people. So whoever follows me - then he is of me; and whoever disobeys me - indeed, You are [yet] Forgiving and Merciful"
  },
  {
    "id": 37,
    "text": "Our Lord, I have settled some of my descendants in an uncultivated valley near Your sacred House, our Lord, that they may establish prayer. So make hearts among the people incline toward them and provide for them from the fruits that they might be grateful"
  },
  {
    "id": 38,
    "text": "Our Lord, indeed You know what we conceal and what we declare, and nothing is hidden from Allah on the earth or in the heaven"
  },
  {
    "id": 39,
    "text": "Praise to Allah, who has granted to me in old age Ishmael and Isaac. Indeed, my Lord is the Hearer of supplication"
  },
  {
    "id": 40,
    "text": "My Lord, make me an establisher of prayer, and [many] from my descendants. Our Lord, and accept my supplication"
  },
  {
    "id": 41,
    "text": "Our Lord, forgive me and my parents and the believers the Day the account is established"
  },
  {
    "id": 42,
    "text": "And never think that Allah is unaware of what the wrongdoers do. He only delays them for a Day when eyes will stare [in horror]"
  },
  {
    "id": 43,
    "text": "Racing ahead, their heads raised up, their glance does not come back to them, and their hearts are void"
  },
  {
    "id": 44,
    "text": "And, [O Muhammad], warn the people of a Day when the punishment will come to them and those who did wrong will say, \"Our Lord, delay us for a short term; we will answer Your call and follow the messengers.\" [But it will be said], \"Had you not sworn, before, that for you there would be no cessation"
  },
  {
    "id": 45,
    "text": "And you lived among the dwellings of those who wronged themselves, and it had become clear to you how We dealt with them. And We presented for you [many] examples"
  },
  {
    "id": 46,
    "text": "And they had planned their plan, but with Allah is [recorded] their plan, even if their plan had been [sufficient] to do away with the mountains"
  },
  {
    "id": 47,
    "text": "So never think that Allah will fail in His promise to His messengers. Indeed, Allah is Exalted in Might and Owner of Retribution"
  },
  {
    "id": 48,
    "text": "[It will be] on the Day the earth will be replaced by another earth, and the heavens [as well], and all creatures will come out before Allah, the One, the Prevailing"
  },
  {
    "id": 49,
    "text": "And you will see the criminals that Day bound together in shackles"
  },
  {
    "id": 50,
    "text": "Their garments of liquid pitch and their faces covered by the Fire"
  },
  {
    "id": 51,
    "text": "So that Allah will recompense every soul for what it earned. Indeed, Allah is swift in account"
  },
  {
    "id": 52,
    "text": "This [Qur'an] is notification for the people that they may be warned thereby and that they may know that He is but one God and that those of understanding will be reminded"
  }
]

export default en
