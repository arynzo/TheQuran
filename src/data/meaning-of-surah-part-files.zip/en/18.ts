import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "[All] praise is [due] to Allah, who has sent down upon His Servant the Book and has not made therein any deviance"
  },
  {
    "id": 2,
    "text": "[He has made it] straight, to warn of severe punishment from Him and to give good tidings to the believers who do righteous deeds that they will have a good reward"
  },
  {
    "id": 3,
    "text": "In which they will remain forever"
  },
  {
    "id": 4,
    "text": "And to warn those who say, \"Allah has taken a son"
  },
  {
    "id": 5,
    "text": "They have no knowledge of it, nor had their fathers. Grave is the word that comes out of their mouths; they speak not except a lie"
  },
  {
    "id": 6,
    "text": "Then perhaps you would kill yourself through grief over them, [O Muhammad], if they do not believe in this message, [and] out of sorrow"
  },
  {
    "id": 7,
    "text": "Indeed, We have made that which is on the earth adornment for it that We may test them [as to] which of them is best in deed"
  },
  {
    "id": 8,
    "text": "And indeed, We will make that which is upon it [into] a barren ground"
  },
  {
    "id": 9,
    "text": "Or have you thought that the companions of the cave and the inscription were, among Our signs, a wonder"
  },
  {
    "id": 10,
    "text": "[Mention] when the youths retreated to the cave and said, \"Our Lord, grant us from Yourself mercy and prepare for us from our affair right guidance"
  },
  {
    "id": 11,
    "text": "So We cast [a cover of sleep] over their ears within the cave for a number of years"
  },
  {
    "id": 12,
    "text": "Then We awakened them that We might show which of the two factions was most precise in calculating what [extent] they had remained in time"
  },
  {
    "id": 13,
    "text": "It is We who relate to you, [O Muhammad], their story in truth. Indeed, they were youths who believed in their Lord, and We increased them in guidance"
  },
  {
    "id": 14,
    "text": "And We made firm their hearts when they stood up and said, \"Our Lord is the Lord of the heavens and the earth. Never will we invoke besides Him any deity. We would have certainly spoken, then, an excessive transgression"
  },
  {
    "id": 15,
    "text": "These, our people, have taken besides Him deities. Why do they not bring for [worship of] them a clear authority? And who is more unjust than one who invents about Allah a lie"
  },
  {
    "id": 16,
    "text": "[The youths said to one another], \"And when you have withdrawn from them and that which they worship other than Allah, retreat to the cave. Your Lord will spread out for you of His mercy and will prepare for you from your affair facility"
  },
  {
    "id": 17,
    "text": "And [had you been present], you would see the sun when it rose, inclining away from their cave on the right, and when it set, passing away from them on the left, while they were [laying] within an open space thereof. That was from the signs of Allah. He whom Allah guides is the [rightly] guided, but he whom He leaves astray - never will you find for him a protecting guide"
  },
  {
    "id": 18,
    "text": "And you would think them awake, while they were asleep. And We turned them to the right and to the left, while their dog stretched his forelegs at the entrance. If you had looked at them, you would have turned from them in flight and been filled by them with terror"
  },
  {
    "id": 19,
    "text": "And similarly, We awakened them that they might question one another. Said a speaker from among them, \"How long have you remained [here]?\" They said, \"We have remained a day or part of a day.\" They said, \"Your Lord is most knowing of how long you remained. So send one of you with this silver coin of yours to the city and let him look to which is the best of food and bring you provision from it and let him be cautious. And let no one be aware of you"
  },
  {
    "id": 20,
    "text": "Indeed, if they come to know of you, they will stone you or return you to their religion. And never would you succeed, then - ever"
  },
  {
    "id": 21,
    "text": "And similarly, We caused them to be found that they [who found them] would know that the promise of Allah is truth and that of the Hour there is no doubt. [That was] when they disputed among themselves about their affair and [then] said, \"Construct over them a structure. Their Lord is most knowing about them.\" Said those who prevailed in the matter, \"We will surely take [for ourselves] over them a masjid"
  },
  {
    "id": 22,
    "text": "They will say there were three, the fourth of them being their dog; and they will say there were five, the sixth of them being their dog - guessing at the unseen; and they will say there were seven, and the eighth of them was their dog. Say, [O Muhammad], \"My Lord is most knowing of their number. None knows them except a few. So do not argue about them except with an obvious argument and do not inquire about them among [the speculators] from anyone"
  },
  {
    "id": 23,
    "text": "And never say of anything, \"Indeed, I will do that tomorrow"
  },
  {
    "id": 24,
    "text": "Except [when adding], \"If Allah wills.\" And remember your Lord when you forget [it] and say, \"Perhaps my Lord will guide me to what is nearer than this to right conduct"
  },
  {
    "id": 25,
    "text": "And they remained in their cave for three hundred years and exceeded by nine"
  },
  {
    "id": 26,
    "text": "Say, \"Allah is most knowing of how long they remained. He has [knowledge of] the unseen [aspects] of the heavens and the earth. How Seeing is He and how Hearing! They have not besides Him any protector, and He shares not His legislation with anyone"
  },
  {
    "id": 27,
    "text": "And recite, [O Muhammad], what has been revealed to you of the Book of your Lord. There is no changer of His words, and never will you find in other than Him a refuge"
  },
  {
    "id": 28,
    "text": "And keep yourself patient [by being] with those who call upon their Lord in the morning and the evening, seeking His countenance. And let not your eyes pass beyond them, desiring adornments of the worldly life, and do not obey one whose heart We have made heedless of Our remembrance and who follows his desire and whose affair is ever [in] neglect"
  },
  {
    "id": 29,
    "text": "And say, \"The truth is from your Lord, so whoever wills - let him believe; and whoever wills - let him disbelieve.\" Indeed, We have prepared for the wrongdoers a fire whose walls will surround them. And if they call for relief, they will be relieved with water like murky oil, which scalds [their] faces. Wretched is the drink, and evil is the resting place"
  },
  {
    "id": 30,
    "text": "Indeed, those who have believed and done righteous deeds - indeed, We will not allow to be lost the reward of any who did well in deeds"
  },
  {
    "id": 31,
    "text": "Those will have gardens of perpetual residence; beneath them rivers will flow. They will be adorned therein with bracelets of gold and will wear green garments of fine silk and brocade, reclining therein on adorned couches. Excellent is the reward, and good is the resting place"
  },
  {
    "id": 32,
    "text": "And present to them an example of two men: We granted to one of them two gardens of grapevines, and We bordered them with palm trees and placed between them [fields of] crops"
  },
  {
    "id": 33,
    "text": "Each of the two gardens produced its fruit and did not fall short thereof in anything. And We caused to gush forth within them a river"
  },
  {
    "id": 34,
    "text": "And he had fruit, so he said to his companion while he was conversing with him, \"I am greater than you in wealth and mightier in [numbers of] men"
  },
  {
    "id": 35,
    "text": "And he entered his garden while he was unjust to himself. He said, \"I do not think that this will perish - ever"
  },
  {
    "id": 36,
    "text": "And I do not think the Hour will occur. And even if I should be brought back to my Lord, I will surely find better than this as a return"
  },
  {
    "id": 37,
    "text": "His companion said to him while he was conversing with him, \"Have you disbelieved in He who created you from dust and then from a sperm-drop and then proportioned you [as] a man"
  },
  {
    "id": 38,
    "text": "But as for me, He is Allah, my Lord, and I do not associate with my Lord anyone"
  },
  {
    "id": 39,
    "text": "And why did you, when you entered your garden, not say, 'What Allah willed [has occurred]; there is no power except in Allah '? Although you see me less than you in wealth and children"
  },
  {
    "id": 40,
    "text": "It may be that my Lord will give me [something] better than your garden and will send upon it a calamity from the sky, and it will become a smooth, dusty ground"
  },
  {
    "id": 41,
    "text": "Or its water will become sunken [into the earth], so you would never be able to seek it"
  },
  {
    "id": 42,
    "text": "And his fruits were encompassed [by ruin], so he began to turn his hands about [in dismay] over what he had spent on it, while it had collapsed upon its trellises, and said, \"Oh, I wish I had not associated with my Lord anyone"
  },
  {
    "id": 43,
    "text": "And there was for him no company to aid him other than Allah, nor could he defend himself"
  },
  {
    "id": 44,
    "text": "There the authority is [completely] for Allah, the Truth. He is best in reward and best in outcome"
  },
  {
    "id": 45,
    "text": "And present to them the example of the life of this world, [its being] like rain which We send down from the sky, and the vegetation of the earth mingles with it and [then] it becomes dry remnants, scattered by the winds. And Allah is ever, over all things, Perfect in Ability"
  },
  {
    "id": 46,
    "text": "Wealth and children are [but] adornment of the worldly life. But the enduring good deeds are better to your Lord for reward and better for [one's] hope"
  },
  {
    "id": 47,
    "text": "And [warn of] the Day when We will remove the mountains and you will see the earth prominent, and We will gather them and not leave behind from them anyone"
  },
  {
    "id": 48,
    "text": "And they will be presented before your Lord in rows, [and He will say], \"You have certainly come to Us just as We created you the first time. But you claimed that We would never make for you an appointment"
  },
  {
    "id": 49,
    "text": "And the record [of deeds] will be placed [open], and you will see the criminals fearful of that within it, and they will say, \"Oh, woe to us! What is this book that leaves nothing small or great except that it has enumerated it?\" And they will find what they did present [before them]. And your Lord does injustice to no one"
  },
  {
    "id": 50,
    "text": "And [mention] when We said to the angels, \"Prostrate to Adam,\" and they prostrated, except for Iblees. He was of the jinn and departed from the command of his Lord. Then will you take him and his descendants as allies other than Me while they are enemies to you? Wretched it is for the wrongdoers as an exchange"
  },
  {
    "id": 51,
    "text": "I did not make them witness to the creation of the heavens and the earth or to the creation of themselves, and I would not have taken the misguiders as assistants"
  },
  {
    "id": 52,
    "text": "And [warn of] the Day when He will say, \"Call 'My partners' whom you claimed,\" and they will invoke them, but they will not respond to them. And We will put between them [a valley of] destruction"
  },
  {
    "id": 53,
    "text": "And the criminals will see the Fire and will be certain that they are to fall therein. And they will not find from it a way elsewhere"
  },
  {
    "id": 54,
    "text": "And We have certainly diversified in this Qur'an for the people from every [kind of] example; but man has ever been, most of anything, [prone to] dispute"
  },
  {
    "id": 55,
    "text": "And nothing has prevented the people from believing when guidance came to them and from asking forgiveness of their Lord except that there [must] befall them the [accustomed] precedent of the former peoples or that the punishment should come [directly] before them"
  },
  {
    "id": 56,
    "text": "And We send not the messengers except as bringers of good tidings and warners. And those who disbelieve dispute by [using] falsehood to [attempt to] invalidate thereby the truth and have taken My verses, and that of which they are warned, in ridicule"
  },
  {
    "id": 57,
    "text": "And who is more unjust than one who is reminded of the verses of his Lord but turns away from them and forgets what his hands have put forth? Indeed, We have placed over their hearts coverings, lest they understand it, and in their ears deafness. And if you invite them to guidance - they will never be guided, then - ever"
  },
  {
    "id": 58,
    "text": "And your Lord is the Forgiving, full of mercy. If He were to impose blame upon them for what they earned, He would have hastened for them the punishment. Rather, for them is an appointment from which they will never find an escape"
  },
  {
    "id": 59,
    "text": "And those cities - We destroyed them when they wronged, and We made for their destruction an appointed time"
  },
  {
    "id": 60,
    "text": "And [mention] when Moses said to his servant, \"I will not cease [traveling] until I reach the junction of the two seas or continue for a long period"
  },
  {
    "id": 61,
    "text": "But when they reached the junction between them, they forgot their fish, and it took its course into the sea, slipping away"
  },
  {
    "id": 62,
    "text": "So when they had passed beyond it, [Moses] said to his boy, \"Bring us our morning meal. We have certainly suffered in this, our journey, [much] fatigue"
  },
  {
    "id": 63,
    "text": "He said, \"Did you see when we retired to the rock? Indeed, I forgot [there] the fish. And none made me forget it except Satan - that I should mention it. And it took its course into the sea amazingly"
  },
  {
    "id": 64,
    "text": "[Moses] said, \"That is what we were seeking.\" So they returned, following their footprints"
  },
  {
    "id": 65,
    "text": "And they found a servant from among Our servants to whom we had given mercy from us and had taught him from Us a [certain] knowledge"
  },
  {
    "id": 66,
    "text": "Moses said to him, \"May I follow you on [the condition] that you teach me from what you have been taught of sound judgement"
  },
  {
    "id": 67,
    "text": "He said, \"Indeed, with me you will never be able to have patience"
  },
  {
    "id": 68,
    "text": "And how can you have patience for what you do not encompass in knowledge"
  },
  {
    "id": 69,
    "text": "[Moses] said, \"You will find me, if Allah wills, patient, and I will not disobey you in [any] order"
  },
  {
    "id": 70,
    "text": "He said, \"Then if you follow me, do not ask me about anything until I make to you about it mention"
  },
  {
    "id": 71,
    "text": "So they set out, until when they had embarked on the ship, al-Khidh r tore it open. [Moses] said, \"Have you torn it open to drown its people? You have certainly done a grave thing"
  },
  {
    "id": 72,
    "text": "[Al-Khidh r] said, \"Did I not say that with me you would never be able to have patience"
  },
  {
    "id": 73,
    "text": "[Moses] said, \"Do not blame me for what I forgot and do not cover me in my matter with difficulty"
  },
  {
    "id": 74,
    "text": "So they set out, until when they met a boy, al-Khidh r killed him. [Moses] said, \"Have you killed a pure soul for other than [having killed] a soul? You have certainly done a deplorable thing"
  },
  {
    "id": 75,
    "text": "[Al-Khidh r] said, \"Did I not tell you that with me you would never be able to have patience"
  },
  {
    "id": 76,
    "text": "[Moses] said, \"If I should ask you about anything after this, then do not keep me as a companion. You have obtained from me an excuse"
  },
  {
    "id": 77,
    "text": "So they set out, until when they came to the people of a town, they asked its people for food, but they refused to offer them hospitality. And they found therein a wall about to collapse, so al-Khidh r restored it. [Moses] said, \"If you wished, you could have taken for it a payment"
  },
  {
    "id": 78,
    "text": "[Al-Khidh r] said, \"This is parting between me and you. I will inform you of the interpretation of that about which you could not have patience"
  },
  {
    "id": 79,
    "text": "As for the ship, it belonged to poor people working at sea. So I intended to cause defect in it as there was after them a king who seized every [good] ship by force"
  },
  {
    "id": 80,
    "text": "And as for the boy, his parents were believers, and we feared that he would overburden them by transgression and disbelief"
  },
  {
    "id": 81,
    "text": "So we intended that their Lord should substitute for them one better than him in purity and nearer to mercy"
  },
  {
    "id": 82,
    "text": "And as for the wall, it belonged to two orphan boys in the city, and there was beneath it a treasure for them, and their father had been righteous. So your Lord intended that they reach maturity and extract their treasure, as a mercy from your Lord. And I did it not of my own accord. That is the interpretation of that about which you could not have patience"
  },
  {
    "id": 83,
    "text": "And they ask you, [O Muhammad], about Dhul-Qarnayn. Say, \"I will recite to you about him a report"
  },
  {
    "id": 84,
    "text": "Indeed We established him upon the earth, and We gave him to everything a way"
  },
  {
    "id": 85,
    "text": "So he followed a way"
  },
  {
    "id": 86,
    "text": "Until, when he reached the setting of the sun, he found it [as if] setting in a spring of dark mud, and he found near it a people. Allah said, \"O Dhul-Qarnayn, either you punish [them] or else adopt among them [a way of] goodness"
  },
  {
    "id": 87,
    "text": "He said, \"As for one who wrongs, we will punish him. Then he will be returned to his Lord, and He will punish him with a terrible punishment"
  },
  {
    "id": 88,
    "text": "But as for one who believes and does righteousness, he will have a reward of Paradise, and we will speak to him from our command with ease"
  },
  {
    "id": 89,
    "text": "Then he followed a way"
  },
  {
    "id": 90,
    "text": "Until, when he came to the rising of the sun, he found it rising on a people for whom We had not made against it any shield"
  },
  {
    "id": 91,
    "text": "Thus. And We had encompassed [all] that he had in knowledge"
  },
  {
    "id": 92,
    "text": "Then he followed a way"
  },
  {
    "id": 93,
    "text": "Until, when he reached [a pass] between two mountains, he found beside them a people who could hardly understand [his] speech"
  },
  {
    "id": 94,
    "text": "They said, \"O Dhul-Qarnayn, indeed Gog and Magog are [great] corrupters in the land. So may we assign for you an expenditure that you might make between us and them a barrier"
  },
  {
    "id": 95,
    "text": "He said, \"That in which my Lord has established me is better [than what you offer], but assist me with strength; I will make between you and them a dam"
  },
  {
    "id": 96,
    "text": "Bring me sheets of iron\" - until, when he had leveled [them] between the two mountain walls, he said, \"Blow [with bellows],\" until when he had made it [like] fire, he said, \"Bring me, that I may pour over it molten copper"
  },
  {
    "id": 97,
    "text": "So Gog and Magog were unable to pass over it, nor were they able [to effect] in it any penetration"
  },
  {
    "id": 98,
    "text": "[Dhul-Qarnayn] said, \"This is a mercy from my Lord; but when the promise of my Lord comes, He will make it level, and ever is the promise of my Lord true"
  },
  {
    "id": 99,
    "text": "And We will leave them that day surging over each other, and [then] the Horn will be blown, and We will assemble them in [one] assembly"
  },
  {
    "id": 100,
    "text": "And We will present Hell that Day to the Disbelievers, on display"
  },
  {
    "id": 101,
    "text": "Those whose eyes had been within a cover [removed] from My remembrance, and they were not able to hear"
  },
  {
    "id": 102,
    "text": "Then do those who disbelieve think that they can take My servants instead of Me as allies? Indeed, We have prepared Hell for the disbelievers as a lodging"
  },
  {
    "id": 103,
    "text": "Say, [O Muhammad], \"Shall we [believers] inform you of the greatest losers as to [their] deeds"
  },
  {
    "id": 104,
    "text": "[They are] those whose effort is lost in worldly life, while they think that they are doing well in work"
  },
  {
    "id": 105,
    "text": "Those are the ones who disbelieve in the verses of their Lord and in [their] meeting Him, so their deeds have become worthless; and We will not assign to them on the Day of Resurrection any importance"
  },
  {
    "id": 106,
    "text": "That is their recompense - Hell - for what they denied and [because] they took My signs and My messengers in ridicule"
  },
  {
    "id": 107,
    "text": "Indeed, those who have believed and done righteous deeds - they will have the Gardens of Paradise as a lodging"
  },
  {
    "id": 108,
    "text": "Wherein they abide eternally. They will not desire from it any transfer"
  },
  {
    "id": 109,
    "text": "Say, \"If the sea were ink for [writing] the words of my Lord, the sea would be exhausted before the words of my Lord were exhausted, even if We brought the like of it as a supplement"
  },
  {
    "id": 110,
    "text": "Say, \"I am only a man like you, to whom has been revealed that your god is one God. So whoever would hope for the meeting with his Lord - let him do righteous work and not associate in the worship of his Lord anyone"
  }
]

export default en
