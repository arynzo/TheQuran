import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "The Inevitable Reality"
  },
  {
    "id": 2,
    "text": "What is the Inevitable Reality"
  },
  {
    "id": 3,
    "text": "And what can make you know what is the Inevitable Reality"
  },
  {
    "id": 4,
    "text": "Thamud and 'Aad denied the Striking Calamity"
  },
  {
    "id": 5,
    "text": "So as for Thamud, they were destroyed by the overpowering [blast]"
  },
  {
    "id": 6,
    "text": "And as for 'Aad, they were destroyed by a screaming, violent wind"
  },
  {
    "id": 7,
    "text": "Which Allah imposed upon them for seven nights and eight days in succession, so you would see the people therein fallen as if they were hollow trunks of palm trees"
  },
  {
    "id": 8,
    "text": "Then do you see of them any remains"
  },
  {
    "id": 9,
    "text": "And there came Pharaoh and those before him and the overturned cities with sin"
  },
  {
    "id": 10,
    "text": "And they disobeyed the messenger of their Lord, so He seized them with a seizure exceeding [in severity]"
  },
  {
    "id": 11,
    "text": "Indeed, when the water overflowed, We carried your ancestors in the sailing ship"
  },
  {
    "id": 12,
    "text": "That We might make it for you a reminder and [that] a conscious ear would be conscious of it"
  },
  {
    "id": 13,
    "text": "Then when the Horn is blown with one blast"
  },
  {
    "id": 14,
    "text": "And the earth and the mountains are lifted and leveled with one blow"
  },
  {
    "id": 15,
    "text": "Then on that Day, the Resurrection will occur"
  },
  {
    "id": 16,
    "text": "And the heaven will split [open], for that Day it is infirm"
  },
  {
    "id": 17,
    "text": "And the angels are at its edges. And there will bear the Throne of your Lord above them, that Day, eight [of them]"
  },
  {
    "id": 18,
    "text": "That Day, you will be exhibited [for judgement]; not hidden among you is anything concealed"
  },
  {
    "id": 19,
    "text": "So as for he who is given his record in his right hand, he will say, \"Here, read my record"
  },
  {
    "id": 20,
    "text": "Indeed, I was certain that I would be meeting my account"
  },
  {
    "id": 21,
    "text": "So he will be in a pleasant life"
  },
  {
    "id": 22,
    "text": "In an elevated garden"
  },
  {
    "id": 23,
    "text": "Its [fruit] to be picked hanging near"
  },
  {
    "id": 24,
    "text": "[They will be told], \"Eat and drink in satisfaction for what you put forth in the days past"
  },
  {
    "id": 25,
    "text": "But as for he who is given his record in his left hand, he will say, \"Oh, I wish I had not been given my record"
  },
  {
    "id": 26,
    "text": "And had not known what is my account"
  },
  {
    "id": 27,
    "text": "I wish my death had been the decisive one"
  },
  {
    "id": 28,
    "text": "My wealth has not availed me"
  },
  {
    "id": 29,
    "text": "Gone from me is my authority"
  },
  {
    "id": 30,
    "text": "[Allah will say], \"Seize him and shackle him"
  },
  {
    "id": 31,
    "text": "Then into Hellfire drive him"
  },
  {
    "id": 32,
    "text": "Then into a chain whose length is seventy cubits insert him"
  },
  {
    "id": 33,
    "text": "Indeed, he did not used to believe in Allah, the Most Great"
  },
  {
    "id": 34,
    "text": "Nor did he encourage the feeding of the poor"
  },
  {
    "id": 35,
    "text": "So there is not for him here this Day any devoted friend"
  },
  {
    "id": 36,
    "text": "Nor any food except from the discharge of wounds"
  },
  {
    "id": 37,
    "text": "None will eat it except the sinners"
  },
  {
    "id": 38,
    "text": "So I swear by what you see"
  },
  {
    "id": 39,
    "text": "And what you do not see"
  },
  {
    "id": 40,
    "text": "[That] indeed, the Qur'an is the word of a noble Messenger"
  },
  {
    "id": 41,
    "text": "And it is not the word of a poet; little do you believe"
  },
  {
    "id": 42,
    "text": "Nor the word of a soothsayer; little do you remember"
  },
  {
    "id": 43,
    "text": "[It is] a revelation from the Lord of the worlds"
  },
  {
    "id": 44,
    "text": "And if Muhammad had made up about Us some [false] sayings"
  },
  {
    "id": 45,
    "text": "We would have seized him by the right hand"
  },
  {
    "id": 46,
    "text": "Then We would have cut from him the aorta"
  },
  {
    "id": 47,
    "text": "And there is no one of you who could prevent [Us] from him"
  },
  {
    "id": 48,
    "text": "And indeed, the Qur'an is a reminder for the righteous"
  },
  {
    "id": 49,
    "text": "And indeed, We know that among you are deniers"
  },
  {
    "id": 50,
    "text": "And indeed, it will be [a cause of] regret upon the disbelievers"
  },
  {
    "id": 51,
    "text": "And indeed, it is the truth of certainty"
  },
  {
    "id": 52,
    "text": "So exalt the name of your Lord, the Most Great"
  }
]

export default en
