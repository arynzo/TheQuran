import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Alif, Lam, Meem"
  },
  {
    "id": 2,
    "text": "Allah - there is no deity except Him, the Ever-Living, the Sustainer of existence"
  },
  {
    "id": 3,
    "text": "He has sent down upon you, [O Muhammad], the Book in truth, confirming what was before it. And He revealed the Torah and the Gospel"
  },
  {
    "id": 4,
    "text": "Before, as guidance for the people. And He revealed the Qur'an. Indeed, those who disbelieve in the verses of Allah will have a severe punishment, and Allah is exalted in Might, the Owner of Retribution"
  },
  {
    "id": 5,
    "text": "Indeed, from Allah nothing is hidden in the earth nor in the heaven"
  },
  {
    "id": 6,
    "text": "It is He who forms you in the wombs however He wills. There is no deity except Him, the Exalted in Might, the Wise"
  },
  {
    "id": 7,
    "text": "It is He who has sent down to you, [O Muhammad], the Book; in it are verses [that are] precise - they are the foundation of the Book - and others unspecific. As for those in whose hearts is deviation [from truth], they will follow that of it which is unspecific, seeking discord and seeking an interpretation [suitable to them]. And no one knows its [true] interpretation except Allah. But those firm in knowledge say, \"We believe in it. All [of it] is from our Lord.\" And no one will be reminded except those of understanding"
  },
  {
    "id": 8,
    "text": "[Who say], \"Our Lord, let not our hearts deviate after You have guided us and grant us from Yourself mercy. Indeed, You are the Bestower"
  },
  {
    "id": 9,
    "text": "Our Lord, surely You will gather the people for a Day about which there is no doubt. Indeed, Allah does not fail in His promise"
  },
  {
    "id": 10,
    "text": "Indeed, those who disbelieve - never will their wealth or their children avail them against Allah at all. And it is they who are fuel for the Fire"
  },
  {
    "id": 11,
    "text": "[Theirs is] like the custom of the people of Pharaoh and those before them. They denied Our signs, so Allah seized them for their sins. And Allah is severe in penalty"
  },
  {
    "id": 12,
    "text": "Say to those who disbelieve, \"You will be overcome and gathered together to Hell, and wretched is the resting place"
  },
  {
    "id": 13,
    "text": "Already there has been for you a sign in the two armies which met - one fighting in the cause of Allah and another of disbelievers. They saw them [to be] twice their [own] number by [their] eyesight. But Allah supports with His victory whom He wills. Indeed in that is a lesson for those of vision"
  },
  {
    "id": 14,
    "text": "Beautified for people is the love of that which they desire - of women and sons, heaped-up sums of gold and silver, fine branded horses, and cattle and tilled land. That is the enjoyment of worldly life, but Allah has with Him the best return"
  },
  {
    "id": 15,
    "text": "Say, \"Shall I inform you of [something] better than that? For those who fear Allah will be gardens in the presence of their Lord beneath which rivers flow, wherein they abide eternally, and purified spouses and approval from Allah. And Allah is Seeing of [His] servants"
  },
  {
    "id": 16,
    "text": "Those who say, \"Our Lord, indeed we have believed, so forgive us our sins and protect us from the punishment of the Fire"
  },
  {
    "id": 17,
    "text": "The patient, the true, the obedient, those who spend [in the way of Allah], and those who seek forgiveness before dawn"
  },
  {
    "id": 18,
    "text": "Allah witnesses that there is no deity except Him, and [so do] the angels and those of knowledge - [that He is] maintaining [creation] in justice. There is no deity except Him, the Exalted in Might, the Wise"
  },
  {
    "id": 19,
    "text": "Indeed, the religion in the sight of Allah is Islam. And those who were given the Scripture did not differ except after knowledge had come to them - out of jealous animosity between themselves. And whoever disbelieves in the verses of Allah, then indeed, Allah is swift in [taking] account"
  },
  {
    "id": 20,
    "text": "So if they argue with you, say, \"I have submitted myself to Allah [in Islam], and [so have] those who follow me.\" And say to those who were given the Scripture and [to] the unlearned, \"Have you submitted yourselves?\" And if they submit [in Islam], they are rightly guided; but if they turn away - then upon you is only the [duty of] notification. And Allah is Seeing of [His] servants"
  },
  {
    "id": 21,
    "text": "Those who disbelieve in the signs of Allah and kill the prophets without right and kill those who order justice from among the people - give them tidings of a painful punishment"
  },
  {
    "id": 22,
    "text": "They are the ones whose deeds have become worthless in this world and the Hereafter, and for them there will be no helpers"
  },
  {
    "id": 23,
    "text": "Do you not consider, [O Muhammad], those who were given a portion of the Scripture? They are invited to the Scripture of Allah that it should arbitrate between them; then a party of them turns away, and they are refusing"
  },
  {
    "id": 24,
    "text": "That is because they say, \"Never will the Fire touch us except for [a few] numbered days,\" and [because] they were deluded in their religion by what they were inventing"
  },
  {
    "id": 25,
    "text": "So how will it be when We assemble them for a Day about which there is no doubt? And each soul will be compensated [in full for] what it earned, and they will not be wronged"
  },
  {
    "id": 26,
    "text": "Say, \"O Allah, Owner of Sovereignty, You give sovereignty to whom You will and You take sovereignty away from whom You will. You honor whom You will and You humble whom You will. In Your hand is [all] good. Indeed, You are over all things competent"
  },
  {
    "id": 27,
    "text": "You cause the night to enter the day, and You cause the day to enter the night; and You bring the living out of the dead, and You bring the dead out of the living. And You give provision to whom You will without account"
  },
  {
    "id": 28,
    "text": "Let not believers take disbelievers as allies rather than believers. And whoever [of you] does that has nothing with Allah, except when taking precaution against them in prudence. And Allah warns you of Himself, and to Allah is the [final] destination"
  },
  {
    "id": 29,
    "text": "Say, \"Whether you conceal what is in your breasts or reveal it, Allah knows it. And He knows that which is in the heavens and that which is on the earth. And Allah is over all things competent"
  },
  {
    "id": 30,
    "text": "The Day every soul will find what it has done of good present [before it] and what it has done of evil, it will wish that between itself and that [evil] was a great distance. And Allah warns you of Himself, and Allah is Kind to [His] servants"
  },
  {
    "id": 31,
    "text": "Say, [O Muhammad], \"If you should love Allah, then follow me, [so] Allah will love you and forgive you your sins. And Allah is Forgiving and Merciful"
  },
  {
    "id": 32,
    "text": "Say, \"Obey Allah and the Messenger.\" But if they turn away - then indeed, Allah does not like the disbelievers"
  },
  {
    "id": 33,
    "text": "Indeed, Allah chose Adam and Noah and the family of Abraham and the family of 'Imran over the worlds"
  },
  {
    "id": 34,
    "text": "Descendants, some of them from others. And Allah is Hearing and Knowing"
  },
  {
    "id": 35,
    "text": "[Mention, O Muhammad], when the wife of 'Imran said, \"My Lord, indeed I have pledged to You what is in my womb, consecrated [for Your service], so accept this from me. Indeed, You are the Hearing, the Knowing"
  },
  {
    "id": 36,
    "text": "But when she delivered her, she said, \"My Lord, I have delivered a female.\" And Allah was most knowing of what she delivered, \"And the male is not like the female. And I have named her Mary, and I seek refuge for her in You and [for] her descendants from Satan, the expelled [from the mercy of Allah]"
  },
  {
    "id": 37,
    "text": "So her Lord accepted her with good acceptance and caused her to grow in a good manner and put her in the care of Zechariah. Every time Zechariah entered upon her in the prayer chamber, he found with her provision. He said, \"O Mary, from where is this [coming] to you?\" She said, \"It is from Allah. Indeed, Allah provides for whom He wills without account"
  },
  {
    "id": 38,
    "text": "At that, Zechariah called upon his Lord, saying, \"My Lord, grant me from Yourself a good offspring. Indeed, You are the Hearer of supplication"
  },
  {
    "id": 39,
    "text": "So the angels called him while he was standing in prayer in the chamber, \"Indeed, Allah gives you good tidings of John, confirming a word from Allah and [who will be] honorable, abstaining [from women], and a prophet from among the righteous"
  },
  {
    "id": 40,
    "text": "He said, \"My Lord, how will I have a boy when I have reached old age and my wife is barren?\" The angel said, \"Such is Allah; He does what He wills"
  },
  {
    "id": 41,
    "text": "He said, \"My Lord, make for me a sign.\" He Said, \"Your sign is that you will not [be able to] speak to the people for three days except by gesture. And remember your Lord much and exalt [Him with praise] in the evening and the morning"
  },
  {
    "id": 42,
    "text": "And [mention] when the angels said, \"O Mary, indeed Allah has chosen you and purified you and chosen you above the women of the worlds"
  },
  {
    "id": 43,
    "text": "O Mary, be devoutly obedient to your Lord and prostrate and bow with those who bow [in prayer]"
  },
  {
    "id": 44,
    "text": "That is from the news of the unseen which We reveal to you, [O Muhammad]. And you were not with them when they cast their pens as to which of them should be responsible for Mary. Nor were you with them when they disputed"
  },
  {
    "id": 45,
    "text": "[And mention] when the angels said, \"O Mary, indeed Allah gives you good tidings of a word from Him, whose name will be the Messiah, Jesus, the son of Mary - distinguished in this world and the Hereafter and among those brought near [to Allah]"
  },
  {
    "id": 46,
    "text": "He will speak to the people in the cradle and in maturity and will be of the righteous"
  },
  {
    "id": 47,
    "text": "She said, \"My Lord, how will I have a child when no man has touched me?\" [The angel] said, \"Such is Allah; He creates what He wills. When He decrees a matter, He only says to it, 'Be,' and it is"
  },
  {
    "id": 48,
    "text": "And He will teach him writing and wisdom and the Torah and the Gospel"
  },
  {
    "id": 49,
    "text": "And [make him] a messenger to the Children of Israel, [who will say], 'Indeed I have come to you with a sign from your Lord in that I design for you from clay [that which is] like the form of a bird, then I breathe into it and it becomes a bird by permission of Allah. And I cure the blind and the leper, and I give life to the dead - by permission of Allah. And I inform you of what you eat and what you store in your houses. Indeed in that is a sign for you, if you are believers"
  },
  {
    "id": 50,
    "text": "And [I have come] confirming what was before me of the Torah and to make lawful for you some of what was forbidden to you. And I have come to you with a sign from your Lord, so fear Allah and obey me"
  },
  {
    "id": 51,
    "text": "Indeed, Allah is my Lord and your Lord, so worship Him. That is the straight path"
  },
  {
    "id": 52,
    "text": "But when Jesus felt [persistence in] disbelief from them, he said, \"Who are my supporters for [the cause of] Allah?\" The disciples said, \"We are supporters for Allah. We have believed in Allah and testify that we are Muslims [submitting to Him]"
  },
  {
    "id": 53,
    "text": "Our Lord, we have believed in what You revealed and have followed the messenger Jesus, so register us among the witnesses [to truth]"
  },
  {
    "id": 54,
    "text": "And the disbelievers planned, but Allah planned. And Allah is the best of planners"
  },
  {
    "id": 55,
    "text": "[Mention] when Allah said, \"O Jesus, indeed I will take you and raise you to Myself and purify you from those who disbelieve and make those who follow you [in submission to Allah alone] superior to those who disbelieve until the Day of Resurrection. Then to Me is your return, and I will judge between you concerning that in which you used to differ"
  },
  {
    "id": 56,
    "text": "And as for those who disbelieved, I will punish them with a severe punishment in this world and the Hereafter, and they will have no helpers"
  },
  {
    "id": 57,
    "text": "But as for those who believed and did righteous deeds, He will give them in full their rewards, and Allah does not like the wrongdoers"
  },
  {
    "id": 58,
    "text": "This is what We recite to you, [O Muhammad], of [Our] verses and the precise [and wise] message"
  },
  {
    "id": 59,
    "text": "Indeed, the example of Jesus to Allah is like that of Adam. He created Him from dust; then He said to him, \"Be,\" and he was"
  },
  {
    "id": 60,
    "text": "The truth is from your Lord, so do not be among the doubters"
  },
  {
    "id": 61,
    "text": "Then whoever argues with you about it after [this] knowledge has come to you - say, \"Come, let us call our sons and your sons, our women and your women, ourselves and yourselves, then supplicate earnestly [together] and invoke the curse of Allah upon the liars [among us]"
  },
  {
    "id": 62,
    "text": "Indeed, this is the true narration. And there is no deity except Allah. And indeed, Allah is the Exalted in Might, the Wise"
  },
  {
    "id": 63,
    "text": "But if they turn away, then indeed - Allah is Knowing of the corrupters"
  },
  {
    "id": 64,
    "text": "Say, \"O People of the Scripture, come to a word that is equitable between us and you - that we will not worship except Allah and not associate anything with Him and not take one another as lords instead of Allah.\" But if they turn away, then say, \"Bear witness that we are Muslims [submitting to Him]"
  },
  {
    "id": 65,
    "text": "O People of the Scripture, why do you argue about Abraham while the Torah and the Gospel were not revealed until after him? Then will you not reason"
  },
  {
    "id": 66,
    "text": "Here you are - those who have argued about that of which you have [some] knowledge, but why do you argue about that of which you have no knowledge? And Allah knows, while you know not"
  },
  {
    "id": 67,
    "text": "Abraham was neither a Jew nor a Christian, but he was one inclining toward truth, a Muslim [submitting to Allah]. And he was not of the polytheists"
  },
  {
    "id": 68,
    "text": "Indeed, the most worthy of Abraham among the people are those who followed him [in submission to Allah] and this prophet, and those who believe [in his message]. And Allah is the ally of the believers"
  },
  {
    "id": 69,
    "text": "A faction of the people of the Scripture wish they could mislead you. But they do not mislead except themselves, and they perceive [it] not"
  },
  {
    "id": 70,
    "text": "O People of the Scripture, why do you disbelieve in the verses of Allah while you witness [to their truth]"
  },
  {
    "id": 71,
    "text": "O People of the Scripture, why do you confuse the truth with falsehood and conceal the truth while you know [it]"
  },
  {
    "id": 72,
    "text": "And a faction of the People of the Scripture say [to each other], \"Believe in that which was revealed to the believers at the beginning of the day and reject it at its end that perhaps they will abandon their religion"
  },
  {
    "id": 73,
    "text": "And do not trust except those who follow your religion.\" Say, \"Indeed, the [true] guidance is the guidance of Allah. [Do you fear] lest someone be given [knowledge] like you were given or that they would [thereby] argue with you before your Lord?\" Say, \"Indeed, [all] bounty is in the hand of Allah - He grants it to whom He wills. And Allah is all-Encompassing and Wise"
  },
  {
    "id": 74,
    "text": "He selects for His mercy whom He wills. And Allah is the possessor of great bounty"
  },
  {
    "id": 75,
    "text": "And among the People of the Scripture is he who, if you entrust him with a great amount [of wealth], he will return it to you. And among them is he who, if you entrust him with a [single] silver coin, he will not return it to you unless you are constantly standing over him [demanding it]. That is because they say, \"There is no blame upon us concerning the unlearned.\" And they speak untruth about Allah while they know [it]"
  },
  {
    "id": 76,
    "text": "But yes, whoever fulfills his commitment and fears Allah - then indeed, Allah loves those who fear Him"
  },
  {
    "id": 77,
    "text": "Indeed, those who exchange the covenant of Allah and their [own] oaths for a small price will have no share in the Hereafter, and Allah will not speak to them or look at them on the Day of Resurrection, nor will He purify them; and they will have a painful punishment"
  },
  {
    "id": 78,
    "text": "And indeed, there is among them a party who alter the Scripture with their tongues so you may think it is from the Scripture, but it is not from the Scripture. And they say, \"This is from Allah,\" but it is not from Allah. And they speak untruth about Allah while they know"
  },
  {
    "id": 79,
    "text": "It is not for a human [prophet] that Allah should give him the Scripture and authority and prophethood and then he would say to the people, \"Be servants to me rather than Allah,\" but [instead, he would say], \"Be pious scholars of the Lord because of what you have taught of the Scripture and because of what you have studied"
  },
  {
    "id": 80,
    "text": "Nor could he order you to take the angels and prophets as lords. Would he order you to disbelief after you had been Muslims"
  },
  {
    "id": 81,
    "text": "And [recall, O People of the Scripture], when Allah took the covenant of the prophets, [saying], \"Whatever I give you of the Scripture and wisdom and then there comes to you a messenger confirming what is with you, you [must] believe in him and support him.\" [Allah] said, \"Have you acknowledged and taken upon that My commitment?\" They said, \"We have acknowledged it.\" He said, \"Then bear witness, and I am with you among the witnesses"
  },
  {
    "id": 82,
    "text": "And whoever turned away after that - they were the defiantly disobedient"
  },
  {
    "id": 83,
    "text": "So is it other than the religion of Allah they desire, while to Him have submitted [all] those within the heavens and earth, willingly or by compulsion, and to Him they will be returned"
  },
  {
    "id": 84,
    "text": "Say, \"We have believed in Allah and in what was revealed to us and what was revealed to Abraham, Ishmael, Isaac, Jacob, and the Descendants, and in what was given to Moses and Jesus and to the prophets from their Lord. We make no distinction between any of them, and we are Muslims [submitting] to Him"
  },
  {
    "id": 85,
    "text": "And whoever desires other than Islam as religion - never will it be accepted from him, and he, in the Hereafter, will be among the losers"
  },
  {
    "id": 86,
    "text": "How shall Allah guide a people who disbelieved after their belief and had witnessed that the Messenger is true and clear signs had come to them? And Allah does not guide the wrongdoing people"
  },
  {
    "id": 87,
    "text": "Those - their recompense will be that upon them is the curse of Allah and the angels and the people, all together"
  },
  {
    "id": 88,
    "text": "Abiding eternally therein. The punishment will not be lightened for them, nor will they be reprieved"
  },
  {
    "id": 89,
    "text": "Except for those who repent after that and correct themselves. For indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 90,
    "text": "Indeed, those who reject the message after their belief and then increase in disbelief - never will their [claimed] repentance be accepted, and they are the ones astray"
  },
  {
    "id": 91,
    "text": "Indeed, those who disbelieve and die while they are disbelievers - never would the [whole] capacity of the earth in gold be accepted from one of them if he would [seek to] ransom himself with it. For those there will be a painful punishment, and they will have no helpers"
  },
  {
    "id": 92,
    "text": "Never will you attain the good [reward] until you spend [in the way of Allah] from that which you love. And whatever you spend - indeed, Allah is Knowing of it"
  },
  {
    "id": 93,
    "text": "All food was lawful to the Children of Israel except what Israel had made unlawful to himself before the Torah was revealed. Say, [O Muhammad], \"So bring the Torah and recite it, if you should be truthful"
  },
  {
    "id": 94,
    "text": "And whoever invents about Allah untruth after that - then those are [truly] the wrongdoers"
  },
  {
    "id": 95,
    "text": "Say, \"Allah has told the truth. So follow the religion of Abraham, inclining toward truth; and he was not of the polytheists"
  },
  {
    "id": 96,
    "text": "Indeed, the first House [of worship] established for mankind was that at Makkah - blessed and a guidance for the worlds"
  },
  {
    "id": 97,
    "text": "In it are clear signs [such as] the standing place of Abraham. And whoever enters it shall be safe. And [due] to Allah from the people is a pilgrimage to the House - for whoever is able to find thereto a way. But whoever disbelieves - then indeed, Allah is free from need of the worlds"
  },
  {
    "id": 98,
    "text": "Say, \"O People of the Scripture, why do you disbelieve in the verses of Allah while Allah is Witness over what you do"
  },
  {
    "id": 99,
    "text": "Say, \"O People of the Scripture, why do you avert from the way of Allah those who believe, seeking to make it [seem] deviant, while you are witnesses [to the truth]? And Allah is not unaware of what you do"
  },
  {
    "id": 100,
    "text": "O you who have believed, if you obey a party of those who were given the Scripture, they would turn you back, after your belief, [to being] unbelievers"
  },
  {
    "id": 101,
    "text": "And how could you disbelieve while to you are being recited the verses of Allah and among you is His Messenger? And whoever holds firmly to Allah has [indeed] been guided to a straight path"
  },
  {
    "id": 102,
    "text": "O you who have believed, fear Allah as He should be feared and do not die except as Muslims [in submission to Him]"
  },
  {
    "id": 103,
    "text": "And hold firmly to the rope of Allah all together and do not become divided. And remember the favor of Allah upon you - when you were enemies and He brought your hearts together and you became, by His favor, brothers. And you were on the edge of a pit of the Fire, and He saved you from it. Thus does Allah make clear to you His verses that you may be guided"
  },
  {
    "id": 104,
    "text": "And let there be [arising] from you a nation inviting to [all that is] good, enjoining what is right and forbidding what is wrong, and those will be the successful"
  },
  {
    "id": 105,
    "text": "And do not be like the ones who became divided and differed after the clear proofs had come to them. And those will have a great punishment"
  },
  {
    "id": 106,
    "text": "On the Day [some] faces will turn white and [some] faces will turn black. As for those whose faces turn black, [to them it will be said], \"Did you disbelieve after your belief? Then taste the punishment for what you used to reject"
  },
  {
    "id": 107,
    "text": "But as for those whose faces will turn white, [they will be] within the mercy of Allah. They will abide therein eternally"
  },
  {
    "id": 108,
    "text": "These are the verses of Allah. We recite them to you, [O Muhammad], in truth; and Allah wants no injustice to the worlds"
  },
  {
    "id": 109,
    "text": "To Allah belongs whatever is in the heavens and whatever is on the earth. And to Allah will [all] matters be returned"
  },
  {
    "id": 110,
    "text": "You are the best nation produced [as an example] for mankind. You enjoin what is right and forbid what is wrong and believe in Allah. If only the People of the Scripture had believed, it would have been better for them. Among them are believers, but most of them are defiantly disobedient"
  },
  {
    "id": 111,
    "text": "They will not harm you except for [some] annoyance. And if they fight you, they will show you their backs; then they will not be aided"
  },
  {
    "id": 112,
    "text": "They have been put under humiliation [by Allah] wherever they are overtaken, except for a covenant from Allah and a rope from the Muslims. And they have drawn upon themselves anger from Allah and have been put under destitution. That is because they disbelieved in the verses of Allah and killed the prophets without right. That is because they disobeyed and [habitually] transgressed"
  },
  {
    "id": 113,
    "text": "They are not [all] the same; among the People of the Scripture is a community standing [in obedience], reciting the verses of Allah during periods of the night and prostrating [in prayer]"
  },
  {
    "id": 114,
    "text": "They believe in Allah and the Last Day, and they enjoin what is right and forbid what is wrong and hasten to good deeds. And those are among the righteous"
  },
  {
    "id": 115,
    "text": "And whatever good they do - never will it be removed from them. And Allah is Knowing of the righteous"
  },
  {
    "id": 116,
    "text": "Indeed, those who disbelieve - never will their wealth or their children avail them against Allah at all, and those are the companions of the Fire; they will abide therein eternally"
  },
  {
    "id": 117,
    "text": "The example of what they spend in this worldly life is like that of a wind containing frost which strikes the harvest of a people who have wronged themselves and destroys it. And Allah has not wronged them, but they wrong themselves"
  },
  {
    "id": 118,
    "text": "O you who have believed, do not take as intimates those other than yourselves, for they will not spare you [any] ruin. They wish you would have hardship. Hatred has already appeared from their mouths, and what their breasts conceal is greater. We have certainly made clear to you the signs, if you will use reason"
  },
  {
    "id": 119,
    "text": "Here you are loving them but they are not loving you, while you believe in the Scripture - all of it. And when they meet you, they say, \"We believe.\" But when they are alone, they bite their fingertips at you in rage. Say, \"Die in your rage. Indeed, Allah is Knowing of that within the breasts"
  },
  {
    "id": 120,
    "text": "If good touches you, it distresses them; but if harm strikes you, they rejoice at it. And if you are patient and fear Allah, their plot will not harm you at all. Indeed, Allah is encompassing of what they do"
  },
  {
    "id": 121,
    "text": "And [remember] when you, [O Muhammad], left your family in the morning to post the believers at their stations for the battle [of Uhud] - and Allah is Hearing and Knowing"
  },
  {
    "id": 122,
    "text": "When two parties among you were about to lose courage, but Allah was their ally; and upon Allah the believers should rely"
  },
  {
    "id": 123,
    "text": "And already had Allah given you victory at [the battle of] Badr while you were few in number. Then fear Allah; perhaps you will be grateful"
  },
  {
    "id": 124,
    "text": "[Remember] when you said to the believers, \"Is it not sufficient for you that your Lord should reinforce you with three thousand angels sent down"
  },
  {
    "id": 125,
    "text": "Yes, if you remain patient and conscious of Allah and the enemy come upon you [attacking] in rage, your Lord will reinforce you with five thousand angels having marks [of distinction]"
  },
  {
    "id": 126,
    "text": "And Allah made it not except as [a sign of] good tidings for you and to reassure your hearts thereby. And victory is not except from Allah, the Exalted in Might, the Wise"
  },
  {
    "id": 127,
    "text": "That He might cut down a section of the disbelievers or suppress them so that they turn back disappointed"
  },
  {
    "id": 128,
    "text": "Not for you, [O Muhammad, but for Allah], is the decision whether He should [cut them down] or forgive them or punish them, for indeed, they are wrongdoers"
  },
  {
    "id": 129,
    "text": "And to Allah belongs whatever is in the heavens and whatever is on the earth. He forgives whom He wills and punishes whom He wills. And Allah is Forgiving and Merciful"
  },
  {
    "id": 130,
    "text": "O you who have believed, do not consume usury, doubled and multiplied, but fear Allah that you may be successful"
  },
  {
    "id": 131,
    "text": "And fear the Fire, which has been prepared for the disbelievers"
  },
  {
    "id": 132,
    "text": "And obey Allah and the Messenger that you may obtain mercy"
  },
  {
    "id": 133,
    "text": "And hasten to forgiveness from your Lord and a garden as wide as the heavens and earth, prepared for the righteous"
  },
  {
    "id": 134,
    "text": "Who spend [in the cause of Allah] during ease and hardship and who restrain anger and who pardon the people - and Allah loves the doers of good"
  },
  {
    "id": 135,
    "text": "And those who, when they commit an immorality or wrong themselves [by transgression], remember Allah and seek forgiveness for their sins - and who can forgive sins except Allah? - and [who] do not persist in what they have done while they know"
  },
  {
    "id": 136,
    "text": "Those - their reward is forgiveness from their Lord and gardens beneath which rivers flow [in Paradise], wherein they will abide eternally; and excellent is the reward of the [righteous] workers"
  },
  {
    "id": 137,
    "text": "Similar situations [as yours] have passed on before you, so proceed throughout the earth and observe how was the end of those who denied"
  },
  {
    "id": 138,
    "text": "This [Qur'an] is a clear statement to [all] the people and a guidance and instruction for those conscious of Allah"
  },
  {
    "id": 139,
    "text": "So do not weaken and do not grieve, and you will be superior if you are [true] believers"
  },
  {
    "id": 140,
    "text": "If a wound should touch you - there has already touched the [opposing] people a wound similar to it. And these days [of varying conditions] We alternate among the people so that Allah may make evident those who believe and [may] take to Himself from among you martyrs - and Allah does not like the wrongdoers"
  },
  {
    "id": 141,
    "text": "And that Allah may purify the believers [through trials] and destroy the disbelievers"
  },
  {
    "id": 142,
    "text": "Or do you think that you will enter Paradise while Allah has not yet made evident those of you who fight in His cause and made evident those who are steadfast"
  },
  {
    "id": 143,
    "text": "And you had certainly wished for martyrdom before you encountered it, and you have [now] seen it [before you] while you were looking on"
  },
  {
    "id": 144,
    "text": "Muhammad is not but a messenger. [Other] messengers have passed on before him. So if he was to die or be killed, would you turn back on your heels [to unbelief]? And he who turns back on his heels will never harm Allah at all; but Allah will reward the grateful"
  },
  {
    "id": 145,
    "text": "And it is not [possible] for one to die except by permission of Allah at a decree determined. And whoever desires the reward of this world - We will give him thereof; and whoever desires the reward of the Hereafter - We will give him thereof. And we will reward the grateful"
  },
  {
    "id": 146,
    "text": "And how many a prophet [fought and] with him fought many religious scholars. But they never lost assurance due to what afflicted them in the cause of Allah, nor did they weaken or submit. And Allah loves the steadfast"
  },
  {
    "id": 147,
    "text": "And their words were not but that they said, \"Our Lord, forgive us our sins and the excess [committed] in our affairs and plant firmly our feet and give us victory over the disbelieving people"
  },
  {
    "id": 148,
    "text": "So Allah gave them the reward of this world and the good reward of the Hereafter. And Allah loves the doers of good"
  },
  {
    "id": 149,
    "text": "O you who have believed, if you obey those who disbelieve, they will turn you back on your heels, and you will [then] become losers"
  },
  {
    "id": 150,
    "text": "But Allah is your protector, and He is the best of helpers"
  },
  {
    "id": 151,
    "text": "We will cast terror into the hearts of those who disbelieve for what they have associated with Allah of which He had not sent down [any] authority. And their refuge will be the Fire, and wretched is the residence of the wrongdoers"
  },
  {
    "id": 152,
    "text": "And Allah had certainly fulfilled His promise to you when you were killing the enemy by His permission until [the time] when you lost courage and fell to disputing about the order [given by the Prophet] and disobeyed after He had shown you that which you love. Among you are some who desire this world, and among you are some who desire the Hereafter. Then he turned you back from them [defeated] that He might test you. And He has already forgiven you, and Allah is the possessor of bounty for the believers"
  },
  {
    "id": 153,
    "text": "[Remember] when you [fled and] climbed [the mountain] without looking aside at anyone while the Messenger was calling you from behind. So Allah repaid you with distress upon distress so you would not grieve for that which had escaped you [of victory and spoils of war] or [for] that which had befallen you [of injury and death]. And Allah is [fully] Acquainted with what you do"
  },
  {
    "id": 154,
    "text": "Then after distress, He sent down upon you security [in the form of] drowsiness, overcoming a faction of you, while another faction worried about themselves, thinking of Allah other than the truth - the thought of ignorance, saying, \"Is there anything for us [to have done] in this matter?\" Say, \"Indeed, the matter belongs completely to Allah.\" They conceal within themselves what they will not reveal to you. They say, \"If there was anything we could have done in the matter, some of us would not have been killed right here.\" Say, \"Even if you had been inside your houses, those decreed to be killed would have come out to their death beds.\" [It was] so that Allah might test what is in your breasts and purify what is in your hearts. And Allah is Knowing of that within the breasts"
  },
  {
    "id": 155,
    "text": "Indeed, those of you who turned back on the day the two armies met, it was Satan who caused them to slip because of some [blame] they had earned. But Allah has already forgiven them. Indeed, Allah is Forgiving and Forbearing"
  },
  {
    "id": 156,
    "text": "O you who have believed, do not be like those who disbelieved and said about their brothers when they traveled through the land or went out to fight, \"If they had been with us, they would not have died or have been killed,\" so Allah makes that [misconception] a regret within their hearts. And it is Allah who gives life and causes death, and Allah is Seeing of what you do"
  },
  {
    "id": 157,
    "text": "And if you are killed in the cause of Allah or die - then forgiveness from Allah and mercy are better than whatever they accumulate [in this world]"
  },
  {
    "id": 158,
    "text": "And whether you die or are killed, unto Allah you will be gathered"
  },
  {
    "id": 159,
    "text": "So by mercy from Allah, [O Muhammad], you were lenient with them. And if you had been rude [in speech] and harsh in heart, they would have disbanded from about you. So pardon them and ask forgiveness for them and consult them in the matter. And when you have decided, then rely upon Allah. Indeed, Allah loves those who rely [upon Him]"
  },
  {
    "id": 160,
    "text": "If Allah should aid you, no one can overcome you; but if He should forsake you, who is there that can aid you after Him? And upon Allah let the believers rely"
  },
  {
    "id": 161,
    "text": "It is not [attributable] to any prophet that he would act unfaithfully [in regard to war booty]. And whoever betrays, [taking unlawfully], will come with what he took on the Day of Resurrection. Then will every soul be [fully] compensated for what it earned, and they will not be wronged"
  },
  {
    "id": 162,
    "text": "So is one who pursues the pleasure of Allah like one who brings upon himself the anger of Allah and whose refuge is Hell? And wretched is the destination"
  },
  {
    "id": 163,
    "text": "They are [varying] degrees in the sight of Allah, and Allah is Seeing of whatever they do"
  },
  {
    "id": 164,
    "text": "Certainly did Allah confer [great] favor upon the believers when He sent among them a Messenger from themselves, reciting to them His verses and purifying them and teaching them the Book and wisdom, although they had been before in manifest error"
  },
  {
    "id": 165,
    "text": "Why [is it that] when a [single] disaster struck you [on the day of Uhud], although you had struck [the enemy in the battle of Badr] with one twice as great, you said, \"From where is this?\" Say, \"It is from yourselves.\" Indeed, Allah is over all things competent"
  },
  {
    "id": 166,
    "text": "And what struck you on the day the two armies met was by permission of Allah that He might make evident the [true] believers"
  },
  {
    "id": 167,
    "text": "And that He might make evident those who are hypocrites. For it was said to them, \"Come, fight in the way of Allah or [at least] defend.\" They said, \"If we had known [there would be] fighting, we would have followed you.\" They were nearer to disbelief that day than to faith, saying with their mouths what was not in their hearts. And Allah is most Knowing of what they conceal"
  },
  {
    "id": 168,
    "text": "Those who said about their brothers while sitting [at home], \"If they had obeyed us, they would not have been killed.\" Say, \"Then prevent death from yourselves, if you should be truthful"
  },
  {
    "id": 169,
    "text": "And never think of those who have been killed in the cause of Allah as dead. Rather, they are alive with their Lord, receiving provision"
  },
  {
    "id": 170,
    "text": "Rejoicing in what Allah has bestowed upon them of His bounty, and they receive good tidings about those [to be martyred] after them who have not yet joined them - that there will be no fear concerning them, nor will they grieve"
  },
  {
    "id": 171,
    "text": "They receive good tidings of favor from Allah and bounty and [of the fact] that Allah does not allow the reward of believers to be lost"
  },
  {
    "id": 172,
    "text": "Those [believers] who responded to Allah and the Messenger after injury had struck them. For those who did good among them and feared Allah is a great reward"
  },
  {
    "id": 173,
    "text": "Those to whom hypocrites said, \"Indeed, the people have gathered against you, so fear them.\" But it [merely] increased them in faith, and they said, \"Sufficient for us is Allah, and [He is] the best Disposer of affairs"
  },
  {
    "id": 174,
    "text": "So they returned with favor from Allah and bounty, no harm having touched them. And they pursued the pleasure of Allah, and Allah is the possessor of great bounty"
  },
  {
    "id": 175,
    "text": "That is only Satan who frightens [you] of his supporters. So fear them not, but fear Me, if you are [indeed] believers"
  },
  {
    "id": 176,
    "text": "And do not be grieved, [O Muhammad], by those who hasten into disbelief. Indeed, they will never harm Allah at all. Allah intends that He should give them no share in the Hereafter, and for them is a great punishment"
  },
  {
    "id": 177,
    "text": "Indeed, those who purchase disbelief [in exchange] for faith - never will they harm Allah at all, and for them is a painful punishment"
  },
  {
    "id": 178,
    "text": "And let not those who disbelieve ever think that [because] We extend their time [of enjoyment] it is better for them. We only extend it for them so that they may increase in sin, and for them is a humiliating punishment"
  },
  {
    "id": 179,
    "text": "Allah would not leave the believers in that [state] you are in [presently] until He separates the evil from the good. Nor would Allah reveal to you the unseen. But [instead], Allah chooses of His messengers whom He wills, so believe in Allah and His messengers. And if you believe and fear Him, then for you is a great reward"
  },
  {
    "id": 180,
    "text": "And let not those who [greedily] withhold what Allah has given them of His bounty ever think that it is better for them. Rather, it is worse for them. Their necks will be encircled by what they withheld on the Day of Resurrection. And to Allah belongs the heritage of the heavens and the earth. And Allah, with what you do, is [fully] Acquainted"
  },
  {
    "id": 181,
    "text": "Allah has certainly heard the statement of those [Jews] who said, \"Indeed, Allah is poor, while we are rich.\" We will record what they said and their killing of the prophets without right and will say, \"Taste the punishment of the Burning Fire"
  },
  {
    "id": 182,
    "text": "That is for what your hands have put forth and because Allah is not ever unjust to [His] servants"
  },
  {
    "id": 183,
    "text": "[They are] those who said, \"Indeed, Allah has taken our promise not to believe any messenger until he brings us an offering which fire [from heaven] will consume.\" Say, \"There have already come to you messengers before me with clear proofs and [even] that of which you speak. So why did you kill them, if you should be truthful"
  },
  {
    "id": 184,
    "text": "Then if they deny you, [O Muhammad] - so were messengers denied before you, who brought clear proofs and written ordinances and the enlightening Scripture"
  },
  {
    "id": 185,
    "text": "Every soul will taste death, and you will only be given your [full] compensation on the Day of Resurrection. So he who is drawn away from the Fire and admitted to Paradise has attained [his desire]. And what is the life of this world except the enjoyment of delusion"
  },
  {
    "id": 186,
    "text": "You will surely be tested in your possessions and in yourselves. And you will surely hear from those who were given the Scripture before you and from those who associate others with Allah much abuse. But if you are patient and fear Allah - indeed, that is of the matters [worthy] of determination"
  },
  {
    "id": 187,
    "text": "And [mention, O Muhammad], when Allah took a covenant from those who were given the Scripture, [saying], \"You must make it clear to the people and not conceal it.\" But they threw it away behind their backs and exchanged it for a small price. And wretched is that which they purchased"
  },
  {
    "id": 188,
    "text": "And never think that those who rejoice in what they have perpetrated and like to be praised for what they did not do - never think them [to be] in safety from the punishment, and for them is a painful punishment"
  },
  {
    "id": 189,
    "text": "And to Allah belongs the dominion of the heavens and the earth, and Allah is over all things competent"
  },
  {
    "id": 190,
    "text": "Indeed, in the creation of the heavens and the earth and the alternation of the night and the day are signs for those of understanding"
  },
  {
    "id": 191,
    "text": "Who remember Allah while standing or sitting or [lying] on their sides and give thought to the creation of the heavens and the earth, [saying], \"Our Lord, You did not create this aimlessly; exalted are You [above such a thing]; then protect us from the punishment of the Fire"
  },
  {
    "id": 192,
    "text": "Our Lord, indeed whoever You admit to the Fire - You have disgraced him, and for the wrongdoers there are no helpers"
  },
  {
    "id": 193,
    "text": "Our Lord, indeed we have heard a caller calling to faith, [saying], 'Believe in your Lord,' and we have believed. Our Lord, so forgive us our sins and remove from us our misdeeds and cause us to die with the righteous"
  },
  {
    "id": 194,
    "text": "Our Lord, and grant us what You promised us through Your messengers and do not disgrace us on the Day of Resurrection. Indeed, You do not fail in [Your] promise"
  },
  {
    "id": 195,
    "text": "And their Lord responded to them, \"Never will I allow to be lost the work of [any] worker among you, whether male or female; you are of one another. So those who emigrated or were evicted from their homes or were harmed in My cause or fought or were killed - I will surely remove from them their misdeeds, and I will surely admit them to gardens beneath which rivers flow as reward from Allah, and Allah has with Him the best reward"
  },
  {
    "id": 196,
    "text": "Be not deceived by the [uninhibited] movement of the disbelievers throughout the land"
  },
  {
    "id": 197,
    "text": "[It is but] a small enjoyment; then their [final] refuge is Hell, and wretched is the resting place"
  },
  {
    "id": 198,
    "text": "But those who feared their Lord will have gardens beneath which rivers flow, abiding eternally therein, as accommodation from Allah. And that which is with Allah is best for the righteous"
  },
  {
    "id": 199,
    "text": "And indeed, among the People of the Scripture are those who believe in Allah and what was revealed to you and what was revealed to them, [being] humbly submissive to Allah. They do not exchange the verses of Allah for a small price. Those will have their reward with their Lord. Indeed, Allah is swift in account"
  },
  {
    "id": 200,
    "text": "O you who have believed, persevere and endure and remain stationed and fear Allah that you may be successful"
  }
]

export default en
