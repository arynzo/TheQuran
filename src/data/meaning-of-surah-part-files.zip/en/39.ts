import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "The revelation of the Qur'an is from Allah, the Exalted in Might, the Wise"
  },
  {
    "id": 2,
    "text": "Indeed, We have sent down to you the Book, [O Muhammad], in truth. So worship Allah, [being] sincere to Him in religion"
  },
  {
    "id": 3,
    "text": "Unquestionably, for Allah is the pure religion. And those who take protectors besides Him [say], \"We only worship them that they may bring us nearer to Allah in position.\" Indeed, Allah will judge between them concerning that over which they differ. Indeed, Allah does not guide he who is a liar and [confirmed] disbeliever"
  },
  {
    "id": 4,
    "text": "If Allah had intended to take a son, He could have chosen from what He creates whatever He willed. Exalted is He; He is Allah, the One, the Prevailing"
  },
  {
    "id": 5,
    "text": "He created the heavens and earth in truth. He wraps the night over the day and wraps the day over the night and has subjected the sun and the moon, each running [its course] for a specified term. Unquestionably, He is the Exalted in Might, the Perpetual Forgiver"
  },
  {
    "id": 6,
    "text": "He created you from one soul. Then He made from it its mate, and He produced for you from the grazing livestock eight mates. He creates you in the wombs of your mothers, creation after creation, within three darknesses. That is Allah, your Lord; to Him belongs dominion. There is no deity except Him, so how are you averted"
  },
  {
    "id": 7,
    "text": "If you disbelieve - indeed, Allah is Free from need of you. And He does not approve for His servants disbelief. And if you are grateful, He approves it for you; and no bearer of burdens will bear the burden of another. Then to your Lord is your return, and He will inform you about what you used to do. Indeed, He is Knowing of that within the breasts"
  },
  {
    "id": 8,
    "text": "And when adversity touches man, he calls upon his Lord, turning to Him [alone]; then when He bestows on him a favor from Himself, he forgets Him whom he called upon before, and he attributes to Allah equals to mislead [people] from His way. Say, \"Enjoy your disbelief for a little; indeed, you are of the companions of the Fire"
  },
  {
    "id": 9,
    "text": "Is one who is devoutly obedient during periods of the night, prostrating and standing [in prayer], fearing the Hereafter and hoping for the mercy of his Lord, [like one who does not]? Say, \"Are those who know equal to those who do not know?\" Only they will remember [who are] people of understanding"
  },
  {
    "id": 10,
    "text": "Say, \"O My servants who have believed, fear your Lord. For those who do good in this world is good, and the earth of Allah is spacious. Indeed, the patient will be given their reward without account"
  },
  {
    "id": 11,
    "text": "Say, [O Muhammad], \"Indeed, I have been commanded to worship Allah, [being] sincere to Him in religion"
  },
  {
    "id": 12,
    "text": "And I have been commanded to be the first [among you] of the Muslims"
  },
  {
    "id": 13,
    "text": "Say, \"Indeed I fear, if I should disobey my Lord, the punishment of a tremendous Day"
  },
  {
    "id": 14,
    "text": "Say, \"Allah [alone] do I worship, sincere to Him in my religion"
  },
  {
    "id": 15,
    "text": "So worship what you will besides Him.\" Say, \"Indeed, the losers are the ones who will lose themselves and their families on the Day of Resurrection. Unquestionably, that is the manifest loss"
  },
  {
    "id": 16,
    "text": "They will have canopies of fire above them and below them, canopies. By that Allah threatens His servants. O My servants, then fear Me"
  },
  {
    "id": 17,
    "text": "But those who have avoided Taghut, lest they worship it, and turned back to Allah - for them are good tidings. So give good tidings to My servants"
  },
  {
    "id": 18,
    "text": "Who listen to speech and follow the best of it. Those are the ones Allah has guided, and those are people of understanding"
  },
  {
    "id": 19,
    "text": "Then, is one who has deserved the decree of punishment [to be guided]? Then, can you save one who is in the Fire"
  },
  {
    "id": 20,
    "text": "But those who have feared their Lord - for them are chambers, above them chambers built high, beneath which rivers flow. [This is] the promise of Allah. Allah does not fail in [His] promise"
  },
  {
    "id": 21,
    "text": "Do you not see that Allah sends down rain from the sky and makes it flow as springs [and rivers] in the earth; then He produces thereby crops of varying colors; then they dry and you see them turned yellow; then He makes them [scattered] debris. Indeed in that is a reminder for those of understanding"
  },
  {
    "id": 22,
    "text": "So is one whose breast Allah has expanded to [accept] Islam and he is upon a light from his Lord [like one whose heart rejects it]? Then woe to those whose hearts are hardened against the remembrance of Allah. Those are in manifest error"
  },
  {
    "id": 23,
    "text": "Allah has sent down the best statement: a consistent Book wherein is reiteration. The skins shiver therefrom of those who fear their Lord; then their skins and their hearts relax at the remembrance of Allah. That is the guidance of Allah by which He guides whom He wills. And one whom Allah leaves astray - for him there is no guide"
  },
  {
    "id": 24,
    "text": "Then is he who will shield with his face the worst of the punishment on the Day of Resurrection [like one secure from it]? And it will be said to the wrongdoers, \"Taste what you used to earn"
  },
  {
    "id": 25,
    "text": "Those before them denied, and punishment came upon them from where they did not perceive"
  },
  {
    "id": 26,
    "text": "So Allah made them taste disgrace in worldly life. But the punishment of the Hereafter is greater, if they only knew"
  },
  {
    "id": 27,
    "text": "And We have certainly presented for the people in this Qur'an from every [kind of] example - that they might remember"
  },
  {
    "id": 28,
    "text": "[It is] an Arabic Qur'an, without any deviance that they might become righteous"
  },
  {
    "id": 29,
    "text": "Allah presents an example: a slave owned by quarreling partners and another belonging exclusively to one man - are they equal in comparison? Praise be to Allah! But most of them do not know"
  },
  {
    "id": 30,
    "text": "Indeed, you are to die, and indeed, they are to die"
  },
  {
    "id": 31,
    "text": "Then indeed you, on the Day of Resurrection, before your Lord, will dispute"
  },
  {
    "id": 32,
    "text": "So who is more unjust than one who lies about Allah and denies the truth when it has come to him? Is there not in Hell a residence for the disbelievers"
  },
  {
    "id": 33,
    "text": "And the one who has brought the truth and [they who] believed in it - those are the righteous"
  },
  {
    "id": 34,
    "text": "They will have whatever they desire with their Lord. That is the reward of the doers of good"
  },
  {
    "id": 35,
    "text": "That Allah may remove from them the worst of what they did and reward them their due for the best of what they used to do"
  },
  {
    "id": 36,
    "text": "Is not Allah sufficient for His Servant [Prophet Muhammad]? And [yet], they threaten you with those [they worship] other than Him. And whoever Allah leaves astray - for him there is no guide"
  },
  {
    "id": 37,
    "text": "And whoever Allah guides - for him there is no misleader. Is not Allah Exalted in Might and Owner of Retribution"
  },
  {
    "id": 38,
    "text": "And if you asked them, \"Who created the heavens and the earth?\" they would surely say, \"Allah.\" Say, \"Then have you considered what you invoke besides Allah? If Allah intended me harm, are they removers of His harm; or if He intended me mercy, are they withholders of His mercy?\" Say, \"Sufficient for me is Allah; upon Him [alone] rely the [wise] reliers"
  },
  {
    "id": 39,
    "text": "Say, \"O my people, work according to your position, [for] indeed, I am working; and you are going to know"
  },
  {
    "id": 40,
    "text": "To whom will come a torment disgracing him and on whom will descend an enduring punishment"
  },
  {
    "id": 41,
    "text": "Indeed, We sent down to you the Book for the people in truth. So whoever is guided - it is for [the benefit of] his soul; and whoever goes astray only goes astray to its detriment. And you are not a manager over them"
  },
  {
    "id": 42,
    "text": "Allah takes the souls at the time of their death, and those that do not die [He takes] during their sleep. Then He keeps those for which He has decreed death and releases the others for a specified term. Indeed in that are signs for a people who give thought"
  },
  {
    "id": 43,
    "text": "Or have they taken other than Allah as intercessors? Say, \"Even though they do not possess [power over] anything, nor do they reason"
  },
  {
    "id": 44,
    "text": "Say, \"To Allah belongs [the right to allow] intercession entirely. To Him belongs the dominion of the heavens and the earth. Then to Him you will be returned"
  },
  {
    "id": 45,
    "text": "And when Allah is mentioned alone, the hearts of those who do not believe in the Hereafter shrink with aversion, but when those [worshipped] other than Him are mentioned, immediately they rejoice"
  },
  {
    "id": 46,
    "text": "Say, \"O Allah, Creator of the heavens and the earth, Knower of the unseen and the witnessed, You will judge between your servants concerning that over which they used to differ"
  },
  {
    "id": 47,
    "text": "And if those who did wrong had all that is in the earth entirely and the like of it with it, they would [attempt to] ransom themselves thereby from the worst of the punishment on the Day of Resurrection. And there will appear to them from Allah that which they had not taken into account"
  },
  {
    "id": 48,
    "text": "And there will appear to them the evils they had earned, and they will be enveloped by what they used to ridicule"
  },
  {
    "id": 49,
    "text": "And when adversity touches man, he calls upon Us; then when We bestow on him a favor from Us, he says, \"I have only been given it because of [my] knowledge.\" Rather, it is a trial, but most of them do not know"
  },
  {
    "id": 50,
    "text": "Those before them had already said it, but they were not availed by what they used to earn"
  },
  {
    "id": 51,
    "text": "And the evil consequences of what they earned struck them. And those who have wronged of these [people] will be afflicted by the evil consequences of what they earned; and they will not cause failure"
  },
  {
    "id": 52,
    "text": "Do they not know that Allah extends provision for whom He wills and restricts [it]? Indeed in that are signs for a people who believe"
  },
  {
    "id": 53,
    "text": "Say, \"O My servants who have transgressed against themselves [by sinning], do not despair of the mercy of Allah. Indeed, Allah forgives all sins. Indeed, it is He who is the Forgiving, the Merciful"
  },
  {
    "id": 54,
    "text": "And return [in repentance] to your Lord and submit to Him before the punishment comes upon you; then you will not be helped"
  },
  {
    "id": 55,
    "text": "And follow the best of what was revealed to you from your Lord before the punishment comes upon you suddenly while you do not perceive"
  },
  {
    "id": 56,
    "text": "Lest a soul should say, \"Oh [how great is] my regret over what I neglected in regard to Allah and that I was among the mockers"
  },
  {
    "id": 57,
    "text": "Or [lest] it say, \"If only Allah had guided me, I would have been among the righteous"
  },
  {
    "id": 58,
    "text": "Or [lest] it say when it sees the punishment, \"If only I had another turn so I could be among the doers of good"
  },
  {
    "id": 59,
    "text": "But yes, there had come to you My verses, but you denied them and were arrogant, and you were among the disbelievers"
  },
  {
    "id": 60,
    "text": "And on the Day of Resurrection you will see those who lied about Allah [with] their faces blackened. Is there not in Hell a residence for the arrogant"
  },
  {
    "id": 61,
    "text": "And Allah will save those who feared Him by their attainment; no evil will touch them, nor will they grieve"
  },
  {
    "id": 62,
    "text": "Allah is the Creator of all things, and He is, over all things, Disposer of affairs"
  },
  {
    "id": 63,
    "text": "To Him belong the keys of the heavens and the earth. And they who disbelieve in the verses of Allah - it is those who are the losers"
  },
  {
    "id": 64,
    "text": "Say, [O Muhammad], \"Is it other than Allah that you order me to worship, O ignorant ones"
  },
  {
    "id": 65,
    "text": "And it was already revealed to you and to those before you that if you should associate [anything] with Allah, your work would surely become worthless, and you would surely be among the losers"
  },
  {
    "id": 66,
    "text": "Rather, worship [only] Allah and be among the grateful"
  },
  {
    "id": 67,
    "text": "They have not appraised Allah with true appraisal, while the earth entirely will be [within] His grip on the Day of Resurrection, and the heavens will be folded in His right hand. Exalted is He and high above what they associate with Him"
  },
  {
    "id": 68,
    "text": "And the Horn will be blown, and whoever is in the heavens and whoever is on the earth will fall dead except whom Allah wills. Then it will be blown again, and at once they will be standing, looking on"
  },
  {
    "id": 69,
    "text": "And the earth will shine with the light of its Lord, and the record [of deeds] will be placed, and the prophets and the witnesses will be brought, and it will be judged between them in truth, and they will not be wronged"
  },
  {
    "id": 70,
    "text": "And every soul will be fully compensated [for] what it did; and He is most knowing of what they do"
  },
  {
    "id": 71,
    "text": "And those who disbelieved will be driven to Hell in groups until, when they reach it, its gates are opened and its keepers will say, \"Did there not come to you messengers from yourselves, reciting to you the verses of your Lord and warning you of the meeting of this Day of yours?\" They will say, \"Yes, but the word of punishment has come into effect upon the disbelievers"
  },
  {
    "id": 72,
    "text": "[To them] it will be said, \"Enter the gates of Hell to abide eternally therein, and wretched is the residence of the arrogant"
  },
  {
    "id": 73,
    "text": "But those who feared their Lord will be driven to Paradise in groups until, when they reach it while its gates have been opened and its keepers say, \"Peace be upon you; you have become pure; so enter it to abide eternally therein,\" [they will enter]"
  },
  {
    "id": 74,
    "text": "And they will say, \"Praise to Allah, who has fulfilled for us His promise and made us inherit the earth [so] we may settle in Paradise wherever we will. And excellent is the reward of [righteous] workers"
  },
  {
    "id": 75,
    "text": "And you will see the angels surrounding the Throne, exalting [Allah] with praise of their Lord. And it will be judged between them in truth, and it will be said, \"[All] praise to Allah, Lord of the worlds"
  }
]

export default en
