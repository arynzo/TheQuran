import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Has there [not] come upon man a period of time when he was not a thing [even] mentioned"
  },
  {
    "id": 2,
    "text": "Indeed, We created man from a sperm-drop mixture that We may try him; and We made him hearing and seeing"
  },
  {
    "id": 3,
    "text": "Indeed, We guided him to the way, be he grateful or be he ungrateful"
  },
  {
    "id": 4,
    "text": "Indeed, We have prepared for the disbelievers chains and shackles and a blaze"
  },
  {
    "id": 5,
    "text": "Indeed, the righteous will drink from a cup [of wine] whose mixture is of Kafur"
  },
  {
    "id": 6,
    "text": "A spring of which the [righteous] servants of Allah will drink; they will make it gush forth in force [and abundance]"
  },
  {
    "id": 7,
    "text": "They [are those who] fulfill [their] vows and fear a Day whose evil will be widespread"
  },
  {
    "id": 8,
    "text": "And they give food in spite of love for it to the needy, the orphan, and the captive"
  },
  {
    "id": 9,
    "text": "[Saying], \"We feed you only for the countenance of Allah. We wish not from you reward or gratitude"
  },
  {
    "id": 10,
    "text": "Indeed, We fear from our Lord a Day austere and distressful"
  },
  {
    "id": 11,
    "text": "So Allah will protect them from the evil of that Day and give them radiance and happiness"
  },
  {
    "id": 12,
    "text": "And will reward them for what they patiently endured [with] a garden [in Paradise] and silk [garments]"
  },
  {
    "id": 13,
    "text": "[They will be] reclining therein on adorned couches. They will not see therein any [burning] sun or [freezing] cold"
  },
  {
    "id": 14,
    "text": "And near above them are its shades, and its [fruit] to be picked will be lowered in compliance"
  },
  {
    "id": 15,
    "text": "And there will be circulated among them vessels of silver and cups having been [created] clear [as glass]"
  },
  {
    "id": 16,
    "text": "Clear glasses [made] from silver of which they have determined the measure"
  },
  {
    "id": 17,
    "text": "And they will be given to drink a cup [of wine] whose mixture is of ginger"
  },
  {
    "id": 18,
    "text": "[From] a fountain within Paradise named Salsabeel"
  },
  {
    "id": 19,
    "text": "There will circulate among them young boys made eternal. When you see them, you would think them [as beautiful as] scattered pearls"
  },
  {
    "id": 20,
    "text": "And when you look there [in Paradise], you will see pleasure and great dominion"
  },
  {
    "id": 21,
    "text": "Upon the inhabitants will be green garments of fine silk and brocade. And they will be adorned with bracelets of silver, and their Lord will give them a purifying drink"
  },
  {
    "id": 22,
    "text": "[And it will be said], \"Indeed, this is for you a reward, and your effort has been appreciated"
  },
  {
    "id": 23,
    "text": "Indeed, it is We who have sent down to you, [O Muhammad], the Qur'an progressively"
  },
  {
    "id": 24,
    "text": "So be patient for the decision of your Lord and do not obey from among them a sinner or ungrateful [disbeliever]"
  },
  {
    "id": 25,
    "text": "And mention the name of your Lord [in prayer] morning and evening"
  },
  {
    "id": 26,
    "text": "And during the night prostrate to Him and exalt Him a long [part of the] night"
  },
  {
    "id": 27,
    "text": "Indeed, these [disbelievers] love the immediate and leave behind them a grave Day"
  },
  {
    "id": 28,
    "text": "We have created them and strengthened their forms, and when We will, We can change their likenesses with [complete] alteration"
  },
  {
    "id": 29,
    "text": "Indeed, this is a reminder, so he who wills may take to his Lord a way"
  },
  {
    "id": 30,
    "text": "And you do not will except that Allah wills. Indeed, Allah is ever Knowing and Wise"
  },
  {
    "id": 31,
    "text": "He admits whom He wills into His mercy; but the wrongdoers - He has prepared for them a painful punishment"
  }
]

export default en
