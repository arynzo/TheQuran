import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Exalted is He who took His Servant by night from al-Masjid al-Haram to al-Masjid al-Aqsa, whose surroundings We have blessed, to show him of Our signs. Indeed, He is the Hearing, the Seeing"
  },
  {
    "id": 2,
    "text": "And We gave Moses the Scripture and made it a guidance for the Children of Israel that you not take other than Me as Disposer of affairs"
  },
  {
    "id": 3,
    "text": "O descendants of those We carried [in the ship] with Noah. Indeed, he was a grateful servant"
  },
  {
    "id": 4,
    "text": "And We conveyed to the Children of Israel in the Scripture that, \"You will surely cause corruption on the earth twice, and you will surely reach [a degree of] great haughtiness"
  },
  {
    "id": 5,
    "text": "So when the [time of] promise came for the first of them, We sent against you servants of Ours - those of great military might, and they probed [even] into the homes, and it was a promise fulfilled"
  },
  {
    "id": 6,
    "text": "Then We gave back to you a return victory over them. And We reinforced you with wealth and sons and made you more numerous in manpower"
  },
  {
    "id": 7,
    "text": "[And said], \"If you do good, you do good for yourselves; and if you do evil, [you do it] to yourselves.\" Then when the final promise came, [We sent your enemies] to sadden your faces and to enter the temple in Jerusalem, as they entered it the first time, and to destroy what they had taken over with [total] destruction"
  },
  {
    "id": 8,
    "text": "[Then Allah said], \"It is expected, [if you repent], that your Lord will have mercy upon you. But if you return [to sin], We will return [to punishment]. And We have made Hell, for the disbelievers, a prison-bed"
  },
  {
    "id": 9,
    "text": "Indeed, this Qur'an guides to that which is most suitable and gives good tidings to the believers who do righteous deeds that they will have a great reward"
  },
  {
    "id": 10,
    "text": "And that those who do not believe in the Hereafter - We have prepared for them a painful punishment"
  },
  {
    "id": 11,
    "text": "And man supplicates for evil as he supplicates for good, and man is ever hasty"
  },
  {
    "id": 12,
    "text": "And We have made the night and day two signs, and We erased the sign of the night and made the sign of the day visible that you may seek bounty from your Lord and may know the number of years and the account [of time]. And everything We have set out in detail"
  },
  {
    "id": 13,
    "text": "And [for] every person We have imposed his fate upon his neck, and We will produce for him on the Day of Resurrection a record which he will encounter spread open"
  },
  {
    "id": 14,
    "text": "[It will be said], \"Read your record. Sufficient is yourself against you this Day as accountant"
  },
  {
    "id": 15,
    "text": "Whoever is guided is only guided for [the benefit of] his soul. And whoever errs only errs against it. And no bearer of burdens will bear the burden of another. And never would We punish until We sent a messenger"
  },
  {
    "id": 16,
    "text": "And when We intend to destroy a city, We command its affluent but they defiantly disobey therein; so the word comes into effect upon it, and We destroy it with [complete] destruction"
  },
  {
    "id": 17,
    "text": "And how many have We destroyed from the generations after Noah. And sufficient is your Lord, concerning the sins of His servants, as Acquainted and Seeing"
  },
  {
    "id": 18,
    "text": "Whoever should desire the immediate - We hasten for him from it what We will to whom We intend. Then We have made for him Hell, which he will [enter to] burn, censured and banished"
  },
  {
    "id": 19,
    "text": "But whoever desires the Hereafter and exerts the effort due to it while he is a believer - it is those whose effort is ever appreciated [by Allah]"
  },
  {
    "id": 20,
    "text": "To each [category] We extend - to these and to those - from the gift of your Lord. And never has the gift of your Lord been restricted"
  },
  {
    "id": 21,
    "text": "Look how We have favored [in provision] some of them over others. But the Hereafter is greater in degrees [of difference] and greater in distinction"
  },
  {
    "id": 22,
    "text": "Do not make [as equal] with Allah another deity and [thereby] become censured and forsaken"
  },
  {
    "id": 23,
    "text": "And your Lord has decreed that you not worship except Him, and to parents, good treatment. Whether one or both of them reach old age [while] with you, say not to them [so much as], \"uff,\" and do not repel them but speak to them a noble word"
  },
  {
    "id": 24,
    "text": "And lower to them the wing of humility out of mercy and say, \"My Lord, have mercy upon them as they brought me up [when I was] small"
  },
  {
    "id": 25,
    "text": "Your Lord is most knowing of what is within yourselves. If you should be righteous [in intention] - then indeed He is ever, to the often returning [to Him], Forgiving"
  },
  {
    "id": 26,
    "text": "And give the relative his right, and [also] the poor and the traveler, and do not spend wastefully"
  },
  {
    "id": 27,
    "text": "Indeed, the wasteful are brothers of the devils, and ever has Satan been to his Lord ungrateful"
  },
  {
    "id": 28,
    "text": "And if you [must] turn away from the needy awaiting mercy from your Lord which you expect, then speak to them a gentle word"
  },
  {
    "id": 29,
    "text": "And do not make your hand [as] chained to your neck or extend it completely and [thereby] become blamed and insolvent"
  },
  {
    "id": 30,
    "text": "Indeed, your Lord extends provision for whom He wills and restricts [it]. Indeed He is ever, concerning His servants, Acquainted and Seeing"
  },
  {
    "id": 31,
    "text": "And do not kill your children for fear of poverty. We provide for them and for you. Indeed, their killing is ever a great sin"
  },
  {
    "id": 32,
    "text": "And do not approach unlawful sexual intercourse. Indeed, it is ever an immorality and is evil as a way"
  },
  {
    "id": 33,
    "text": "And do not kill the soul which Allah has forbidden, except by right. And whoever is killed unjustly - We have given his heir authority, but let him not exceed limits in [the matter of] taking life. Indeed, he has been supported [by the law]"
  },
  {
    "id": 34,
    "text": "And do not approach the property of an orphan, except in the way that is best, until he reaches maturity. And fulfill [every] commitment. Indeed, the commitment is ever [that about which one will be] questioned"
  },
  {
    "id": 35,
    "text": "And give full measure when you measure, and weigh with an even balance. That is the best [way] and best in result"
  },
  {
    "id": 36,
    "text": "And do not pursue that of which you have no knowledge. Indeed, the hearing, the sight and the heart - about all those [one] will be questioned"
  },
  {
    "id": 37,
    "text": "And do not walk upon the earth exultantly. Indeed, you will never tear the earth [apart], and you will never reach the mountains in height"
  },
  {
    "id": 38,
    "text": "All that - its evil is ever, in the sight of your Lord, detested"
  },
  {
    "id": 39,
    "text": "That is from what your Lord has revealed to you, [O Muhammad], of wisdom. And, [O mankind], do not make [as equal] with Allah another deity, lest you be thrown into Hell, blamed and banished"
  },
  {
    "id": 40,
    "text": "Then, has your Lord chosen you for [having] sons and taken from among the angels daughters? Indeed, you say a grave saying"
  },
  {
    "id": 41,
    "text": "And We have certainly diversified [the contents] in this Qur'an that mankind may be reminded, but it does not increase the disbelievers except in aversion"
  },
  {
    "id": 42,
    "text": "Say, [O Muhammad], \"If there had been with Him [other] gods, as they say, then they [each] would have sought to the Owner of the Throne a way"
  },
  {
    "id": 43,
    "text": "Exalted is He and high above what they say by great sublimity"
  },
  {
    "id": 44,
    "text": "The seven heavens and the earth and whatever is in them exalt Him. And there is not a thing except that it exalts [Allah] by His praise, but you do not understand their [way of] exalting. Indeed, He is ever Forbearing and Forgiving"
  },
  {
    "id": 45,
    "text": "And when you recite the Qur'an, We put between you and those who do not believe in the Hereafter a concealed partition"
  },
  {
    "id": 46,
    "text": "And We have placed over their hearts coverings, lest they understand it, and in their ears deafness. And when you mention your Lord alone in the Qur'an, they turn back in aversion"
  },
  {
    "id": 47,
    "text": "We are most knowing of how they listen to it when they listen to you and [of] when they are in private conversation, when the wrongdoers say, \"You follow not but a man affected by magic"
  },
  {
    "id": 48,
    "text": "Look how they strike for you comparisons; but they have strayed, so they cannot [find] a way"
  },
  {
    "id": 49,
    "text": "And they say, \"When we are bones and crumbled particles, will we [truly] be resurrected as a new creation"
  },
  {
    "id": 50,
    "text": "Say, \"Be you stones or iron"
  },
  {
    "id": 51,
    "text": "Or [any] creation of that which is great within your breasts.\" And they will say, \"Who will restore us?\" Say, \"He who brought you forth the first time.\" Then they will nod their heads toward you and say, \"When is that?\" Say, \"Perhaps it will be soon"
  },
  {
    "id": 52,
    "text": "On the Day He will call you and you will respond with praise of Him and think that you had not remained [in the world] except for a little"
  },
  {
    "id": 53,
    "text": "And tell My servants to say that which is best. Indeed, Satan induces [dissension] among them. Indeed Satan is ever, to mankind, a clear enemy"
  },
  {
    "id": 54,
    "text": "Your Lord is most knowing of you. If He wills, He will have mercy upon you; or if He wills, He will punish you. And We have not sent you, [O Muhammad], over them as a manager"
  },
  {
    "id": 55,
    "text": "And your Lord is most knowing of whoever is in the heavens and the earth. And We have made some of the prophets exceed others [in various ways], and to David We gave the book [of Psalms]"
  },
  {
    "id": 56,
    "text": "Say, \"Invoke those you have claimed [as gods] besides Him, for they do not possess the [ability for] removal of adversity from you or [for its] transfer [to someone else]"
  },
  {
    "id": 57,
    "text": "Those whom they invoke seek means of access to their Lord, [striving as to] which of them would be nearest, and they hope for His mercy and fear His punishment. Indeed, the punishment of your Lord is ever feared"
  },
  {
    "id": 58,
    "text": "And there is no city but that We will destroy it before the Day of Resurrection or punish it with a severe punishment. That has ever been in the Register inscribed"
  },
  {
    "id": 59,
    "text": "And nothing has prevented Us from sending signs except that the former peoples denied them. And We gave Thamud the she-camel as a visible sign, but they wronged her. And We send not the signs except as a warning"
  },
  {
    "id": 60,
    "text": "And [remember, O Muhammad], when We told you, \"Indeed, your Lord has encompassed the people.\" And We did not make the sight which We showed you except as a trial for the people, as was the accursed tree [mentioned] in the Qur'an. And We threaten them, but it increases them not except in great transgression"
  },
  {
    "id": 61,
    "text": "And [mention] when We said to the angles, \"Prostrate to Adam,\" and they prostrated, except for Iblees. He said, \"Should I prostrate to one You created from clay"
  },
  {
    "id": 62,
    "text": "[Iblees] said, \"Do You see this one whom You have honored above me? If You delay me until the Day of Resurrection, I will surely destroy his descendants, except for a few"
  },
  {
    "id": 63,
    "text": "[Allah] said, \"Go, for whoever of them follows you, indeed Hell will be the recompense of you - an ample recompense"
  },
  {
    "id": 64,
    "text": "And incite [to senselessness] whoever you can among them with your voice and assault them with your horses and foot soldiers and become a partner in their wealth and their children and promise them.\" But Satan does not promise them except delusion"
  },
  {
    "id": 65,
    "text": "Indeed, over My [believing] servants there is for you no authority. And sufficient is your Lord as Disposer of affairs"
  },
  {
    "id": 66,
    "text": "It is your Lord who drives the ship for you through the sea that you may seek of His bounty. Indeed, He is ever, to you, Merciful"
  },
  {
    "id": 67,
    "text": "And when adversity touches you at sea, lost are [all] those you invoke except for Him. But when He delivers you to the land, you turn away [from Him]. And ever is man ungrateful"
  },
  {
    "id": 68,
    "text": "Then do you feel secure that [instead] He will not cause a part of the land to swallow you or send against you a storm of stones? Then you would not find for yourselves an advocate"
  },
  {
    "id": 69,
    "text": "Or do you feel secure that He will not send you back into the sea another time and send upon you a hurricane of wind and drown you for what you denied? Then you would not find for yourselves against Us an avenger"
  },
  {
    "id": 70,
    "text": "And We have certainly honored the children of Adam and carried them on the land and sea and provided for them of the good things and preferred them over much of what We have created, with [definite] preference"
  },
  {
    "id": 71,
    "text": "[Mention, O Muhammad], the Day We will call forth every people with their record [of deeds]. Then whoever is given his record in his right hand - those will read their records, and injustice will not be done to them, [even] as much as a thread [inside the date seed]"
  },
  {
    "id": 72,
    "text": "And whoever is blind in this [life] will be blind in the Hereafter and more astray in way"
  },
  {
    "id": 73,
    "text": "And indeed, they were about to tempt you away from that which We revealed to you in order to [make] you invent about Us something else; and then they would have taken you as a friend"
  },
  {
    "id": 74,
    "text": "And if We had not strengthened you, you would have almost inclined to them a little"
  },
  {
    "id": 75,
    "text": "Then [if you had], We would have made you taste double [punishment in] life and double [after] death. Then you would not find for yourself against Us a helper"
  },
  {
    "id": 76,
    "text": "And indeed, they were about to drive you from the land to evict you therefrom. And then [when they do], they will not remain [there] after you, except for a little"
  },
  {
    "id": 77,
    "text": "[That is Our] established way for those We had sent before you of Our messengers; and you will not find in Our way any alteration"
  },
  {
    "id": 78,
    "text": "Establish prayer at the decline of the sun [from its meridian] until the darkness of the night and [also] the Qur'an of dawn. Indeed, the recitation of dawn is ever witnessed"
  },
  {
    "id": 79,
    "text": "And from [part of] the night, pray with it as additional [worship] for you; it is expected that your Lord will resurrect you to a praised station"
  },
  {
    "id": 80,
    "text": "And say, \"My Lord, cause me to enter a sound entrance and to exit a sound exit and grant me from Yourself a supporting authority"
  },
  {
    "id": 81,
    "text": "And say, \"Truth has come, and falsehood has departed. Indeed is falsehood, [by nature], ever bound to depart"
  },
  {
    "id": 82,
    "text": "And We send down of the Qur'an that which is healing and mercy for the believers, but it does not increase the wrongdoers except in loss"
  },
  {
    "id": 83,
    "text": "And when We bestow favor upon the disbeliever, he turns away and distances himself; and when evil touches him, he is ever despairing"
  },
  {
    "id": 84,
    "text": "Say, \"Each works according to his manner, but your Lord is most knowing of who is best guided in way"
  },
  {
    "id": 85,
    "text": "And they ask you, [O Muhammad], about the soul. Say, \"The soul is of the affair of my Lord. And mankind have not been given of knowledge except a little"
  },
  {
    "id": 86,
    "text": "And if We willed, We could surely do away with that which We revealed to you. Then you would not find for yourself concerning it an advocate against Us"
  },
  {
    "id": 87,
    "text": "Except [We have left it with you] as a mercy from your Lord. Indeed, His favor upon you has ever been great"
  },
  {
    "id": 88,
    "text": "Say, \"If mankind and the jinn gathered in order to produce the like of this Qur'an, they could not produce the like of it, even if they were to each other assistants"
  },
  {
    "id": 89,
    "text": "And We have certainly diversified for the people in this Qur'an from every [kind] of example, but most of the people refused [anything] except disbelief"
  },
  {
    "id": 90,
    "text": "And they say, \"We will not believe you until you break open for us from the ground a spring"
  },
  {
    "id": 91,
    "text": "Or [until] you have a garden of palm tress and grapes and make rivers gush forth within them in force [and abundance]"
  },
  {
    "id": 92,
    "text": "Or you make the heaven fall upon us in fragments as you have claimed or you bring Allah and the angels before [us]"
  },
  {
    "id": 93,
    "text": "Or you have a house of gold or you ascend into the sky. And [even then], we will not believe in your ascension until you bring down to us a book we may read.\" Say, \"Exalted is my Lord! Was I ever but a human messenger"
  },
  {
    "id": 94,
    "text": "And what prevented the people from believing when guidance came to them except that they said, \"Has Allah sent a human messenger"
  },
  {
    "id": 95,
    "text": "Say, \"If there were upon the earth angels walking securely, We would have sent down to them from the heaven an angel [as a] messenger"
  },
  {
    "id": 96,
    "text": "Say, \"Sufficient is Allah as Witness between me and you. Indeed he is ever, concerning His servants, Acquainted and Seeing"
  },
  {
    "id": 97,
    "text": "And whoever Allah guides - he is the [rightly] guided; and whoever He sends astray - you will never find for them protectors besides Him, and We will gather them on the Day of Resurrection [fallen] on their faces - blind, dumb and deaf. Their refuge is Hell; every time it subsides We increase them in blazing fire"
  },
  {
    "id": 98,
    "text": "That is their recompense because they disbelieved in Our verses and said, \"When we are bones and crumbled particles, will we [truly] be resurrected [in] a new creation"
  },
  {
    "id": 99,
    "text": "Do they not see that Allah, who created the heavens and earth, is [the one] Able to create the likes of them? And He has appointed for them a term, about which there is no doubt. But the wrongdoers refuse [anything] except disbelief"
  },
  {
    "id": 100,
    "text": "Say [to them], \"If you possessed the depositories of the mercy of my Lord, then you would withhold out of fear of spending.\" And ever has man been stingy"
  },
  {
    "id": 101,
    "text": "And We had certainly given Moses nine evident signs, so ask the Children of Israel [about] when he came to them and Pharaoh said to him, \"Indeed I think, O Moses, that you are affected by magic"
  },
  {
    "id": 102,
    "text": "[Moses] said, \"You have already known that none has sent down these [signs] except the Lord of the heavens and the earth as evidence, and indeed I think, O Pharaoh, that you are destroyed"
  },
  {
    "id": 103,
    "text": "So he intended to drive them from the land, but We drowned him and those with him all together"
  },
  {
    "id": 104,
    "text": "And We said after Pharaoh to the Children of Israel, \"Dwell in the land, and when there comes the promise of the Hereafter, We will bring you forth in [one] gathering"
  },
  {
    "id": 105,
    "text": "And with the truth We have sent the Qur'an down, and with the truth it has descended. And We have not sent you, [O Muhammad], except as a bringer of good tidings and a warner"
  },
  {
    "id": 106,
    "text": "And [it is] a Qur'an which We have separated [by intervals] that you might recite it to the people over a prolonged period. And We have sent it down progressively"
  },
  {
    "id": 107,
    "text": "Say, \"Believe in it or do not believe. Indeed, those who were given knowledge before it - when it is recited to them, they fall upon their faces in prostration"
  },
  {
    "id": 108,
    "text": "And they say, \"Exalted is our Lord! Indeed, the promise of our Lord has been fulfilled"
  },
  {
    "id": 109,
    "text": "And they fall upon their faces weeping, and the Qur'an increases them in humble submission"
  },
  {
    "id": 110,
    "text": "Say, \"Call upon Allah or call upon the Most Merciful. Whichever [name] you call - to Him belong the best names.\" And do not recite [too] loudly in your prayer or [too] quietly but seek between that an [intermediate] way"
  },
  {
    "id": 111,
    "text": "And say, \"Praise to Allah, who has not taken a son and has had no partner in [His] dominion and has no [need of a] protector out of weakness; and glorify Him with [great] glorification"
  }
]

export default en
