import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "They ask you, [O Muhammad], about the bounties [of war]. Say, \"The [decision concerning] bounties is for Allah and the Messenger.\" So fear Allah and amend that which is between you and obey Allah and His Messenger, if you should be believers"
  },
  {
    "id": 2,
    "text": "The believers are only those who, when Allah is mentioned, their hearts become fearful, and when His verses are recited to them, it increases them in faith; and upon their Lord they rely"
  },
  {
    "id": 3,
    "text": "The ones who establish prayer, and from what We have provided them, they spend"
  },
  {
    "id": 4,
    "text": "Those are the believers, truly. For them are degrees [of high position] with their Lord and forgiveness and noble provision"
  },
  {
    "id": 5,
    "text": "[It is] just as when your Lord brought you out of your home [for the battle of Badr] in truth, while indeed, a party among the believers were unwilling"
  },
  {
    "id": 6,
    "text": "Arguing with you concerning the truth after it had become clear, as if they were being driven toward death while they were looking on"
  },
  {
    "id": 7,
    "text": "[Remember, O believers], when Allah promised you one of the two groups - that it would be yours - and you wished that the unarmed one would be yours. But Allah intended to establish the truth by His words and to eliminate the disbelievers"
  },
  {
    "id": 8,
    "text": "That He should establish the truth and abolish falsehood, even if the criminals disliked it"
  },
  {
    "id": 9,
    "text": "[Remember] when you asked help of your Lord, and He answered you, \"Indeed, I will reinforce you with a thousand from the angels, following one another"
  },
  {
    "id": 10,
    "text": "And Allah made it not but good tidings and so that your hearts would be assured thereby. And victory is not but from Allah. Indeed, Allah is Exalted in Might and Wise"
  },
  {
    "id": 11,
    "text": "[Remember] when He overwhelmed you with drowsiness [giving] security from Him and sent down upon you from the sky, rain by which to purify you and remove from you the evil [suggestions] of Satan and to make steadfast your hearts and plant firmly thereby your feet"
  },
  {
    "id": 12,
    "text": "[Remember] when your Lord inspired to the angels, \"I am with you, so strengthen those who have believed. I will cast terror into the hearts of those who disbelieved, so strike [them] upon the necks and strike from them every fingertip"
  },
  {
    "id": 13,
    "text": "That is because they opposed Allah and His Messenger. And whoever opposes Allah and His Messenger - indeed, Allah is severe in penalty"
  },
  {
    "id": 14,
    "text": "That [is yours], so taste it.\" And indeed for the disbelievers is the punishment of the Fire"
  },
  {
    "id": 15,
    "text": "O you who have believed, when you meet those who disbelieve advancing [for battle], do not turn to them your backs [in flight]"
  },
  {
    "id": 16,
    "text": "And whoever turns his back to them on such a day, unless swerving [as a strategy] for war or joining [another] company, has certainly returned with anger [upon him] from Allah, and his refuge is Hell - and wretched is the destination"
  },
  {
    "id": 17,
    "text": "And you did not kill them, but it was Allah who killed them. And you threw not, [O Muhammad], when you threw, but it was Allah who threw that He might test the believers with a good test. Indeed, Allah is Hearing and Knowing"
  },
  {
    "id": 18,
    "text": "That [is so], and [also] that Allah will weaken the plot of the disbelievers"
  },
  {
    "id": 19,
    "text": "If you [disbelievers] seek the victory - the defeat has come to you. And if you desist [from hostilities], it is best for you; but if you return [to war], We will return, and never will you be availed by your [large] company at all, even if it should increase; and [that is] because Allah is with the believers"
  },
  {
    "id": 20,
    "text": "O you who have believed, obey Allah and His Messenger and do not turn from him while you hear [his order]"
  },
  {
    "id": 21,
    "text": "And do not be like those who say, \"We have heard,\" while they do not hear"
  },
  {
    "id": 22,
    "text": "Indeed, the worst of living creatures in the sight of Allah are the deaf and dumb who do not use reason"
  },
  {
    "id": 23,
    "text": "Had Allah known any good in them, He would have made them hear. And if He had made them hear, they would [still] have turned away, while they were refusing"
  },
  {
    "id": 24,
    "text": "O you who have believed, respond to Allah and to the Messenger when he calls you to that which gives you life. And know that Allah intervenes between a man and his heart and that to Him you will be gathered"
  },
  {
    "id": 25,
    "text": "And fear a trial which will not strike those who have wronged among you exclusively, and know that Allah is severe in penalty"
  },
  {
    "id": 26,
    "text": "And remember when you were few and oppressed in the land, fearing that people might abduct you, but He sheltered you, supported you with His victory, and provided you with good things - that you might be grateful"
  },
  {
    "id": 27,
    "text": "O you who have believed, do not betray Allah and the Messenger or betray your trusts while you know [the consequence]"
  },
  {
    "id": 28,
    "text": "And know that your properties and your children are but a trial and that Allah has with Him a great reward"
  },
  {
    "id": 29,
    "text": "O you who have believed, if you fear Allah, He will grant you a criterion and will remove from you your misdeeds and forgive you. And Allah is the possessor of great bounty"
  },
  {
    "id": 30,
    "text": "And [remember, O Muhammad], when those who disbelieved plotted against you to restrain you or kill you or evict you [from Makkah]. But they plan, and Allah plans. And Allah is the best of planners"
  },
  {
    "id": 31,
    "text": "And when Our verses are recited to them, they say, \"We have heard. If we willed, we could say [something] like this. This is not but legends of the former peoples"
  },
  {
    "id": 32,
    "text": "And [remember] when they said, \"O Allah, if this should be the truth from You, then rain down upon us stones from the sky or bring us a painful punishment"
  },
  {
    "id": 33,
    "text": "But Allah would not punish them while you, [O Muhammad], are among them, and Allah would not punish them while they seek forgiveness"
  },
  {
    "id": 34,
    "text": "But why should Allah not punish them while they obstruct [people] from al-Masjid al- Haram and they were not [fit to be] its guardians? Its [true] guardians are not but the righteous, but most of them do not know"
  },
  {
    "id": 35,
    "text": "And their prayer at the House was not except whistling and handclapping. So taste the punishment for what you disbelieved"
  },
  {
    "id": 36,
    "text": "Indeed, those who disbelieve spend their wealth to avert [people] from the way of Allah. So they will spend it; then it will be for them a [source of] regret; then they will be overcome. And those who have disbelieved - unto Hell they will be gathered"
  },
  {
    "id": 37,
    "text": "[This is] so that Allah may distinguish the wicked from the good and place the wicked some of them upon others and heap them all together and put them into Hell. It is those who are the losers"
  },
  {
    "id": 38,
    "text": "Say to those who have disbelieved [that] if they cease, what has previously occurred will be forgiven for them. But if they return [to hostility] - then the precedent of the former [rebellious] peoples has already taken place"
  },
  {
    "id": 39,
    "text": "And fight them until there is no fitnah and [until] the religion, all of it, is for Allah. And if they cease - then indeed, Allah is Seeing of what they do"
  },
  {
    "id": 40,
    "text": "But if they turn away - then know that Allah is your protector. Excellent is the protector, and Excellent is the helper"
  },
  {
    "id": 41,
    "text": "And know that anything you obtain of war booty - then indeed, for Allah is one fifth of it and for the Messenger and for [his] near relatives and the orphans, the needy, and the [stranded] traveler, if you have believed in Allah and in that which We sent down to Our Servant on the day of criterion - the day when the two armies met. And Allah, over all things, is competent"
  },
  {
    "id": 42,
    "text": "[Remember] when you were on the near side of the valley, and they were on the farther side, and the caravan was lower [in position] than you. If you had made an appointment [to meet], you would have missed the appointment. But [it was] so that Allah might accomplish a matter already destined - that those who perished [through disbelief] would perish upon evidence and those who lived [in faith] would live upon evidence; and indeed, Allah is Hearing and Knowing"
  },
  {
    "id": 43,
    "text": "[Remember, O Muhammad], when Allah showed them to you in your dream as few; and if He had shown them to you as many, you [believers] would have lost courage and would have disputed in the matter [of whether to fight], but Allah saved [you from that]. Indeed, He is Knowing of that within the breasts"
  },
  {
    "id": 44,
    "text": "And [remember] when He showed them to you, when you met, as few in your eyes, and He made you [appear] as few in their eyes so that Allah might accomplish a matter already destined. And to Allah are [all] matters returned"
  },
  {
    "id": 45,
    "text": "O you who have believed, when you encounter a company [from the enemy forces], stand firm and remember Allah much that you may be successful"
  },
  {
    "id": 46,
    "text": "And obey Allah and His Messenger, and do not dispute and [thus] lose courage and [then] your strength would depart; and be patient. Indeed, Allah is with the patient"
  },
  {
    "id": 47,
    "text": "And do not be like those who came forth from their homes insolently and to be seen by people and avert [them] from the way of Allah. And Allah is encompassing of what they do"
  },
  {
    "id": 48,
    "text": "And [remember] when Satan made their deeds pleasing to them and said, \"No one can overcome you today from among the people, and indeed, I am your protector.\" But when the two armies sighted each other, he turned on his heels and said, \"Indeed, I am disassociated from you. Indeed, I see what you do not see; indeed I fear Allah. And Allah is severe in penalty"
  },
  {
    "id": 49,
    "text": "[Remember] when the hypocrites and those in whose hearts was disease said, \"Their religion has deluded those [Muslims].\" But whoever relies upon Allah - then indeed, Allah is Exalted in Might and Wise"
  },
  {
    "id": 50,
    "text": "And if you could but see when the angels take the souls of those who disbelieved... They are striking their faces and their backs and [saying], \"Taste the punishment of the Burning Fire"
  },
  {
    "id": 51,
    "text": "That is for what your hands have put forth [of evil] and because Allah is not ever unjust to His servants"
  },
  {
    "id": 52,
    "text": "[Theirs is] like the custom of the people of Pharaoh and of those before them. They disbelieved in the signs of Allah, so Allah seized them for their sins. Indeed, Allah is Powerful and severe in penalty"
  },
  {
    "id": 53,
    "text": "That is because Allah would not change a favor which He had bestowed upon a people until they change what is within themselves. And indeed, Allah is Hearing and Knowing"
  },
  {
    "id": 54,
    "text": "[Theirs is] like the custom of the people of Pharaoh and of those before them. They denied the signs of their Lord, so We destroyed them for their sins, and We drowned the people of Pharaoh. And all [of them] were wrongdoers"
  },
  {
    "id": 55,
    "text": "Indeed, the worst of living creatures in the sight of Allah are those who have disbelieved, and they will not [ever] believe"
  },
  {
    "id": 56,
    "text": "The ones with whom you made a treaty but then they break their pledge every time, and they do not fear Allah"
  },
  {
    "id": 57,
    "text": "So if you, [O Muhammad], gain dominance over them in war, disperse by [means of] them those behind them that perhaps they will be reminded"
  },
  {
    "id": 58,
    "text": "If you [have reason to] fear from a people betrayal, throw [their treaty] back to them, [putting you] on equal terms. Indeed, Allah does not like traitors"
  },
  {
    "id": 59,
    "text": "And let not those who disbelieve think they will escape. Indeed, they will not cause failure [to Allah]"
  },
  {
    "id": 60,
    "text": "And prepare against them whatever you are able of power and of steeds of war by which you may terrify the enemy of Allah and your enemy and others besides them whom you do not know [but] whom Allah knows. And whatever you spend in the cause of Allah will be fully repaid to you, and you will not be wronged"
  },
  {
    "id": 61,
    "text": "And if they incline to peace, then incline to it [also] and rely upon Allah. Indeed, it is He who is the Hearing, the Knowing"
  },
  {
    "id": 62,
    "text": "But if they intend to deceive you - then sufficient for you is Allah. It is He who supported you with His help and with the believers"
  },
  {
    "id": 63,
    "text": "And brought together their hearts. If you had spent all that is in the earth, you could not have brought their hearts together; but Allah brought them together. Indeed, He is Exalted in Might and Wise"
  },
  {
    "id": 64,
    "text": "O Prophet, sufficient for you is Allah and for whoever follows you of the believers"
  },
  {
    "id": 65,
    "text": "O Prophet, urge the believers to battle. If there are among you twenty [who are] steadfast, they will overcome two hundred. And if there are among you one hundred [who are] steadfast, they will overcome a thousand of those who have disbelieved because they are a people who do not understand"
  },
  {
    "id": 66,
    "text": "Now, Allah has lightened [the hardship] for you, and He knows that among you is weakness. So if there are from you one hundred [who are] steadfast, they will overcome two hundred. And if there are among you a thousand, they will overcome two thousand by permission of Allah. And Allah is with the steadfast"
  },
  {
    "id": 67,
    "text": "It is not for a prophet to have captives [of war] until he inflicts a massacre [upon Allah 's enemies] in the land. Some Muslims desire the commodities of this world, but Allah desires [for you] the Hereafter. And Allah is Exalted in Might and Wise"
  },
  {
    "id": 68,
    "text": "If not for a decree from Allah that preceded, you would have been touched for what you took by a great punishment"
  },
  {
    "id": 69,
    "text": "So consume what you have taken of war booty [as being] lawful and good, and fear Allah. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 70,
    "text": "O Prophet, say to whoever is in your hands of the captives, \"If Allah knows [any] good in your hearts, He will give you [something] better than what was taken from you, and He will forgive you; and Allah is Forgiving and Merciful"
  },
  {
    "id": 71,
    "text": "But if they intend to betray you - then they have already betrayed Allah before, and He empowered [you] over them. And Allah is Knowing and Wise"
  },
  {
    "id": 72,
    "text": "Indeed, those who have believed and emigrated and fought with their wealth and lives in the cause of Allah and those who gave shelter and aided - they are allies of one another. But those who believed and did not emigrate - for you there is no guardianship of them until they emigrate. And if they seek help of you for the religion, then you must help, except against a people between yourselves and whom is a treaty. And Allah is Seeing of what you do"
  },
  {
    "id": 73,
    "text": "And those who disbelieved are allies of one another. If you do not do so, there will be fitnah on earth and great corruption"
  },
  {
    "id": 74,
    "text": "But those who have believed and emigrated and fought in the cause of Allah and those who gave shelter and aided - it is they who are the believers, truly. For them is forgiveness and noble provision"
  },
  {
    "id": 75,
    "text": "And those who believed after [the initial emigration] and emigrated and fought with you - they are of you. But those of [blood] relationship are more entitled [to inheritance] in the decree of Allah. Indeed, Allah is Knowing of all things"
  }
]

export default en
