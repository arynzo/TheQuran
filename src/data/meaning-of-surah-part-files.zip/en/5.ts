import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "O you who have believed, fulfill [all] contracts. Lawful for you are the animals of grazing livestock except for that which is recited to you [in this Qur'an] - hunting not being permitted while you are in the state of ihram. Indeed, Allah ordains what He intends"
  },
  {
    "id": 2,
    "text": "O you who have believed, do not violate the rites of Allah or [the sanctity of] the sacred month or [neglect the marking of] the sacrificial animals and garlanding [them] or [violate the safety of] those coming to the Sacred House seeking bounty from their Lord and [His] approval. But when you come out of ihram, then [you may] hunt. And do not let the hatred of a people for having obstructed you from al-Masjid al-Haram lead you to transgress. And cooperate in righteousness and piety, but do not cooperate in sin and aggression. And fear Allah; indeed, Allah is severe in penalty"
  },
  {
    "id": 3,
    "text": "Prohibited to you are dead animals, blood, the flesh of swine, and that which has been dedicated to other than Allah, and [those animals] killed by strangling or by a violent blow or by a head-long fall or by the goring of horns, and those from which a wild animal has eaten, except what you [are able to] slaughter [before its death], and those which are sacrificed on stone altars, and [prohibited is] that you seek decision through divining arrows. That is grave disobedience. This day those who disbelieve have despaired of [defeating] your religion; so fear them not, but fear Me. This day I have perfected for you your religion and completed My favor upon you and have approved for you Islam as religion. But whoever is forced by severe hunger with no inclination to sin - then indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 4,
    "text": "They ask you, [O Muhammad], what has been made lawful for them. Say, \"Lawful for you are [all] good foods and [game caught by] what you have trained of hunting animals which you train as Allah has taught you. So eat of what they catch for you, and mention the name of Allah upon it, and fear Allah.\" Indeed, Allah is swift in account"
  },
  {
    "id": 5,
    "text": "This day [all] good foods have been made lawful, and the food of those who were given the Scripture is lawful for you and your food is lawful for them. And [lawful in marriage are] chaste women from among the believers and chaste women from among those who were given the Scripture before you, when you have given them their due compensation, desiring chastity, not unlawful sexual intercourse or taking [secret] lovers. And whoever denies the faith - his work has become worthless, and he, in the Hereafter, will be among the losers"
  },
  {
    "id": 6,
    "text": "O you who have believed, when you rise to [perform] prayer, wash your faces and your forearms to the elbows and wipe over your heads and wash your feet to the ankles. And if you are in a state of janabah, then purify yourselves. But if you are ill or on a journey or one of you comes from the place of relieving himself or you have contacted women and do not find water, then seek clean earth and wipe over your faces and hands with it. Allah does not intend to make difficulty for you, but He intends to purify you and complete His favor upon you that you may be grateful"
  },
  {
    "id": 7,
    "text": "And remember the favor of Allah upon you and His covenant with which He bound you when you said, \"We hear and we obey\"; and fear Allah. Indeed, Allah is Knowing of that within the breasts"
  },
  {
    "id": 8,
    "text": "O you who have believed, be persistently standing firm for Allah, witnesses in justice, and do not let the hatred of a people prevent you from being just. Be just; that is nearer to righteousness. And fear Allah; indeed, Allah is Acquainted with what you do"
  },
  {
    "id": 9,
    "text": "Allah has promised those who believe and do righteous deeds [that] for them there is forgiveness and great reward"
  },
  {
    "id": 10,
    "text": "But those who disbelieve and deny Our signs - those are the companions of Hellfire"
  },
  {
    "id": 11,
    "text": "O you who have believed, remember the favor of Allah upon you when a people determined to extend their hands [in aggression] against you, but He withheld their hands from you; and fear Allah. And upon Allah let the believers rely"
  },
  {
    "id": 12,
    "text": "And Allah had already taken a covenant from the Children of Israel, and We delegated from among them twelve leaders. And Allah said, \"I am with you. If you establish prayer and give zakah and believe in My messengers and support them and loan Allah a goodly loan, I will surely remove from you your misdeeds and admit you to gardens beneath which rivers flow. But whoever of you disbelieves after that has certainly strayed from the soundness of the way"
  },
  {
    "id": 13,
    "text": "So for their breaking of the covenant We cursed them and made their hearts hard. They distort words from their [proper] usages and have forgotten a portion of that of which they were reminded. And you will still observe deceit among them, except a few of them. But pardon them and overlook [their misdeeds]. Indeed, Allah loves the doers of good"
  },
  {
    "id": 14,
    "text": "And from those who say, \"We are Christians\" We took their covenant; but they forgot a portion of that of which they were reminded. So We caused among them animosity and hatred until the Day of Resurrection. And Allah is going to inform them about what they used to do"
  },
  {
    "id": 15,
    "text": "O People of the Scripture, there has come to you Our Messenger making clear to you much of what you used to conceal of the Scripture and overlooking much. There has come to you from Allah a light and a clear Book"
  },
  {
    "id": 16,
    "text": "By which Allah guides those who pursue His pleasure to the ways of peace and brings them out from darknesses into the light, by His permission, and guides them to a straight path"
  },
  {
    "id": 17,
    "text": "They have certainly disbelieved who say that Allah is Christ, the son of Mary. Say, \"Then who could prevent Allah at all if He had intended to destroy Christ, the son of Mary, or his mother or everyone on the earth?\" And to Allah belongs the dominion of the heavens and the earth and whatever is between them. He creates what He wills, and Allah is over all things competent"
  },
  {
    "id": 18,
    "text": "But the Jews and the Christians say, \"We are the children of Allah and His beloved.\" Say, \"Then why does He punish you for your sins?\" Rather, you are human beings from among those He has created. He forgives whom He wills, and He punishes whom He wills. And to Allah belongs the dominion of the heavens and the earth and whatever is between them, and to Him is the [final] destination"
  },
  {
    "id": 19,
    "text": "O People of the Scripture, there has come to you Our Messenger to make clear to you [the religion] after a period [of suspension] of messengers, lest you say, \"There came not to us any bringer of good tidings or a warner.\" But there has come to you a bringer of good tidings and a warner. And Allah is over all things competent"
  },
  {
    "id": 20,
    "text": "And [mention, O Muhammad], when Moses said to his people, \"O my people, remember the favor of Allah upon you when He appointed among you prophets and made you possessors and gave you that which He had not given anyone among the worlds"
  },
  {
    "id": 21,
    "text": "O my people, enter the Holy Land which Allah has assigned to you and do not turn back [from fighting in Allah 's cause] and [thus] become losers"
  },
  {
    "id": 22,
    "text": "They said, \"O Moses, indeed within it is a people of tyrannical strength, and indeed, we will never enter it until they leave it; but if they leave it, then we will enter"
  },
  {
    "id": 23,
    "text": "Said two men from those who feared [to disobey] upon whom Allah had bestowed favor, \"Enter upon them through the gate, for when you have entered it, you will be predominant. And upon Allah rely, if you should be believers"
  },
  {
    "id": 24,
    "text": "They said, \"O Moses, indeed we will not enter it, ever, as long as they are within it; so go, you and your Lord, and fight. Indeed, we are remaining right here"
  },
  {
    "id": 25,
    "text": "[Moses] said, \"My Lord, indeed I do not possess except myself and my brother, so part us from the defiantly disobedient people"
  },
  {
    "id": 26,
    "text": "[Allah] said, \"Then indeed, it is forbidden to them for forty years [in which] they will wander throughout the land. So do not grieve over the defiantly disobedient people"
  },
  {
    "id": 27,
    "text": "And recite to them the story of Adam's two sons, in truth, when they both offered a sacrifice [to Allah], and it was accepted from one of them but was not accepted from the other. Said [the latter], \"I will surely kill you.\" Said [the former], \"Indeed, Allah only accepts from the righteous [who fear Him]"
  },
  {
    "id": 28,
    "text": "If you should raise your hand against me to kill me - I shall not raise my hand against you to kill you. Indeed, I fear Allah, Lord of the worlds"
  },
  {
    "id": 29,
    "text": "Indeed I want you to obtain [thereby] my sin and your sin so you will be among the companions of the Fire. And that is the recompense of wrongdoers"
  },
  {
    "id": 30,
    "text": "And his soul permitted to him the murder of his brother, so he killed him and became among the losers"
  },
  {
    "id": 31,
    "text": "Then Allah sent a crow searching in the ground to show him how to hide the disgrace of his brother. He said, \"O woe to me! Have I failed to be like this crow and hide the body of my brother?\" And he became of the regretful"
  },
  {
    "id": 32,
    "text": "Because of that, We decreed upon the Children of Israel that whoever kills a soul unless for a soul or for corruption [done] in the land - it is as if he had slain mankind entirely. And whoever saves one - it is as if he had saved mankind entirely. And our messengers had certainly come to them with clear proofs. Then indeed many of them, [even] after that, throughout the land, were transgressors"
  },
  {
    "id": 33,
    "text": "Indeed, the penalty for those who wage war against Allah and His Messenger and strive upon earth [to cause] corruption is none but that they be killed or crucified or that their hands and feet be cut off from opposite sides or that they be exiled from the land. That is for them a disgrace in this world; and for them in the Hereafter is a great punishment"
  },
  {
    "id": 34,
    "text": "Except for those who return [repenting] before you apprehend them. And know that Allah is Forgiving and Merciful"
  },
  {
    "id": 35,
    "text": "O you who have believed, fear Allah and seek the means [of nearness] to Him and strive in His cause that you may succeed"
  },
  {
    "id": 36,
    "text": "Indeed, those who disbelieve - if they should have all that is in the earth and the like of it with it by which to ransom themselves from the punishment of the Day of Resurrection, it will not be accepted from them, and for them is a painful punishment"
  },
  {
    "id": 37,
    "text": "They will wish to get out of the Fire, but never are they to emerge therefrom, and for them is an enduring punishment"
  },
  {
    "id": 38,
    "text": "[As for] the thief, the male and the female, amputate their hands in recompense for what they committed as a deterrent [punishment] from Allah. And Allah is Exalted in Might and Wise"
  },
  {
    "id": 39,
    "text": "But whoever repents after his wrongdoing and reforms, indeed, Allah will turn to him in forgiveness. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 40,
    "text": "Do you not know that to Allah belongs the dominion of the heavens and the earth? He punishes whom He wills and forgives whom He wills, and Allah is over all things competent"
  },
  {
    "id": 41,
    "text": "O Messenger, let them not grieve you who hasten into disbelief of those who say, \"We believe\" with their mouths, but their hearts believe not, and from among the Jews. [They are] avid listeners to falsehood, listening to another people who have not come to you. They distort words beyond their [proper] usages, saying \"If you are given this, take it; but if you are not given it, then beware.\" But he for whom Allah intends fitnah - never will you possess [power to do] for him a thing against Allah. Those are the ones for whom Allah does not intend to purify their hearts. For them in this world is disgrace, and for them in the Hereafter is a great punishment"
  },
  {
    "id": 42,
    "text": "[They are] avid listeners to falsehood, devourers of [what is] unlawful. So if they come to you, [O Muhammad], judge between them or turn away from them. And if you turn away from them - never will they harm you at all. And if you judge, judge between them with justice. Indeed, Allah loves those who act justly"
  },
  {
    "id": 43,
    "text": "But how is it that they come to you for judgement while they have the Torah, in which is the judgement of Allah? Then they turn away, [even] after that; but those are not [in fact] believers"
  },
  {
    "id": 44,
    "text": "Indeed, We sent down the Torah, in which was guidance and light. The prophets who submitted [to Allah] judged by it for the Jews, as did the rabbis and scholars by that with which they were entrusted of the Scripture of Allah, and they were witnesses thereto. So do not fear the people but fear Me, and do not exchange My verses for a small price. And whoever does not judge by what Allah has revealed - then it is those who are the disbelievers"
  },
  {
    "id": 45,
    "text": "And We ordained for them therein a life for a life, an eye for an eye, a nose for a nose, an ear for an ear, a tooth for a tooth, and for wounds is legal retribution. But whoever gives [up his right as] charity, it is an expiation for him. And whoever does not judge by what Allah has revealed - then it is those who are the wrongdoers"
  },
  {
    "id": 46,
    "text": "And We sent, following in their footsteps, Jesus, the son of Mary, confirming that which came before him in the Torah; and We gave him the Gospel, in which was guidance and light and confirming that which preceded it of the Torah as guidance and instruction for the righteous"
  },
  {
    "id": 47,
    "text": "And let the People of the Gospel judge by what Allah has revealed therein. And whoever does not judge by what Allah has revealed - then it is those who are the defiantly disobedient"
  },
  {
    "id": 48,
    "text": "And We have revealed to you, [O Muhammad], the Book in truth, confirming that which preceded it of the Scripture and as a criterion over it. So judge between them by what Allah has revealed and do not follow their inclinations away from what has come to you of the truth. To each of you We prescribed a law and a method. Had Allah willed, He would have made you one nation [united in religion], but [He intended] to test you in what He has given you; so race to [all that is] good. To Allah is your return all together, and He will [then] inform you concerning that over which you used to differ"
  },
  {
    "id": 49,
    "text": "And judge, [O Muhammad], between them by what Allah has revealed and do not follow their inclinations and beware of them, lest they tempt you away from some of what Allah has revealed to you. And if they turn away - then know that Allah only intends to afflict them with some of their [own] sins. And indeed, many among the people are defiantly disobedient"
  },
  {
    "id": 50,
    "text": "Then is it the judgement of [the time of] ignorance they desire? But who is better than Allah in judgement for a people who are certain [in faith]"
  },
  {
    "id": 51,
    "text": "O you who have believed, do not take the Jews and the Christians as allies. They are [in fact] allies of one another. And whoever is an ally to them among you - then indeed, he is [one] of them. Indeed, Allah guides not the wrongdoing people"
  },
  {
    "id": 52,
    "text": "So you see those in whose hearts is disease hastening into [association with] them, saying, \"We are afraid a misfortune may strike us.\" But perhaps Allah will bring conquest or a decision from Him, and they will become, over what they have been concealing within themselves, regretful"
  },
  {
    "id": 53,
    "text": "And those who believe will say, \"Are these the ones who swore by Allah their strongest oaths that indeed they were with you?\" Their deeds have become worthless, and they have become losers"
  },
  {
    "id": 54,
    "text": "O you who have believed, whoever of you should revert from his religion - Allah will bring forth [in place of them] a people He will love and who will love Him [who are] humble toward the believers, powerful against the disbelievers; they strive in the cause of Allah and do not fear the blame of a critic. That is the favor of Allah; He bestows it upon whom He wills. And Allah is all-Encompassing and Knowing"
  },
  {
    "id": 55,
    "text": "Your ally is none but Allah and [therefore] His Messenger and those who have believed - those who establish prayer and give zakah, and they bow [in worship]"
  },
  {
    "id": 56,
    "text": "And whoever is an ally of Allah and His Messenger and those who have believed - indeed, the party of Allah - they will be the predominant"
  },
  {
    "id": 57,
    "text": "O you who have believed, take not those who have taken your religion in ridicule and amusement among the ones who were given the Scripture before you nor the disbelievers as allies. And fear Allah, if you should [truly] be believers"
  },
  {
    "id": 58,
    "text": "And when you call to prayer, they take it in ridicule and amusement. That is because they are a people who do not use reason"
  },
  {
    "id": 59,
    "text": "Say, \"O People of the Scripture, do you resent us except [for the fact] that we have believed in Allah and what was revealed to us and what was revealed before and because most of you are defiantly disobedient"
  },
  {
    "id": 60,
    "text": "Say, \"Shall I inform you of [what is] worse than that as penalty from Allah? [It is that of] those whom Allah has cursed and with whom He became angry and made of them apes and pigs and slaves of Taghut. Those are worse in position and further astray from the sound way"
  },
  {
    "id": 61,
    "text": "And when they come to you, they say, \"We believe.\" But they have entered with disbelief [in their hearts], and they have certainly left with it. And Allah is most knowing of what they were concealing"
  },
  {
    "id": 62,
    "text": "And you see many of them hastening into sin and aggression and the devouring of [what is] unlawful. How wretched is what they have been doing"
  },
  {
    "id": 63,
    "text": "Why do the rabbis and religious scholars not forbid them from saying what is sinful and devouring what is unlawful? How wretched is what they have been practicing"
  },
  {
    "id": 64,
    "text": "And the Jews say, \"The hand of Allah is chained.\" Chained are their hands, and cursed are they for what they say. Rather, both His hands are extended; He spends however He wills. And that which has been revealed to you from your Lord will surely increase many of them in transgression and disbelief. And We have cast among them animosity and hatred until the Day of Resurrection. Every time they kindled the fire of war [against you], Allah extinguished it. And they strive throughout the land [causing] corruption, and Allah does not like corrupters"
  },
  {
    "id": 65,
    "text": "And if only the People of the Scripture had believed and feared Allah, We would have removed from them their misdeeds and admitted them to Gardens of Pleasure"
  },
  {
    "id": 66,
    "text": "And if only they upheld [the law of] the Torah, the Gospel, and what has been revealed to them from their Lord, they would have consumed [provision] from above them and from beneath their feet. Among them are a moderate community, but many of them - evil is that which they do"
  },
  {
    "id": 67,
    "text": "O Messenger, announce that which has been revealed to you from your Lord, and if you do not, then you have not conveyed His message. And Allah will protect you from the people. Indeed, Allah does not guide the disbelieving people"
  },
  {
    "id": 68,
    "text": "Say, \"O People of the Scripture, you are [standing] on nothing until you uphold [the law of] the Torah, the Gospel, and what has been revealed to you from your Lord.\" And that which has been revealed to you from your Lord will surely increase many of them in transgression and disbelief. So do not grieve over the disbelieving people"
  },
  {
    "id": 69,
    "text": "Indeed, those who have believed [in Prophet Muhammad] and those [before Him] who were Jews or Sabeans or Christians - those [among them] who believed in Allah and the Last Day and did righteousness - no fear will there be concerning them, nor will they grieve"
  },
  {
    "id": 70,
    "text": "We had already taken the covenant of the Children of Israel and had sent to them messengers. Whenever there came to them a messenger with what their souls did not desire, a party [of messengers] they denied, and another party they killed"
  },
  {
    "id": 71,
    "text": "And they thought there would be no [resulting] punishment, so they became blind and deaf. Then Allah turned to them in forgiveness; then [again] many of them became blind and deaf. And Allah is Seeing of what they do"
  },
  {
    "id": 72,
    "text": "They have certainly disbelieved who say, \"Allah is the Messiah, the son of Mary\" while the Messiah has said, \"O Children of Israel, worship Allah, my Lord and your Lord.\" Indeed, he who associates others with Allah - Allah has forbidden him Paradise, and his refuge is the Fire. And there are not for the wrongdoers any helpers"
  },
  {
    "id": 73,
    "text": "They have certainly disbelieved who say, \"Allah is the third of three.\" And there is no god except one God. And if they do not desist from what they are saying, there will surely afflict the disbelievers among them a painful punishment"
  },
  {
    "id": 74,
    "text": "So will they not repent to Allah and seek His forgiveness? And Allah is Forgiving and Merciful"
  },
  {
    "id": 75,
    "text": "The Messiah, son of Mary, was not but a messenger; [other] messengers have passed on before him. And his mother was a supporter of truth. They both used to eat food. Look how We make clear to them the signs; then look how they are deluded"
  },
  {
    "id": 76,
    "text": "Say, \"Do you worship besides Allah that which holds for you no [power of] harm or benefit while it is Allah who is the Hearing, the Knowing"
  },
  {
    "id": 77,
    "text": "Say, \"O People of the Scripture, do not exceed limits in your religion beyond the truth and do not follow the inclinations of a people who had gone astray before and misled many and have strayed from the soundness of the way"
  },
  {
    "id": 78,
    "text": "Cursed were those who disbelieved among the Children of Israel by the tongue of David and of Jesus, the son of Mary. That was because they disobeyed and [habitually] transgressed"
  },
  {
    "id": 79,
    "text": "They used not to prevent one another from wrongdoing that they did. How wretched was that which they were doing"
  },
  {
    "id": 80,
    "text": "You see many of them becoming allies of those who disbelieved. How wretched is that which they have put forth for themselves in that Allah has become angry with them, and in the punishment they will abide eternally"
  },
  {
    "id": 81,
    "text": "And if they had believed in Allah and the Prophet and in what was revealed to him, they would not have taken them as allies; but many of them are defiantly disobedient"
  },
  {
    "id": 82,
    "text": "You will surely find the most intense of the people in animosity toward the believers [to be] the Jews and those who associate others with Allah; and you will find the nearest of them in affection to the believers those who say, \"We are Christians.\" That is because among them are priests and monks and because they are not arrogant"
  },
  {
    "id": 83,
    "text": "And when they hear what has been revealed to the Messenger, you see their eyes overflowing with tears because of what they have recognized of the truth. They say, \"Our Lord, we have believed, so register us among the witnesses"
  },
  {
    "id": 84,
    "text": "And why should we not believe in Allah and what has come to us of the truth? And we aspire that our Lord will admit us [to Paradise] with the righteous people"
  },
  {
    "id": 85,
    "text": "So Allah rewarded them for what they said with gardens [in Paradise] beneath which rivers flow, wherein they abide eternally. And that is the reward of doers of good"
  },
  {
    "id": 86,
    "text": "But those who disbelieved and denied Our signs - they are the companions of Hellfire"
  },
  {
    "id": 87,
    "text": "O you who have believed, do not prohibit the good things which Allah has made lawful to you and do not transgress. Indeed, Allah does not like transgressors"
  },
  {
    "id": 88,
    "text": "And eat of what Allah has provided for you [which is] lawful and good. And fear Allah, in whom you are believers"
  },
  {
    "id": 89,
    "text": "Allah will not impose blame upon you for what is meaningless in your oaths, but He will impose blame upon you for [breaking] what you intended of oaths. So its expiation is the feeding of ten needy people from the average of that which you feed your [own] families or clothing them or the freeing of a slave. But whoever cannot find [or afford it] - then a fast of three days [is required]. That is the expiation for oaths when you have sworn. But guard your oaths. Thus does Allah make clear to you His verses that you may be grateful"
  },
  {
    "id": 90,
    "text": "O you who have believed, indeed, intoxicants, gambling, [sacrificing on] stone alters [to other than Allah], and divining arrows are but defilement from the work of Satan, so avoid it that you may be successful"
  },
  {
    "id": 91,
    "text": "Satan only wants to cause between you animosity and hatred through intoxicants and gambling and to avert you from the remembrance of Allah and from prayer. So will you not desist"
  },
  {
    "id": 92,
    "text": "And obey Allah and obey the Messenger and beware. And if you turn away - then know that upon Our Messenger is only [the responsibility for] clear notification"
  },
  {
    "id": 93,
    "text": "There is not upon those who believe and do righteousness [any] blame concerning what they have eaten [in the past] if they [now] fear Allah and believe and do righteous deeds, and then fear Allah and believe, and then fear Allah and do good; and Allah loves the doers of good"
  },
  {
    "id": 94,
    "text": "O you who have believed, Allah will surely test you through something of the game that your hands and spears [can] reach, that Allah may make evident those who fear Him unseen. And whoever transgresses after that - for him is a painful punishment"
  },
  {
    "id": 95,
    "text": "O you who have believed, do not kill game while you are in the state of ihram. And whoever of you kills it intentionally - the penalty is an equivalent from sacrificial animals to what he killed, as judged by two just men among you as an offering [to Allah] delivered to the Ka'bah, or an expiation: the feeding of needy people or the equivalent of that in fasting, that he may taste the consequence of his deed. Allah has pardoned what is past; but whoever returns [to violation], then Allah will take retribution from him. And Allah is Exalted in Might and Owner of Retribution"
  },
  {
    "id": 96,
    "text": "Lawful to you is game from the sea and its food as provision for you and the travelers, but forbidden to you is game from the land as long as you are in the state of ihram. And fear Allah to whom you will be gathered"
  },
  {
    "id": 97,
    "text": "Allah has made the Ka'bah, the Sacred House, standing for the people and [has sanctified] the sacred months and the sacrificial animals and the garlands [by which they are identified]. That is so you may know that Allah knows what is in the heavens and what is in the earth and that Allah is Knowing of all things"
  },
  {
    "id": 98,
    "text": "Know that Allah is severe in penalty and that Allah is Forgiving and Merciful"
  },
  {
    "id": 99,
    "text": "Not upon the Messenger is [responsibility] except [for] notification. And Allah knows whatever you reveal and whatever you conceal"
  },
  {
    "id": 100,
    "text": "Say, \"Not equal are the evil and the good, although the abundance of evil might impress you.\" So fear Allah, O you of understanding, that you may be successful"
  },
  {
    "id": 101,
    "text": "O you who have believed, do not ask about things which, if they are shown to you, will distress you. But if you ask about them while the Qur'an is being revealed, they will be shown to you. Allah has pardoned that which is past; and Allah is Forgiving and Forbearing"
  },
  {
    "id": 102,
    "text": "A people asked such [questions] before you; then they became thereby disbelievers"
  },
  {
    "id": 103,
    "text": "Allah has not appointed [such innovations as] bahirah or sa'ibah or wasilah or ham. But those who disbelieve invent falsehood about Allah, and most of them do not reason"
  },
  {
    "id": 104,
    "text": "And when it is said to them, \"Come to what Allah has revealed and to the Messenger,\" they say, \"Sufficient for us is that upon which we found our fathers.\" Even though their fathers knew nothing, nor were they guided"
  },
  {
    "id": 105,
    "text": "O you who have believed, upon you is [responsibility for] yourselves. Those who have gone astray will not harm you when you have been guided. To Allah is you return all together; then He will inform you of what you used to do"
  },
  {
    "id": 106,
    "text": "O you who have believed, testimony [should be taken] among you when death approaches one of you at the time of bequest - [that of] two just men from among you or two others from outside if you are traveling through the land and the disaster of death should strike you. Detain them after the prayer and let them both swear by Allah if you doubt [their testimony, saying], \"We will not exchange our oath for a price, even if he should be a near relative, and we will not withhold the testimony of Allah. Indeed, we would then be of the sinful"
  },
  {
    "id": 107,
    "text": "But if it is found that those two were guilty of perjury, let two others stand in their place [who are] foremost [in claim] from those who have a lawful right. And let them swear by Allah, \"Our testimony is truer than their testimony, and we have not transgressed. Indeed, we would then be of the wrongdoers"
  },
  {
    "id": 108,
    "text": "That is more likely that they will give testimony according to its [true] objective, or [at least] they would fear that [other] oaths might be taken after their oaths. And fear Allah and listen; and Allah does not guide the defiantly disobedient people"
  },
  {
    "id": 109,
    "text": "[Be warned of] the Day when Allah will assemble the messengers and say, \"What was the response you received?\" They will say, \"We have no knowledge. Indeed, it is You who is Knower of the unseen"
  },
  {
    "id": 110,
    "text": "[The Day] when Allah will say, \"O Jesus, Son of Mary, remember My favor upon you and upon your mother when I supported you with the Pure Spirit and you spoke to the people in the cradle and in maturity; and [remember] when I taught you writing and wisdom and the Torah and the Gospel; and when you designed from clay [what was] like the form of a bird with My permission, then you breathed into it, and it became a bird with My permission; and you healed the blind and the leper with My permission; and when you brought forth the dead with My permission; and when I restrained the Children of Israel from [killing] you when you came to them with clear proofs and those who disbelieved among them said, \"This is not but obvious magic"
  },
  {
    "id": 111,
    "text": "And [remember] when I inspired to the disciples, \"Believe in Me and in My messenger Jesus.\" They said, \"We have believed, so bear witness that indeed we are Muslims [in submission to Allah]"
  },
  {
    "id": 112,
    "text": "[And remember] when the disciples said, \"O Jesus, Son of Mary, can your Lord send down to us a table [spread with food] from the heaven? [Jesus] said,\" Fear Allah, if you should be believers"
  },
  {
    "id": 113,
    "text": "They said, \"We wish to eat from it and let our hearts be reassured and know that you have been truthful to us and be among its witnesses"
  },
  {
    "id": 114,
    "text": "Said Jesus, the son of Mary, \"O Allah, our Lord, send down to us a table [spread with food] from the heaven to be for us a festival for the first of us and the last of us and a sign from You. And provide for us, and You are the best of providers"
  },
  {
    "id": 115,
    "text": "Allah said, \"Indeed, I will sent it down to you, but whoever disbelieves afterwards from among you - then indeed will I punish him with a punishment by which I have not punished anyone among the worlds"
  },
  {
    "id": 116,
    "text": "And [beware the Day] when Allah will say, \"O Jesus, Son of Mary, did you say to the people, 'Take me and my mother as deities besides Allah?'\" He will say, \"Exalted are You! It was not for me to say that to which I have no right. If I had said it, You would have known it. You know what is within myself, and I do not know what is within Yourself. Indeed, it is You who is Knower of the unseen"
  },
  {
    "id": 117,
    "text": "I said not to them except what You commanded me - to worship Allah, my Lord and your Lord. And I was a witness over them as long as I was among them; but when You took me up, You were the Observer over them, and You are, over all things, Witness"
  },
  {
    "id": 118,
    "text": "If You should punish them - indeed they are Your servants; but if You forgive them - indeed it is You who is the Exalted in Might, the Wise"
  },
  {
    "id": 119,
    "text": "Allah will say, \"This is the Day when the truthful will benefit from their truthfulness.\" For them are gardens [in Paradise] beneath which rivers flow, wherein they will abide forever, Allah being pleased with them, and they with Him. That is the great attainment"
  },
  {
    "id": 120,
    "text": "To Allah belongs the dominion of the heavens and the earth and whatever is within them. And He is over all things competent"
  }
]

export default en
