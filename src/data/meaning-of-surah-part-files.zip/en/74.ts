import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "O you who covers himself [with a garment]"
  },
  {
    "id": 2,
    "text": "Arise and warn"
  },
  {
    "id": 3,
    "text": "And your Lord glorify"
  },
  {
    "id": 4,
    "text": "And your clothing purify"
  },
  {
    "id": 5,
    "text": "And uncleanliness avoid"
  },
  {
    "id": 6,
    "text": "And do not confer favor to acquire more"
  },
  {
    "id": 7,
    "text": "But for your Lord be patient"
  },
  {
    "id": 8,
    "text": "And when the trumpet is blown"
  },
  {
    "id": 9,
    "text": "That Day will be a difficult day"
  },
  {
    "id": 10,
    "text": "For the disbelievers - not easy"
  },
  {
    "id": 11,
    "text": "Leave Me with the one I created alone"
  },
  {
    "id": 12,
    "text": "And to whom I granted extensive wealth"
  },
  {
    "id": 13,
    "text": "And children present [with him]"
  },
  {
    "id": 14,
    "text": "And spread [everything] before him, easing [his life]"
  },
  {
    "id": 15,
    "text": "Then he desires that I should add more"
  },
  {
    "id": 16,
    "text": "No! Indeed, he has been toward Our verses obstinate"
  },
  {
    "id": 17,
    "text": "I will cover him with arduous torment"
  },
  {
    "id": 18,
    "text": "Indeed, he thought and deliberated"
  },
  {
    "id": 19,
    "text": "So may he be destroyed [for] how he deliberated"
  },
  {
    "id": 20,
    "text": "Then may he be destroyed [for] how he deliberated"
  },
  {
    "id": 21,
    "text": "Then he considered [again]"
  },
  {
    "id": 22,
    "text": "Then he frowned and scowled"
  },
  {
    "id": 23,
    "text": "Then he turned back and was arrogant"
  },
  {
    "id": 24,
    "text": "And said, \"This is not but magic imitated [from others]"
  },
  {
    "id": 25,
    "text": "This is not but the word of a human being"
  },
  {
    "id": 26,
    "text": "I will drive him into Saqar"
  },
  {
    "id": 27,
    "text": "And what can make you know what is Saqar"
  },
  {
    "id": 28,
    "text": "It lets nothing remain and leaves nothing [unburned]"
  },
  {
    "id": 29,
    "text": "Blackening the skins"
  },
  {
    "id": 30,
    "text": "Over it are nineteen [angels]"
  },
  {
    "id": 31,
    "text": "And We have not made the keepers of the Fire except angels. And We have not made their number except as a trial for those who disbelieve - that those who were given the Scripture will be convinced and those who have believed will increase in faith and those who were given the Scripture and the believers will not doubt and that those in whose hearts is hypocrisy and the disbelievers will say, \"What does Allah intend by this as an example?\" Thus does Allah leave astray whom He wills and guides whom He wills. And none knows the soldiers of your Lord except Him. And mention of the Fire is not but a reminder to humanity"
  },
  {
    "id": 32,
    "text": "No! By the moon"
  },
  {
    "id": 33,
    "text": "And [by] the night when it departs"
  },
  {
    "id": 34,
    "text": "And [by] the morning when it brightens"
  },
  {
    "id": 35,
    "text": "Indeed, the Fire is of the greatest [afflictions]"
  },
  {
    "id": 36,
    "text": "As a warning to humanity"
  },
  {
    "id": 37,
    "text": "To whoever wills among you to proceed or stay behind"
  },
  {
    "id": 38,
    "text": "Every soul, for what it has earned, will be retained"
  },
  {
    "id": 39,
    "text": "Except the companions of the right"
  },
  {
    "id": 40,
    "text": "[Who will be] in gardens, questioning each other"
  },
  {
    "id": 41,
    "text": "About the criminals"
  },
  {
    "id": 42,
    "text": "[And asking them], \"What put you into Saqar"
  },
  {
    "id": 43,
    "text": "They will say, \"We were not of those who prayed"
  },
  {
    "id": 44,
    "text": "Nor did we used to feed the poor"
  },
  {
    "id": 45,
    "text": "And we used to enter into vain discourse with those who engaged [in it]"
  },
  {
    "id": 46,
    "text": "And we used to deny the Day of Recompense"
  },
  {
    "id": 47,
    "text": "Until there came to us the certainty"
  },
  {
    "id": 48,
    "text": "So there will not benefit them the intercession of [any] intercessors"
  },
  {
    "id": 49,
    "text": "Then what is [the matter] with them that they are, from the reminder, turning away"
  },
  {
    "id": 50,
    "text": "As if they were alarmed donkeys"
  },
  {
    "id": 51,
    "text": "Fleeing from a lion"
  },
  {
    "id": 52,
    "text": "Rather, every person among them desires that he would be given scriptures spread about"
  },
  {
    "id": 53,
    "text": "No! But they do not fear the Hereafter"
  },
  {
    "id": 54,
    "text": "No! Indeed, the Qur'an is a reminder"
  },
  {
    "id": 55,
    "text": "Then whoever wills will remember it"
  },
  {
    "id": 56,
    "text": "And they will not remember except that Allah wills. He is worthy of fear and adequate for [granting] forgiveness"
  }
]

export default en
