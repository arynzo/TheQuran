import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "About what are they asking one another"
  },
  {
    "id": 2,
    "text": "About the great news"
  },
  {
    "id": 3,
    "text": "That over which they are in disagreement"
  },
  {
    "id": 4,
    "text": "No! They are going to know"
  },
  {
    "id": 5,
    "text": "Then, no! They are going to know"
  },
  {
    "id": 6,
    "text": "Have We not made the earth a resting place"
  },
  {
    "id": 7,
    "text": "And the mountains as stakes"
  },
  {
    "id": 8,
    "text": "And We created you in pairs"
  },
  {
    "id": 9,
    "text": "And made your sleep [a means for] rest"
  },
  {
    "id": 10,
    "text": "And made the night as clothing"
  },
  {
    "id": 11,
    "text": "And made the day for livelihood"
  },
  {
    "id": 12,
    "text": "And constructed above you seven strong [heavens]"
  },
  {
    "id": 13,
    "text": "And made [therein] a burning lamp"
  },
  {
    "id": 14,
    "text": "And sent down, from the rain clouds, pouring water"
  },
  {
    "id": 15,
    "text": "That We may bring forth thereby grain and vegetation"
  },
  {
    "id": 16,
    "text": "And gardens of entwined growth"
  },
  {
    "id": 17,
    "text": "Indeed, the Day of Judgement is an appointed time"
  },
  {
    "id": 18,
    "text": "The Day the Horn is blown and you will come forth in multitudes"
  },
  {
    "id": 19,
    "text": "And the heaven is opened and will become gateways"
  },
  {
    "id": 20,
    "text": "And the mountains are removed and will be [but] a mirage"
  },
  {
    "id": 21,
    "text": "Indeed, Hell has been lying in wait"
  },
  {
    "id": 22,
    "text": "For the transgressors, a place of return"
  },
  {
    "id": 23,
    "text": "In which they will remain for ages [unending]"
  },
  {
    "id": 24,
    "text": "They will not taste therein [any] coolness or drink"
  },
  {
    "id": 25,
    "text": "Except scalding water and [foul] purulence"
  },
  {
    "id": 26,
    "text": "An appropriate recompense"
  },
  {
    "id": 27,
    "text": "Indeed, they were not expecting an account"
  },
  {
    "id": 28,
    "text": "And denied Our verses with [emphatic] denial"
  },
  {
    "id": 29,
    "text": "But all things We have enumerated in writing"
  },
  {
    "id": 30,
    "text": "So taste [the penalty], and never will We increase you except in torment"
  },
  {
    "id": 31,
    "text": "Indeed, for the righteous is attainment"
  },
  {
    "id": 32,
    "text": "Gardens and grapevines"
  },
  {
    "id": 33,
    "text": "And full-breasted [companions] of equal age"
  },
  {
    "id": 34,
    "text": "And a full cup"
  },
  {
    "id": 35,
    "text": "No ill speech will they hear therein or any falsehood"
  },
  {
    "id": 36,
    "text": "[As] reward from your Lord, [a generous] gift [made due by] account"
  },
  {
    "id": 37,
    "text": "[From] the Lord of the heavens and the earth and whatever is between them, the Most Merciful. They possess not from Him [authority for] speech"
  },
  {
    "id": 38,
    "text": "The Day that the Spirit and the angels will stand in rows, they will not speak except for one whom the Most Merciful permits, and he will say what is correct"
  },
  {
    "id": 39,
    "text": "That is the True Day; so he who wills may take to his Lord a [way of] return"
  },
  {
    "id": 40,
    "text": "Indeed, We have warned you of a near punishment on the Day when a man will observe what his hands have put forth and the disbeliever will say, \"Oh, I wish that I were dust"
  }
]

export default en
