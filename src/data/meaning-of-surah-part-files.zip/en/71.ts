import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Indeed, We sent Noah to his people, [saying], \"Warn your people before there comes to them a painful punishment"
  },
  {
    "id": 2,
    "text": "He said, \"O my people, indeed I am to you a clear warner"
  },
  {
    "id": 3,
    "text": "[Saying], 'Worship Allah, fear Him and obey me"
  },
  {
    "id": 4,
    "text": "Allah will forgive you of your sins and delay you for a specified term. Indeed, the time [set by] Allah, when it comes, will not be delayed, if you only knew"
  },
  {
    "id": 5,
    "text": "He said, \"My Lord, indeed I invited my people [to truth] night and day"
  },
  {
    "id": 6,
    "text": "But my invitation increased them not except in flight"
  },
  {
    "id": 7,
    "text": "And indeed, every time I invited them that You may forgive them, they put their fingers in their ears, covered themselves with their garments, persisted, and were arrogant with [great] arrogance"
  },
  {
    "id": 8,
    "text": "Then I invited them publicly"
  },
  {
    "id": 9,
    "text": "Then I announced to them and [also] confided to them secretly"
  },
  {
    "id": 10,
    "text": "And said, 'Ask forgiveness of your Lord. Indeed, He is ever a Perpetual Forgiver"
  },
  {
    "id": 11,
    "text": "He will send [rain from] the sky upon you in [continuing] showers"
  },
  {
    "id": 12,
    "text": "And give you increase in wealth and children and provide for you gardens and provide for you rivers"
  },
  {
    "id": 13,
    "text": "What is [the matter] with you that you do not attribute to Allah [due] grandeur"
  },
  {
    "id": 14,
    "text": "While He has created you in stages"
  },
  {
    "id": 15,
    "text": "Do you not consider how Allah has created seven heavens in layers"
  },
  {
    "id": 16,
    "text": "And made the moon therein a [reflected] light and made the sun a burning lamp"
  },
  {
    "id": 17,
    "text": "And Allah has caused you to grow from the earth a [progressive] growth"
  },
  {
    "id": 18,
    "text": "Then He will return you into it and extract you [another] extraction"
  },
  {
    "id": 19,
    "text": "And Allah has made for you the earth an expanse"
  },
  {
    "id": 20,
    "text": "That you may follow therein roads of passage"
  },
  {
    "id": 21,
    "text": "Noah said, \"My Lord, indeed they have disobeyed me and followed him whose wealth and children will not increase him except in loss"
  },
  {
    "id": 22,
    "text": "And they conspired an immense conspiracy"
  },
  {
    "id": 23,
    "text": "And said, 'Never leave your gods and never leave Wadd or Suwa' or Yaghuth and Ya'uq and Nasr"
  },
  {
    "id": 24,
    "text": "And already they have misled many. And, [my Lord], do not increase the wrongdoers except in error"
  },
  {
    "id": 25,
    "text": "Because of their sins they were drowned and put into the Fire, and they found not for themselves besides Allah [any] helpers"
  },
  {
    "id": 26,
    "text": "And Noah said, \"My Lord, do not leave upon the earth from among the disbelievers an inhabitant"
  },
  {
    "id": 27,
    "text": "Indeed, if You leave them, they will mislead Your servants and not beget except [every] wicked one and [confirmed] disbeliever"
  },
  {
    "id": 28,
    "text": "My Lord, forgive me and my parents and whoever enters my house a believer and the believing men and believing women. And do not increase the wrongdoers except in destruction"
  }
]

export default en
