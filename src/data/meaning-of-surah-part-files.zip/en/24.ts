import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "[This is] a surah which We have sent down and made [that within it] obligatory and revealed therein verses of clear evidence that you might remember"
  },
  {
    "id": 2,
    "text": "The [unmarried] woman or [unmarried] man found guilty of sexual intercourse - lash each one of them with a hundred lashes, and do not be taken by pity for them in the religion of Allah, if you should believe in Allah and the Last Day. And let a group of the believers witness their punishment"
  },
  {
    "id": 3,
    "text": "The fornicator does not marry except a [female] fornicator or polytheist, and none marries her except a fornicator or a polytheist, and that has been made unlawful to the believers"
  },
  {
    "id": 4,
    "text": "And those who accuse chaste women and then do not produce four witnesses - lash them with eighty lashes and do not accept from them testimony ever after. And those are the defiantly disobedient"
  },
  {
    "id": 5,
    "text": "Except for those who repent thereafter and reform, for indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 6,
    "text": "And those who accuse their wives [of adultery] and have no witnesses except themselves - then the witness of one of them [shall be] four testimonies [swearing] by Allah that indeed, he is of the truthful"
  },
  {
    "id": 7,
    "text": "And the fifth [oath will be] that the curse of Allah be upon him if he should be among the liars"
  },
  {
    "id": 8,
    "text": "But it will prevent punishment from her if she gives four testimonies [swearing] by Allah that indeed, he is of the liars"
  },
  {
    "id": 9,
    "text": "And the fifth [oath will be] that the wrath of Allah be upon her if he was of the truthful"
  },
  {
    "id": 10,
    "text": "And if not for the favor of Allah upon you and His mercy... and because Allah is Accepting of repentance and Wise"
  },
  {
    "id": 11,
    "text": "Indeed, those who came with falsehood are a group among you. Do not think it bad for you; rather it is good for you. For every person among them is what [punishment] he has earned from the sin, and he who took upon himself the greater portion thereof - for him is a great punishment"
  },
  {
    "id": 12,
    "text": "Why, when you heard it, did not the believing men and believing women think good of one another and say, \"This is an obvious falsehood"
  },
  {
    "id": 13,
    "text": "Why did they [who slandered] not produce for it four witnesses? And when they do not produce the witnesses, then it is they, in the sight of Allah, who are the liars"
  },
  {
    "id": 14,
    "text": "And if it had not been for the favor of Allah upon you and His mercy in this world and the Hereafter, you would have been touched for that [lie] in which you were involved by a great punishment"
  },
  {
    "id": 15,
    "text": "When you received it with your tongues and said with your mouths that of which you had no knowledge and thought it was insignificant while it was, in the sight of Allah, tremendous"
  },
  {
    "id": 16,
    "text": "And why, when you heard it, did you not say, \"It is not for us to speak of this. Exalted are You, [O Allah]; this is a great slander"
  },
  {
    "id": 17,
    "text": "Allah warns you against returning to the likes of this [conduct], ever, if you should be believers"
  },
  {
    "id": 18,
    "text": "And Allah makes clear to you the verses, and Allah is Knowing and Wise"
  },
  {
    "id": 19,
    "text": "Indeed, those who like that immorality should be spread [or publicized] among those who have believed will have a painful punishment in this world and the Hereafter. And Allah knows and you do not know"
  },
  {
    "id": 20,
    "text": "And if it had not been for the favor of Allah upon you and His mercy... and because Allah is Kind and Merciful"
  },
  {
    "id": 21,
    "text": "O you who have believed, do not follow the footsteps of Satan. And whoever follows the footsteps of Satan - indeed, he enjoins immorality and wrongdoing. And if not for the favor of Allah upon you and His mercy, not one of you would have been pure, ever, but Allah purifies whom He wills, and Allah is Hearing and Knowing"
  },
  {
    "id": 22,
    "text": "And let not those of virtue among you and wealth swear not to give [aid] to their relatives and the needy and the emigrants for the cause of Allah, and let them pardon and overlook. Would you not like that Allah should forgive you? And Allah is Forgiving and Merciful"
  },
  {
    "id": 23,
    "text": "Indeed, those who [falsely] accuse chaste, unaware and believing women are cursed in this world and the Hereafter; and they will have a great punishment"
  },
  {
    "id": 24,
    "text": "On a Day when their tongues, their hands and their feet will bear witness against them as to what they used to do"
  },
  {
    "id": 25,
    "text": "That Day, Allah will pay them in full their deserved recompense, and they will know that it is Allah who is the perfect in justice"
  },
  {
    "id": 26,
    "text": "Evil words are for evil men, and evil men are [subjected] to evil words. And good words are for good men, and good men are [an object] of good words. Those [good people] are declared innocent of what the slanderers say. For them is forgiveness and noble provision"
  },
  {
    "id": 27,
    "text": "O you who have believed, do not enter houses other than your own houses until you ascertain welcome and greet their inhabitants. That is best for you; perhaps you will be reminded"
  },
  {
    "id": 28,
    "text": "And if you do not find anyone therein, do not enter them until permission has been given you. And if it is said to you, \"Go back,\" then go back; it is purer for you. And Allah is Knowing of what you do"
  },
  {
    "id": 29,
    "text": "There is no blame upon you for entering houses not inhabited in which there is convenience for you. And Allah knows what you reveal and what you conceal"
  },
  {
    "id": 30,
    "text": "Tell the believing men to reduce [some] of their vision and guard their private parts. That is purer for them. Indeed, Allah is Acquainted with what they do"
  },
  {
    "id": 31,
    "text": "And tell the believing women to reduce [some] of their vision and guard their private parts and not expose their adornment except that which [necessarily] appears thereof and to wrap [a portion of] their headcovers over their chests and not expose their adornment except to their husbands, their fathers, their husbands' fathers, their sons, their husbands' sons, their brothers, their brothers' sons, their sisters' sons, their women, that which their right hands possess, or those male attendants having no physical desire, or children who are not yet aware of the private aspects of women. And let them not stamp their feet to make known what they conceal of their adornment. And turn to Allah in repentance, all of you, O believers, that you might succeed"
  },
  {
    "id": 32,
    "text": "And marry the unmarried among you and the righteous among your male slaves and female slaves. If they should be poor, Allah will enrich them from His bounty, and Allah is all-Encompassing and Knowing"
  },
  {
    "id": 33,
    "text": "But let them who find not [the means for] marriage abstain [from sexual relations] until Allah enriches them from His bounty. And those who seek a contract [for eventual emancipation] from among whom your right hands possess - then make a contract with them if you know there is within them goodness and give them from the wealth of Allah which He has given you. And do not compel your slave girls to prostitution, if they desire chastity, to seek [thereby] the temporary interests of worldly life. And if someone should compel them, then indeed, Allah is [to them], after their compulsion, Forgiving and Merciful"
  },
  {
    "id": 34,
    "text": "And We have certainly sent down to you distinct verses and examples from those who passed on before you and an admonition for those who fear Allah"
  },
  {
    "id": 35,
    "text": "Allah is the Light of the heavens and the earth. The example of His light is like a niche within which is a lamp, the lamp is within glass, the glass as if it were a pearly [white] star lit from [the oil of] a blessed olive tree, neither of the east nor of the west, whose oil would almost glow even if untouched by fire. Light upon light. Allah guides to His light whom He wills. And Allah presents examples for the people, and Allah is Knowing of all things"
  },
  {
    "id": 36,
    "text": "[Such niches are] in mosques which Allah has ordered to be raised and that His name be mentioned therein; exalting Him within them in the morning and the evenings"
  },
  {
    "id": 37,
    "text": "[Are] men whom neither commerce nor sale distracts from the remembrance of Allah and performance of prayer and giving of zakah. They fear a Day in which the hearts and eyes will [fearfully] turn about"
  },
  {
    "id": 38,
    "text": "That Allah may reward them [according to] the best of what they did and increase them from His bounty. And Allah gives provision to whom He wills without account"
  },
  {
    "id": 39,
    "text": "But those who disbelieved - their deeds are like a mirage in a lowland which a thirsty one thinks is water until, when he comes to it, he finds it is nothing but finds Allah before Him, and He will pay him in full his due; and Allah is swift in account"
  },
  {
    "id": 40,
    "text": "Or [they are] like darknesses within an unfathomable sea which is covered by waves, upon which are waves, over which are clouds - darknesses, some of them upon others. When one puts out his hand [therein], he can hardly see it. And he to whom Allah has not granted light - for him there is no light"
  },
  {
    "id": 41,
    "text": "Do you not see that Allah is exalted by whomever is within the heavens and the earth and [by] the birds with wings spread [in flight]? Each [of them] has known his [means of] prayer and exalting [Him], and Allah is Knowing of what they do"
  },
  {
    "id": 42,
    "text": "And to Allah belongs the dominion of the heavens and the earth, and to Allah is the destination"
  },
  {
    "id": 43,
    "text": "Do you not see that Allah drives clouds? Then He brings them together, then He makes them into a mass, and you see the rain emerge from within it. And He sends down from the sky, mountains [of clouds] within which is hail, and He strikes with it whom He wills and averts it from whom He wills. The flash of its lightening almost takes away the eyesight"
  },
  {
    "id": 44,
    "text": "Allah alternates the night and the day. Indeed in that is a lesson for those who have vision"
  },
  {
    "id": 45,
    "text": "Allah has created every [living] creature from water. And of them are those that move on their bellies, and of them are those that walk on two legs, and of them are those that walk on four. Allah creates what He wills. Indeed, Allah is over all things competent"
  },
  {
    "id": 46,
    "text": "We have certainly sent down distinct verses. And Allah guides whom He wills to a straight path"
  },
  {
    "id": 47,
    "text": "But the hypocrites say, \"We have believed in Allah and in the Messenger, and we obey\"; then a party of them turns away after that. And those are not believers"
  },
  {
    "id": 48,
    "text": "And when they are called to [the words of] Allah and His Messenger to judge between them, at once a party of them turns aside [in refusal]"
  },
  {
    "id": 49,
    "text": "But if the right is theirs, they come to him in prompt obedience"
  },
  {
    "id": 50,
    "text": "Is there disease in their hearts? Or have they doubted? Or do they fear that Allah will be unjust to them, or His Messenger? Rather, it is they who are the wrongdoers"
  },
  {
    "id": 51,
    "text": "The only statement of the [true] believers when they are called to Allah and His Messenger to judge between them is that they say, \"We hear and we obey.\" And those are the successful"
  },
  {
    "id": 52,
    "text": "And whoever obeys Allah and His Messenger and fears Allah and is conscious of Him - it is those who are the attainers"
  },
  {
    "id": 53,
    "text": "And they swear by Allah their strongest oaths that if you ordered them, they would go forth [in Allah 's cause]. Say, \"Do not swear. [Such] obedience is known. Indeed, Allah is Acquainted with that which you do"
  },
  {
    "id": 54,
    "text": "Say, \"Obey Allah and obey the Messenger; but if you turn away - then upon him is only that [duty] with which he has been charged, and upon you is that with which you have been charged. And if you obey him, you will be [rightly] guided. And there is not upon the Messenger except the [responsibility for] clear notification"
  },
  {
    "id": 55,
    "text": "Allah has promised those who have believed among you and done righteous deeds that He will surely grant them succession [to authority] upon the earth just as He granted it to those before them and that He will surely establish for them [therein] their religion which He has preferred for them and that He will surely substitute for them, after their fear, security, [for] they worship Me, not associating anything with Me. But whoever disbelieves after that - then those are the defiantly disobedient"
  },
  {
    "id": 56,
    "text": "And establish prayer and give zakah and obey the Messenger - that you may receive mercy"
  },
  {
    "id": 57,
    "text": "Never think that the disbelievers are causing failure [to Allah] upon the earth. Their refuge will be the Fire - and how wretched the destination"
  },
  {
    "id": 58,
    "text": "O you who have believed, let those whom your right hands possess and those who have not [yet] reached puberty among you ask permission of you [before entering] at three times: before the dawn prayer and when you put aside your clothing [for rest] at noon and after the night prayer. [These are] three times of privacy for you. There is no blame upon you nor upon them beyond these [periods], for they continually circulate among you - some of you, among others. Thus does Allah make clear to you the verses; and Allah is Knowing and Wise"
  },
  {
    "id": 59,
    "text": "And when the children among you reach puberty, let them ask permission [at all times] as those before them have done. Thus does Allah make clear to you His verses; and Allah is Knowing and Wise"
  },
  {
    "id": 60,
    "text": "And women of post-menstrual age who have no desire for marriage - there is no blame upon them for putting aside their outer garments [but] not displaying adornment. But to modestly refrain [from that] is better for them. And Allah is Hearing and Knowing"
  },
  {
    "id": 61,
    "text": "There is not upon the blind [any] constraint nor upon the lame constraint nor upon the ill constraint nor upon yourselves when you eat from your [own] houses or the houses of your fathers or the houses of your mothers or the houses of your brothers or the houses of your sisters or the houses of your father's brothers or the houses of your father's sisters or the houses of your mother's brothers or the houses of your mother's sisters or [from houses] whose keys you possess or [from the house] of your friend. There is no blame upon you whether you eat together or separately. But when you enter houses, give greetings of peace upon each other - a greeting from Allah, blessed and good. Thus does Allah make clear to you the verses [of ordinance] that you may understand"
  },
  {
    "id": 62,
    "text": "The believers are only those who believe in Allah and His Messenger and, when they are [meeting] with him for a matter of common interest, do not depart until they have asked his permission. Indeed, those who ask your permission, [O Muhammad] - those are the ones who believe in Allah and His Messenger. So when they ask your permission for something of their affairs, then give permission to whom you will among them and ask forgiveness for them of Allah. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 63,
    "text": "Do not make [your] calling of the Messenger among yourselves as the call of one of you to another. Already Allah knows those of you who slip away, concealed by others. So let those beware who dissent from the Prophet's order, lest fitnah strike them or a painful punishment"
  },
  {
    "id": 64,
    "text": "Unquestionably, to Allah belongs whatever is in the heavens and earth. Already He knows that upon which you [stand] and [knows] the Day when they will be returned to Him and He will inform them of what they have done. And Allah is Knowing of all things"
  }
]

export default en
