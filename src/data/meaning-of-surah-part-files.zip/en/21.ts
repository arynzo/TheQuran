import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "[The time of] their account has approached for the people, while they are in heedlessness turning away"
  },
  {
    "id": 2,
    "text": "No mention comes to them anew from their Lord except that they listen to it while they are at play"
  },
  {
    "id": 3,
    "text": "With their hearts distracted. And those who do wrong conceal their private conversation, [saying], \"Is this [Prophet] except a human being like you? So would you approach magic while you are aware [of it]"
  },
  {
    "id": 4,
    "text": "The Prophet said, \"My Lord knows whatever is said throughout the heaven and earth, and He is the Hearing, the Knowing"
  },
  {
    "id": 5,
    "text": "But they say, \"[The revelation is but] a mixture of false dreams; rather, he has invented it; rather, he is a poet. So let him bring us a sign just as the previous [messengers] were sent [with miracles]"
  },
  {
    "id": 6,
    "text": "Not a [single] city which We destroyed believed before them, so will they believe"
  },
  {
    "id": 7,
    "text": "And We sent not before you, [O Muhammad], except men to whom We revealed [the message], so ask the people of the message if you do not know"
  },
  {
    "id": 8,
    "text": "And We did not make the prophets forms not eating food, nor were they immortal [on earth]"
  },
  {
    "id": 9,
    "text": "Then We fulfilled for them the promise, and We saved them and whom We willed and destroyed the transgressors"
  },
  {
    "id": 10,
    "text": "We have certainly sent down to you a Book in which is your mention. Then will you not reason"
  },
  {
    "id": 11,
    "text": "And how many a city which was unjust have We shattered and produced after it another people"
  },
  {
    "id": 12,
    "text": "And when its inhabitants perceived Our punishment, at once they fled from it"
  },
  {
    "id": 13,
    "text": "[Some angels said], \"Do not flee but return to where you were given luxury and to your homes - perhaps you will be questioned"
  },
  {
    "id": 14,
    "text": "They said, \"O woe to us! Indeed, we were wrongdoers"
  },
  {
    "id": 15,
    "text": "And that declaration of theirs did not cease until We made them [as] a harvest [mowed down], extinguished [like a fire]"
  },
  {
    "id": 16,
    "text": "And We did not create the heaven and earth and that between them in play"
  },
  {
    "id": 17,
    "text": "Had We intended to take a diversion, We could have taken it from [what is] with Us - if [indeed] We were to do so"
  },
  {
    "id": 18,
    "text": "Rather, We dash the truth upon falsehood, and it destroys it, and thereupon it departs. And for you is destruction from that which you describe"
  },
  {
    "id": 19,
    "text": "To Him belongs whoever is in the heavens and the earth. And those near Him are not prevented by arrogance from His worship, nor do they tire"
  },
  {
    "id": 20,
    "text": "They exalt [Him] night and day [and] do not slacken"
  },
  {
    "id": 21,
    "text": "Or have men taken for themselves gods from the earth who resurrect [the dead]"
  },
  {
    "id": 22,
    "text": "Had there been within the heavens and earth gods besides Allah, they both would have been ruined. So exalted is Allah, Lord of the Throne, above what they describe"
  },
  {
    "id": 23,
    "text": "He is not questioned about what He does, but they will be questioned"
  },
  {
    "id": 24,
    "text": "Or have they taken gods besides Him? Say, [O Muhammad], \"Produce your proof. This [Qur'an] is the message for those with me and the message of those before me.\" But most of them do not know the truth, so they are turning away"
  },
  {
    "id": 25,
    "text": "And We sent not before you any messenger except that We revealed to him that, \"There is no deity except Me, so worship Me"
  },
  {
    "id": 26,
    "text": "And they say, \"The Most Merciful has taken a son.\" Exalted is He! Rather, they are [but] honored servants"
  },
  {
    "id": 27,
    "text": "They cannot precede Him in word, and they act by His command"
  },
  {
    "id": 28,
    "text": "He knows what is [presently] before them and what will be after them, and they cannot intercede except on behalf of one whom He approves. And they, from fear of Him, are apprehensive"
  },
  {
    "id": 29,
    "text": "And whoever of them should say, \"Indeed, I am a god besides Him\"- that one We would recompense with Hell. Thus do We recompense the wrongdoers"
  },
  {
    "id": 30,
    "text": "Have those who disbelieved not considered that the heavens and the earth were a joined entity, and We separated them and made from water every living thing? Then will they not believe"
  },
  {
    "id": 31,
    "text": "And We placed within the earth firmly set mountains, lest it should shift with them, and We made therein [mountain] passes [as] roads that they might be guided"
  },
  {
    "id": 32,
    "text": "And We made the sky a protected ceiling, but they, from its signs, are turning away"
  },
  {
    "id": 33,
    "text": "And it is He who created the night and the day and the sun and the moon; all [heavenly bodies] in an orbit are swimming"
  },
  {
    "id": 34,
    "text": "And We did not grant to any man before you eternity [on earth]; so if you die - would they be eternal"
  },
  {
    "id": 35,
    "text": "Every soul will taste death. And We test you with evil and with good as trial; and to Us you will be returned"
  },
  {
    "id": 36,
    "text": "And when those who disbelieve see you, [O Muhammad], they take you not except in ridicule, [saying], \"Is this the one who insults your gods?\" And they are, at the mention of the Most Merciful, disbelievers"
  },
  {
    "id": 37,
    "text": "Man was created of haste. I will show you My signs, so do not impatiently urge Me"
  },
  {
    "id": 38,
    "text": "And they say, \"When is this promise, if you should be truthful"
  },
  {
    "id": 39,
    "text": "If those who disbelieved but knew the time when they will not avert the Fire from their faces or from their backs and they will not be aided"
  },
  {
    "id": 40,
    "text": "Rather, it will come to them unexpectedly and bewilder them, and they will not be able to repel it, nor will they be reprieved"
  },
  {
    "id": 41,
    "text": "And already were messengers ridiculed before you, but those who mocked them were enveloped by what they used to ridicule"
  },
  {
    "id": 42,
    "text": "Say, \"Who can protect you at night or by day from the Most Merciful?\" But they are, from the remembrance of their Lord, turning away"
  },
  {
    "id": 43,
    "text": "Or do they have gods to defend them other than Us? They are unable [even] to help themselves, nor can they be protected from Us"
  },
  {
    "id": 44,
    "text": "But, [on the contrary], We have provided good things for these [disbelievers] and their fathers until life was prolonged for them. Then do they not see that We set upon the land, reducing it from its borders? So it is they who will overcome"
  },
  {
    "id": 45,
    "text": "Say, \"I only warn you by revelation.\" But the deaf do not hear the call when they are warned"
  },
  {
    "id": 46,
    "text": "And if [as much as] a whiff of the punishment of your Lord should touch them, they would surely say, \"O woe to us! Indeed, we have been wrongdoers"
  },
  {
    "id": 47,
    "text": "And We place the scales of justice for the Day of Resurrection, so no soul will be treated unjustly at all. And if there is [even] the weight of a mustard seed, We will bring it forth. And sufficient are We as accountant"
  },
  {
    "id": 48,
    "text": "And We had already given Moses and Aaron the criterion and a light and a reminder for the righteous"
  },
  {
    "id": 49,
    "text": "Who fear their Lord unseen, while they are of the Hour apprehensive"
  },
  {
    "id": 50,
    "text": "And this [Qur'an] is a blessed message which We have sent down. Then are you with it unacquainted"
  },
  {
    "id": 51,
    "text": "And We had certainly given Abraham his sound judgement before, and We were of him well-Knowing"
  },
  {
    "id": 52,
    "text": "When he said to his father and his people, \"What are these statues to which you are devoted"
  },
  {
    "id": 53,
    "text": "They said, \"We found our fathers worshippers of them"
  },
  {
    "id": 54,
    "text": "He said, \"You were certainly, you and your fathers, in manifest error"
  },
  {
    "id": 55,
    "text": "They said, \"Have you come to us with truth, or are you of those who jest"
  },
  {
    "id": 56,
    "text": "He said, \"[No], rather, your Lord is the Lord of the heavens and the earth who created them, and I, to that, am of those who testify"
  },
  {
    "id": 57,
    "text": "And [I swear] by Allah, I will surely plan against your idols after you have turned and gone away"
  },
  {
    "id": 58,
    "text": "So he made them into fragments, except a large one among them, that they might return to it [and question]"
  },
  {
    "id": 59,
    "text": "They said, \"Who has done this to our gods? Indeed, he is of the wrongdoers"
  },
  {
    "id": 60,
    "text": "They said, \"We heard a young man mention them who is called Abraham"
  },
  {
    "id": 61,
    "text": "They said, \"Then bring him before the eyes of the people that they may testify"
  },
  {
    "id": 62,
    "text": "They said, \"Have you done this to our gods, O Abraham"
  },
  {
    "id": 63,
    "text": "He said, \"Rather, this - the largest of them - did it, so ask them, if they should [be able to] speak"
  },
  {
    "id": 64,
    "text": "So they returned to [blaming] themselves and said [to each other], \"Indeed, you are the wrongdoers"
  },
  {
    "id": 65,
    "text": "Then they reversed themselves, [saying], \"You have already known that these do not speak"
  },
  {
    "id": 66,
    "text": "He said, \"Then do you worship instead of Allah that which does not benefit you at all or harm you"
  },
  {
    "id": 67,
    "text": "Uff to you and to what you worship instead of Allah. Then will you not use reason"
  },
  {
    "id": 68,
    "text": "They said, \"Burn him and support your gods - if you are to act"
  },
  {
    "id": 69,
    "text": "Allah said, \"O fire, be coolness and safety upon Abraham"
  },
  {
    "id": 70,
    "text": "And they intended for him harm, but We made them the greatest losers"
  },
  {
    "id": 71,
    "text": "And We delivered him and Lot to the land which We had blessed for the worlds"
  },
  {
    "id": 72,
    "text": "And We gave him Isaac and Jacob in addition, and all [of them] We made righteous"
  },
  {
    "id": 73,
    "text": "And We made them leaders guiding by Our command. And We inspired to them the doing of good deeds, establishment of prayer, and giving of zakah; and they were worshippers of Us"
  },
  {
    "id": 74,
    "text": "And to Lot We gave judgement and knowledge, and We saved him from the city that was committing wicked deeds. Indeed, they were a people of evil, defiantly disobedient"
  },
  {
    "id": 75,
    "text": "And We admitted him into Our mercy. Indeed, he was of the righteous"
  },
  {
    "id": 76,
    "text": "And [mention] Noah, when he called [to Allah] before [that time], so We responded to him and saved him and his family from the great flood"
  },
  {
    "id": 77,
    "text": "And We saved him from the people who denied Our signs. Indeed, they were a people of evil, so We drowned them, all together"
  },
  {
    "id": 78,
    "text": "And [mention] David and Solomon, when they judged concerning the field - when the sheep of a people overran it [at night], and We were witness to their judgement"
  },
  {
    "id": 79,
    "text": "And We gave understanding of the case to Solomon, and to each [of them] We gave judgement and knowledge. And We subjected the mountains to exalt [Us], along with David and [also] the birds. And We were doing [that]"
  },
  {
    "id": 80,
    "text": "And We taught him the fashioning of coats of armor to protect you from your [enemy in] battle. So will you then be grateful"
  },
  {
    "id": 81,
    "text": "And to Solomon [We subjected] the wind, blowing forcefully, proceeding by his command toward the land which We had blessed. And We are ever, of all things, Knowing"
  },
  {
    "id": 82,
    "text": "And of the devils were those who dived for him and did work other than that. And We were of them a guardian"
  },
  {
    "id": 83,
    "text": "And [mention] Job, when he called to his Lord, \"Indeed, adversity has touched me, and you are the Most Merciful of the merciful"
  },
  {
    "id": 84,
    "text": "So We responded to him and removed what afflicted him of adversity. And We gave him [back] his family and the like thereof with them as mercy from Us and a reminder for the worshippers [of Allah]"
  },
  {
    "id": 85,
    "text": "And [mention] Ishmael and Idrees and Dhul-Kifl; all were of the patient"
  },
  {
    "id": 86,
    "text": "And We admitted them into Our mercy. Indeed, they were of the righteous"
  },
  {
    "id": 87,
    "text": "And [mention] the man of the fish, when he went off in anger and thought that We would not decree [anything] upon him. And he called out within the darknesses, \"There is no deity except You; exalted are You. Indeed, I have been of the wrongdoers"
  },
  {
    "id": 88,
    "text": "So We responded to him and saved him from the distress. And thus do We save the believers"
  },
  {
    "id": 89,
    "text": "And [mention] Zechariah, when he called to his Lord, \"My Lord, do not leave me alone [with no heir], while you are the best of inheritors"
  },
  {
    "id": 90,
    "text": "So We responded to him, and We gave to him John, and amended for him his wife. Indeed, they used to hasten to good deeds and supplicate Us in hope and fear, and they were to Us humbly submissive"
  },
  {
    "id": 91,
    "text": "And [mention] the one who guarded her chastity, so We blew into her [garment] through Our angel [Gabriel], and We made her and her son a sign for the worlds"
  },
  {
    "id": 92,
    "text": "Indeed this, your religion, is one religion, and I am your Lord, so worship Me"
  },
  {
    "id": 93,
    "text": "And [yet] they divided their affair among themselves, [but] all to Us will return"
  },
  {
    "id": 94,
    "text": "So whoever does righteous deeds while he is a believer - no denial will there be for his effort, and indeed We, of it, are recorders"
  },
  {
    "id": 95,
    "text": "And there is prohibition upon [the people of] a city which We have destroyed that they will [ever] return"
  },
  {
    "id": 96,
    "text": "Until when [the dam of] Gog and Magog has been opened and they, from every elevation, descend"
  },
  {
    "id": 97,
    "text": "And [when] the true promise has approached; then suddenly the eyes of those who disbelieved will be staring [in horror, while they say], \"O woe to us; we had been unmindful of this; rather, we were wrongdoers"
  },
  {
    "id": 98,
    "text": "Indeed, you [disbelievers] and what you worship other than Allah are the firewood of Hell. You will be coming to [enter] it"
  },
  {
    "id": 99,
    "text": "Had these [false deities] been [actual] gods, they would not have come to it, but all are eternal therein"
  },
  {
    "id": 100,
    "text": "For them therein is heavy sighing, and they therein will not hear"
  },
  {
    "id": 101,
    "text": "Indeed, those for whom the best [reward] has preceded from Us - they are from it far removed"
  },
  {
    "id": 102,
    "text": "They will not hear its sound, while they are, in that which their souls desire, abiding eternally"
  },
  {
    "id": 103,
    "text": "They will not be grieved by the greatest terror, and the angels will meet them, [saying], \"This is your Day which you have been promised"
  },
  {
    "id": 104,
    "text": "The Day when We will fold the heaven like the folding of a [written] sheet for the records. As We began the first creation, We will repeat it. [That is] a promise binding upon Us. Indeed, We will do it"
  },
  {
    "id": 105,
    "text": "And We have already written in the book [of Psalms] after the [previous] mention that the land [of Paradise] is inherited by My righteous servants"
  },
  {
    "id": 106,
    "text": "Indeed, in this [Qur'an] is notification for a worshipping people"
  },
  {
    "id": 107,
    "text": "And We have not sent you, [O Muhammad], except as a mercy to the worlds"
  },
  {
    "id": 108,
    "text": "Say, \"It is only revealed to me that your god is but one God; so will you be Muslims [in submission to Him]"
  },
  {
    "id": 109,
    "text": "But if they turn away, then say, \"I have announced to [all of] you equally. And I know not whether near or far is that which you are promised"
  },
  {
    "id": 110,
    "text": "Indeed, He knows what is declared of speech, and He knows what you conceal"
  },
  {
    "id": 111,
    "text": "And I know not; perhaps it is a trial for you and enjoyment for a time"
  },
  {
    "id": 112,
    "text": "[The Prophet] has said, \"My Lord, judge [between us] in truth. And our Lord is the Most Merciful, the one whose help is sought against that which you describe"
  }
]

export default en
