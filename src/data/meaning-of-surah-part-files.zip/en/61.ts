import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Whatever is in the heavens and whatever is on the earth exalts Allah, and He is the Exalted in Might, the Wise"
  },
  {
    "id": 2,
    "text": "O you who have believed, why do you say what you do not do"
  },
  {
    "id": 3,
    "text": "Great is hatred in the sight of Allah that you say what you do not do"
  },
  {
    "id": 4,
    "text": "Indeed, Allah loves those who fight in His cause in a row as though they are a [single] structure joined firmly"
  },
  {
    "id": 5,
    "text": "And [mention, O Muhammad], when Moses said to his people, \"O my people, why do you harm me while you certainly know that I am the messenger of Allah to you?\" And when they deviated, Allah caused their hearts to deviate. And Allah does not guide the defiantly disobedient people"
  },
  {
    "id": 6,
    "text": "And [mention] when Jesus, the son of Mary, said, \"O children of Israel, indeed I am the messenger of Allah to you confirming what came before me of the Torah and bringing good tidings of a messenger to come after me, whose name is Ahmad.\" But when he came to them with clear evidences, they said, \"This is obvious magic"
  },
  {
    "id": 7,
    "text": "And who is more unjust than one who invents about Allah untruth while he is being invited to Islam. And Allah does not guide the wrongdoing people"
  },
  {
    "id": 8,
    "text": "They want to extinguish the light of Allah with their mouths, but Allah will perfect His light, although the disbelievers dislike it"
  },
  {
    "id": 9,
    "text": "It is He who sent His Messenger with guidance and the religion of truth to manifest it over all religion, although those who associate others with Allah dislike it"
  },
  {
    "id": 10,
    "text": "O you who have believed, shall I guide you to a transaction that will save you from a painful punishment"
  },
  {
    "id": 11,
    "text": "[It is that] you believe in Allah and His Messenger and strive in the cause of Allah with your wealth and your lives. That is best for you, if you should know"
  },
  {
    "id": 12,
    "text": "He will forgive for you your sins and admit you to gardens beneath which rivers flow and pleasant dwellings in gardens of perpetual residence. That is the great attainment"
  },
  {
    "id": 13,
    "text": "And [you will obtain] another [favor] that you love - victory from Allah and an imminent conquest; and give good tidings to the believers"
  },
  {
    "id": 14,
    "text": "O you who have believed, be supporters of Allah, as when Jesus, the son of Mary, said to the disciples, \"Who are my supporters for Allah?\" The disciples said, \"We are supporters of Allah.\" And a faction of the Children of Israel believed and a faction disbelieved. So We supported those who believed against their enemy, and they became dominant"
  }
]

export default en
