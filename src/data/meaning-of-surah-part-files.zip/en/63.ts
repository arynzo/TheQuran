import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "When the hypocrites come to you, [O Muhammad], they say, \"We testify that you are the Messenger of Allah.\" And Allah knows that you are His Messenger, and Allah testifies that the hypocrites are liars"
  },
  {
    "id": 2,
    "text": "They have taken their oaths as a cover, so they averted [people] from the way of Allah. Indeed, it was evil that they were doing"
  },
  {
    "id": 3,
    "text": "That is because they believed, and then they disbelieved; so their hearts were sealed over, and they do not understand"
  },
  {
    "id": 4,
    "text": "And when you see them, their forms please you, and if they speak, you listen to their speech. [They are] as if they were pieces of wood propped up - they think that every shout is against them. They are the enemy, so beware of them. May Allah destroy them; how are they deluded"
  },
  {
    "id": 5,
    "text": "And when it is said to them, \"Come, the Messenger of Allah will ask forgiveness for you,\" they turn their heads aside and you see them evading while they are arrogant"
  },
  {
    "id": 6,
    "text": "It is all the same for them whether you ask forgiveness for them or do not ask forgiveness for them; never will Allah forgive them. Indeed, Allah does not guide the defiantly disobedient people"
  },
  {
    "id": 7,
    "text": "They are the ones who say, \"Do not spend on those who are with the Messenger of Allah until they disband.\" And to Allah belongs the depositories of the heavens and the earth, but the hypocrites do not understand"
  },
  {
    "id": 8,
    "text": "They say, \"If we return to al-Madinah, the more honored [for power] will surely expel therefrom the more humble.\" And to Allah belongs [all] honor, and to His Messenger, and to the believers, but the hypocrites do not know"
  },
  {
    "id": 9,
    "text": "O you who have believed, let not your wealth and your children divert you from remembrance of Allah. And whoever does that - then those are the losers"
  },
  {
    "id": 10,
    "text": "And spend [in the way of Allah] from what We have provided you before death approaches one of you and he says, \"My Lord, if only You would delay me for a brief term so I would give charity and be among the righteous"
  },
  {
    "id": 11,
    "text": "But never will Allah delay a soul when its time has come. And Allah is Acquainted with what you do"
  }
]

export default en
