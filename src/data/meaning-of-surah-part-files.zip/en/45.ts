import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Ha, Meem"
  },
  {
    "id": 2,
    "text": "The revelation of the Book is from Allah, the Exalted in Might, the Wise"
  },
  {
    "id": 3,
    "text": "Indeed, within the heavens and earth are signs for the believers"
  },
  {
    "id": 4,
    "text": "And in the creation of yourselves and what He disperses of moving creatures are signs for people who are certain [in faith]"
  },
  {
    "id": 5,
    "text": "And [in] the alternation of night and day and [in] what Allah sends down from the sky of provision and gives life thereby to the earth after its lifelessness and [in His] directing of the winds are signs for a people who reason"
  },
  {
    "id": 6,
    "text": "These are the verses of Allah which We recite to you in truth. Then in what statement after Allah and His verses will they believe"
  },
  {
    "id": 7,
    "text": "Woe to every sinful liar"
  },
  {
    "id": 8,
    "text": "Who hears the verses of Allah recited to him, then persists arrogantly as if he had not heard them. So give him tidings of a painful punishment"
  },
  {
    "id": 9,
    "text": "And when he knows anything of Our verses, he takes them in ridicule. Those will have a humiliating punishment"
  },
  {
    "id": 10,
    "text": "Before them is Hell, and what they had earned will not avail them at all nor what they had taken besides Allah as allies. And they will have a great punishment"
  },
  {
    "id": 11,
    "text": "This [Qur'an] is guidance. And those who have disbelieved in the verses of their Lord will have a painful punishment of foul nature"
  },
  {
    "id": 12,
    "text": "It is Allah who subjected to you the sea so that ships may sail upon it by His command and that you may seek of His bounty; and perhaps you will be grateful"
  },
  {
    "id": 13,
    "text": "And He has subjected to you whatever is in the heavens and whatever is on the earth - all from Him. Indeed in that are signs for a people who give thought"
  },
  {
    "id": 14,
    "text": "Say, [O Muhammad], to those who have believed that they [should] forgive those who expect not the days of Allah so that He may recompense a people for what they used to earn"
  },
  {
    "id": 15,
    "text": "Whoever does a good deed - it is for himself; and whoever does evil - it is against the self. Then to your Lord you will be returned"
  },
  {
    "id": 16,
    "text": "And We did certainly give the Children of Israel the Scripture and judgement and prophethood, and We provided them with good things and preferred them over the worlds"
  },
  {
    "id": 17,
    "text": "And We gave them clear proofs of the matter [of religion]. And they did not differ except after knowledge had come to them - out of jealous animosity between themselves. Indeed, your Lord will judge between them on the Day of Resurrection concerning that over which they used to differ"
  },
  {
    "id": 18,
    "text": "Then We put you, [O Muhammad], on an ordained way concerning the matter [of religion]; so follow it and do not follow the inclinations of those who do not know"
  },
  {
    "id": 19,
    "text": "Indeed, they will never avail you against Allah at all. And indeed, the wrongdoers are allies of one another; but Allah is the protector of the righteous"
  },
  {
    "id": 20,
    "text": "This [Qur'an] is enlightenment for mankind and guidance and mercy for a people who are certain [in faith]"
  },
  {
    "id": 21,
    "text": "Or do those who commit evils think We will make them like those who have believed and done righteous deeds - [make them] equal in their life and their death? Evil is that which they judge"
  },
  {
    "id": 22,
    "text": "And Allah created the heavens and earth in truth and so that every soul may be recompensed for what it has earned, and they will not be wronged"
  },
  {
    "id": 23,
    "text": "Have you seen he who has taken as his god his [own] desire, and Allah has sent him astray due to knowledge and has set a seal upon his hearing and his heart and put over his vision a veil? So who will guide him after Allah? Then will you not be reminded"
  },
  {
    "id": 24,
    "text": "And they say, \"There is not but our worldly life; we die and live, and nothing destroys us except time.\" And they have of that no knowledge; they are only assuming"
  },
  {
    "id": 25,
    "text": "And when Our verses are recited to them as clear evidences, their argument is only that they say, \"Bring [back] our forefathers, if you should be truthful"
  },
  {
    "id": 26,
    "text": "Say, \"Allah causes you to live, then causes you to die; then He will assemble you for the Day of Resurrection, about which there is no doubt, but most of the people do not know"
  },
  {
    "id": 27,
    "text": "And to Allah belongs the dominion of the heavens and the earth. And the Day the Hour appears - that Day the falsifiers will lose"
  },
  {
    "id": 28,
    "text": "And you will see every nation kneeling [from fear]. Every nation will be called to its record [and told], \"Today you will be recompensed for what you used to do"
  },
  {
    "id": 29,
    "text": "This, Our record, speaks about you in truth. Indeed, We were having transcribed whatever you used to do"
  },
  {
    "id": 30,
    "text": "So as for those who believed and did righteous deeds, their Lord will admit them into His mercy. That is what is the clear attainment"
  },
  {
    "id": 31,
    "text": "But as for those who disbelieved, [it will be said], \"Were not Our verses recited to you, but you were arrogant and became a people of criminals"
  },
  {
    "id": 32,
    "text": "And when it was said, 'Indeed, the promise of Allah is truth and the Hour [is coming] - no doubt about it,' you said, 'We know not what is the Hour. We assume only assumption, and we are not convinced"
  },
  {
    "id": 33,
    "text": "And the evil consequences of what they did will appear to them, and they will be enveloped by what they used to ridicule"
  },
  {
    "id": 34,
    "text": "And it will be said, \"Today We will forget you as you forgot the meeting of this Day of yours, and your refuge is the Fire, and for you there are no helpers"
  },
  {
    "id": 35,
    "text": "That is because you took the verses of Allah in ridicule, and worldly life deluded you.\" So that Day they will not be removed from it, nor will they be asked to appease [Allah]"
  },
  {
    "id": 36,
    "text": "Then, to Allah belongs [all] praise - Lord of the heavens and Lord of the earth, Lord of the worlds"
  },
  {
    "id": 37,
    "text": "And to Him belongs [all] grandeur within the heavens and the earth, and He is the Exalted in Might, the Wise"
  }
]

export default en
