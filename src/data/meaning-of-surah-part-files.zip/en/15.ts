import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Alif, Lam, Ra. These are the verses of the Book and a clear Qur'an"
  },
  {
    "id": 2,
    "text": "Perhaps those who disbelieve will wish that they had been Muslims"
  },
  {
    "id": 3,
    "text": "Let them eat and enjoy themselves and be diverted by [false] hope, for they are going to know"
  },
  {
    "id": 4,
    "text": "And We did not destroy any city but that for it was a known decree"
  },
  {
    "id": 5,
    "text": "No nation will precede its term, nor will they remain thereafter"
  },
  {
    "id": 6,
    "text": "And they say, \"O you upon whom the message has been sent down, indeed you are mad"
  },
  {
    "id": 7,
    "text": "Why do you not bring us the angels, if you should be among the truthful"
  },
  {
    "id": 8,
    "text": "We do not send down the angels except with truth; and the disbelievers would not then be reprieved"
  },
  {
    "id": 9,
    "text": "Indeed, it is We who sent down the Qur'an and indeed, We will be its guardian"
  },
  {
    "id": 10,
    "text": "And We had certainly sent [messengers] before you, [O Muhammad], among the sects of the former peoples"
  },
  {
    "id": 11,
    "text": "And no messenger would come to them except that they ridiculed him"
  },
  {
    "id": 12,
    "text": "Thus do We insert denial into the hearts of the criminals"
  },
  {
    "id": 13,
    "text": "They will not believe in it, while there has already occurred the precedent of the former peoples"
  },
  {
    "id": 14,
    "text": "And [even] if We opened to them a gate from the heaven and they continued therein to ascend"
  },
  {
    "id": 15,
    "text": "They would say, \"Our eyes have only been dazzled. Rather, we are a people affected by magic"
  },
  {
    "id": 16,
    "text": "And We have placed within the heaven great stars and have beautified it for the observers"
  },
  {
    "id": 17,
    "text": "And We have protected it from every devil expelled [from the mercy of Allah]"
  },
  {
    "id": 18,
    "text": "Except one who steals a hearing and is pursued by a clear burning flame"
  },
  {
    "id": 19,
    "text": "And the earth - We have spread it and cast therein firmly set mountains and caused to grow therein [something] of every well-balanced thing"
  },
  {
    "id": 20,
    "text": "And We have made for you therein means of living and [for] those for whom you are not providers"
  },
  {
    "id": 21,
    "text": "And there is not a thing but that with Us are its depositories, and We do not send it down except according to a known measure"
  },
  {
    "id": 22,
    "text": "And We have sent the fertilizing winds and sent down water from the sky and given you drink from it. And you are not its retainers"
  },
  {
    "id": 23,
    "text": "And indeed, it is We who give life and cause death, and We are the Inheritor"
  },
  {
    "id": 24,
    "text": "And We have already known the preceding [generations] among you, and We have already known the later [ones to come]"
  },
  {
    "id": 25,
    "text": "And indeed, your Lord will gather them; indeed, He is Wise and Knowing"
  },
  {
    "id": 26,
    "text": "And We did certainly create man out of clay from an altered black mud"
  },
  {
    "id": 27,
    "text": "And the jinn We created before from scorching fire"
  },
  {
    "id": 28,
    "text": "And [mention, O Muhammad], when your Lord said to the angels, \"I will create a human being out of clay from an altered black mud"
  },
  {
    "id": 29,
    "text": "And when I have proportioned him and breathed into him of My [created] soul, then fall down to him in prostration"
  },
  {
    "id": 30,
    "text": "So the angels prostrated - all of them entirely"
  },
  {
    "id": 31,
    "text": "Except Iblees, he refused to be with those who prostrated"
  },
  {
    "id": 32,
    "text": "[Allah] said, O Iblees, what is [the matter] with you that you are not with those who prostrate"
  },
  {
    "id": 33,
    "text": "He said, \"Never would I prostrate to a human whom You created out of clay from an altered black mud"
  },
  {
    "id": 34,
    "text": "[Allah] said, \"Then get out of it, for indeed, you are expelled"
  },
  {
    "id": 35,
    "text": "And indeed, upon you is the curse until the Day of Recompense"
  },
  {
    "id": 36,
    "text": "He said, \"My Lord, then reprieve me until the Day they are resurrected"
  },
  {
    "id": 37,
    "text": "[Allah] said, \"So indeed, you are of those reprieved"
  },
  {
    "id": 38,
    "text": "Until the Day of the time well-known"
  },
  {
    "id": 39,
    "text": "[Iblees] said, \"My Lord, because You have put me in error, I will surely make [disobedience] attractive to them on earth, and I will mislead them all"
  },
  {
    "id": 40,
    "text": "Except, among them, Your chosen servants"
  },
  {
    "id": 41,
    "text": "[Allah] said, \"This is a path [of return] to Me [that is] straight"
  },
  {
    "id": 42,
    "text": "Indeed, My servants - no authority will you have over them, except those who follow you of the deviators"
  },
  {
    "id": 43,
    "text": "And indeed, Hell is the promised place for them all"
  },
  {
    "id": 44,
    "text": "It has seven gates; for every gate is of them a portion designated"
  },
  {
    "id": 45,
    "text": "Indeed, the righteous will be within gardens and springs"
  },
  {
    "id": 46,
    "text": "[Having been told], \"Enter it in peace, safe [and secure]"
  },
  {
    "id": 47,
    "text": "And We will remove whatever is in their breasts of resentment, [so they will be] brothers, on thrones facing each other"
  },
  {
    "id": 48,
    "text": "No fatigue will touch them therein, nor from it will they [ever] be removed"
  },
  {
    "id": 49,
    "text": "[O Muhammad], inform My servants that it is I who am the Forgiving, the Merciful"
  },
  {
    "id": 50,
    "text": "And that it is My punishment which is the painful punishment"
  },
  {
    "id": 51,
    "text": "And inform them about the guests of Abraham"
  },
  {
    "id": 52,
    "text": "When they entered upon him and said, \"Peace.\" [Abraham] said, \"Indeed, we are fearful of you"
  },
  {
    "id": 53,
    "text": "[The angels] said, \"Fear not. Indeed, we give you good tidings of a learned boy"
  },
  {
    "id": 54,
    "text": "He said, \"Have you given me good tidings although old age has come upon me? Then of what [wonder] do you inform"
  },
  {
    "id": 55,
    "text": "They said, \"We have given you good tidings in truth, so do not be of the despairing"
  },
  {
    "id": 56,
    "text": "He said, \"And who despairs of the mercy of his Lord except for those astray"
  },
  {
    "id": 57,
    "text": "[Abraham] said, \"Then what is your business [here], O messengers"
  },
  {
    "id": 58,
    "text": "They said, \"Indeed, we have been sent to a people of criminals"
  },
  {
    "id": 59,
    "text": "Except the family of Lot; indeed, we will save them all"
  },
  {
    "id": 60,
    "text": "Except his wife.\" Allah decreed that she is of those who remain behind"
  },
  {
    "id": 61,
    "text": "And when the messengers came to the family of Lot"
  },
  {
    "id": 62,
    "text": "He said, \"Indeed, you are people unknown"
  },
  {
    "id": 63,
    "text": "They said, \"But we have come to you with that about which they were disputing"
  },
  {
    "id": 64,
    "text": "And we have come to you with truth, and indeed, we are truthful"
  },
  {
    "id": 65,
    "text": "So set out with your family during a portion of the night and follow behind them and let not anyone among you look back and continue on to where you are commanded"
  },
  {
    "id": 66,
    "text": "And We conveyed to him [the decree] of that matter: that those [sinners] would be eliminated by early morning"
  },
  {
    "id": 67,
    "text": "And the people of the city came rejoicing"
  },
  {
    "id": 68,
    "text": "[Lot] said, \"Indeed, these are my guests, so do not shame me"
  },
  {
    "id": 69,
    "text": "And fear Allah and do not disgrace me"
  },
  {
    "id": 70,
    "text": "They said, \"Have we not forbidden you from [protecting] people"
  },
  {
    "id": 71,
    "text": "[Lot] said, \"These are my daughters - if you would be doers [of lawful marriage]"
  },
  {
    "id": 72,
    "text": "By your life, [O Muhammad], indeed they were, in their intoxication, wandering blindly"
  },
  {
    "id": 73,
    "text": "So the shriek seized them at sunrise"
  },
  {
    "id": 74,
    "text": "And We made the highest part [of the city] its lowest and rained upon them stones of hard clay"
  },
  {
    "id": 75,
    "text": "Indeed in that are signs for those who discern"
  },
  {
    "id": 76,
    "text": "And indeed, those cities are [situated] on an established road"
  },
  {
    "id": 77,
    "text": "Indeed in that is a sign for the believers"
  },
  {
    "id": 78,
    "text": "And the companions of the thicket were [also] wrongdoers"
  },
  {
    "id": 79,
    "text": "So We took retribution from them, and indeed, both [cities] are on a clear highway"
  },
  {
    "id": 80,
    "text": "And certainly did the companions of Thamud deny the messengers"
  },
  {
    "id": 81,
    "text": "And We gave them Our signs, but from them they were turning away"
  },
  {
    "id": 82,
    "text": "And they used to carve from the mountains, houses, feeling secure"
  },
  {
    "id": 83,
    "text": "But the shriek seized them at early morning"
  },
  {
    "id": 84,
    "text": "So nothing availed them [from] what they used to earn"
  },
  {
    "id": 85,
    "text": "And We have not created the heavens and earth and that between them except in truth. And indeed, the Hour is coming; so forgive with gracious forgiveness"
  },
  {
    "id": 86,
    "text": "Indeed, your Lord - He is the Knowing Creator"
  },
  {
    "id": 87,
    "text": "And We have certainly given you, [O Muhammad], seven of the often repeated [verses] and the great Qur'an"
  },
  {
    "id": 88,
    "text": "Do not extend your eyes toward that by which We have given enjoyment to [certain] categories of the disbelievers, and do not grieve over them. And lower your wing to the believers"
  },
  {
    "id": 89,
    "text": "And say, \"Indeed, I am the clear warner"
  },
  {
    "id": 90,
    "text": "Just as We had revealed [scriptures] to the separators"
  },
  {
    "id": 91,
    "text": "Who have made the Qur'an into portions"
  },
  {
    "id": 92,
    "text": "So by your Lord, We will surely question them all"
  },
  {
    "id": 93,
    "text": "About what they used to do"
  },
  {
    "id": 94,
    "text": "Then declare what you are commanded and turn away from the polytheists"
  },
  {
    "id": 95,
    "text": "Indeed, We are sufficient for you against the mockers"
  },
  {
    "id": 96,
    "text": "Who make [equal] with Allah another deity. But they are going to know"
  },
  {
    "id": 97,
    "text": "And We already know that your breast is constrained by what they say"
  },
  {
    "id": 98,
    "text": "So exalt [Allah] with praise of your Lord and be of those who prostrate [to Him]"
  },
  {
    "id": 99,
    "text": "And worship your Lord until there comes to you the certainty (death)"
  }
]

export default en
