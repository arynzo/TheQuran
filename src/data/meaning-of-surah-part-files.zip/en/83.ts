import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Woe to those who give less [than due]"
  },
  {
    "id": 2,
    "text": "Who, when they take a measure from people, take in full"
  },
  {
    "id": 3,
    "text": "But if they give by measure or by weight to them, they cause loss"
  },
  {
    "id": 4,
    "text": "Do they not think that they will be resurrected"
  },
  {
    "id": 5,
    "text": "For a tremendous Day"
  },
  {
    "id": 6,
    "text": "The Day when mankind will stand before the Lord of the worlds"
  },
  {
    "id": 7,
    "text": "No! Indeed, the record of the wicked is in sijjeen"
  },
  {
    "id": 8,
    "text": "And what can make you know what is sijjeen"
  },
  {
    "id": 9,
    "text": "It is [their destination recorded in] a register inscribed"
  },
  {
    "id": 10,
    "text": "Woe, that Day, to the deniers"
  },
  {
    "id": 11,
    "text": "Who deny the Day of Recompense"
  },
  {
    "id": 12,
    "text": "And none deny it except every sinful transgressor"
  },
  {
    "id": 13,
    "text": "When Our verses are recited to him, he says, \"Legends of the former peoples"
  },
  {
    "id": 14,
    "text": "No! Rather, the stain has covered their hearts of that which they were earning"
  },
  {
    "id": 15,
    "text": "No! Indeed, from their Lord, that Day, they will be partitioned"
  },
  {
    "id": 16,
    "text": "Then indeed, they will [enter and] burn in Hellfire"
  },
  {
    "id": 17,
    "text": "Then it will be said [to them], \"This is what you used to deny"
  },
  {
    "id": 18,
    "text": "No! Indeed, the record of the righteous is in 'illiyyun"
  },
  {
    "id": 19,
    "text": "And what can make you know what is 'illiyyun"
  },
  {
    "id": 20,
    "text": "It is [their destination recorded in] a register inscribed"
  },
  {
    "id": 21,
    "text": "Which is witnessed by those brought near [to Allah]"
  },
  {
    "id": 22,
    "text": "Indeed, the righteous will be in pleasure"
  },
  {
    "id": 23,
    "text": "On adorned couches, observing"
  },
  {
    "id": 24,
    "text": "You will recognize in their faces the radiance of pleasure"
  },
  {
    "id": 25,
    "text": "They will be given to drink [pure] wine [which was] sealed"
  },
  {
    "id": 26,
    "text": "The last of it is musk. So for this let the competitors compete"
  },
  {
    "id": 27,
    "text": "And its mixture is of Tasneem"
  },
  {
    "id": 28,
    "text": "A spring from which those near [to Allah] drink"
  },
  {
    "id": 29,
    "text": "Indeed, those who committed crimes used to laugh at those who believed"
  },
  {
    "id": 30,
    "text": "And when they passed by them, they would exchange derisive glances"
  },
  {
    "id": 31,
    "text": "And when they returned to their people, they would return jesting"
  },
  {
    "id": 32,
    "text": "And when they saw them, they would say, \"Indeed, those are truly lost"
  },
  {
    "id": 33,
    "text": "But they had not been sent as guardians over them"
  },
  {
    "id": 34,
    "text": "So Today those who believed are laughing at the disbelievers"
  },
  {
    "id": 35,
    "text": "On adorned couches, observing"
  },
  {
    "id": 36,
    "text": "Have the disbelievers [not] been rewarded [this Day] for what they used to do"
  }
]

export default en
