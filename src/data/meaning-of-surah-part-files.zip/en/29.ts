import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Alif, Lam, Meem"
  },
  {
    "id": 2,
    "text": "Do the people think that they will be left to say, \"We believe\" and they will not be tried"
  },
  {
    "id": 3,
    "text": "But We have certainly tried those before them, and Allah will surely make evident those who are truthful, and He will surely make evident the liars"
  },
  {
    "id": 4,
    "text": "Or do those who do evil deeds think they can outrun Us? Evil is what they judge"
  },
  {
    "id": 5,
    "text": "Whoever should hope for the meeting with Allah - indeed, the term decreed by Allah is coming. And He is the Hearing, the Knowing"
  },
  {
    "id": 6,
    "text": "And whoever strives only strives for [the benefit of] himself. Indeed, Allah is free from need of the worlds"
  },
  {
    "id": 7,
    "text": "And those who believe and do righteous deeds - We will surely remove from them their misdeeds and will surely reward them according to the best of what they used to do"
  },
  {
    "id": 8,
    "text": "And We have enjoined upon man goodness to parents. But if they endeavor to make you associate with Me that of which you have no knowledge, do not obey them. To Me is your return, and I will inform you about what you used to do"
  },
  {
    "id": 9,
    "text": "And those who believe and do righteous deeds - We will surely admit them among the righteous [into Paradise]"
  },
  {
    "id": 10,
    "text": "And of the people are some who say, \"We believe in Allah,\" but when one [of them] is harmed for [the cause of] Allah, they consider the trial of the people as [if it were] the punishment of Allah. But if victory comes from your Lord, they say, \"Indeed, We were with you.\" Is not Allah most knowing of what is within the breasts of all creatures"
  },
  {
    "id": 11,
    "text": "And Allah will surely make evident those who believe, and He will surely make evident the hypocrites"
  },
  {
    "id": 12,
    "text": "And those who disbelieve say to those who believe, \"Follow our way, and we will carry your sins.\" But they will not carry anything of their sins. Indeed, they are liars"
  },
  {
    "id": 13,
    "text": "But they will surely carry their [own] burdens and [other] burdens along with their burdens, and they will surely be questioned on the Day of Resurrection about what they used to invent"
  },
  {
    "id": 14,
    "text": "And We certainly sent Noah to his people, and he remained among them a thousand years minus fifty years, and the flood seized them while they were wrongdoers"
  },
  {
    "id": 15,
    "text": "But We saved him and the companions of the ship, and We made it a sign for the worlds"
  },
  {
    "id": 16,
    "text": "And [We sent] Abraham, when he said to his people, \"Worship Allah and fear Him. That is best for you, if you should know"
  },
  {
    "id": 17,
    "text": "You only worship, besides Allah, idols, and you produce a falsehood. Indeed, those you worship besides Allah do not possess for you [the power of] provision. So seek from Allah provision and worship Him and be grateful to Him. To Him you will be returned"
  },
  {
    "id": 18,
    "text": "And if you [people] deny [the message] - already nations before you have denied. And there is not upon the Messenger except [the duty of] clear notification"
  },
  {
    "id": 19,
    "text": "Have they not considered how Allah begins creation and then repeats it? Indeed that, for Allah, is easy"
  },
  {
    "id": 20,
    "text": "Say, [O Muhammad], \"Travel through the land and observe how He began creation. Then Allah will produce the final creation. Indeed Allah, over all things, is competent"
  },
  {
    "id": 21,
    "text": "He punishes whom He wills and has mercy upon whom He wills, and to Him you will be returned"
  },
  {
    "id": 22,
    "text": "And you will not cause failure [to Allah] upon the earth or in the heaven. And you have not other than Allah any protector or any helper"
  },
  {
    "id": 23,
    "text": "And the ones who disbelieve in the signs of Allah and the meeting with Him - those have despaired of My mercy, and they will have a painful punishment"
  },
  {
    "id": 24,
    "text": "And the answer of Abraham's people was not but that they said, \"Kill him or burn him,\" but Allah saved him from the fire. Indeed in that are signs for a people who believe"
  },
  {
    "id": 25,
    "text": "And [Abraham] said, \"You have only taken, other than Allah, idols as [a bond of] affection among you in worldly life. Then on the Day of Resurrection you will deny one another and curse one another, and your refuge will be the Fire, and you will not have any helpers"
  },
  {
    "id": 26,
    "text": "And Lot believed him. [Abraham] said, \"Indeed, I will emigrate to [the service of] my Lord. Indeed, He is the Exalted in Might, the Wise"
  },
  {
    "id": 27,
    "text": "And We gave to Him Isaac and Jacob and placed in his descendants prophethood and scripture. And We gave him his reward in this world, and indeed, he is in the Hereafter among the righteous"
  },
  {
    "id": 28,
    "text": "And [mention] Lot, when he said to his people, \"Indeed, you commit such immorality as no one has preceded you with from among the worlds"
  },
  {
    "id": 29,
    "text": "Indeed, you approach men and obstruct the road and commit in your meetings [every] evil.\" And the answer of his people was not but they said, \"Bring us the punishment of Allah, if you should be of the truthful"
  },
  {
    "id": 30,
    "text": "He said, \"My Lord, support me against the corrupting people"
  },
  {
    "id": 31,
    "text": "And when Our messengers came to Abraham with the good tidings, they said, \"Indeed, we will destroy the people of that Lot's city. Indeed, its people have been wrongdoers"
  },
  {
    "id": 32,
    "text": "[Abraham] said, \"Indeed, within it is Lot.\" They said, \"We are more knowing of who is within it. We will surely save him and his family, except his wife. She is to be of those who remain behind"
  },
  {
    "id": 33,
    "text": "And when Our messengers came to Lot, he was distressed for them and felt for them great discomfort. They said, \"Fear not, nor grieve. Indeed, we will save you and your family, except your wife; she is to be of those who remain behind"
  },
  {
    "id": 34,
    "text": "Indeed, we will bring down on the people of this city punishment from the sky because they have been defiantly disobedient"
  },
  {
    "id": 35,
    "text": "And We have certainly left of it a sign as clear evidence for a people who use reason"
  },
  {
    "id": 36,
    "text": "And to Madyan [We sent] their brother Shu'ayb, and he said, \"O my people, worship Allah and expect the Last Day and do not commit abuse on the earth, spreading corruption"
  },
  {
    "id": 37,
    "text": "But they denied him, so the earthquake seized them, and they became within their home [corpses] fallen prone"
  },
  {
    "id": 38,
    "text": "And [We destroyed] 'Aad and Thamud, and it has become clear to you from their [ruined] dwellings. And Satan had made pleasing to them their deeds and averted them from the path, and they were endowed with perception"
  },
  {
    "id": 39,
    "text": "And [We destroyed] Qarun and Pharaoh and Haman. And Moses had already come to them with clear evidences, and they were arrogant in the land, but they were not outrunners [of Our punishment]"
  },
  {
    "id": 40,
    "text": "So each We seized for his sin; and among them were those upon whom We sent a storm of stones, and among them were those who were seized by the blast [from the sky], and among them were those whom We caused the earth to swallow, and among them were those whom We drowned. And Allah would not have wronged them, but it was they who were wronging themselves"
  },
  {
    "id": 41,
    "text": "The example of those who take allies other than Allah is like that of the spider who takes a home. And indeed, the weakest of homes is the home of the spider, if they only knew"
  },
  {
    "id": 42,
    "text": "Indeed, Allah knows whatever thing they call upon other than Him. And He is the Exalted in Might, the Wise"
  },
  {
    "id": 43,
    "text": "And these examples We present to the people, but none will understand them except those of knowledge"
  },
  {
    "id": 44,
    "text": "Allah created the heavens and the earth in truth. Indeed in that is a sign for the believers"
  },
  {
    "id": 45,
    "text": "Recite, [O Muhammad], what has been revealed to you of the Book and establish prayer. Indeed, prayer prohibits immorality and wrongdoing, and the remembrance of Allah is greater. And Allah knows that which you do"
  },
  {
    "id": 46,
    "text": "And do not argue with the People of the Scripture except in a way that is best, except for those who commit injustice among them, and say, \"We believe in that which has been revealed to us and revealed to you. And our God and your God is one; and we are Muslims [in submission] to Him"
  },
  {
    "id": 47,
    "text": "And thus We have sent down to you the Qur'an. And those to whom We [previously] gave the Scripture believe in it. And among these [people of Makkah] are those who believe in it. And none reject Our verses except the disbelievers"
  },
  {
    "id": 48,
    "text": "And you did not recite before it any scripture, nor did you inscribe one with your right hand. Otherwise the falsifiers would have had [cause for] doubt"
  },
  {
    "id": 49,
    "text": "Rather, the Qur'an is distinct verses [preserved] within the breasts of those who have been given knowledge. And none reject Our verses except the wrongdoers"
  },
  {
    "id": 50,
    "text": "But they say, \"Why are not signs sent down to him from his Lord?\" Say, \"The signs are only with Allah, and I am only a clear warner"
  },
  {
    "id": 51,
    "text": "And is it not sufficient for them that We revealed to you the Book which is recited to them? Indeed in that is a mercy and reminder for a people who believe"
  },
  {
    "id": 52,
    "text": "Say, \"Sufficient is Allah between me and you as Witness. He knows what is in the heavens and earth. And they who have believed in falsehood and disbelieved in Allah - it is those who are the losers"
  },
  {
    "id": 53,
    "text": "And they urge you to hasten the punishment. And if not for [the decree of] a specified term, punishment would have reached them. But it will surely come to them suddenly while they perceive not"
  },
  {
    "id": 54,
    "text": "They urge you to hasten the punishment. And indeed, Hell will be encompassing of the disbelievers"
  },
  {
    "id": 55,
    "text": "On the Day the punishment will cover them from above them and from below their feet and it is said, \"Taste [the result of] what you used to do"
  },
  {
    "id": 56,
    "text": "O My servants who have believed, indeed My earth is spacious, so worship only Me"
  },
  {
    "id": 57,
    "text": "Every soul will taste death. Then to Us will you be returned"
  },
  {
    "id": 58,
    "text": "And those who have believed and done righteous deeds - We will surely assign to them of Paradise [elevated] chambers beneath which rivers flow, wherein they abide eternally. Excellent is the reward of the [righteous] workers"
  },
  {
    "id": 59,
    "text": "Who have been patient and upon their Lord rely"
  },
  {
    "id": 60,
    "text": "And how many a creature carries not its [own] provision. Allah provides for it and for you. And He is the Hearing, the Knowing"
  },
  {
    "id": 61,
    "text": "If you asked them, \"Who created the heavens and earth and subjected the sun and the moon?\" they would surely say, \"Allah.\" Then how are they deluded"
  },
  {
    "id": 62,
    "text": "Allah extends provision for whom He wills of His servants and restricts for him. Indeed Allah is, of all things, Knowing"
  },
  {
    "id": 63,
    "text": "And if you asked them, \"Who sends down rain from the sky and gives life thereby to the earth after its lifelessness?\" they would surely say \" Allah.\" Say, \"Praise to Allah \"; but most of them do not reason"
  },
  {
    "id": 64,
    "text": "And this worldly life is not but diversion and amusement. And indeed, the home of the Hereafter - that is the [eternal] life, if only they knew"
  },
  {
    "id": 65,
    "text": "And when they board a ship, they supplicate Allah, sincere to Him in religion. But when He delivers them to the land, at once they associate others with Him"
  },
  {
    "id": 66,
    "text": "So that they will deny what We have granted them, and they will enjoy themselves. But they are going to know"
  },
  {
    "id": 67,
    "text": "Have they not seen that We made [Makkah] a safe sanctuary, while people are being taken away all around them? Then in falsehood do they believe, and in the favor of Allah they disbelieve"
  },
  {
    "id": 68,
    "text": "And who is more unjust than one who invents a lie about Allah or denies the truth when it has come to him? Is there not in Hell a [sufficient] residence for the disbelievers"
  },
  {
    "id": 69,
    "text": "And those who strive for Us - We will surely guide them to Our ways. And indeed, Allah is with the doers of good"
  }
]

export default en
