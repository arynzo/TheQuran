import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Kaf, Ha, Ya, 'Ayn, Sad"
  },
  {
    "id": 2,
    "text": "[This is] a mention of the mercy of your Lord to His servant Zechariah"
  },
  {
    "id": 3,
    "text": "When he called to his Lord a private supplication"
  },
  {
    "id": 4,
    "text": "He said, \"My Lord, indeed my bones have weakened, and my head has filled with white, and never have I been in my supplication to You, my Lord, unhappy"
  },
  {
    "id": 5,
    "text": "And indeed, I fear the successors after me, and my wife has been barren, so give me from Yourself an heir"
  },
  {
    "id": 6,
    "text": "Who will inherit me and inherit from the family of Jacob. And make him, my Lord, pleasing [to You]"
  },
  {
    "id": 7,
    "text": "[He was told], \"O Zechariah, indeed We give you good tidings of a boy whose name will be John. We have not assigned to any before [this] name"
  },
  {
    "id": 8,
    "text": "He said, \"My Lord, how will I have a boy when my wife has been barren and I have reached extreme old age"
  },
  {
    "id": 9,
    "text": "[An angel] said, \"Thus [it will be]; your Lord says, 'It is easy for Me, for I created you before, while you were nothing"
  },
  {
    "id": 10,
    "text": "[Zechariah] said, \"My Lord, make for me a sign.\" He said, \"Your sign is that you will not speak to the people for three nights, [being] sound"
  },
  {
    "id": 11,
    "text": "So he came out to his people from the prayer chamber and signaled to them to exalt [Allah] in the morning and afternoon"
  },
  {
    "id": 12,
    "text": "[Allah] said, \"O John, take the Scripture with determination.\" And We gave him judgement [while yet] a boy"
  },
  {
    "id": 13,
    "text": "And affection from Us and purity, and he was fearing of Allah"
  },
  {
    "id": 14,
    "text": "And dutiful to his parents, and he was not a disobedient tyrant"
  },
  {
    "id": 15,
    "text": "And peace be upon him the day he was born and the day he dies and the day he is raised alive"
  },
  {
    "id": 16,
    "text": "And mention, [O Muhammad], in the Book [the story of] Mary, when she withdrew from her family to a place toward the east"
  },
  {
    "id": 17,
    "text": "And she took, in seclusion from them, a screen. Then We sent to her Our Angel, and he represented himself to her as a well-proportioned man"
  },
  {
    "id": 18,
    "text": "She said, \"Indeed, I seek refuge in the Most Merciful from you, [so leave me], if you should be fearing of Allah"
  },
  {
    "id": 19,
    "text": "He said, \"I am only the messenger of your Lord to give you [news of] a pure boy"
  },
  {
    "id": 20,
    "text": "She said, \"How can I have a boy while no man has touched me and I have not been unchaste"
  },
  {
    "id": 21,
    "text": "He said, \"Thus [it will be]; your Lord says, 'It is easy for Me, and We will make him a sign to the people and a mercy from Us. And it is a matter [already] decreed"
  },
  {
    "id": 22,
    "text": "So she conceived him, and she withdrew with him to a remote place"
  },
  {
    "id": 23,
    "text": "And the pains of childbirth drove her to the trunk of a palm tree. She said, \"Oh, I wish I had died before this and was in oblivion, forgotten"
  },
  {
    "id": 24,
    "text": "But he called her from below her, \"Do not grieve; your Lord has provided beneath you a stream"
  },
  {
    "id": 25,
    "text": "And shake toward you the trunk of the palm tree; it will drop upon you ripe, fresh dates"
  },
  {
    "id": 26,
    "text": "So eat and drink and be contented. And if you see from among humanity anyone, say, 'Indeed, I have vowed to the Most Merciful abstention, so I will not speak today to [any] man"
  },
  {
    "id": 27,
    "text": "Then she brought him to her people, carrying him. They said, \"O Mary, you have certainly done a thing unprecedented"
  },
  {
    "id": 28,
    "text": "O sister of Aaron, your father was not a man of evil, nor was your mother unchaste"
  },
  {
    "id": 29,
    "text": "So she pointed to him. They said, \"How can we speak to one who is in the cradle a child"
  },
  {
    "id": 30,
    "text": "[Jesus] said, \"Indeed, I am the servant of Allah. He has given me the Scripture and made me a prophet"
  },
  {
    "id": 31,
    "text": "And He has made me blessed wherever I am and has enjoined upon me prayer and zakah as long as I remain alive"
  },
  {
    "id": 32,
    "text": "And [made me] dutiful to my mother, and He has not made me a wretched tyrant"
  },
  {
    "id": 33,
    "text": "And peace is on me the day I was born and the day I will die and the day I am raised alive"
  },
  {
    "id": 34,
    "text": "That is Jesus, the son of Mary - the word of truth about which they are in dispute"
  },
  {
    "id": 35,
    "text": "It is not [befitting] for Allah to take a son; exalted is He! When He decrees an affair, He only says to it, \"Be,\" and it is"
  },
  {
    "id": 36,
    "text": "[Jesus said], \"And indeed, Allah is my Lord and your Lord, so worship Him. That is a straight path"
  },
  {
    "id": 37,
    "text": "Then the factions differed [concerning Jesus] from among them, so woe to those who disbelieved - from the scene of a tremendous Day"
  },
  {
    "id": 38,
    "text": "How [clearly] they will hear and see the Day they come to Us, but the wrongdoers today are in clear error"
  },
  {
    "id": 39,
    "text": "And warn them, [O Muhammad], of the Day of Regret, when the matter will be concluded; and [yet], they are in [a state of] heedlessness, and they do not believe"
  },
  {
    "id": 40,
    "text": "Indeed, it is We who will inherit the earth and whoever is on it, and to Us they will be returned"
  },
  {
    "id": 41,
    "text": "And mention in the Book [the story of] Abraham. Indeed, he was a man of truth and a prophet"
  },
  {
    "id": 42,
    "text": "[Mention] when he said to his father, \"O my father, why do you worship that which does not hear and does not see and will not benefit you at all"
  },
  {
    "id": 43,
    "text": "O my father, indeed there has come to me of knowledge that which has not come to you, so follow me; I will guide you to an even path"
  },
  {
    "id": 44,
    "text": "O my father, do not worship Satan. Indeed Satan has ever been, to the Most Merciful, disobedient"
  },
  {
    "id": 45,
    "text": "O my father, indeed I fear that there will touch you a punishment from the Most Merciful so you would be to Satan a companion [in Hellfire]"
  },
  {
    "id": 46,
    "text": "[His father] said, \"Have you no desire for my gods, O Abraham? If you do not desist, I will surely stone you, so avoid me a prolonged time"
  },
  {
    "id": 47,
    "text": "[Abraham] said, \"Peace will be upon you. I will ask forgiveness for you of my Lord. Indeed, He is ever gracious to me"
  },
  {
    "id": 48,
    "text": "And I will leave you and those you invoke other than Allah and will invoke my Lord. I expect that I will not be in invocation to my Lord unhappy"
  },
  {
    "id": 49,
    "text": "So when he had left them and those they worshipped other than Allah, We gave him Isaac and Jacob, and each [of them] We made a prophet"
  },
  {
    "id": 50,
    "text": "And We gave them of Our mercy, and we made for them a reputation of high honor"
  },
  {
    "id": 51,
    "text": "And mention in the Book, Moses. Indeed, he was chosen, and he was a messenger and a prophet"
  },
  {
    "id": 52,
    "text": "And We called him from the side of the mount at [his] right and brought him near, confiding [to him]"
  },
  {
    "id": 53,
    "text": "And We gave him out of Our mercy his brother Aaron as a prophet"
  },
  {
    "id": 54,
    "text": "And mention in the Book, Ishmael. Indeed, he was true to his promise, and he was a messenger and a prophet"
  },
  {
    "id": 55,
    "text": "And he used to enjoin on his people prayer and zakah and was to his Lord pleasing"
  },
  {
    "id": 56,
    "text": "And mention in the Book, Idrees. Indeed, he was a man of truth and a prophet"
  },
  {
    "id": 57,
    "text": "And We raised him to a high station"
  },
  {
    "id": 58,
    "text": "Those were the ones upon whom Allah bestowed favor from among the prophets of the descendants of Adam and of those We carried [in the ship] with Noah, and of the descendants of Abraham and Israel, and of those whom We guided and chose. When the verses of the Most Merciful were recited to them, they fell in prostration and weeping"
  },
  {
    "id": 59,
    "text": "But there came after them successors who neglected prayer and pursued desires; so they are going to meet evil"
  },
  {
    "id": 60,
    "text": "Except those who repent, believe and do righteousness; for those will enter Paradise and will not be wronged at all"
  },
  {
    "id": 61,
    "text": "[Therein are] gardens of perpetual residence which the Most Merciful has promised His servants in the unseen. Indeed, His promise has ever been coming"
  },
  {
    "id": 62,
    "text": "They will not hear therein any ill speech - only [greetings of] peace - and they will have their provision therein, morning and afternoon"
  },
  {
    "id": 63,
    "text": "That is Paradise, which We give as inheritance to those of Our servants who were fearing of Allah"
  },
  {
    "id": 64,
    "text": "[Gabriel said], \"And we [angels] descend not except by the order of your Lord. To Him belongs that before us and that behind us and what is in between. And never is your Lord forgetful"
  },
  {
    "id": 65,
    "text": "Lord of the heavens and the earth and whatever is between them - so worship Him and have patience for His worship. Do you know of any similarity to Him"
  },
  {
    "id": 66,
    "text": "And the disbeliever says, \"When I have died, am I going to be brought forth alive"
  },
  {
    "id": 67,
    "text": "Does man not remember that We created him before, while he was nothing"
  },
  {
    "id": 68,
    "text": "So by your Lord, We will surely gather them and the devils; then We will bring them to be present around Hell upon their knees"
  },
  {
    "id": 69,
    "text": "Then We will surely extract from every sect those of them who were worst against the Most Merciful in insolence"
  },
  {
    "id": 70,
    "text": "Then, surely it is We who are most knowing of those most worthy of burning therein"
  },
  {
    "id": 71,
    "text": "And there is none of you except he will come to it. This is upon your Lord an inevitability decreed"
  },
  {
    "id": 72,
    "text": "Then We will save those who feared Allah and leave the wrongdoers within it, on their knees"
  },
  {
    "id": 73,
    "text": "And when Our verses are recited to them as clear evidences, those who disbelieve say to those who believe, \"Which of [our] two parties is best in position and best in association"
  },
  {
    "id": 74,
    "text": "And how many a generation have We destroyed before them who were better in possessions and [outward] appearance"
  },
  {
    "id": 75,
    "text": "Say, \"Whoever is in error - let the Most Merciful extend for him an extension [in wealth and time] until, when they see that which they were promised - either punishment [in this world] or the Hour [of resurrection] - they will come to know who is worst in position and weaker in soldiers"
  },
  {
    "id": 76,
    "text": "And Allah increases those who were guided, in guidance, and the enduring good deeds are better to your Lord for reward and better for recourse"
  },
  {
    "id": 77,
    "text": "Then, have you seen he who disbelieved in Our verses and said, \"I will surely be given wealth and children [in the next life]"
  },
  {
    "id": 78,
    "text": "Has he looked into the unseen, or has he taken from the Most Merciful a promise"
  },
  {
    "id": 79,
    "text": "No! We will record what he says and extend for him from the punishment extensively"
  },
  {
    "id": 80,
    "text": "And We will inherit him [in] what he mentions, and he will come to Us alone"
  },
  {
    "id": 81,
    "text": "And they have taken besides Allah [false] deities that they would be for them [a source of] honor"
  },
  {
    "id": 82,
    "text": "No! Those \"gods\" will deny their worship of them and will be against them opponents [on the Day of Judgement]"
  },
  {
    "id": 83,
    "text": "Do you not see that We have sent the devils upon the disbelievers, inciting them to [evil] with [constant] incitement"
  },
  {
    "id": 84,
    "text": "So be not impatient over them. We only count out to them a [limited] number"
  },
  {
    "id": 85,
    "text": "On the Day We will gather the righteous to the Most Merciful as a delegation"
  },
  {
    "id": 86,
    "text": "And will drive the criminals to Hell in thirst"
  },
  {
    "id": 87,
    "text": "None will have [power of] intercession except he who had taken from the Most Merciful a covenant"
  },
  {
    "id": 88,
    "text": "And they say, \"The Most Merciful has taken [for Himself] a son"
  },
  {
    "id": 89,
    "text": "You have done an atrocious thing"
  },
  {
    "id": 90,
    "text": "The heavens almost rupture therefrom and the earth splits open and the mountains collapse in devastation"
  },
  {
    "id": 91,
    "text": "That they attribute to the Most Merciful a son"
  },
  {
    "id": 92,
    "text": "And it is not appropriate for the Most Merciful that He should take a son"
  },
  {
    "id": 93,
    "text": "There is no one in the heavens and earth but that he comes to the Most Merciful as a servant"
  },
  {
    "id": 94,
    "text": "He has enumerated them and counted them a [full] counting"
  },
  {
    "id": 95,
    "text": "And all of them are coming to Him on the Day of Resurrection alone"
  },
  {
    "id": 96,
    "text": "Indeed, those who have believed and done righteous deeds - the Most Merciful will appoint for them affection"
  },
  {
    "id": 97,
    "text": "So, [O Muhammad], We have only made Qur'an easy in the Arabic language that you may give good tidings thereby to the righteous and warn thereby a hostile people"
  },
  {
    "id": 98,
    "text": "And how many have We destroyed before them of generations? Do you perceive of them anyone or hear from them a sound"
  }
]

export default en
