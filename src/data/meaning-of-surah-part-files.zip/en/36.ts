import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Ya, Seen"
  },
  {
    "id": 2,
    "text": "By the wise Qur'an"
  },
  {
    "id": 3,
    "text": "Indeed you, [O Muhammad], are from among the messengers"
  },
  {
    "id": 4,
    "text": "On a straight path"
  },
  {
    "id": 5,
    "text": "[This is] a revelation of the Exalted in Might, the Merciful"
  },
  {
    "id": 6,
    "text": "That you may warn a people whose forefathers were not warned, so they are unaware"
  },
  {
    "id": 7,
    "text": "Already the word has come into effect upon most of them, so they do not believe"
  },
  {
    "id": 8,
    "text": "Indeed, We have put shackles on their necks, and they are to their chins, so they are with heads [kept] aloft"
  },
  {
    "id": 9,
    "text": "And We have put before them a barrier and behind them a barrier and covered them, so they do not see"
  },
  {
    "id": 10,
    "text": "And it is all the same for them whether you warn them or do not warn them - they will not believe"
  },
  {
    "id": 11,
    "text": "You can only warn one who follows the message and fears the Most Merciful unseen. So give him good tidings of forgiveness and noble reward"
  },
  {
    "id": 12,
    "text": "Indeed, it is We who bring the dead to life and record what they have put forth and what they left behind, and all things We have enumerated in a clear register"
  },
  {
    "id": 13,
    "text": "And present to them an example: the people of the city, when the messengers came to it"
  },
  {
    "id": 14,
    "text": "When We sent to them two but they denied them, so We strengthened them with a third, and they said, \"Indeed, we are messengers to you"
  },
  {
    "id": 15,
    "text": "They said, \"You are not but human beings like us, and the Most Merciful has not revealed a thing. You are only telling lies"
  },
  {
    "id": 16,
    "text": "They said, \"Our Lord knows that we are messengers to you"
  },
  {
    "id": 17,
    "text": "And we are not responsible except for clear notification"
  },
  {
    "id": 18,
    "text": "They said, \"Indeed, we consider you a bad omen. If you do not desist, we will surely stone you, and there will surely touch you, from us, a painful punishment"
  },
  {
    "id": 19,
    "text": "They said, \"Your omen is with yourselves. Is it because you were reminded? Rather, you are a transgressing people"
  },
  {
    "id": 20,
    "text": "And there came from the farthest end of the city a man, running. He said, \"O my people, follow the messengers"
  },
  {
    "id": 21,
    "text": "Follow those who do not ask of you [any] payment, and they are [rightly] guided"
  },
  {
    "id": 22,
    "text": "And why should I not worship He who created me and to whom you will be returned"
  },
  {
    "id": 23,
    "text": "Should I take other than Him [false] deities [while], if the Most Merciful intends for me some adversity, their intercession will not avail me at all, nor can they save me"
  },
  {
    "id": 24,
    "text": "Indeed, I would then be in manifest error"
  },
  {
    "id": 25,
    "text": "Indeed, I have believed in your Lord, so listen to me"
  },
  {
    "id": 26,
    "text": "It was said, \"Enter Paradise.\" He said, \"I wish my people could know"
  },
  {
    "id": 27,
    "text": "Of how my Lord has forgiven me and placed me among the honored"
  },
  {
    "id": 28,
    "text": "And We did not send down upon his people after him any soldiers from the heaven, nor would We have done so"
  },
  {
    "id": 29,
    "text": "It was not but one shout, and immediately they were extinguished"
  },
  {
    "id": 30,
    "text": "How regretful for the servants. There did not come to them any messenger except that they used to ridicule him"
  },
  {
    "id": 31,
    "text": "Have they not considered how many generations We destroyed before them - that they to them will not return"
  },
  {
    "id": 32,
    "text": "And indeed, all of them will yet be brought present before Us"
  },
  {
    "id": 33,
    "text": "And a sign for them is the dead earth. We have brought it to life and brought forth from it grain, and from it they eat"
  },
  {
    "id": 34,
    "text": "And We placed therein gardens of palm trees and grapevines and caused to burst forth therefrom some springs"
  },
  {
    "id": 35,
    "text": "That they may eat of His fruit. And their hands have not produced it, so will they not be grateful"
  },
  {
    "id": 36,
    "text": "Exalted is He who created all pairs - from what the earth grows and from themselves and from that which they do not know"
  },
  {
    "id": 37,
    "text": "And a sign for them is the night. We remove from it [the light of] day, so they are [left] in darkness"
  },
  {
    "id": 38,
    "text": "And the sun runs [on course] toward its stopping point. That is the determination of the Exalted in Might, the Knowing"
  },
  {
    "id": 39,
    "text": "And the moon - We have determined for it phases, until it returns [appearing] like the old date stalk"
  },
  {
    "id": 40,
    "text": "It is not allowable for the sun to reach the moon, nor does the night overtake the day, but each, in an orbit, is swimming"
  },
  {
    "id": 41,
    "text": "And a sign for them is that We carried their forefathers in a laden ship"
  },
  {
    "id": 42,
    "text": "And We created for them from the likes of it that which they ride"
  },
  {
    "id": 43,
    "text": "And if We should will, We could drown them; then no one responding to a cry would there be for them, nor would they be saved"
  },
  {
    "id": 44,
    "text": "Except as a mercy from Us and provision for a time"
  },
  {
    "id": 45,
    "text": "But when it is said to them, \"Beware of what is before you and what is behind you; perhaps you will receive mercy"
  },
  {
    "id": 46,
    "text": "And no sign comes to them from the signs of their Lord except that they are from it turning away"
  },
  {
    "id": 47,
    "text": "And when it is said to them, \"Spend from that which Allah has provided for you,\" those who disbelieve say to those who believe, \"Should we feed one whom, if Allah had willed, He would have fed? You are not but in clear error"
  },
  {
    "id": 48,
    "text": "And they say, \"When is this promise, if you should be truthful"
  },
  {
    "id": 49,
    "text": "They do not await except one blast which will seize them while they are disputing"
  },
  {
    "id": 50,
    "text": "And they will not be able [to give] any instruction, nor to their people can they return"
  },
  {
    "id": 51,
    "text": "And the Horn will be blown; and at once from the graves to their Lord they will hasten"
  },
  {
    "id": 52,
    "text": "They will say, \"O woe to us! Who has raised us up from our sleeping place?\" [The reply will be], \"This is what the Most Merciful had promised, and the messengers told the truth"
  },
  {
    "id": 53,
    "text": "It will not be but one blast, and at once they are all brought present before Us"
  },
  {
    "id": 54,
    "text": "So today no soul will be wronged at all, and you will not be recompensed except for what you used to do"
  },
  {
    "id": 55,
    "text": "Indeed the companions of Paradise, that Day, will be amused in [joyful] occupation"
  },
  {
    "id": 56,
    "text": "They and their spouses - in shade, reclining on adorned couches"
  },
  {
    "id": 57,
    "text": "For them therein is fruit, and for them is whatever they request [or wish]"
  },
  {
    "id": 58,
    "text": "[And] \"Peace,\" a word from a Merciful Lord"
  },
  {
    "id": 59,
    "text": "[Then He will say], \"But stand apart today, you criminals"
  },
  {
    "id": 60,
    "text": "Did I not enjoin upon you, O children of Adam, that you not worship Satan - [for] indeed, he is to you a clear enemy"
  },
  {
    "id": 61,
    "text": "And that you worship [only] Me? This is a straight path"
  },
  {
    "id": 62,
    "text": "And he had already led astray from among you much of creation, so did you not use reason"
  },
  {
    "id": 63,
    "text": "This is the Hellfire which you were promised"
  },
  {
    "id": 64,
    "text": "[Enter to] burn therein today for what you used to deny"
  },
  {
    "id": 65,
    "text": "That Day, We will seal over their mouths, and their hands will speak to Us, and their feet will testify about what they used to earn"
  },
  {
    "id": 66,
    "text": "And if We willed, We could have obliterated their eyes, and they would race to [find] the path, and how could they see"
  },
  {
    "id": 67,
    "text": "And if We willed, We could have deformed them, [paralyzing them] in their places so they would not be able to proceed, nor could they return"
  },
  {
    "id": 68,
    "text": "And he to whom We grant long life We reverse in creation; so will they not understand"
  },
  {
    "id": 69,
    "text": "And We did not give Prophet Muhammad, knowledge of poetry, nor is it befitting for him. It is not but a message and a clear Qur'an"
  },
  {
    "id": 70,
    "text": "To warn whoever is alive and justify the word against the disbelievers"
  },
  {
    "id": 71,
    "text": "Do they not see that We have created for them from what Our hands have made, grazing livestock, and [then] they are their owners"
  },
  {
    "id": 72,
    "text": "And We have tamed them for them, so some of them they ride, and some of them they eat"
  },
  {
    "id": 73,
    "text": "And for them therein are [other] benefits and drinks, so will they not be grateful"
  },
  {
    "id": 74,
    "text": "But they have taken besides Allah [false] deities that perhaps they would be helped"
  },
  {
    "id": 75,
    "text": "They are not able to help them, and they [themselves] are for them soldiers in attendance"
  },
  {
    "id": 76,
    "text": "So let not their speech grieve you. Indeed, We know what they conceal and what they declare"
  },
  {
    "id": 77,
    "text": "Does man not consider that We created him from a [mere] sperm-drop - then at once he is a clear adversary"
  },
  {
    "id": 78,
    "text": "And he presents for Us an example and forgets his [own] creation. He says, \"Who will give life to bones while they are disintegrated"
  },
  {
    "id": 79,
    "text": "Say, \"He will give them life who produced them the first time; and He is, of all creation, Knowing"
  },
  {
    "id": 80,
    "text": "[It is] He who made for you from the green tree, fire, and then from it you ignite"
  },
  {
    "id": 81,
    "text": "Is not He who created the heavens and the earth Able to create the likes of them? Yes, [it is so]; and He is the Knowing Creator"
  },
  {
    "id": 82,
    "text": "His command is only when He intends a thing that He says to it, \"Be,\" and it is"
  },
  {
    "id": 83,
    "text": "So exalted is He in whose hand is the realm of all things, and to Him you will be returned"
  }
]

export default en
