import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Ta, Seen. These are the verses of the Qur'an and a clear Book"
  },
  {
    "id": 2,
    "text": "As guidance and good tidings for the believers"
  },
  {
    "id": 3,
    "text": "Who establish prayer and give zakah, and of the Hereafter they are certain [in faith]"
  },
  {
    "id": 4,
    "text": "Indeed, for those who do not believe in the Hereafter, We have made pleasing to them their deeds, so they wander blindly"
  },
  {
    "id": 5,
    "text": "Those are the ones for whom there will be the worst of punishment, and in the Hereafter they are the greatest losers"
  },
  {
    "id": 6,
    "text": "And indeed, [O Muhammad], you receive the Qur'an from one Wise and Knowing"
  },
  {
    "id": 7,
    "text": "[Mention] when Moses said to his family, \"Indeed, I have perceived a fire. I will bring you from there information or will bring you a burning torch that you may warm yourselves"
  },
  {
    "id": 8,
    "text": "But when he came to it, he was called, \"Blessed is whoever is at the fire and whoever is around it. And exalted is Allah, Lord of the worlds"
  },
  {
    "id": 9,
    "text": "O Moses, indeed it is I - Allah, the Exalted in Might, the Wise"
  },
  {
    "id": 10,
    "text": "And [he was told], \"Throw down your staff.\" But when he saw it writhing as if it were a snake, he turned in flight and did not return. [Allah said], \"O Moses, fear not. Indeed, in My presence the messengers do not fear"
  },
  {
    "id": 11,
    "text": "Otherwise, he who wrongs, then substitutes good after evil - indeed, I am Forgiving and Merciful"
  },
  {
    "id": 12,
    "text": "And put your hand into the opening of your garment [at the breast]; it will come out white without disease. [These are] among the nine signs [you will take] to Pharaoh and his people. Indeed, they have been a people defiantly disobedient"
  },
  {
    "id": 13,
    "text": "But when there came to them Our visible signs, they said, \"This is obvious magic"
  },
  {
    "id": 14,
    "text": "And they rejected them, while their [inner] selves were convinced thereof, out of injustice and haughtiness. So see how was the end of the corrupters"
  },
  {
    "id": 15,
    "text": "And We had certainly given to David and Solomon knowledge, and they said, \"Praise [is due] to Allah, who has favored us over many of His believing servants"
  },
  {
    "id": 16,
    "text": "And Solomon inherited David. He said, \"O people, we have been taught the language of birds, and we have been given from all things. Indeed, this is evident bounty"
  },
  {
    "id": 17,
    "text": "And gathered for Solomon were his soldiers of the jinn and men and birds, and they were [marching] in rows"
  },
  {
    "id": 18,
    "text": "Until, when they came upon the valley of the ants, an ant said, \"O ants, enter your dwellings that you not be crushed by Solomon and his soldiers while they perceive not"
  },
  {
    "id": 19,
    "text": "So [Solomon] smiled, amused at her speech, and said, \"My Lord, enable me to be grateful for Your favor which You have bestowed upon me and upon my parents and to do righteousness of which You approve. And admit me by Your mercy into [the ranks of] Your righteous servants"
  },
  {
    "id": 20,
    "text": "And he took attendance of the birds and said, \"Why do I not see the hoopoe - or is he among the absent"
  },
  {
    "id": 21,
    "text": "I will surely punish him with a severe punishment or slaughter him unless he brings me clear authorization"
  },
  {
    "id": 22,
    "text": "But the hoopoe stayed not long and said, \"I have encompassed [in knowledge] that which you have not encompassed, and I have come to you from Sheba with certain news"
  },
  {
    "id": 23,
    "text": "Indeed, I found [there] a woman ruling them, and she has been given of all things, and she has a great throne"
  },
  {
    "id": 24,
    "text": "I found her and her people prostrating to the sun instead of Allah, and Satan has made their deeds pleasing to them and averted them from [His] way, so they are not guided"
  },
  {
    "id": 25,
    "text": "[And] so they do not prostrate to Allah, who brings forth what is hidden within the heavens and the earth and knows what you conceal and what you declare"
  },
  {
    "id": 26,
    "text": "Allah - there is no deity except Him, Lord of the Great Throne"
  },
  {
    "id": 27,
    "text": "[Solomon] said, \"We will see whether you were truthful or were of the liars"
  },
  {
    "id": 28,
    "text": "Take this letter of mine and deliver it to them. Then leave them and see what [answer] they will return"
  },
  {
    "id": 29,
    "text": "She said, \"O eminent ones, indeed, to me has been delivered a noble letter"
  },
  {
    "id": 30,
    "text": "Indeed, it is from Solomon, and indeed, it reads: 'In the name of Allah, the Entirely Merciful, the Especially Merciful"
  },
  {
    "id": 31,
    "text": "Be not haughty with me but come to me in submission [as Muslims]"
  },
  {
    "id": 32,
    "text": "She said, \"O eminent ones, advise me in my affair. I would not decide a matter until you witness [for] me"
  },
  {
    "id": 33,
    "text": "They said, \"We are men of strength and of great military might, but the command is yours, so see what you will command"
  },
  {
    "id": 34,
    "text": "She said, \"Indeed kings - when they enter a city, they ruin it and render the honored of its people humbled. And thus do they do"
  },
  {
    "id": 35,
    "text": "But indeed, I will send to them a gift and see with what [reply] the messengers will return"
  },
  {
    "id": 36,
    "text": "So when they came to Solomon, he said, \"Do you provide me with wealth? But what Allah has given me is better than what He has given you. Rather, it is you who rejoice in your gift"
  },
  {
    "id": 37,
    "text": "Return to them, for we will surely come to them with soldiers that they will be powerless to encounter, and we will surely expel them therefrom in humiliation, and they will be debased"
  },
  {
    "id": 38,
    "text": "[Solomon] said, \"O assembly [of jinn], which of you will bring me her throne before they come to me in submission"
  },
  {
    "id": 39,
    "text": "A powerful one from among the jinn said, \"I will bring it to you before you rise from your place, and indeed, I am for this [task] strong and trustworthy"
  },
  {
    "id": 40,
    "text": "Said one who had knowledge from the Scripture, \"I will bring it to you before your glance returns to you.\" And when [Solomon] saw it placed before him, he said, \"This is from the favor of my Lord to test me whether I will be grateful or ungrateful. And whoever is grateful - his gratitude is only for [the benefit of] himself. And whoever is ungrateful - then indeed, my Lord is Free of need and Generous"
  },
  {
    "id": 41,
    "text": "He said, \"Disguise for her her throne; we will see whether she will be guided [to truth] or will be of those who is not guided"
  },
  {
    "id": 42,
    "text": "So when she arrived, it was said [to her], \"Is your throne like this?\" She said, \"[It is] as though it was it.\" [Solomon said], \"And we were given knowledge before her, and we have been Muslims [in submission to Allah]"
  },
  {
    "id": 43,
    "text": "And that which she was worshipping other than Allah had averted her [from submission to Him]. Indeed, she was from a disbelieving people"
  },
  {
    "id": 44,
    "text": "She was told, \"Enter the palace.\" But when she saw it, she thought it was a body of water and uncovered her shins [to wade through]. He said, \"Indeed, it is a palace [whose floor is] made smooth with glass.\" She said, \"My Lord, indeed I have wronged myself, and I submit with Solomon to Allah, Lord of the worlds"
  },
  {
    "id": 45,
    "text": "And We had certainly sent to Thamud their brother Salih, [saying], \"Worship Allah,\" and at once they were two parties conflicting"
  },
  {
    "id": 46,
    "text": "He said, \"O my people, why are you impatient for evil instead of good? Why do you not seek forgiveness of Allah that you may receive mercy"
  },
  {
    "id": 47,
    "text": "They said, \"We consider you a bad omen, you and those with you.\" He said, \"Your omen is with Allah. Rather, you are a people being tested"
  },
  {
    "id": 48,
    "text": "And there were in the city nine family heads causing corruption in the land and not amending [its affairs]"
  },
  {
    "id": 49,
    "text": "They said, \"Take a mutual oath by Allah that we will kill him by night, he and his family. Then we will say to his executor, 'We did not witness the destruction of his family, and indeed, we are truthful"
  },
  {
    "id": 50,
    "text": "And they planned a plan, and We planned a plan, while they perceived not"
  },
  {
    "id": 51,
    "text": "Then look how was the outcome of their plan - that We destroyed them and their people, all"
  },
  {
    "id": 52,
    "text": "So those are their houses, desolate because of the wrong they had done. Indeed in that is a sign for people who know"
  },
  {
    "id": 53,
    "text": "And We saved those who believed and used to fear Allah"
  },
  {
    "id": 54,
    "text": "And [mention] Lot, when he said to his people, \"Do you commit immorality while you are seeing"
  },
  {
    "id": 55,
    "text": "Do you indeed approach men with desire instead of women? Rather, you are a people behaving ignorantly"
  },
  {
    "id": 56,
    "text": "But the answer of his people was not except that they said, \"Expel the family of Lot from your city. Indeed, they are people who keep themselves pure"
  },
  {
    "id": 57,
    "text": "So We saved him and his family, except for his wife; We destined her to be of those who remained behind"
  },
  {
    "id": 58,
    "text": "And We rained upon them a rain [of stones], and evil was the rain of those who were warned"
  },
  {
    "id": 59,
    "text": "Say, [O Muhammad], \"Praise be to Allah, and peace upon His servants whom He has chosen. Is Allah better or what they associate with Him"
  },
  {
    "id": 60,
    "text": "[More precisely], is He [not best] who created the heavens and the earth and sent down for you rain from the sky, causing to grow thereby gardens of joyful beauty which you could not [otherwise] have grown the trees thereof? Is there a deity with Allah? [No], but they are a people who ascribe equals [to Him]"
  },
  {
    "id": 61,
    "text": "Is He [not best] who made the earth a stable ground and placed within it rivers and made for it firmly set mountains and placed between the two seas a barrier? Is there a deity with Allah? [No], but most of them do not know"
  },
  {
    "id": 62,
    "text": "Is He [not best] who responds to the desperate one when he calls upon Him and removes evil and makes you inheritors of the earth? Is there a deity with Allah? Little do you remember"
  },
  {
    "id": 63,
    "text": "Is He [not best] who guides you through the darknesses of the land and sea and who sends the winds as good tidings before His mercy? Is there a deity with Allah? High is Allah above whatever they associate with Him"
  },
  {
    "id": 64,
    "text": "Is He [not best] who begins creation and then repeats it and who provides for you from the heaven and earth? Is there a deity with Allah? Say, \"Produce your proof, if you should be truthful"
  },
  {
    "id": 65,
    "text": "Say, \"None in the heavens and earth knows the unseen except Allah, and they do not perceive when they will be resurrected"
  },
  {
    "id": 66,
    "text": "Rather, their knowledge is arrested concerning the Hereafter. Rather, they are in doubt about it. Rather, they are, concerning it, blind"
  },
  {
    "id": 67,
    "text": "And those who disbelieve say, \"When we have become dust as well as our forefathers, will we indeed be brought out [of the graves]"
  },
  {
    "id": 68,
    "text": "We have been promised this, we and our forefathers, before. This is not but legends of the former peoples"
  },
  {
    "id": 69,
    "text": "Say, [O Muhammad], \"Travel through the land and observe how was the end of the criminals"
  },
  {
    "id": 70,
    "text": "And grieve not over them or be in distress from what they conspire"
  },
  {
    "id": 71,
    "text": "And they say, \"When is [the fulfillment of] this promise, if you should be truthful"
  },
  {
    "id": 72,
    "text": "Say, \"Perhaps it is close behind you - some of that for which you are impatient"
  },
  {
    "id": 73,
    "text": "And indeed, your Lord is full of bounty for the people, but most of them do not show gratitude"
  },
  {
    "id": 74,
    "text": "And indeed, your Lord knows what their breasts conceal and what they declare"
  },
  {
    "id": 75,
    "text": "And there is nothing concealed within the heaven and the earth except that it is in a clear Register"
  },
  {
    "id": 76,
    "text": "Indeed, this Qur'an relates to the Children of Israel most of that over which they disagree"
  },
  {
    "id": 77,
    "text": "And indeed, it is guidance and mercy for the believers"
  },
  {
    "id": 78,
    "text": "Indeed, your Lord will judge between them by His [wise] judgement. And He is the Exalted in Might, the Knowing"
  },
  {
    "id": 79,
    "text": "So rely upon Allah; indeed, you are upon the clear truth"
  },
  {
    "id": 80,
    "text": "Indeed, you will not make the dead hear, nor will you make the deaf hear the call when they have turned their backs retreating"
  },
  {
    "id": 81,
    "text": "And you cannot guide the blind away from their error. You will only make hear those who believe in Our verses so they are Muslims [submitting to Allah]"
  },
  {
    "id": 82,
    "text": "And when the word befalls them, We will bring forth for them a creature from the earth speaking to them, [saying] that the people were, of Our verses, not certain [in faith]"
  },
  {
    "id": 83,
    "text": "And [warn of] the Day when We will gather from every nation a company of those who deny Our signs, and they will be [driven] in rows"
  },
  {
    "id": 84,
    "text": "Until, when they arrive [at the place of Judgement], He will say, \"Did you deny My signs while you encompassed them not in knowledge, or what [was it that] you were doing"
  },
  {
    "id": 85,
    "text": "And the decree will befall them for the wrong they did, and they will not [be able to] speak"
  },
  {
    "id": 86,
    "text": "Do they not see that We made the night that they may rest therein and the day giving sight? Indeed in that are signs for a people who believe"
  },
  {
    "id": 87,
    "text": "And [warn of] the Day the Horn will be blown, and whoever is in the heavens and whoever is on the earth will be terrified except whom Allah wills. And all will come to Him humbled"
  },
  {
    "id": 88,
    "text": "And you see the mountains, thinking them rigid, while they will pass as the passing of clouds. [It is] the work of Allah, who perfected all things. Indeed, He is Acquainted with that which you do"
  },
  {
    "id": 89,
    "text": "Whoever comes [at Judgement] with a good deed will have better than it, and they, from the terror of that Day, will be safe"
  },
  {
    "id": 90,
    "text": "And whoever comes with an evil deed - their faces will be overturned into the Fire, [and it will be said], \"Are you recompensed except for what you used to do"
  },
  {
    "id": 91,
    "text": "[Say, O Muhammad], \"I have only been commanded to worship the Lord of this city, who made it sacred and to whom [belongs] all things. And I am commanded to be of the Muslims [those who submit to Allah]"
  },
  {
    "id": 92,
    "text": "And to recite the Qur'an.\" And whoever is guided is only guided for [the benefit of] himself; and whoever strays - say, \"I am only [one] of the warners"
  },
  {
    "id": 93,
    "text": "And say, \"[All] praise is [due] to Allah. He will show you His signs, and you will recognize them. And your Lord is not unaware of what you do"
  }
]

export default en
