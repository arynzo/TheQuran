import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Ha, Meem"
  },
  {
    "id": 2,
    "text": "The revelation of the Book is from Allah, the Exalted in Might, the Knowing"
  },
  {
    "id": 3,
    "text": "The forgiver of sin, acceptor of repentance, severe in punishment, owner of abundance. There is no deity except Him; to Him is the destination"
  },
  {
    "id": 4,
    "text": "No one disputes concerning the signs of Allah except those who disbelieve, so be not deceived by their [uninhibited] movement throughout the land"
  },
  {
    "id": 5,
    "text": "The people of Noah denied before them and the [disbelieving] factions after them, and every nation intended [a plot] for their messenger to seize him, and they disputed by [using] falsehood to [attempt to] invalidate thereby the truth. So I seized them, and how [terrible] was My penalty"
  },
  {
    "id": 6,
    "text": "And thus has the word of your Lord come into effect upon those who disbelieved that they are companions of the Fire"
  },
  {
    "id": 7,
    "text": "Those [angels] who carry the Throne and those around it exalt [Allah] with praise of their Lord and believe in Him and ask forgiveness for those who have believed, [saying], \"Our Lord, You have encompassed all things in mercy and knowledge, so forgive those who have repented and followed Your way and protect them from the punishment of Hellfire"
  },
  {
    "id": 8,
    "text": "Our Lord, and admit them to gardens of perpetual residence which You have promised them and whoever was righteous among their fathers, their spouses and their offspring. Indeed, it is You who is the Exalted in Might, the Wise"
  },
  {
    "id": 9,
    "text": "And protect them from the evil consequences [of their deeds]. And he whom You protect from evil consequences that Day - You will have given him mercy. And that is the great attainment"
  },
  {
    "id": 10,
    "text": "Indeed, those who disbelieve will be addressed, \"The hatred of Allah for you was [even] greater than your hatred of yourselves [this Day in Hell] when you were invited to faith, but you refused"
  },
  {
    "id": 11,
    "text": "They will say, \"Our Lord, You made us lifeless twice and gave us life twice, and we have confessed our sins. So is there to an exit any way"
  },
  {
    "id": 12,
    "text": "[They will be told], \"That is because, when Allah was called upon alone, you disbelieved; but if others were associated with Him, you believed. So the judgement is with Allah, the Most High, the Grand"
  },
  {
    "id": 13,
    "text": "It is He who shows you His signs and sends down to you from the sky, provision. But none will remember except he who turns back [in repentance]"
  },
  {
    "id": 14,
    "text": "So invoke Allah, [being] sincere to Him in religion, although the disbelievers dislike it"
  },
  {
    "id": 15,
    "text": "[He is] the Exalted above [all] degrees, Owner of the Throne; He places the inspiration of His command upon whom He wills of His servants to warn of the Day of Meeting"
  },
  {
    "id": 16,
    "text": "The Day they come forth nothing concerning them will be concealed from Allah. To whom belongs [all] sovereignty this Day? To Allah, the One, the Prevailing"
  },
  {
    "id": 17,
    "text": "This Day every soul will be recompensed for what it earned. No injustice today! Indeed, Allah is swift in account"
  },
  {
    "id": 18,
    "text": "And warn them, [O Muhammad], of the Approaching Day, when hearts are at the throats, filled [with distress]. For the wrongdoers there will be no devoted friend and no intercessor [who is] obeyed"
  },
  {
    "id": 19,
    "text": "He knows that which deceives the eyes and what the breasts conceal"
  },
  {
    "id": 20,
    "text": "And Allah judges with truth, while those they invoke besides Him judge not with anything. Indeed, Allah - He is the Hearing, the Seeing"
  },
  {
    "id": 21,
    "text": "Have they not traveled through the land and observed how was the end of those who were before them? They were greater than them in strength and in impression on the land, but Allah seized them for their sins. And they had not from Allah any protector"
  },
  {
    "id": 22,
    "text": "That was because their messengers were coming to them with clear proofs, but they disbelieved, so Allah seized them. Indeed, He is Powerful and severe in punishment"
  },
  {
    "id": 23,
    "text": "And We did certainly send Moses with Our signs and a clear authority"
  },
  {
    "id": 24,
    "text": "To Pharaoh, Haman and Qarun; but they said, \"[He is] a magician and a liar"
  },
  {
    "id": 25,
    "text": "And when he brought them the truth from Us, they said, \"Kill the sons of those who have believed with him and keep their women alive.\" But the plan of the disbelievers is not except in error"
  },
  {
    "id": 26,
    "text": "And Pharaoh said, \"Let me kill Moses and let him call upon his Lord. Indeed, I fear that he will change your religion or that he will cause corruption in the land"
  },
  {
    "id": 27,
    "text": "But Moses said, \"Indeed, I have sought refuge in my Lord and your Lord from every arrogant one who does not believe in the Day of Account"
  },
  {
    "id": 28,
    "text": "And a believing man from the family of Pharaoh who concealed his faith said, \"Do you kill a man [merely] because he says, 'My Lord is Allah' while he has brought you clear proofs from your Lord? And if he should be lying, then upon him is [the consequence of] his lie; but if he should be truthful, there will strike you some of what he promises you. Indeed, Allah does not guide one who is a transgressor and a liar"
  },
  {
    "id": 29,
    "text": "O my people, sovereignty is yours today, [your being] dominant in the land. But who would protect us from the punishment of Allah if it came to us?\" Pharaoh said, \"I do not show you except what I see, and I do not guide you except to the way of right conduct"
  },
  {
    "id": 30,
    "text": "And he who believed said, \"O my people, indeed I fear for you [a fate] like the day of the companies"
  },
  {
    "id": 31,
    "text": "Like the custom of the people of Noah and of 'Aad and Thamud and those after them. And Allah wants no injustice for [His] servants"
  },
  {
    "id": 32,
    "text": "And O my people, indeed I fear for you the Day of Calling"
  },
  {
    "id": 33,
    "text": "The Day you will turn your backs fleeing; there is not for you from Allah any protector. And whoever Allah leaves astray - there is not for him any guide"
  },
  {
    "id": 34,
    "text": "And Joseph had already come to you before with clear proofs, but you remained in doubt of that which he brought to you, until when he died, you said, 'Never will Allah send a messenger after him.' Thus does Allah leave astray he who is a transgressor and skeptic"
  },
  {
    "id": 35,
    "text": "Those who dispute concerning the signs of Allah without an authority having come to them - great is hatred [of them] in the sight of Allah and in the sight of those who have believed. Thus does Allah seal over every heart [belonging to] an arrogant tyrant"
  },
  {
    "id": 36,
    "text": "And Pharaoh said, \"O Haman, construct for me a tower that I might reach the ways"
  },
  {
    "id": 37,
    "text": "The ways into the heavens - so that I may look at the deity of Moses; but indeed, I think he is a liar.\" And thus was made attractive to Pharaoh the evil of his deed, and he was averted from the [right] way. And the plan of Pharaoh was not except in ruin"
  },
  {
    "id": 38,
    "text": "And he who believed said, \"O my people, follow me, I will guide you to the way of right conduct"
  },
  {
    "id": 39,
    "text": "O my people, this worldly life is only [temporary] enjoyment, and indeed, the Hereafter - that is the home of [permanent] settlement"
  },
  {
    "id": 40,
    "text": "Whoever does an evil deed will not be recompensed except by the like thereof; but whoever does righteousness, whether male or female, while he is a believer - those will enter Paradise, being given provision therein without account"
  },
  {
    "id": 41,
    "text": "And O my people, how is it that I invite you to salvation while you invite me to the Fire"
  },
  {
    "id": 42,
    "text": "You invite me to disbelieve in Allah and associate with Him that of which I have no knowledge, and I invite you to the Exalted in Might, the Perpetual Forgiver"
  },
  {
    "id": 43,
    "text": "Assuredly, that to which you invite me has no [response to a] supplication in this world or in the Hereafter; and indeed, our return is to Allah, and indeed, the transgressors will be companions of the Fire"
  },
  {
    "id": 44,
    "text": "And you will remember what I [now] say to you, and I entrust my affair to Allah. Indeed, Allah is Seeing of [His] servants"
  },
  {
    "id": 45,
    "text": "So Allah protected him from the evils they plotted, and the people of Pharaoh were enveloped by the worst of punishment"
  },
  {
    "id": 46,
    "text": "The Fire, they are exposed to it morning and evening. And the Day the Hour appears [it will be said], \"Make the people of Pharaoh enter the severest punishment"
  },
  {
    "id": 47,
    "text": "And [mention] when they will argue within the Fire, and the weak will say to those who had been arrogant, \"Indeed, we were [only] your followers, so will you relieve us of a share of the Fire"
  },
  {
    "id": 48,
    "text": "Those who had been arrogant will say, \"Indeed, all [of us] are in it. Indeed, Allah has judged between the servants"
  },
  {
    "id": 49,
    "text": "And those in the Fire will say to the keepers of Hell, \"Supplicate your Lord to lighten for us a day from the punishment"
  },
  {
    "id": 50,
    "text": "They will say, \"Did there not come to you your messengers with clear proofs?\" They will say, \"Yes.\" They will reply, \"Then supplicate [yourselves], but the supplication of the disbelievers is not except in error"
  },
  {
    "id": 51,
    "text": "Indeed, We will support Our messengers and those who believe during the life of this world and on the Day when the witnesses will stand"
  },
  {
    "id": 52,
    "text": "The Day their excuse will not benefit the wrongdoers, and they will have the curse, and they will have the worst home"
  },
  {
    "id": 53,
    "text": "And We had certainly given Moses guidance, and We caused the Children of Israel to inherit the Scripture"
  },
  {
    "id": 54,
    "text": "As guidance and a reminder for those of understanding"
  },
  {
    "id": 55,
    "text": "So be patient, [O Muhammad]. Indeed, the promise of Allah is truth. And ask forgiveness for your sin and exalt [Allah] with praise of your Lord in the evening and the morning"
  },
  {
    "id": 56,
    "text": "Indeed, those who dispute concerning the signs of Allah without [any] authority having come to them - there is not within their breasts except pride, [the extent of] which they cannot reach. So seek refuge in Allah. Indeed, it is He who is the Hearing, the Seeing"
  },
  {
    "id": 57,
    "text": "The creation of the heavens and earth is greater than the creation of mankind, but most of the people do not know"
  },
  {
    "id": 58,
    "text": "And not equal are the blind and the seeing, nor are those who believe and do righteous deeds and the evildoer. Little do you remember"
  },
  {
    "id": 59,
    "text": "Indeed, the Hour is coming - no doubt about it - but most of the people do not believe"
  },
  {
    "id": 60,
    "text": "And your Lord says, \"Call upon Me; I will respond to you.\" Indeed, those who disdain My worship will enter Hell [rendered] contemptible"
  },
  {
    "id": 61,
    "text": "It is Allah who made for you the night that you may rest therein and the day giving sight. Indeed, Allah is full of bounty to the people, but most of the people are not grateful"
  },
  {
    "id": 62,
    "text": "That is Allah, your Lord, Creator of all things; there is no deity except Him, so how are you deluded"
  },
  {
    "id": 63,
    "text": "Thus were those [before you] deluded who were rejecting the signs of Allah"
  },
  {
    "id": 64,
    "text": "It is Allah who made for you the earth a place of settlement and the sky a ceiling and formed you and perfected your forms and provided you with good things. That is Allah, your Lord; then blessed is Allah, Lord of the worlds"
  },
  {
    "id": 65,
    "text": "He is the Ever-Living; there is no deity except Him, so call upon Him, [being] sincere to Him in religion. [All] praise is [due] to Allah, Lord of the worlds"
  },
  {
    "id": 66,
    "text": "Say, [O Muhammad], \"Indeed, I have been forbidden to worship those you call upon besides Allah once the clear proofs have come to me from my Lord, and I have been commanded to submit to the Lord of the worlds"
  },
  {
    "id": 67,
    "text": "It is He who created you from dust, then from a sperm-drop, then from a clinging clot; then He brings you out as a child; then [He develops you] that you reach your [time of] maturity, then [further] that you become elders. And among you is he who is taken in death before [that], so that you reach a specified term; and perhaps you will use reason"
  },
  {
    "id": 68,
    "text": "He it is who gives life and causes death; and when He decrees a matter, He but says to it, \"Be,\" and it is"
  },
  {
    "id": 69,
    "text": "Do you not consider those who dispute concerning the signs of Allah - how are they averted"
  },
  {
    "id": 70,
    "text": "Those who deny the Book and that with which We sent Our messengers - they are going to know"
  },
  {
    "id": 71,
    "text": "When the shackles are around their necks and the chains; they will be dragged"
  },
  {
    "id": 72,
    "text": "In boiling water; then in the Fire they will be filled [with flame]"
  },
  {
    "id": 73,
    "text": "Then it will be said to them, \"Where is that which you used to associate [with Him in worship]"
  },
  {
    "id": 74,
    "text": "Other than Allah?\" They will say, \"They have departed from us; rather, we did not used to invoke previously anything.\" Thus does Allah put astray the disbelievers"
  },
  {
    "id": 75,
    "text": "[The angels will say], \"That was because you used to exult upon the earth without right and you used to behave insolently"
  },
  {
    "id": 76,
    "text": "Enter the gates of Hell to abide eternally therein, and wretched is the residence of the arrogant"
  },
  {
    "id": 77,
    "text": "So be patient, [O Muhammad]; indeed, the promise of Allah is truth. And whether We show you some of what We have promised them or We take you in death, it is to Us they will be returned"
  },
  {
    "id": 78,
    "text": "And We have already sent messengers before you. Among them are those [whose stories] We have related to you, and among them are those [whose stories] We have not related to you. And it was not for any messenger to bring a sign [or verse] except by permission of Allah. So when the command of Allah comes, it will be concluded in truth, and the falsifiers will thereupon lose [all]"
  },
  {
    "id": 79,
    "text": "It is Allah who made for you the grazing animals upon which you ride, and some of them you eat"
  },
  {
    "id": 80,
    "text": "And for you therein are [other] benefits and that you may realize upon them a need which is in your breasts; and upon them and upon ships you are carried"
  },
  {
    "id": 81,
    "text": "And He shows you His signs. So which of the signs of Allah do you deny"
  },
  {
    "id": 82,
    "text": "Have they not traveled through the land and observed how was the end of those before them? They were more numerous than themselves and greater in strength and in impression on the land, but they were not availed by what they used to earn"
  },
  {
    "id": 83,
    "text": "And when their messengers came to them with clear proofs, they [merely] rejoiced in what they had of knowledge, but they were enveloped by what they used to ridicule"
  },
  {
    "id": 84,
    "text": "And when they saw Our punishment, they said,\" We believe in Allah alone and disbelieve in that which we used to associate with Him"
  },
  {
    "id": 85,
    "text": "But never did their faith benefit them once they saw Our punishment. [It is] the established way of Allah which has preceded among His servants. And the disbelievers thereupon lost [all]"
  }
]

export default en
