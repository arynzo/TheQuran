import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Ha, Meem"
  },
  {
    "id": 2,
    "text": "[This is] a revelation from the Entirely Merciful, the Especially Merciful"
  },
  {
    "id": 3,
    "text": "A Book whose verses have been detailed, an Arabic Qur'an for a people who know"
  },
  {
    "id": 4,
    "text": "As a giver of good tidings and a warner; but most of them turn away, so they do not hear"
  },
  {
    "id": 5,
    "text": "And they say, \"Our hearts are within coverings from that to which you invite us, and in our ears is deafness, and between us and you is a partition, so work; indeed, we are working"
  },
  {
    "id": 6,
    "text": "Say, O [Muhammad], \"I am only a man like you to whom it has been revealed that your god is but one God; so take a straight course to Him and seek His forgiveness.\" And woe to those who associate others with Allah"
  },
  {
    "id": 7,
    "text": "Those who do not give zakah, and in the Hereafter they are disbelievers"
  },
  {
    "id": 8,
    "text": "Indeed, those who believe and do righteous deeds - for them is a reward uninterrupted"
  },
  {
    "id": 9,
    "text": "Say, \"Do you indeed disbelieve in He who created the earth in two days and attribute to Him equals? That is the Lord of the worlds"
  },
  {
    "id": 10,
    "text": "And He placed on the earth firmly set mountains over its surface, and He blessed it and determined therein its [creatures'] sustenance in four days without distinction - for [the information] of those who ask"
  },
  {
    "id": 11,
    "text": "Then He directed Himself to the heaven while it was smoke and said to it and to the earth, \"Come [into being], willingly or by compulsion.\" They said, \"We have come willingly"
  },
  {
    "id": 12,
    "text": "And He completed them as seven heavens within two days and inspired in each heaven its command. And We adorned the nearest heaven with lamps and as protection. That is the determination of the Exalted in Might, the Knowing"
  },
  {
    "id": 13,
    "text": "But if they turn away, then say, \"I have warned you of a thunderbolt like the thunderbolt [that struck] 'Aad and Thamud"
  },
  {
    "id": 14,
    "text": "[That occurred] when the messengers had come to them before them and after them, [saying], \"Worship not except Allah.\" They said, \"If our Lord had willed, He would have sent down the angels, so indeed we, in that with which you have been sent, are disbelievers"
  },
  {
    "id": 15,
    "text": "As for 'Aad, they were arrogant upon the earth without right and said, \"Who is greater than us in strength?\" Did they not consider that Allah who created them was greater than them in strength? But they were rejecting Our signs"
  },
  {
    "id": 16,
    "text": "So We sent upon them a screaming wind during days of misfortune to make them taste the punishment of disgrace in the worldly life; but the punishment of the Hereafter is more disgracing, and they will not be helped"
  },
  {
    "id": 17,
    "text": "And as for Thamud, We guided them, but they preferred blindness over guidance, so the thunderbolt of humiliating punishment seized them for what they used to earn"
  },
  {
    "id": 18,
    "text": "And We saved those who believed and used to fear Allah"
  },
  {
    "id": 19,
    "text": "And [mention, O Muhammad], the Day when the enemies of Allah will be gathered to the Fire while they are [driven] assembled in rows"
  },
  {
    "id": 20,
    "text": "Until, when they reach it, their hearing and their eyes and their skins will testify against them of what they used to do"
  },
  {
    "id": 21,
    "text": "And they will say to their skins, \"Why have you testified against us?\" They will say, \"We were made to speak by Allah, who has made everything speak; and He created you the first time, and to Him you are returned"
  },
  {
    "id": 22,
    "text": "And you were not covering yourselves, lest your hearing testify against you or your sight or your skins, but you assumed that Allah does not know much of what you do"
  },
  {
    "id": 23,
    "text": "And that was your assumption which you assumed about your Lord. It has brought you to ruin, and you have become among the losers"
  },
  {
    "id": 24,
    "text": "So [even] if they are patient, the Fire is a residence for them; and if they ask to appease [Allah], they will not be of those who are allowed to appease"
  },
  {
    "id": 25,
    "text": "And We appointed for them companions who made attractive to them what was before them and what was behind them [of sin], and the word has come into effect upon them among nations which had passed on before them of jinn and men. Indeed, they [all] were losers"
  },
  {
    "id": 26,
    "text": "And those who disbelieve say, \"Do not listen to this Qur'an and speak noisily during [the recitation of] it that perhaps you will overcome"
  },
  {
    "id": 27,
    "text": "But We will surely cause those who disbelieve to taste a severe punishment, and We will surely recompense them for the worst of what they had been doing"
  },
  {
    "id": 28,
    "text": "That is the recompense of the enemies of Allah - the Fire. For them therein is the home of eternity as recompense for what they, of Our verses, were rejecting"
  },
  {
    "id": 29,
    "text": "And those who disbelieved will [then] say, \"Our Lord, show us those who misled us of the jinn and men [so] we may put them under our feet that they will be among the lowest"
  },
  {
    "id": 30,
    "text": "Indeed, those who have said, \"Our Lord is Allah \" and then remained on a right course - the angels will descend upon them, [saying], \"Do not fear and do not grieve but receive good tidings of Paradise, which you were promised"
  },
  {
    "id": 31,
    "text": "We [angels] were your allies in worldly life and [are so] in the Hereafter. And you will have therein whatever your souls desire, and you will have therein whatever you request [or wish]"
  },
  {
    "id": 32,
    "text": "As accommodation from a [Lord who is] Forgiving and Merciful"
  },
  {
    "id": 33,
    "text": "And who is better in speech than one who invites to Allah and does righteousness and says, \"Indeed, I am of the Muslims"
  },
  {
    "id": 34,
    "text": "And not equal are the good deed and the bad. Repel [evil] by that [deed] which is better; and thereupon the one whom between you and him is enmity [will become] as though he was a devoted friend"
  },
  {
    "id": 35,
    "text": "But none is granted it except those who are patient, and none is granted it except one having a great portion [of good]"
  },
  {
    "id": 36,
    "text": "And if there comes to you from Satan an evil suggestion, then seek refuge in Allah. Indeed, He is the Hearing, the Knowing"
  },
  {
    "id": 37,
    "text": "And of His signs are the night and day and the sun and moon. Do not prostrate to the sun or to the moon, but prostate to Allah, who created them, if it should be Him that you worship"
  },
  {
    "id": 38,
    "text": "But if they are arrogant - then those who are near your Lord exalt Him by night and by day, and they do not become weary"
  },
  {
    "id": 39,
    "text": "And of His signs is that you see the earth stilled, but when We send down upon it rain, it quivers and grows. Indeed, He who has given it life is the Giver of Life to the dead. Indeed, He is over all things competent"
  },
  {
    "id": 40,
    "text": "Indeed, those who inject deviation into Our verses are not concealed from Us. So, is he who is cast into the Fire better or he who comes secure on the Day of Resurrection? Do whatever you will; indeed, He is Seeing of what you do"
  },
  {
    "id": 41,
    "text": "Indeed, those who disbelieve in the message after it has come to them... And indeed, it is a mighty Book"
  },
  {
    "id": 42,
    "text": "Falsehood cannot approach it from before it or from behind it; [it is] a revelation from a [Lord who is] Wise and Praiseworthy"
  },
  {
    "id": 43,
    "text": "Nothing is said to you, [O Muhammad], except what was already said to the messengers before you. Indeed, your Lord is a possessor of forgiveness and a possessor of painful penalty"
  },
  {
    "id": 44,
    "text": "And if We had made it a non-Arabic Qur'an, they would have said, \"Why are its verses not explained in detail [in our language]? Is it a foreign [recitation] and an Arab [messenger]?\" Say, \"It is, for those who believe, a guidance and cure.\" And those who do not believe - in their ears is deafness, and it is upon them blindness. Those are being called from a distant place"
  },
  {
    "id": 45,
    "text": "And We had already given Moses the Scripture, but it came under disagreement. And if not for a word that preceded from your Lord, it would have been concluded between them. And indeed they are, concerning the Qur'an, in disquieting doubt"
  },
  {
    "id": 46,
    "text": "Whoever does righteousness - it is for his [own] soul; and whoever does evil [does so] against it. And your Lord is not ever unjust to [His] servants"
  },
  {
    "id": 47,
    "text": "To him [alone] is attributed knowledge of the Hour. And fruits emerge not from their coverings nor does a female conceive or give birth except with His knowledge. And the Day He will call to them, \"Where are My 'partners'?\" they will say, \"We announce to You that there is [no longer] among us any witness [to that]"
  },
  {
    "id": 48,
    "text": "And lost from them will be those they were invoking before, and they will be certain that they have no place of escape"
  },
  {
    "id": 49,
    "text": "Man is not weary of supplication for good [things], but if evil touches him, he is hopeless and despairing"
  },
  {
    "id": 50,
    "text": "And if We let him taste mercy from Us after an adversity which has touched him, he will surely say, \"This is [due] to me, and I do not think the Hour will occur; and [even] if I should be returned to my Lord, indeed, for me there will be with Him the best.\" But We will surely inform those who disbelieved about what they did, and We will surely make them taste a massive punishment"
  },
  {
    "id": 51,
    "text": "And when We bestow favor upon man, he turns away and distances himself; but when evil touches him, then he is full of extensive supplication"
  },
  {
    "id": 52,
    "text": "Say, \"Have you considered: if the Qur'an is from Allah and you disbelieved in it, who would be more astray than one who is in extreme dissension"
  },
  {
    "id": 53,
    "text": "We will show them Our signs in the horizons and within themselves until it becomes clear to them that it is the truth. But is it not sufficient concerning your Lord that He is, over all things, a Witness"
  },
  {
    "id": 54,
    "text": "Unquestionably, they are in doubt about the meeting with their Lord. Unquestionably He is, of all things, encompassing"
  }
]

export default en
