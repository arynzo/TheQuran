import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Alif, Lam, Meem, Sad"
  },
  {
    "id": 2,
    "text": "[This is] a Book revealed to you, [O Muhammad] - so let there not be in your breast distress therefrom - that you may warn thereby and as a reminder to the believers"
  },
  {
    "id": 3,
    "text": "Follow, [O mankind], what has been revealed to you from your Lord and do not follow other than Him any allies. Little do you remember"
  },
  {
    "id": 4,
    "text": "And how many cities have We destroyed, and Our punishment came to them at night or while they were sleeping at noon"
  },
  {
    "id": 5,
    "text": "And their declaration when Our punishment came to them was only that they said, \"Indeed, we were wrongdoers"
  },
  {
    "id": 6,
    "text": "Then We will surely question those to whom [a message] was sent, and We will surely question the messengers"
  },
  {
    "id": 7,
    "text": "Then We will surely relate [their deeds] to them with knowledge, and We were not [at all] absent"
  },
  {
    "id": 8,
    "text": "And the weighing [of deeds] that Day will be the truth. So those whose scales are heavy - it is they who will be the successful"
  },
  {
    "id": 9,
    "text": "And those whose scales are light - they are the ones who will lose themselves for what injustice they were doing toward Our verses"
  },
  {
    "id": 10,
    "text": "And We have certainly established you upon the earth and made for you therein ways of livelihood. Little are you grateful"
  },
  {
    "id": 11,
    "text": "And We have certainly created you, [O Mankind], and given you [human] form. Then We said to the angels, \"Prostrate to Adam\"; so they prostrated, except for Iblees. He was not of those who prostrated"
  },
  {
    "id": 12,
    "text": "[Allah] said, \"What prevented you from prostrating when I commanded you?\" [Satan] said, \"I am better than him. You created me from fire and created him from clay"
  },
  {
    "id": 13,
    "text": "[Allah] said, \"Descend from Paradise, for it is not for you to be arrogant therein. So get out; indeed, you are of the debased"
  },
  {
    "id": 14,
    "text": "[Satan] said, \"Reprieve me until the Day they are resurrected"
  },
  {
    "id": 15,
    "text": "[Allah] said, \"Indeed, you are of those reprieved"
  },
  {
    "id": 16,
    "text": "[Satan] said, \"Because You have put me in error, I will surely sit in wait for them on Your straight path"
  },
  {
    "id": 17,
    "text": "Then I will come to them from before them and from behind them and on their right and on their left, and You will not find most of them grateful [to You]"
  },
  {
    "id": 18,
    "text": "[Allah] said, \"Get out of Paradise, reproached and expelled. Whoever follows you among them - I will surely fill Hell with you, all together"
  },
  {
    "id": 19,
    "text": "And \"O Adam, dwell, you and your wife, in Paradise and eat from wherever you will but do not approach this tree, lest you be among the wrongdoers"
  },
  {
    "id": 20,
    "text": "But Satan whispered to them to make apparent to them that which was concealed from them of their private parts. He said, \"Your Lord did not forbid you this tree except that you become angels or become of the immortal"
  },
  {
    "id": 21,
    "text": "And he swore [by Allah] to them, \"Indeed, I am to you from among the sincere advisors"
  },
  {
    "id": 22,
    "text": "So he made them fall, through deception. And when they tasted of the tree, their private parts became apparent to them, and they began to fasten together over themselves from the leaves of Paradise. And their Lord called to them, \"Did I not forbid you from that tree and tell you that Satan is to you a clear enemy"
  },
  {
    "id": 23,
    "text": "They said, \"Our Lord, we have wronged ourselves, and if You do not forgive us and have mercy upon us, we will surely be among the losers"
  },
  {
    "id": 24,
    "text": "[Allah] said, \"Descend, being to one another enemies. And for you on the earth is a place of settlement and enjoyment for a time"
  },
  {
    "id": 25,
    "text": "He said, \"Therein you will live, and therein you will die, and from it you will be brought forth"
  },
  {
    "id": 26,
    "text": "O children of Adam, We have bestowed upon you clothing to conceal your private parts and as adornment. But the clothing of righteousness - that is best. That is from the signs of Allah that perhaps they will remember"
  },
  {
    "id": 27,
    "text": "O children of Adam, let not Satan tempt you as he removed your parents from Paradise, stripping them of their clothing to show them their private parts. Indeed, he sees you, he and his tribe, from where you do not see them. Indeed, We have made the devils allies to those who do not believe"
  },
  {
    "id": 28,
    "text": "And when they commit an immorality, they say, \"We found our fathers doing it, and Allah has ordered us to do it.\" Say, \"Indeed, Allah does not order immorality. Do you say about Allah that which you do not know"
  },
  {
    "id": 29,
    "text": "Say, [O Muhammad], \"My Lord has ordered justice and that you maintain yourselves [in worship of Him] at every place [or time] of prostration, and invoke Him, sincere to Him in religion.\" Just as He originated you, you will return [to life]"
  },
  {
    "id": 30,
    "text": "A group [of you] He guided, and a group deserved [to be in] error. Indeed, they had taken the devils as allies instead of Allah while they thought that they were guided"
  },
  {
    "id": 31,
    "text": "O children of Adam, take your adornment at every masjid, and eat and drink, but be not excessive. Indeed, He likes not those who commit excess"
  },
  {
    "id": 32,
    "text": "Say, \"Who has forbidden the adornment of Allah which He has produced for His servants and the good [lawful] things of provision?\" Say, \"They are for those who believe during the worldly life [but] exclusively for them on the Day of Resurrection.\" Thus do We detail the verses for a people who know"
  },
  {
    "id": 33,
    "text": "Say, \"My Lord has only forbidden immoralities - what is apparent of them and what is concealed - and sin, and oppression without right, and that you associate with Allah that for which He has not sent down authority, and that you say about Allah that which you do not know"
  },
  {
    "id": 34,
    "text": "And for every nation is a [specified] term. So when their time has come, they will not remain behind an hour, nor will they precede [it]"
  },
  {
    "id": 35,
    "text": "O children of Adam, if there come to you messengers from among you relating to you My verses, then whoever fears Allah and reforms - there will be no fear concerning them, nor will they grieve"
  },
  {
    "id": 36,
    "text": "But the ones who deny Our verses and are arrogant toward them - those are the companions of the Fire; they will abide therein eternally"
  },
  {
    "id": 37,
    "text": "And who is more unjust than one who invents about Allah a lie or denies His verses? Those will attain their portion of the decree until when Our messengers come to them to take them in death, they will say, \"Where are those you used to invoke besides Allah?\" They will say, \"They have departed from us,\" and will bear witness against themselves that they were disbelievers"
  },
  {
    "id": 38,
    "text": "[Allah] will say, \"Enter among nations which had passed on before you of jinn and mankind into the Fire.\" Every time a nation enters, it will curse its sister until, when they have all overtaken one another therein, the last of them will say about the first of them \"Our Lord, these had misled us, so give them a double punishment of the Fire. He will say, \"For each is double, but you do not know"
  },
  {
    "id": 39,
    "text": "And the first of them will say to the last of them, \"Then you had not any favor over us, so taste the punishment for what you used to earn"
  },
  {
    "id": 40,
    "text": "Indeed, those who deny Our verses and are arrogant toward them - the gates of Heaven will not be opened for them, nor will they enter Paradise until a camel enters into the eye of a needle. And thus do We recompense the criminals"
  },
  {
    "id": 41,
    "text": "They will have from Hell a bed and over them coverings [of fire]. And thus do We recompense the wrongdoers"
  },
  {
    "id": 42,
    "text": "But those who believed and did righteous deeds - We charge no soul except [within] its capacity. Those are the companions of Paradise; they will abide therein eternally"
  },
  {
    "id": 43,
    "text": "And We will have removed whatever is within their breasts of resentment, [while] flowing beneath them are rivers. And they will say, \"Praise to Allah, who has guided us to this; and we would never have been guided if Allah had not guided us. Certainly the messengers of our Lord had come with the truth.\" And they will be called, \"This is Paradise, which you have been made to inherit for what you used to do"
  },
  {
    "id": 44,
    "text": "And the companions of Paradise will call out to the companions of the Fire, \"We have already found what our Lord promised us to be true. Have you found what your Lord promised to be true?\" They will say, \"Yes.\" Then an announcer will announce among them, \"The curse of Allah shall be upon the wrongdoers"
  },
  {
    "id": 45,
    "text": "Who averted [people] from the way of Allah and sought to make it [seem] deviant while they were, concerning the Hereafter, disbelievers"
  },
  {
    "id": 46,
    "text": "And between them will be a partition, and on [its] elevations are men who recognize all by their mark. And they call out to the companions of Paradise, \"Peace be upon you.\" They have not [yet] entered it, but they long intensely"
  },
  {
    "id": 47,
    "text": "And when their eyes are turned toward the companions of the Fire, they say, \"Our Lord, do not place us with the wrongdoing people"
  },
  {
    "id": 48,
    "text": "And the companions of the Elevations will call to men [within Hell] whom they recognize by their mark, saying, \"Of no avail to you was your gathering and [the fact] that you were arrogant"
  },
  {
    "id": 49,
    "text": "[Allah will say], \"Are these the ones whom you [inhabitants of Hell] swore that Allah would never offer them mercy? Enter Paradise, [O People of the Elevations]. No fear will there be concerning you, nor will you grieve"
  },
  {
    "id": 50,
    "text": "And the companions of the Fire will call to the companions of Paradise, \"Pour upon us some water or from whatever Allah has provided you.\" They will say, \"Indeed, Allah has forbidden them both to the disbelievers"
  },
  {
    "id": 51,
    "text": "Who took their religion as distraction and amusement and whom the worldly life deluded.\" So today We will forget them just as they forgot the meeting of this Day of theirs and for having rejected Our verses"
  },
  {
    "id": 52,
    "text": "And We had certainly brought them a Book which We detailed by knowledge - as guidance and mercy to a people who believe"
  },
  {
    "id": 53,
    "text": "Do they await except its result? The Day its result comes those who had ignored it before will say, \"The messengers of our Lord had come with the truth, so are there [now] any intercessors to intercede for us or could we be sent back to do other than we used to do?\" They will have lost themselves, and lost from them is what they used to invent"
  },
  {
    "id": 54,
    "text": "Indeed, your Lord is Allah, who created the heavens and earth in six days and then established Himself above the Throne. He covers the night with the day, [another night] chasing it rapidly; and [He created] the sun, the moon, and the stars, subjected by His command. Unquestionably, His is the creation and the command; blessed is Allah, Lord of the worlds"
  },
  {
    "id": 55,
    "text": "Call upon your Lord in humility and privately; indeed, He does not like transgressors"
  },
  {
    "id": 56,
    "text": "And cause not corruption upon the earth after its reformation. And invoke Him in fear and aspiration. Indeed, the mercy of Allah is near to the doers of good"
  },
  {
    "id": 57,
    "text": "And it is He who sends the winds as good tidings before His mercy until, when they have carried heavy rainclouds, We drive them to a dead land and We send down rain therein and bring forth thereby [some] of all the fruits. Thus will We bring forth the dead; perhaps you may be reminded"
  },
  {
    "id": 58,
    "text": "And the good land - its vegetation emerges by permission of its Lord; but that which is bad - nothing emerges except sparsely, with difficulty. Thus do We diversify the signs for a people who are grateful"
  },
  {
    "id": 59,
    "text": "We had certainly sent Noah to his people, and he said, \"O my people, worship Allah; you have no deity other than Him. Indeed, I fear for you the punishment of a tremendous Day"
  },
  {
    "id": 60,
    "text": "Said the eminent among his people, \"Indeed, we see you in clear error"
  },
  {
    "id": 61,
    "text": "[Noah] said, \"O my people, there is not error in me, but I am a messenger from the Lord of the worlds"
  },
  {
    "id": 62,
    "text": "I convey to you the messages of my Lord and advise you; and I know from Allah what you do not know"
  },
  {
    "id": 63,
    "text": "Then do you wonder that there has come to you a reminder from your Lord through a man from among you, that he may warn you and that you may fear Allah so you might receive mercy"
  },
  {
    "id": 64,
    "text": "But they denied him, so We saved him and those who were with him in the ship. And We drowned those who denied Our signs. Indeed, they were a blind people"
  },
  {
    "id": 65,
    "text": "And to the 'Aad [We sent] their brother Hud. He said, \"O my people, worship Allah; you have no deity other than Him. Then will you not fear Him"
  },
  {
    "id": 66,
    "text": "Said the eminent ones who disbelieved among his people, \"Indeed, we see you in foolishness, and indeed, we think you are of the liars"
  },
  {
    "id": 67,
    "text": "[Hud] said, \"O my people, there is not foolishness in me, but I am a messenger from the Lord of the worlds"
  },
  {
    "id": 68,
    "text": "I convey to you the messages of my Lord, and I am to you a trustworthy adviser"
  },
  {
    "id": 69,
    "text": "Then do you wonder that there has come to you a reminder from your Lord through a man from among you, that he may warn you? And remember when He made you successors after the people of Noah and increased you in stature extensively. So remember the favors of Allah that you might succeed"
  },
  {
    "id": 70,
    "text": "They said, \"Have you come to us that we should worship Allah alone and leave what our fathers have worshipped? Then bring us what you promise us, if you should be of the truthful"
  },
  {
    "id": 71,
    "text": "[Hud] said, \"Already have defilement and anger fallen upon you from your Lord. Do you dispute with me concerning [mere] names you have named them, you and your fathers, for which Allah has not sent down any authority? Then wait; indeed, I am with you among those who wait"
  },
  {
    "id": 72,
    "text": "So We saved him and those with him by mercy from Us. And We eliminated those who denied Our signs, and they were not [at all] believers"
  },
  {
    "id": 73,
    "text": "And to the Thamud [We sent] their brother Salih. He said, \"O my people, worship Allah; you have no deity other than Him. There has come to you clear evidence from your Lord. This is the she-camel of Allah [sent] to you as a sign. So leave her to eat within Allah 's land and do not touch her with harm, lest there seize you a painful punishment"
  },
  {
    "id": 74,
    "text": "And remember when He made you successors after the 'Aad and settled you in the land, [and] you take for yourselves palaces from its plains and carve from the mountains, homes. Then remember the favors of Allah and do not commit abuse on the earth, spreading corruption"
  },
  {
    "id": 75,
    "text": "Said the eminent ones who were arrogant among his people to those who were oppressed - to those who believed among them, \"Do you [actually] know that Salih is sent from his Lord?\" They said, \"Indeed we, in that with which he was sent, are believers"
  },
  {
    "id": 76,
    "text": "Said those who were arrogant, \"Indeed we, in that which you have believed, are disbelievers"
  },
  {
    "id": 77,
    "text": "So they hamstrung the she-camel and were insolent toward the command of their Lord and said, \"O Salih, bring us what you promise us, if you should be of the messengers"
  },
  {
    "id": 78,
    "text": "So the earthquake seized them, and they became within their home [corpses] fallen prone"
  },
  {
    "id": 79,
    "text": "And he turned away from them and said, \"O my people, I had certainly conveyed to you the message of my Lord and advised you, but you do not like advisors"
  },
  {
    "id": 80,
    "text": "And [We had sent] Lot when he said to his people, \"Do you commit such immorality as no one has preceded you with from among the worlds"
  },
  {
    "id": 81,
    "text": "Indeed, you approach men with desire, instead of women. Rather, you are a transgressing people"
  },
  {
    "id": 82,
    "text": "But the answer of his people was only that they said, \"Evict them from your city! Indeed, they are men who keep themselves pure"
  },
  {
    "id": 83,
    "text": "So We saved him and his family, except for his wife; she was of those who remained [with the evildoers]"
  },
  {
    "id": 84,
    "text": "And We rained upon them a rain [of stones]. Then see how was the end of the criminals"
  },
  {
    "id": 85,
    "text": "And to [the people of] Madyan [We sent] their brother Shu'ayb. He said, \"O my people, worship Allah; you have no deity other than Him. There has come to you clear evidence from your Lord. So fulfill the measure and weight and do not deprive people of their due and cause not corruption upon the earth after its reformation. That is better for you, if you should be believers"
  },
  {
    "id": 86,
    "text": "And do not sit on every path, threatening and averting from the way of Allah those who believe in Him, seeking to make it [seem] deviant. And remember when you were few and He increased you. And see how was the end of the corrupters"
  },
  {
    "id": 87,
    "text": "And if there should be a group among you who has believed in that with which I have been sent and a group that has not believed, then be patient until Allah judges between us. And He is the best of judges"
  },
  {
    "id": 88,
    "text": "Said the eminent ones who were arrogant among his people, \"We will surely evict you, O Shu'ayb, and those who have believed with you from our city, or you must return to our religion.\" He said, \"Even if we were unwilling"
  },
  {
    "id": 89,
    "text": "We would have invented against Allah a lie if we returned to your religion after Allah had saved us from it. And it is not for us to return to it except that Allah, our Lord, should will. Our Lord has encompassed all things in knowledge. Upon Allah we have relied. Our Lord, decide between us and our people in truth, and You are the best of those who give decision"
  },
  {
    "id": 90,
    "text": "Said the eminent ones who disbelieved among his people, \"If you should follow Shu'ayb, indeed, you would then be losers"
  },
  {
    "id": 91,
    "text": "So the earthquake seized them, and they became within their home [corpses] fallen prone"
  },
  {
    "id": 92,
    "text": "Those who denied Shu'ayb - it was as though they had never resided there. Those who denied Shu'ayb - it was they who were the losers"
  },
  {
    "id": 93,
    "text": "And he turned away from them and said, \"O my people, I had certainly conveyed to you the messages of my Lord and advised you, so how could I grieve for a disbelieving people"
  },
  {
    "id": 94,
    "text": "And We sent to no city a prophet [who was denied] except that We seized its people with poverty and hardship that they might humble themselves [to Allah]"
  },
  {
    "id": 95,
    "text": "Then We exchanged in place of the bad [condition], good, until they increased [and prospered] and said, \"Our fathers [also] were touched with hardship and ease.\" So We seized them suddenly while they did not perceive"
  },
  {
    "id": 96,
    "text": "And if only the people of the cities had believed and feared Allah, We would have opened upon them blessings from the heaven and the earth; but they denied [the messengers], so We seized them for what they were earning"
  },
  {
    "id": 97,
    "text": "Then, did the people of the cities feel secure from Our punishment coming to them at night while they were asleep"
  },
  {
    "id": 98,
    "text": "Or did the people of the cities feel secure from Our punishment coming to them in the morning while they were at play"
  },
  {
    "id": 99,
    "text": "Then did they feel secure from the plan of Allah? But no one feels secure from the plan of Allah except the losing people"
  },
  {
    "id": 100,
    "text": "Has it not become clear to those who inherited the earth after its [previous] people that if We willed, We could afflict them for their sins? But We seal over their hearts so they do not hear"
  },
  {
    "id": 101,
    "text": "Those cities - We relate to you, [O Muhammad], some of their news. And certainly did their messengers come to them with clear proofs, but they were not to believe in that which they had denied before. Thus does Allah seal over the hearts of the disbelievers"
  },
  {
    "id": 102,
    "text": "And We did not find for most of them any covenant; but indeed, We found most of them defiantly disobedient"
  },
  {
    "id": 103,
    "text": "Then We sent after them Moses with Our signs to Pharaoh and his establishment, but they were unjust toward them. So see how was the end of the corrupters"
  },
  {
    "id": 104,
    "text": "And Moses said, \"O Pharaoh, I am a messenger from the Lord of the worlds"
  },
  {
    "id": 105,
    "text": "[Who is] obligated not to say about Allah except the truth. I have come to you with clear evidence from your Lord, so send with me the Children of Israel"
  },
  {
    "id": 106,
    "text": "[Pharaoh] said, \"If you have come with a sign, then bring it forth, if you should be of the truthful"
  },
  {
    "id": 107,
    "text": "So Moses threw his staff, and suddenly it was a serpent, manifest"
  },
  {
    "id": 108,
    "text": "And he drew out his hand; thereupon it was white [with radiance] for the observers"
  },
  {
    "id": 109,
    "text": "Said the eminent among the people of Pharaoh, \"Indeed, this is a learned magician"
  },
  {
    "id": 110,
    "text": "Who wants to expel you from your land [through magic], so what do you instruct"
  },
  {
    "id": 111,
    "text": "They said, \"Postpone [the matter of] him and his brother and send among the cities gatherers"
  },
  {
    "id": 112,
    "text": "Who will bring you every learned magician"
  },
  {
    "id": 113,
    "text": "And the magicians came to Pharaoh. They said, \"Indeed for us is a reward if we are the predominant"
  },
  {
    "id": 114,
    "text": "He said, \"Yes, and, [moreover], you will be among those made near [to me]"
  },
  {
    "id": 115,
    "text": "They said, \"O Moses, either you throw [your staff], or we will be the ones to throw [first]"
  },
  {
    "id": 116,
    "text": "He said, \"Throw,\" and when they threw, they bewitched the eyes of the people and struck terror into them, and they presented a great [feat of] magic"
  },
  {
    "id": 117,
    "text": "And We inspired to Moses, \"Throw your staff,\" and at once it devoured what they were falsifying"
  },
  {
    "id": 118,
    "text": "So the truth was established, and abolished was what they were doing"
  },
  {
    "id": 119,
    "text": "And Pharaoh and his people were overcome right there and became debased"
  },
  {
    "id": 120,
    "text": "And the magicians fell down in prostration [to Allah]"
  },
  {
    "id": 121,
    "text": "They said, \"We have believed in the Lord of the worlds"
  },
  {
    "id": 122,
    "text": "The Lord of Moses and Aaron"
  },
  {
    "id": 123,
    "text": "Said Pharaoh, \"You believed in him before I gave you permission. Indeed, this is a conspiracy which you conspired in the city to expel therefrom its people. But you are going to know"
  },
  {
    "id": 124,
    "text": "I will surely cut off your hands and your feet on opposite sides; then I will surely crucify you all"
  },
  {
    "id": 125,
    "text": "They said, \"Indeed, to our Lord we will return"
  },
  {
    "id": 126,
    "text": "And you do not resent us except because we believed in the signs of our Lord when they came to us. Our Lord, pour upon us patience and let us die as Muslims [in submission to You]"
  },
  {
    "id": 127,
    "text": "And the eminent among the people of Pharaoh said,\" Will you leave Moses and his people to cause corruption in the land and abandon you and your gods?\" [Pharaoh] said, \"We will kill their sons and keep their women alive; and indeed, we are subjugators over them"
  },
  {
    "id": 128,
    "text": "Said Moses to his people, \"Seek help through Allah and be patient. Indeed, the earth belongs to Allah. He causes to inherit it whom He wills of His servants. And the [best] outcome is for the righteous"
  },
  {
    "id": 129,
    "text": "They said, \"We have been harmed before you came to us and after you have come to us.\" He said, \"Perhaps your Lord will destroy your enemy and grant you succession in the land and see how you will do"
  },
  {
    "id": 130,
    "text": "And We certainly seized the people of Pharaoh with years of famine and a deficiency in fruits that perhaps they would be reminded"
  },
  {
    "id": 131,
    "text": "But when good came to them, they said, \"This is ours [by right].\" And if a bad [condition] struck them, they saw an evil omen in Moses and those with him. Unquestionably, their fortune is with Allah, but most of them do not know"
  },
  {
    "id": 132,
    "text": "And they said, \"No matter what sign you bring us with which to bewitch us, we will not be believers in you"
  },
  {
    "id": 133,
    "text": "So We sent upon them the flood and locusts and lice and frogs and blood as distinct signs, but they were arrogant and were a criminal people"
  },
  {
    "id": 134,
    "text": "And when the punishment descended upon them, they said, \"O Moses, invoke for us your Lord by what He has promised you. If you [can] remove the punishment from us, we will surely believe you, and we will send with you the Children of Israel"
  },
  {
    "id": 135,
    "text": "But when We removed the punishment from them until a term which they were to reach, then at once they broke their word"
  },
  {
    "id": 136,
    "text": "So We took retribution from them, and We drowned them in the sea because they denied Our signs and were heedless of them"
  },
  {
    "id": 137,
    "text": "And We caused the people who had been oppressed to inherit the eastern regions of the land and the western ones, which We had blessed. And the good word of your Lord was fulfilled for the Children of Israel because of what they had patiently endured. And We destroyed [all] that Pharaoh and his people were producing and what they had been building"
  },
  {
    "id": 138,
    "text": "And We took the Children of Israel across the sea; then they came upon a people intent in devotion to [some] idols of theirs. They said, \"O Moses, make for us a god just as they have gods.\" He said, \"Indeed, you are a people behaving ignorantly"
  },
  {
    "id": 139,
    "text": "Indeed, those [worshippers] - destroyed is that in which they are [engaged], and worthless is whatever they were doing"
  },
  {
    "id": 140,
    "text": "He said, \"Is it other than Allah I should desire for you as a god while He has preferred you over the worlds"
  },
  {
    "id": 141,
    "text": "And [recall, O Children of Israel], when We saved you from the people of Pharaoh, [who were] afflicting you with the worst torment - killing your sons and keeping your women alive. And in that was a great trial from your Lord"
  },
  {
    "id": 142,
    "text": "And We made an appointment with Moses for thirty nights and perfected them by [the addition of] ten; so the term of his Lord was completed as forty nights. And Moses said to his brother Aaron, \"Take my place among my people, do right [by them], and do not follow the way of the corrupters"
  },
  {
    "id": 143,
    "text": "And when Moses arrived at Our appointed time and his Lord spoke to him, he said, \"My Lord, show me [Yourself] that I may look at You.\" [Allah] said, \"You will not see Me, but look at the mountain; if it should remain in place, then you will see Me.\" But when his Lord appeared to the mountain, He rendered it level, and Moses fell unconscious. And when he awoke, he said, \"Exalted are You! I have repented to You, and I am the first of the believers"
  },
  {
    "id": 144,
    "text": "[Allah] said, \"O Moses, I have chosen you over the people with My messages and My words [to you]. So take what I have given you and be among the grateful"
  },
  {
    "id": 145,
    "text": "And We wrote for him on the tablets [something] of all things - instruction and explanation for all things, [saying], \"Take them with determination and order your people to take the best of it. I will show you the home of the defiantly disobedient"
  },
  {
    "id": 146,
    "text": "I will turn away from My signs those who are arrogant upon the earth without right; and if they should see every sign, they will not believe in it. And if they see the way of consciousness, they will not adopt it as a way; but if they see the way of error, they will adopt it as a way. That is because they have denied Our signs and they were heedless of them"
  },
  {
    "id": 147,
    "text": "Those who denied Our signs and the meeting of the Hereafter - their deeds have become worthless. Are they recompensed except for what they used to do"
  },
  {
    "id": 148,
    "text": "And the people of Moses made, after [his departure], from their ornaments a calf - an image having a lowing sound. Did they not see that it could neither speak to them nor guide them to a way? They took it [for worship], and they were wrongdoers"
  },
  {
    "id": 149,
    "text": "And when regret overcame them and they saw that they had gone astray, they said, \"If our Lord does not have mercy upon us and forgive us, we will surely be among the losers"
  },
  {
    "id": 150,
    "text": "And when Moses returned to his people, angry and grieved, he said, \"How wretched is that by which you have replaced me after [my departure]. Were you impatient over the matter of your Lord?\" And he threw down the tablets and seized his brother by [the hair of] his head, pulling him toward him. [Aaron] said, \"O son of my mother, indeed the people oppressed me and were about to kill me, so let not the enemies rejoice over me and do not place me among the wrongdoing people"
  },
  {
    "id": 151,
    "text": "[Moses] said, \"My Lord, forgive me and my brother and admit us into Your mercy, for You are the most merciful of the merciful"
  },
  {
    "id": 152,
    "text": "Indeed, those who took the calf [for worship] will obtain anger from their Lord and humiliation in the life of this world, and thus do We recompense the inventors [of falsehood]"
  },
  {
    "id": 153,
    "text": "But those who committed misdeeds and then repented after them and believed - indeed your Lord, thereafter, is Forgiving and Merciful"
  },
  {
    "id": 154,
    "text": "And when the anger subsided in Moses, he took up the tablets; and in their inscription was guidance and mercy for those who are fearful of their Lord"
  },
  {
    "id": 155,
    "text": "And Moses chose from his people seventy men for Our appointment. And when the earthquake seized them, he said, \"My Lord, if You had willed, You could have destroyed them before and me [as well]. Would You destroy us for what the foolish among us have done? This is not but Your trial by which You send astray whom You will and guide whom You will. You are our Protector, so forgive us and have mercy upon us; and You are the best of forgivers"
  },
  {
    "id": 156,
    "text": "And decree for us in this world [that which is] good and [also] in the Hereafter; indeed, we have turned back to You.\" [Allah] said, \"My punishment - I afflict with it whom I will, but My mercy encompasses all things.\" So I will decree it [especially] for those who fear Me and give zakah and those who believe in Our verses"
  },
  {
    "id": 157,
    "text": "Those who follow the Messenger, the unlettered prophet, whom they find written in what they have of the Torah and the Gospel, who enjoins upon them what is right and forbids them what is wrong and makes lawful for them the good things and prohibits for them the evil and relieves them of their burden and the shackles which were upon them. So they who have believed in him, honored him, supported him and followed the light which was sent down with him - it is those who will be the successful"
  },
  {
    "id": 158,
    "text": "Say, [O Muhammad], \"O mankind, indeed I am the Messenger of Allah to you all, [from Him] to whom belongs the dominion of the heavens and the earth. There is no deity except Him; He gives life and causes death.\" So believe in Allah and His Messenger, the unlettered prophet, who believes in Allah and His words, and follow him that you may be guided"
  },
  {
    "id": 159,
    "text": "And among the people of Moses is a community which guides by truth and by it establishes justice"
  },
  {
    "id": 160,
    "text": "And We divided them into twelve descendant tribes [as distinct] nations. And We inspired to Moses when his people implored him for water, \"Strike with your staff the stone,\" and there gushed forth from it twelve springs. Every people knew its watering place. And We shaded them with clouds and sent down upon them manna and quails, [saying], \"Eat from the good things with which We have provided you.\" And they wronged Us not, but they were [only] wronging themselves"
  },
  {
    "id": 161,
    "text": "And [mention, O Muhammad], when it was said to them, \"Dwell in this city and eat from it wherever you will and say, 'Relieve us of our burdens,' and enter the gate bowing humbly; We will [then] forgive you your sins. We will increase the doers of good [in goodness and reward]"
  },
  {
    "id": 162,
    "text": "But those who wronged among them changed [the words] to a statement other than that which had been said to them. So We sent upon them a punishment from the sky for the wrong that they were doing"
  },
  {
    "id": 163,
    "text": "And ask them about the town that was by the sea - when they transgressed in [the matter of] the sabbath - when their fish came to them openly on their sabbath day, and the day they had no sabbath they did not come to them. Thus did We give them trial because they were defiantly disobedient"
  },
  {
    "id": 164,
    "text": "And when a community among them said, \"Why do you advise [or warn] a people whom Allah is [about] to destroy or to punish with a severe punishment?\" they [the advisors] said, \"To be absolved before your Lord and perhaps they may fear Him"
  },
  {
    "id": 165,
    "text": "And when they forgot that by which they had been reminded, We saved those who had forbidden evil and seized those who wronged, with a wretched punishment, because they were defiantly disobeying"
  },
  {
    "id": 166,
    "text": "So when they were insolent about that which they had been forbidden, We said to them, \"Be apes, despised"
  },
  {
    "id": 167,
    "text": "And [mention] when your Lord declared that He would surely [continue to] send upon them until the Day of Resurrection those who would afflict them with the worst torment. Indeed, your Lord is swift in penalty; but indeed, He is Forgiving and Merciful"
  },
  {
    "id": 168,
    "text": "And We divided them throughout the earth into nations. Of them some were righteous, and of them some were otherwise. And We tested them with good [times] and bad that perhaps they would return [to obedience]"
  },
  {
    "id": 169,
    "text": "And there followed them successors who inherited the Scripture [while] taking the commodities of this lower life and saying, \"It will be forgiven for us.\" And if an offer like it comes to them, they will [again] take it. Was not the covenant of the Scripture taken from them that they would not say about Allah except the truth, and they studied what was in it? And the home of the Hereafter is better for those who fear Allah, so will you not use reason"
  },
  {
    "id": 170,
    "text": "But those who hold fast to the Book and establish prayer - indeed, We will not allow to be lost the reward of the reformers"
  },
  {
    "id": 171,
    "text": "And [mention] when We raised the mountain above them as if it was a dark cloud and they were certain that it would fall upon them, [and Allah said], \"Take what We have given you with determination and remember what is in it that you might fear Allah"
  },
  {
    "id": 172,
    "text": "And [mention] when your Lord took from the children of Adam - from their loins - their descendants and made them testify of themselves, [saying to them], \"Am I not your Lord?\" They said, \"Yes, we have testified.\" [This] - lest you should say on the day of Resurrection, \"Indeed, we were of this unaware"
  },
  {
    "id": 173,
    "text": "Or [lest] you say, \"It was only that our fathers associated [others in worship] with Allah before, and we were but descendants after them. Then would You destroy us for what the falsifiers have done"
  },
  {
    "id": 174,
    "text": "And thus do We [explain in] detail the verses, and perhaps they will return"
  },
  {
    "id": 175,
    "text": "And recite to them, [O Muhammad], the news of him to whom we gave [knowledge of] Our signs, but he detached himself from them; so Satan pursued him, and he became of the deviators"
  },
  {
    "id": 176,
    "text": "And if We had willed, we could have elevated him thereby, but he adhered [instead] to the earth and followed his own desire. So his example is like that of the dog: if you chase him, he pants, or if you leave him, he [still] pants. That is the example of the people who denied Our signs. So relate the stories that perhaps they will give thought"
  },
  {
    "id": 177,
    "text": "How evil an example [is that of] the people who denied Our signs and used to wrong themselves"
  },
  {
    "id": 178,
    "text": "Whoever Allah guides - he is the [rightly] guided; and whoever He sends astray - it is those who are the losers"
  },
  {
    "id": 179,
    "text": "And We have certainly created for Hell many of the jinn and mankind. They have hearts with which they do not understand, they have eyes with which they do not see, and they have ears with which they do not hear. Those are like livestock; rather, they are more astray. It is they who are the heedless"
  },
  {
    "id": 180,
    "text": "And to Allah belong the best names, so invoke Him by them. And leave [the company of] those who practice deviation concerning His names. They will be recompensed for what they have been doing"
  },
  {
    "id": 181,
    "text": "And among those We created is a community which guides by truth and thereby establishes justice"
  },
  {
    "id": 182,
    "text": "But those who deny Our signs - We will progressively lead them [to destruction] from where they do not know"
  },
  {
    "id": 183,
    "text": "And I will give them time. Indeed, my plan is firm"
  },
  {
    "id": 184,
    "text": "Then do they not give thought? There is in their companion [Muhammad] no madness. He is not but a clear warner"
  },
  {
    "id": 185,
    "text": "Do they not look into the realm of the heavens and the earth and everything that Allah has created and [think] that perhaps their appointed time has come near? So in what statement hereafter will they believe"
  },
  {
    "id": 186,
    "text": "Whoever Allah sends astray - there is no guide for him. And He leaves them in their transgression, wandering blindly"
  },
  {
    "id": 187,
    "text": "They ask you, [O Muhammad], about the Hour: when is its arrival? Say, \"Its knowledge is only with my Lord. None will reveal its time except Him. It lays heavily upon the heavens and the earth. It will not come upon you except unexpectedly.\" They ask you as if you are familiar with it. Say, \"Its knowledge is only with Allah, but most of the people do not know"
  },
  {
    "id": 188,
    "text": "Say, \"I hold not for myself [the power of] benefit or harm, except what Allah has willed. And if I knew the unseen, I could have acquired much wealth, and no harm would have touched me. I am not except a warner and a bringer of good tidings to a people who believe"
  },
  {
    "id": 189,
    "text": "It is He who created you from one soul and created from it its mate that he might dwell in security with her. And when he covers her, she carries a light burden and continues therein. And when it becomes heavy, they both invoke Allah, their Lord, \"If You should give us a good [child], we will surely be among the grateful"
  },
  {
    "id": 190,
    "text": "But when He gives them a good [child], they ascribe partners to Him concerning that which He has given them. Exalted is Allah above what they associate with Him"
  },
  {
    "id": 191,
    "text": "Do they associate with Him those who create nothing and they are [themselves] created"
  },
  {
    "id": 192,
    "text": "And the false deities are unable to [give] them help, nor can they help themselves"
  },
  {
    "id": 193,
    "text": "And if you [believers] invite them to guidance, they will not follow you. It is all the same for you whether you invite them or you are silent"
  },
  {
    "id": 194,
    "text": "Indeed, those you [polytheists] call upon besides Allah are servants like you. So call upon them and let them respond to you, if you should be truthful"
  },
  {
    "id": 195,
    "text": "Do they have feet by which they walk? Or do they have hands by which they strike? Or do they have eyes by which they see? Or do they have ears by which they hear? Say, [O Muhammad], \"Call your 'partners' and then conspire against me and give me no respite"
  },
  {
    "id": 196,
    "text": "Indeed, my protector is Allah, who has sent down the Book; and He is an ally to the righteous"
  },
  {
    "id": 197,
    "text": "And those you call upon besides Him are unable to help you, nor can they help themselves"
  },
  {
    "id": 198,
    "text": "And if you invite them to guidance, they do not hear; and you see them looking at you while they do not see"
  },
  {
    "id": 199,
    "text": "Take what is given freely, enjoin what is good, and turn away from the ignorant"
  },
  {
    "id": 200,
    "text": "And if an evil suggestion comes to you from Satan, then seek refuge in Allah. Indeed, He is Hearing and Knowing"
  },
  {
    "id": 201,
    "text": "Indeed, those who fear Allah - when an impulse touches them from Satan, they remember [Him] and at once they have insight"
  },
  {
    "id": 202,
    "text": "But their brothers - the devils increase them in error; then they do not stop short"
  },
  {
    "id": 203,
    "text": "And when you, [O Muhammad], do not bring them a sign, they say, \"Why have you not contrived it?\" Say, \"I only follow what is revealed to me from my Lord. This [Qur'an] is enlightenment from your Lord and guidance and mercy for a people who believe"
  },
  {
    "id": 204,
    "text": "So when the Qur'an is recited, then listen to it and pay attention that you may receive mercy"
  },
  {
    "id": 205,
    "text": "And remember your Lord within yourself in humility and in fear without being apparent in speech - in the mornings and the evenings. And do not be among the heedless"
  },
  {
    "id": 206,
    "text": "Indeed, those who are near your Lord are not prevented by arrogance from His worship, and they exalt Him, and to Him they prostrate"
  }
]

export default en
