import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "O you who have believed, do not put [yourselves] before Allah and His Messenger but fear Allah. Indeed, Allah is Hearing and Knowing"
  },
  {
    "id": 2,
    "text": "O you who have believed, do not raise your voices above the voice of the Prophet or be loud to him in speech like the loudness of some of you to others, lest your deeds become worthless while you perceive not"
  },
  {
    "id": 3,
    "text": "Indeed, those who lower their voices before the Messenger of Allah - they are the ones whose hearts Allah has tested for righteousness. For them is forgiveness and great reward"
  },
  {
    "id": 4,
    "text": "Indeed, those who call you, [O Muhammad], from behind the chambers - most of them do not use reason"
  },
  {
    "id": 5,
    "text": "And if they had been patient until you [could] come out to them, it would have been better for them. But Allah is Forgiving and Merciful"
  },
  {
    "id": 6,
    "text": "O you who have believed, if there comes to you a disobedient one with information, investigate, lest you harm a people out of ignorance and become, over what you have done, regretful"
  },
  {
    "id": 7,
    "text": "And know that among you is the Messenger of Allah. If he were to obey you in much of the matter, you would be in difficulty, but Allah has endeared to you the faith and has made it pleasing in your hearts and has made hateful to you disbelief, defiance and disobedience. Those are the [rightly] guided"
  },
  {
    "id": 8,
    "text": "[It is] as bounty from Allah and favor. And Allah is Knowing and Wise"
  },
  {
    "id": 9,
    "text": "And if two factions among the believers should fight, then make settlement between the two. But if one of them oppresses the other, then fight against the one that oppresses until it returns to the ordinance of Allah. And if it returns, then make settlement between them in justice and act justly. Indeed, Allah loves those who act justly"
  },
  {
    "id": 10,
    "text": "The believers are but brothers, so make settlement between your brothers. And fear Allah that you may receive mercy"
  },
  {
    "id": 11,
    "text": "O you who have believed, let not a people ridicule [another] people; perhaps they may be better than them; nor let women ridicule [other] women; perhaps they may be better than them. And do not insult one another and do not call each other by [offensive] nicknames. Wretched is the name of disobedience after [one's] faith. And whoever does not repent - then it is those who are the wrongdoers"
  },
  {
    "id": 12,
    "text": "O you who have believed, avoid much [negative] assumption. Indeed, some assumption is sin. And do not spy or backbite each other. Would one of you like to eat the flesh of his brother when dead? You would detest it. And fear Allah; indeed, Allah is Accepting of repentance and Merciful"
  },
  {
    "id": 13,
    "text": "O mankind, indeed We have created you from male and female and made you peoples and tribes that you may know one another. Indeed, the most noble of you in the sight of Allah is the most righteous of you. Indeed, Allah is Knowing and Acquainted"
  },
  {
    "id": 14,
    "text": "The bedouins say, \"We have believed.\" Say, \"You have not [yet] believed; but say [instead], 'We have submitted,' for faith has not yet entered your hearts. And if you obey Allah and His Messenger, He will not deprive you from your deeds of anything. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 15,
    "text": "The believers are only the ones who have believed in Allah and His Messenger and then doubt not but strive with their properties and their lives in the cause of Allah. It is those who are the truthful"
  },
  {
    "id": 16,
    "text": "Say, \"Would you acquaint Allah with your religion while Allah knows whatever is in the heavens and whatever is on the earth, and Allah is Knowing of all things"
  },
  {
    "id": 17,
    "text": "They consider it a favor to you that they have accepted Islam. Say, \"Do not consider your Islam a favor to me. Rather, Allah has conferred favor upon you that He has guided you to the faith, if you should be truthful"
  },
  {
    "id": 18,
    "text": "Indeed, Allah knows the unseen [aspects] of the heavens and the earth. And Allah is Seeing of what you do"
  }
]

export default en
