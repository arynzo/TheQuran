import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Whatever is in the heavens and earth exalts Allah, and He is the Exalted in Might, the Wise"
  },
  {
    "id": 2,
    "text": "His is the dominion of the heavens and earth. He gives life and causes death, and He is over all things competent"
  },
  {
    "id": 3,
    "text": "He is the First and the Last, the Ascendant and the Intimate, and He is, of all things, Knowing"
  },
  {
    "id": 4,
    "text": "It is He who created the heavens and earth in six days and then established Himself above the Throne. He knows what penetrates into the earth and what emerges from it and what descends from the heaven and what ascends therein; and He is with you wherever you are. And Allah, of what you do, is Seeing"
  },
  {
    "id": 5,
    "text": "His is the dominion of the heavens and earth. And to Allah are returned [all] matters"
  },
  {
    "id": 6,
    "text": "He causes the night to enter the day and causes the day to enter the night, and he is Knowing of that within the breasts"
  },
  {
    "id": 7,
    "text": "Believe in Allah and His Messenger and spend out of that in which He has made you successors. For those who have believed among you and spent, there will be a great reward"
  },
  {
    "id": 8,
    "text": "And why do you not believe in Allah while the Messenger invites you to believe in your Lord and He has taken your covenant, if you should [truly] be believers"
  },
  {
    "id": 9,
    "text": "It is He who sends down upon His Servant [Muhammad] verses of clear evidence that He may bring you out from darknesses into the light. And indeed, Allah is to you Kind and Merciful"
  },
  {
    "id": 10,
    "text": "And why do you not spend in the cause of Allah while to Allah belongs the heritage of the heavens and the earth? Not equal among you are those who spent before the conquest [of Makkah] and fought [and those who did so after it]. Those are greater in degree than they who spent afterwards and fought. But to all Allah has promised the best [reward]. And Allah, with what you do, is Acquainted"
  },
  {
    "id": 11,
    "text": "Who is it that would loan Allah a goodly loan so He will multiply it for him and he will have a noble reward"
  },
  {
    "id": 12,
    "text": "On the Day you see the believing men and believing women, their light proceeding before them and on their right, [it will be said], \"Your good tidings today are [of] gardens beneath which rivers flow, wherein you will abide eternally.\" That is what is the great attainment"
  },
  {
    "id": 13,
    "text": "On the [same] Day the hypocrite men and hypocrite women will say to those who believed, \"Wait for us that we may acquire some of your light.\" It will be said, \"Go back behind you and seek light.\" And a wall will be placed between them with a door, its interior containing mercy, but on the outside of it is torment"
  },
  {
    "id": 14,
    "text": "The hypocrites will call to the believers, \"Were we not with you?\" They will say, \"Yes, but you afflicted yourselves and awaited [misfortune for us] and doubted, and wishful thinking deluded you until there came the command of Allah. And the Deceiver deceived you concerning Allah"
  },
  {
    "id": 15,
    "text": "So today no ransom will be taken from you or from those who disbelieved. Your refuge is the Fire. It is most worthy of you, and wretched is the destination"
  },
  {
    "id": 16,
    "text": "Has the time not come for those who have believed that their hearts should become humbly submissive at the remembrance of Allah and what has come down of the truth? And let them not be like those who were given the Scripture before, and a long period passed over them, so their hearts hardened; and many of them are defiantly disobedient"
  },
  {
    "id": 17,
    "text": "Know that Allah gives life to the earth after its lifelessness. We have made clear to you the signs; perhaps you will understand"
  },
  {
    "id": 18,
    "text": "Indeed, the men who practice charity and the women who practice charity and [they who] have loaned Allah a goodly loan - it will be multiplied for them, and they will have a noble reward"
  },
  {
    "id": 19,
    "text": "And those who have believed in Allah and His messengers - those are [in the ranks of] the supporters of truth and the martyrs, with their Lord. For them is their reward and their light. But those who have disbelieved and denied Our verses - those are the companions of Hellfire"
  },
  {
    "id": 20,
    "text": "Know that the life of this world is but amusement and diversion and adornment and boasting to one another and competition in increase of wealth and children - like the example of a rain whose [resulting] plant growth pleases the tillers; then it dries and you see it turned yellow; then it becomes [scattered] debris. And in the Hereafter is severe punishment and forgiveness from Allah and approval. And what is the worldly life except the enjoyment of delusion"
  },
  {
    "id": 21,
    "text": "Race toward forgiveness from your Lord and a Garden whose width is like the width of the heavens and earth, prepared for those who believed in Allah and His messengers. That is the bounty of Allah which He gives to whom He wills, and Allah is the possessor of great bounty"
  },
  {
    "id": 22,
    "text": "No disaster strikes upon the earth or among yourselves except that it is in a register before We bring it into being - indeed that, for Allah, is easy"
  },
  {
    "id": 23,
    "text": "In order that you not despair over what has eluded you and not exult [in pride] over what He has given you. And Allah does not like everyone self-deluded and boastful"
  },
  {
    "id": 24,
    "text": "[Those] who are stingy and enjoin upon people stinginess. And whoever turns away - then indeed, Allah is the Free of need, the Praiseworthy"
  },
  {
    "id": 25,
    "text": "We have already sent Our messengers with clear evidences and sent down with them the Scripture and the balance that the people may maintain [their affairs] in justice. And We sent down iron, wherein is great military might and benefits for the people, and so that Allah may make evident those who support Him and His messengers unseen. Indeed, Allah is Powerful and Exalted in Might"
  },
  {
    "id": 26,
    "text": "And We have already sent Noah and Abraham and placed in their descendants prophethood and scripture; and among them is he who is guided, but many of them are defiantly disobedient"
  },
  {
    "id": 27,
    "text": "Then We sent following their footsteps Our messengers and followed [them] with Jesus, the son of Mary, and gave him the Gospel. And We placed in the hearts of those who followed him compassion and mercy and monasticism, which they innovated; We did not prescribe it for them except [that they did so] seeking the approval of Allah. But they did not observe it with due observance. So We gave the ones who believed among them their reward, but many of them are defiantly disobedient"
  },
  {
    "id": 28,
    "text": "O you who have believed, fear Allah and believe in His Messenger; He will [then] give you a double portion of His mercy and make for you a light by which you will walk and forgive you; and Allah is Forgiving and Merciful"
  },
  {
    "id": 29,
    "text": "[This is] so that the People of the Scripture may know that they are not able [to obtain] anything from the bounty of Allah and that [all] bounty is in the hand of Allah; He gives it to whom He wills. And Allah is the possessor of great bounty"
  }
]

export default en
