import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "[All] praise is [due] to Allah, Creator of the heavens and the earth, [who] made the angels messengers having wings, two or three or four. He increases in creation what He wills. Indeed, Allah is over all things competent"
  },
  {
    "id": 2,
    "text": "Whatever Allah grants to people of mercy - none can withhold it; and whatever He withholds - none can release it thereafter. And He is the Exalted in Might, the Wise"
  },
  {
    "id": 3,
    "text": "O mankind, remember the favor of Allah upon you. Is there any creator other than Allah who provides for you from the heaven and earth? There is no deity except Him, so how are you deluded"
  },
  {
    "id": 4,
    "text": "And if they deny you, [O Muhammad] - already were messengers denied before you. And to Allah are returned [all] matters"
  },
  {
    "id": 5,
    "text": "O mankind, indeed the promise of Allah is truth, so let not the worldly life delude you and be not deceived about Allah by the Deceiver"
  },
  {
    "id": 6,
    "text": "Indeed, Satan is an enemy to you; so take him as an enemy. He only invites his party to be among the companions of the Blaze"
  },
  {
    "id": 7,
    "text": "Those who disbelieve will have a severe punishment, and those who believe and do righteous deeds will have forgiveness and great reward"
  },
  {
    "id": 8,
    "text": "Then is one to whom the evil of his deed has been made attractive so he considers it good [like one rightly guided]? For indeed, Allah sends astray whom He wills and guides whom He wills. So do not let yourself perish over them in regret. Indeed, Allah is Knowing of what they do"
  },
  {
    "id": 9,
    "text": "And it is Allah who sends the winds, and they stir the clouds, and We drive them to a dead land and give life thereby to the earth after its lifelessness. Thus is the resurrection"
  },
  {
    "id": 10,
    "text": "Whoever desires honor [through power] - then to Allah belongs all honor. To Him ascends good speech, and righteous work raises it. But they who plot evil deeds will have a severe punishment, and the plotting of those - it will perish"
  },
  {
    "id": 11,
    "text": "And Allah created you from dust, then from a sperm-drop; then He made you mates. And no female conceives nor does she give birth except with His knowledge. And no aged person is granted [additional] life nor is his lifespan lessened but that it is in a register. Indeed, that for Allah is easy"
  },
  {
    "id": 12,
    "text": "And not alike are the two bodies of water. One is fresh and sweet, palatable for drinking, and one is salty and bitter. And from each you eat tender meat and extract ornaments which you wear, and you see the ships plowing through [them] that you might seek of His bounty; and perhaps you will be grateful"
  },
  {
    "id": 13,
    "text": "He causes the night to enter the day, and He causes the day to enter the night and has subjected the sun and the moon - each running [its course] for a specified term. That is Allah, your Lord; to Him belongs sovereignty. And those whom you invoke other than Him do not possess [as much as] the membrane of a date seed"
  },
  {
    "id": 14,
    "text": "If you invoke them, they do not hear your supplication; and if they heard, they would not respond to you. And on the Day of Resurrection they will deny your association. And none can inform you like [one] Acquainted [with all matters]"
  },
  {
    "id": 15,
    "text": "O mankind, you are those in need of Allah, while Allah is the Free of need, the Praiseworthy"
  },
  {
    "id": 16,
    "text": "If He wills, He can do away with you and bring forth a new creation"
  },
  {
    "id": 17,
    "text": "And that is for Allah not difficult"
  },
  {
    "id": 18,
    "text": "And no bearer of burdens will bear the burden of another. And if a heavily laden soul calls [another] to [carry some of] its load, nothing of it will be carried, even if he should be a close relative. You can only warn those who fear their Lord unseen and have established prayer. And whoever purifies himself only purifies himself for [the benefit of] his soul. And to Allah is the [final] destination"
  },
  {
    "id": 19,
    "text": "Not equal are the blind and the seeing"
  },
  {
    "id": 20,
    "text": "Nor are the darknesses and the light"
  },
  {
    "id": 21,
    "text": "Nor are the shade and the heat"
  },
  {
    "id": 22,
    "text": "And not equal are the living and the dead. Indeed, Allah causes to hear whom He wills, but you cannot make hear those in the graves"
  },
  {
    "id": 23,
    "text": "You, [O Muhammad], are not but a warner"
  },
  {
    "id": 24,
    "text": "Indeed, We have sent you with the truth as a bringer of good tidings and a warner. And there was no nation but that there had passed within it a warner"
  },
  {
    "id": 25,
    "text": "And if they deny you - then already have those before them denied. Their messengers came to them with clear proofs and written ordinances and with the enlightening Scripture"
  },
  {
    "id": 26,
    "text": "Then I seized the ones who disbelieved, and how [terrible] was My reproach"
  },
  {
    "id": 27,
    "text": "Do you not see that Allah sends down rain from the sky, and We produce thereby fruits of varying colors? And in the mountains are tracts, white and red of varying shades and [some] extremely black"
  },
  {
    "id": 28,
    "text": "And among people and moving creatures and grazing livestock are various colors similarly. Only those fear Allah, from among His servants, who have knowledge. Indeed, Allah is Exalted in Might and Forgiving"
  },
  {
    "id": 29,
    "text": "Indeed, those who recite the Book of Allah and establish prayer and spend [in His cause] out of what We have provided them, secretly and publicly, [can] expect a profit that will never perish"
  },
  {
    "id": 30,
    "text": "That He may give them in full their rewards and increase for them of His bounty. Indeed, He is Forgiving and Appreciative"
  },
  {
    "id": 31,
    "text": "And that which We have revealed to you, [O Muhammad], of the Book is the truth, confirming what was before it. Indeed, Allah, of His servants, is Acquainted and Seeing"
  },
  {
    "id": 32,
    "text": "Then we caused to inherit the Book those We have chosen of Our servants; and among them is he who wrongs himself, and among them is he who is moderate, and among them is he who is foremost in good deeds by permission of Allah. That [inheritance] is what is the great bounty"
  },
  {
    "id": 33,
    "text": "[For them are] gardens of perpetual residence which they will enter. They will be adorned therein with bracelets of gold and pearls, and their garments therein will be silk"
  },
  {
    "id": 34,
    "text": "And they will say, \"Praise to Allah, who has removed from us [all] sorrow. Indeed, our Lord is Forgiving and Appreciative"
  },
  {
    "id": 35,
    "text": "He who has settled us in the home of duration out of His bounty. There touches us not in it any fatigue, and there touches us not in it weariness [of mind]"
  },
  {
    "id": 36,
    "text": "And for those who disbelieve will be the fire of Hell. [Death] is not decreed for them so they may die, nor will its torment be lightened for them. Thus do we recompense every ungrateful one"
  },
  {
    "id": 37,
    "text": "And they will cry out therein, \"Our Lord, remove us; we will do righteousness - other than what we were doing!\" But did We not grant you life enough for whoever would remember therein to remember, and the warner had come to you? So taste [the punishment], for there is not for the wrongdoers any helper"
  },
  {
    "id": 38,
    "text": "Indeed, Allah is Knower of the unseen [aspects] of the heavens and earth. Indeed, He is Knowing of that within the breasts"
  },
  {
    "id": 39,
    "text": "It is He who has made you successors upon the earth. And whoever disbelieves - upon him will be [the consequence of] his disbelief. And the disbelief of the disbelievers does not increase them in the sight of their Lord except in hatred; and the disbelief of the disbelievers does not increase them except in loss"
  },
  {
    "id": 40,
    "text": "Say, \"Have you considered your 'partners' whom you invoke besides Allah? Show me what they have created from the earth, or have they partnership [with Him] in the heavens? Or have We given them a book so they are [standing] on evidence therefrom? [No], rather, the wrongdoers do not promise each other except delusion"
  },
  {
    "id": 41,
    "text": "Indeed, Allah holds the heavens and the earth, lest they cease. And if they should cease, no one could hold them [in place] after Him. Indeed, He is Forbearing and Forgiving"
  },
  {
    "id": 42,
    "text": "And they swore by Allah their strongest oaths that if a warner came to them, they would be more guided than [any] one of the [previous] nations. But when a warner came to them, it did not increase them except in aversion"
  },
  {
    "id": 43,
    "text": "[Due to] arrogance in the land and plotting of evil; but the evil plot does not encompass except its own people. Then do they await except the way of the former peoples? But you will never find in the way of Allah any change, and you will never find in the way of Allah any alteration"
  },
  {
    "id": 44,
    "text": "Have they not traveled through the land and observed how was the end of those before them? And they were greater than them in power. But Allah is not to be caused failure by anything in the heavens or on the earth. Indeed, He is ever Knowing and Competent"
  },
  {
    "id": 45,
    "text": "And if Allah were to impose blame on the people for what they have earned, He would not leave upon the earth any creature. But He defers them for a specified term. And when their time comes, then indeed Allah has ever been, of His servants, Seeing"
  }
]

export default en
