import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Those who disbelieve and avert [people] from the way of Allah - He will waste their deeds"
  },
  {
    "id": 2,
    "text": "And those who believe and do righteous deeds and believe in what has been sent down upon Muhammad - and it is the truth from their Lord - He will remove from them their misdeeds and amend their condition"
  },
  {
    "id": 3,
    "text": "That is because those who disbelieve follow falsehood, and those who believe follow the truth from their Lord. Thus does Allah present to the people their comparisons"
  },
  {
    "id": 4,
    "text": "So when you meet those who disbelieve [in battle], strike [their] necks until, when you have inflicted slaughter upon them, then secure their bonds, and either [confer] favor afterwards or ransom [them] until the war lays down its burdens. That [is the command]. And if Allah had willed, He could have taken vengeance upon them [Himself], but [He ordered armed struggle] to test some of you by means of others. And those who are killed in the cause of Allah - never will He waste their deeds"
  },
  {
    "id": 5,
    "text": "He will guide them and amend their condition"
  },
  {
    "id": 6,
    "text": "And admit them to Paradise, which He has made known to them"
  },
  {
    "id": 7,
    "text": "O you who have believed, if you support Allah, He will support you and plant firmly your feet"
  },
  {
    "id": 8,
    "text": "But those who disbelieve - for them is misery, and He will waste their deeds"
  },
  {
    "id": 9,
    "text": "That is because they disliked what Allah revealed, so He rendered worthless their deeds"
  },
  {
    "id": 10,
    "text": "Have they not traveled through the land and seen how was the end of those before them? Allah destroyed [everything] over them, and for the disbelievers is something comparable"
  },
  {
    "id": 11,
    "text": "That is because Allah is the protector of those who have believed and because the disbelievers have no protector"
  },
  {
    "id": 12,
    "text": "Indeed, Allah will admit those who have believed and done righteous deeds to gardens beneath which rivers flow, but those who disbelieve enjoy themselves and eat as grazing livestock eat, and the Fire will be a residence for them"
  },
  {
    "id": 13,
    "text": "And how many a city was stronger than your city [Makkah] which drove you out? We destroyed them; and there was no helper for them"
  },
  {
    "id": 14,
    "text": "So is he who is on clear evidence from his Lord like him to whom the evil of his work has been made attractive and they follow their [own] desires"
  },
  {
    "id": 15,
    "text": "Is the description of Paradise, which the righteous are promised, wherein are rivers of water unaltered, rivers of milk the taste of which never changes, rivers of wine delicious to those who drink, and rivers of purified honey, in which they will have from all [kinds of] fruits and forgiveness from their Lord, like [that of] those who abide eternally in the Fire and are given to drink scalding water that will sever their intestines"
  },
  {
    "id": 16,
    "text": "And among them, [O Muhammad], are those who listen to you, until when they depart from you, they say to those who were given knowledge, \"What has he said just now?\" Those are the ones of whom Allah has sealed over their hearts and who have followed their [own] desires"
  },
  {
    "id": 17,
    "text": "And those who are guided - He increases them in guidance and gives them their righteousness"
  },
  {
    "id": 18,
    "text": "Then do they await except that the Hour should come upon them unexpectedly? But already there have come [some of] its indications. Then what good to them, when it has come, will be their remembrance"
  },
  {
    "id": 19,
    "text": "So know, [O Muhammad], that there is no deity except Allah and ask forgiveness for your sin and for the believing men and believing women. And Allah knows of your movement and your resting place"
  },
  {
    "id": 20,
    "text": "Those who believe say, \"Why has a surah not been sent down? But when a precise surah is revealed and fighting is mentioned therein, you see those in whose hearts is hypocrisy looking at you with a look of one overcome by death. And more appropriate for them [would have been]"
  },
  {
    "id": 21,
    "text": "Obedience and good words. And when the matter [of fighting] was determined, if they had been true to Allah, it would have been better for them"
  },
  {
    "id": 22,
    "text": "So would you perhaps, if you turned away, cause corruption on earth and sever your [ties of] relationship"
  },
  {
    "id": 23,
    "text": "Those [who do so] are the ones that Allah has cursed, so He deafened them and blinded their vision"
  },
  {
    "id": 24,
    "text": "Then do they not reflect upon the Qur'an, or are there locks upon [their] hearts"
  },
  {
    "id": 25,
    "text": "Indeed, those who reverted back [to disbelief] after guidance had become clear to them - Satan enticed them and prolonged hope for them"
  },
  {
    "id": 26,
    "text": "That is because they said to those who disliked what Allah sent down, \"We will obey you in part of the matter.\" And Allah knows what they conceal"
  },
  {
    "id": 27,
    "text": "Then how [will it be] when the angels take them in death, striking their faces and their backs"
  },
  {
    "id": 28,
    "text": "That is because they followed what angered Allah and disliked [what earns] His pleasure, so He rendered worthless their deeds"
  },
  {
    "id": 29,
    "text": "Or do those in whose hearts is disease think that Allah would never expose their [feelings of] hatred"
  },
  {
    "id": 30,
    "text": "And if We willed, We could show them to you, and you would know them by their mark; but you will surely know them by the tone of [their] speech. And Allah knows your deeds"
  },
  {
    "id": 31,
    "text": "And We will surely test you until We make evident those who strive among you [for the cause of Allah] and the patient, and We will test your affairs"
  },
  {
    "id": 32,
    "text": "Indeed, those who disbelieved and averted [people] from the path of Allah and opposed the Messenger after guidance had become clear to them - never will they harm Allah at all, and He will render worthless their deeds"
  },
  {
    "id": 33,
    "text": "O you who have believed, obey Allah and obey the Messenger and do not invalidate your deeds"
  },
  {
    "id": 34,
    "text": "Indeed, those who disbelieved and averted [people] from the path of Allah and then died while they were disbelievers - never will Allah forgive them"
  },
  {
    "id": 35,
    "text": "So do not weaken and call for peace while you are superior; and Allah is with you and will never deprive you of [the reward of] your deeds"
  },
  {
    "id": 36,
    "text": "[This] worldly life is only amusement and diversion. And if you believe and fear Allah, He will give you your rewards and not ask you for your properties"
  },
  {
    "id": 37,
    "text": "If He should ask you for them and press you, you would withhold, and He would expose your unwillingness"
  },
  {
    "id": 38,
    "text": "Here you are - those invited to spend in the cause of Allah - but among you are those who withhold [out of greed]. And whoever withholds only withholds [benefit] from himself; and Allah is the Free of need, while you are the needy. And if you turn away, He will replace you with another people; then they will not be the likes of you"
  }
]

export default en
