import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "O mankind, fear your Lord, who created you from one soul and created from it its mate and dispersed from both of them many men and women. And fear Allah, through whom you ask one another, and the wombs. Indeed Allah is ever, over you, an Observer"
  },
  {
    "id": 2,
    "text": "And give to the orphans their properties and do not substitute the defective [of your own] for the good [of theirs]. And do not consume their properties into your own. Indeed, that is ever a great sin"
  },
  {
    "id": 3,
    "text": "And if you fear that you will not deal justly with the orphan girls, then marry those that please you of [other] women, two or three or four. But if you fear that you will not be just, then [marry only] one or those your right hand possesses. That is more suitable that you may not incline [to injustice]"
  },
  {
    "id": 4,
    "text": "And give the women [upon marriage] their [bridal] gifts graciously. But if they give up willingly to you anything of it, then take it in satisfaction and ease"
  },
  {
    "id": 5,
    "text": "And do not give the weak-minded your property, which Allah has made a means of sustenance for you, but provide for them with it and clothe them and speak to them words of appropriate kindness"
  },
  {
    "id": 6,
    "text": "And test the orphans [in their abilities] until they reach marriageable age. Then if you perceive in them sound judgement, release their property to them. And do not consume it excessively and quickly, [anticipating] that they will grow up. And whoever, [when acting as guardian], is self-sufficient should refrain [from taking a fee]; and whoever is poor - let him take according to what is acceptable. Then when you release their property to them, bring witnesses upon them. And sufficient is Allah as Accountant"
  },
  {
    "id": 7,
    "text": "For men is a share of what the parents and close relatives leave, and for women is a share of what the parents and close relatives leave, be it little or much - an obligatory share"
  },
  {
    "id": 8,
    "text": "And when [other] relatives and orphans and the needy are present at the [time of] division, then provide for them [something] out of the estate and speak to them words of appropriate kindness"
  },
  {
    "id": 9,
    "text": "And let those [executors and guardians] fear [injustice] as if they [themselves] had left weak offspring behind and feared for them. So let them fear Allah and speak words of appropriate justice"
  },
  {
    "id": 10,
    "text": "Indeed, those who devour the property of orphans unjustly are only consuming into their bellies fire. And they will be burned in a Blaze"
  },
  {
    "id": 11,
    "text": "Allah instructs you concerning your children: for the male, what is equal to the share of two females. But if there are [only] daughters, two or more, for them is two thirds of one's estate. And if there is only one, for her is half. And for one's parents, to each one of them is a sixth of his estate if he left children. But if he had no children and the parents [alone] inherit from him, then for his mother is one third. And if he had brothers [or sisters], for his mother is a sixth, after any bequest he [may have] made or debt. Your parents or your children - you know not which of them are nearest to you in benefit. [These shares are] an obligation [imposed] by Allah. Indeed, Allah is ever Knowing and Wise"
  },
  {
    "id": 12,
    "text": "And for you is half of what your wives leave if they have no child. But if they have a child, for you is one fourth of what they leave, after any bequest they [may have] made or debt. And for the wives is one fourth if you leave no child. But if you leave a child, then for them is an eighth of what you leave, after any bequest you [may have] made or debt. And if a man or woman leaves neither ascendants nor descendants but has a brother or a sister, then for each one of them is a sixth. But if they are more than two, they share a third, after any bequest which was made or debt, as long as there is no detriment [caused]. [This is] an ordinance from Allah, and Allah is Knowing and Forbearing"
  },
  {
    "id": 13,
    "text": "These are the limits [set by] Allah, and whoever obeys Allah and His Messenger will be admitted by Him to gardens [in Paradise] under which rivers flow, abiding eternally therein; and that is the great attainment"
  },
  {
    "id": 14,
    "text": "And whoever disobeys Allah and His Messenger and transgresses His limits - He will put him into the Fire to abide eternally therein, and he will have a humiliating punishment"
  },
  {
    "id": 15,
    "text": "Those who commit unlawful sexual intercourse of your women - bring against them four [witnesses] from among you. And if they testify, confine the guilty women to houses until death takes them or Allah ordains for them [another] way"
  },
  {
    "id": 16,
    "text": "And the two who commit it among you, dishonor them both. But if they repent and correct themselves, leave them alone. Indeed, Allah is ever Accepting of repentance and Merciful"
  },
  {
    "id": 17,
    "text": "The repentance accepted by Allah is only for those who do wrong in ignorance [or carelessness] and then repent soon after. It is those to whom Allah will turn in forgiveness, and Allah is ever Knowing and Wise"
  },
  {
    "id": 18,
    "text": "But repentance is not [accepted] of those who [continue to] do evil deeds up until, when death comes to one of them, he says, \"Indeed, I have repented now,\" or of those who die while they are disbelievers. For them We have prepared a painful punishment"
  },
  {
    "id": 19,
    "text": "O you who have believed, it is not lawful for you to inherit women by compulsion. And do not make difficulties for them in order to take [back] part of what you gave them unless they commit a clear immorality. And live with them in kindness. For if you dislike them - perhaps you dislike a thing and Allah makes therein much good"
  },
  {
    "id": 20,
    "text": "But if you want to replace one wife with another and you have given one of them a great amount [in gifts], do not take [back] from it anything. Would you take it in injustice and manifest sin"
  },
  {
    "id": 21,
    "text": "And how could you take it while you have gone in unto each other and they have taken from you a solemn covenant"
  },
  {
    "id": 22,
    "text": "And do not marry those [women] whom your fathers married, except what has already occurred. Indeed, it was an immorality and hateful [to Allah] and was evil as a way"
  },
  {
    "id": 23,
    "text": "Prohibited to you [for marriage] are your mothers, your daughters, your sisters, your father's sisters, your mother's sisters, your brother's daughters, your sister's daughters, your [milk] mothers who nursed you, your sisters through nursing, your wives' mothers, and your step-daughters under your guardianship [born] of your wives unto whom you have gone in. But if you have not gone in unto them, there is no sin upon you. And [also prohibited are] the wives of your sons who are from your [own] loins, and that you take [in marriage] two sisters simultaneously, except for what has already occurred. Indeed, Allah is ever Forgiving and Merciful"
  },
  {
    "id": 24,
    "text": "And [also prohibited to you are all] married women except those your right hands possess. [This is] the decree of Allah upon you. And lawful to you are [all others] beyond these, [provided] that you seek them [in marriage] with [gifts from] your property, desiring chastity, not unlawful sexual intercourse. So for whatever you enjoy [of marriage] from them, give them their due compensation as an obligation. And there is no blame upon you for what you mutually agree to beyond the obligation. Indeed, Allah is ever Knowing and Wise"
  },
  {
    "id": 25,
    "text": "And whoever among you cannot [find] the means to marry free, believing women, then [he may marry] from those whom your right hands possess of believing slave girls. And Allah is most knowing about your faith. You [believers] are of one another. So marry them with the permission of their people and give them their due compensation according to what is acceptable. [They should be] chaste, neither [of] those who commit unlawful intercourse randomly nor those who take [secret] lovers. But once they are sheltered in marriage, if they should commit adultery, then for them is half the punishment for free [unmarried] women. This [allowance] is for him among you who fears sin, but to be patient is better for you. And Allah is Forgiving and Merciful"
  },
  {
    "id": 26,
    "text": "Allah wants to make clear to you [the lawful from the unlawful] and guide you to the [good] practices of those before you and to accept your repentance. And Allah is Knowing and Wise"
  },
  {
    "id": 27,
    "text": "Allah wants to accept your repentance, but those who follow [their] passions want you to digress [into] a great deviation"
  },
  {
    "id": 28,
    "text": "And Allah wants to lighten for you [your difficulties]; and mankind was created weak"
  },
  {
    "id": 29,
    "text": "O you who have believed, do not consume one another's wealth unjustly but only [in lawful] business by mutual consent. And do not kill yourselves [or one another]. Indeed, Allah is to you ever Merciful"
  },
  {
    "id": 30,
    "text": "And whoever does that in aggression and injustice - then We will drive him into a Fire. And that, for Allah, is [always] easy"
  },
  {
    "id": 31,
    "text": "If you avoid the major sins which you are forbidden, We will remove from you your lesser sins and admit you to a noble entrance [into Paradise]"
  },
  {
    "id": 32,
    "text": "And do not wish for that by which Allah has made some of you exceed others. For men is a share of what they have earned, and for women is a share of what they have earned. And ask Allah of his bounty. Indeed Allah is ever, of all things, Knowing"
  },
  {
    "id": 33,
    "text": "And for all, We have made heirs to what is left by parents and relatives. And to those whom your oaths have bound [to you] - give them their share. Indeed Allah is ever, over all things, a Witness"
  },
  {
    "id": 34,
    "text": "Men are in charge of women by [right of] what Allah has given one over the other and what they spend [for maintenance] from their wealth. So righteous women are devoutly obedient, guarding in [the husband's] absence what Allah would have them guard. But those [wives] from whom you fear arrogance - [first] advise them; [then if they persist], forsake them in bed; and [finally], strike them. But if they obey you [once more], seek no means against them. Indeed, Allah is ever Exalted and Grand"
  },
  {
    "id": 35,
    "text": "And if you fear dissension between the two, send an arbitrator from his people and an arbitrator from her people. If they both desire reconciliation, Allah will cause it between them. Indeed, Allah is ever Knowing and Acquainted [with all things]"
  },
  {
    "id": 36,
    "text": "Worship Allah and associate nothing with Him, and to parents do good, and to relatives, orphans, the needy, the near neighbor, the neighbor farther away, the companion at your side, the traveler, and those whom your right hands possess. Indeed, Allah does not like those who are self-deluding and boastful"
  },
  {
    "id": 37,
    "text": "Who are stingy and enjoin upon [other] people stinginess and conceal what Allah has given them of His bounty - and We have prepared for the disbelievers a humiliating punishment"
  },
  {
    "id": 38,
    "text": "And [also] those who spend of their wealth to be seen by the people and believe not in Allah nor in the Last Day. And he to whom Satan is a companion - then evil is he as a companion"
  },
  {
    "id": 39,
    "text": "And what [harm would come] upon them if they believed in Allah and the Last Day and spent out of what Allah provided for them? And Allah is ever, about them, Knowing"
  },
  {
    "id": 40,
    "text": "Indeed, Allah does not do injustice, [even] as much as an atom's weight; while if there is a good deed, He multiplies it and gives from Himself a great reward"
  },
  {
    "id": 41,
    "text": "So how [will it be] when We bring from every nation a witness and we bring you, [O Muhammad] against these [people] as a witness"
  },
  {
    "id": 42,
    "text": "That Day, those who disbelieved and disobeyed the Messenger will wish they could be covered by the earth. And they will not conceal from Allah a [single] statement"
  },
  {
    "id": 43,
    "text": "O you who have believed, do not approach prayer while you are intoxicated until you know what you are saying or in a state of janabah, except those passing through [a place of prayer], until you have washed [your whole body]. And if you are ill or on a journey or one of you comes from the place of relieving himself or you have contacted women and find no water, then seek clean earth and wipe over your faces and your hands [with it]. Indeed, Allah is ever Pardoning and Forgiving"
  },
  {
    "id": 44,
    "text": "Have you not seen those who were given a portion of the Scripture, purchasing error [in exchange for it] and wishing you would lose the way"
  },
  {
    "id": 45,
    "text": "And Allah is most knowing of your enemies; and sufficient is Allah as an ally, and sufficient is Allah as a helper"
  },
  {
    "id": 46,
    "text": "Among the Jews are those who distort words from their [proper] usages and say, \"We hear and disobey\" and \"Hear but be not heard\" and \"Ra'ina,\" twisting their tongues and defaming the religion. And if they had said [instead], \"We hear and obey\" and \"Wait for us [to understand],\" it would have been better for them and more suitable. But Allah has cursed them for their disbelief, so they believe not, except for a few"
  },
  {
    "id": 47,
    "text": "O you who were given the Scripture, believe in what We have sent down [to Muhammad], confirming that which is with you, before We obliterate faces and turn them toward their backs or curse them as We cursed the sabbath-breakers. And ever is the decree of Allah accomplished"
  },
  {
    "id": 48,
    "text": "Indeed, Allah does not forgive association with Him, but He forgives what is less than that for whom He wills. And he who associates others with Allah has certainly fabricated a tremendous sin"
  },
  {
    "id": 49,
    "text": "Have you not seen those who claim themselves to be pure? Rather, Allah purifies whom He wills, and injustice is not done to them, [even] as much as a thread [inside a date seed]"
  },
  {
    "id": 50,
    "text": "Look how they invent about Allah untruth, and sufficient is that as a manifest sin"
  },
  {
    "id": 51,
    "text": "Have you not seen those who were given a portion of the Scripture, who believe in superstition and false objects of worship and say about the disbelievers, \"These are better guided than the believers as to the way"
  },
  {
    "id": 52,
    "text": "Those are the ones whom Allah has cursed; and he whom Allah curses - never will you find for him a helper"
  },
  {
    "id": 53,
    "text": "Or have they a share of dominion? Then [if that were so], they would not give the people [even as much as] the speck on a date seed"
  },
  {
    "id": 54,
    "text": "Or do they envy people for what Allah has given them of His bounty? But we had already given the family of Abraham the Scripture and wisdom and conferred upon them a great kingdom"
  },
  {
    "id": 55,
    "text": "And some among them believed in it, and some among them were averse to it. And sufficient is Hell as a blaze"
  },
  {
    "id": 56,
    "text": "Indeed, those who disbelieve in Our verses - We will drive them into a Fire. Every time their skins are roasted through We will replace them with other skins so they may taste the punishment. Indeed, Allah is ever Exalted in Might and Wise"
  },
  {
    "id": 57,
    "text": "But those who believe and do righteous deeds - We will admit them to gardens beneath which rivers flow, wherein they abide forever. For them therein are purified spouses, and We will admit them to deepening shade"
  },
  {
    "id": 58,
    "text": "Indeed, Allah commands you to render trusts to whom they are due and when you judge between people to judge with justice. Excellent is that which Allah instructs you. Indeed, Allah is ever Hearing and Seeing"
  },
  {
    "id": 59,
    "text": "O you who have believed, obey Allah and obey the Messenger and those in authority among you. And if you disagree over anything, refer it to Allah and the Messenger, if you should believe in Allah and the Last Day. That is the best [way] and best in result"
  },
  {
    "id": 60,
    "text": "Have you not seen those who claim to have believed in what was revealed to you, [O Muhammad], and what was revealed before you? They wish to refer legislation to Taghut, while they were commanded to reject it; and Satan wishes to lead them far astray"
  },
  {
    "id": 61,
    "text": "And when it is said to them, \"Come to what Allah has revealed and to the Messenger,\" you see the hypocrites turning away from you in aversion"
  },
  {
    "id": 62,
    "text": "So how [will it be] when disaster strikes them because of what their hands have put forth and then they come to you swearing by Allah, \"We intended nothing but good conduct and accommodation"
  },
  {
    "id": 63,
    "text": "Those are the ones of whom Allah knows what is in their hearts, so turn away from them but admonish them and speak to them a far-reaching word"
  },
  {
    "id": 64,
    "text": "And We did not send any messenger except to be obeyed by permission of Allah. And if, when they wronged themselves, they had come to you, [O Muhammad], and asked forgiveness of Allah and the Messenger had asked forgiveness for them, they would have found Allah Accepting of repentance and Merciful"
  },
  {
    "id": 65,
    "text": "But no, by your Lord, they will not [truly] believe until they make you, [O Muhammad], judge concerning that over which they dispute among themselves and then find within themselves no discomfort from what you have judged and submit in [full, willing] submission"
  },
  {
    "id": 66,
    "text": "And if We had decreed upon them, \"Kill yourselves\" or \"Leave your homes,\" they would not have done it, except for a few of them. But if they had done what they were instructed, it would have been better for them and a firmer position [for them in faith]"
  },
  {
    "id": 67,
    "text": "And then We would have given them from Us a great reward"
  },
  {
    "id": 68,
    "text": "And We would have guided them to a straight path"
  },
  {
    "id": 69,
    "text": "And whoever obeys Allah and the Messenger - those will be with the ones upon whom Allah has bestowed favor of the prophets, the steadfast affirmers of truth, the martyrs and the righteous. And excellent are those as companions"
  },
  {
    "id": 70,
    "text": "That is the bounty from Allah, and sufficient is Allah as Knower"
  },
  {
    "id": 71,
    "text": "O you who have believed, take your precaution and [either] go forth in companies or go forth all together"
  },
  {
    "id": 72,
    "text": "And indeed, there is among you he who lingers behind; and if disaster strikes you, he says, \"Allah has favored me in that I was not present with them"
  },
  {
    "id": 73,
    "text": "But if bounty comes to you from Allah, he will surely say, as if there had never been between you and him any affection. \"Oh, I wish I had been with them so I could have attained a great attainment"
  },
  {
    "id": 74,
    "text": "So let those fight in the cause of Allah who sell the life of this world for the Hereafter. And he who fights in the cause of Allah and is killed or achieves victory - We will bestow upon him a great reward"
  },
  {
    "id": 75,
    "text": "And what is [the matter] with you that you fight not in the cause of Allah and [for] the oppressed among men, women, and children who say, \"Our Lord, take us out of this city of oppressive people and appoint for us from Yourself a protector and appoint for us from Yourself a helper"
  },
  {
    "id": 76,
    "text": "Those who believe fight in the cause of Allah, and those who disbelieve fight in the cause of Taghut. So fight against the allies of Satan. Indeed, the plot of Satan has ever been weak"
  },
  {
    "id": 77,
    "text": "Have you not seen those who were told, \"Restrain your hands [from fighting] and establish prayer and give zakah\"? But then when fighting was ordained for them, at once a party of them feared men as they fear Allah or with [even] greater fear. They said, \"Our Lord, why have You decreed upon us fighting? If only You had postponed [it for] us for a short time.\" Say, The enjoyment of this world is little, and the Hereafter is better for he who fears Allah. And injustice will not be done to you, [even] as much as a thread [inside a date seed]"
  },
  {
    "id": 78,
    "text": "Wherever you may be, death will overtake you, even if you should be within towers of lofty construction. But if good comes to them, they say, \"This is from Allah \"; and if evil befalls them, they say, \"This is from you.\" Say, \"All [things] are from Allah.\" So what is [the matter] with those people that they can hardly understand any statement"
  },
  {
    "id": 79,
    "text": "What comes to you of good is from Allah, but what comes to you of evil, [O man], is from yourself. And We have sent you, [O Muhammad], to the people as a messenger, and sufficient is Allah as Witness"
  },
  {
    "id": 80,
    "text": "He who obeys the Messenger has obeyed Allah; but those who turn away - We have not sent you over them as a guardian"
  },
  {
    "id": 81,
    "text": "And they say, \"[We pledge] obedience.\" But when they leave you, a group of them spend the night determining to do other than what you say. But Allah records what they plan by night. So leave them alone and rely upon Allah. And sufficient is Allah as Disposer of affairs"
  },
  {
    "id": 82,
    "text": "Then do they not reflect upon the Qur'an? If it had been from [any] other than Allah, they would have found within it much contradiction"
  },
  {
    "id": 83,
    "text": "And when there comes to them information about [public] security or fear, they spread it around. But if they had referred it back to the Messenger or to those of authority among them, then the ones who [can] draw correct conclusions from it would have known about it. And if not for the favor of Allah upon you and His mercy, you would have followed Satan, except for a few"
  },
  {
    "id": 84,
    "text": "So fight, [O Muhammad], in the cause of Allah; you are not held responsible except for yourself. And encourage the believers [to join you] that perhaps Allah will restrain the [military] might of those who disbelieve. And Allah is greater in might and stronger in [exemplary] punishment"
  },
  {
    "id": 85,
    "text": "Whoever intercedes for a good cause will have a reward therefrom; and whoever intercedes for an evil cause will have a burden therefrom. And ever is Allah, over all things, a Keeper"
  },
  {
    "id": 86,
    "text": "And when you are greeted with a greeting, greet [in return] with one better than it or [at least] return it [in a like manner]. Indeed, Allah is ever, over all things, an Accountant"
  },
  {
    "id": 87,
    "text": "Allah - there is no deity except Him. He will surely assemble you for [account on] the Day of Resurrection, about which there is no doubt. And who is more truthful than Allah in statement"
  },
  {
    "id": 88,
    "text": "What is [the matter] with you [that you are] two groups concerning the hypocrites, while Allah has made them fall back [into error and disbelief] for what they earned. Do you wish to guide those whom Allah has sent astray? And he whom Allah sends astray - never will you find for him a way [of guidance]"
  },
  {
    "id": 89,
    "text": "They wish you would disbelieve as they disbelieved so you would be alike. So do not take from among them allies until they emigrate for the cause of Allah. But if they turn away, then seize them and kill them wherever you find them and take not from among them any ally or helper"
  },
  {
    "id": 90,
    "text": "Except for those who take refuge with a people between yourselves and whom is a treaty or those who come to you, their hearts strained at [the prospect of] fighting you or fighting their own people. And if Allah had willed, He could have given them power over you, and they would have fought you. So if they remove themselves from you and do not fight you and offer you peace, then Allah has not made for you a cause [for fighting] against them"
  },
  {
    "id": 91,
    "text": "You will find others who wish to obtain security from you and [to] obtain security from their people. Every time they are returned to [the influence of] disbelief, they fall back into it. So if they do not withdraw from you or offer you peace or restrain their hands, then seize them and kill them wherever you overtake them. And those - We have made for you against them a clear authorization"
  },
  {
    "id": 92,
    "text": "And never is it for a believer to kill a believer except by mistake. And whoever kills a believer by mistake - then the freeing of a believing slave and a compensation payment presented to the deceased's family [is required] unless they give [up their right as] charity. But if the deceased was from a people at war with you and he was a believer - then [only] the freeing of a believing slave; and if he was from a people with whom you have a treaty - then a compensation payment presented to his family and the freeing of a believing slave. And whoever does not find [one or cannot afford to buy one] - then [instead], a fast for two months consecutively, [seeking] acceptance of repentance from Allah. And Allah is ever Knowing and Wise"
  },
  {
    "id": 93,
    "text": "But whoever kills a believer intentionally - his recompense is Hell, wherein he will abide eternally, and Allah has become angry with him and has cursed him and has prepared for him a great punishment"
  },
  {
    "id": 94,
    "text": "O you who have believed, when you go forth [to fight] in the cause of Allah, investigate; and do not say to one who gives you [a greeting of] peace \"You are not a believer,\" aspiring for the goods of worldly life; for with Allah are many acquisitions. You [yourselves] were like that before; then Allah conferred His favor upon you, so investigate. Indeed Allah is ever, with what you do, Acquainted"
  },
  {
    "id": 95,
    "text": "Not equal are those believers remaining [at home] - other than the disabled - and the mujahideen, [who strive and fight] in the cause of Allah with their wealth and their lives. Allah has preferred the mujahideen through their wealth and their lives over those who remain [behind], by degrees. And to both Allah has promised the best [reward]. But Allah has preferred the mujahideen over those who remain [behind] with a great reward"
  },
  {
    "id": 96,
    "text": "Degrees [of high position] from Him and forgiveness and mercy. And Allah is ever Forgiving and Merciful"
  },
  {
    "id": 97,
    "text": "Indeed, those whom the angels take [in death] while wronging themselves - [the angels] will say, \"In what [condition] were you?\" They will say, \"We were oppressed in the land.\" The angels will say, \"Was not the earth of Allah spacious [enough] for you to emigrate therein?\" For those, their refuge is Hell - and evil it is as a destination"
  },
  {
    "id": 98,
    "text": "Except for the oppressed among men, women and children who cannot devise a plan nor are they directed to a way"
  },
  {
    "id": 99,
    "text": "For those it is expected that Allah will pardon them, and Allah is ever Pardoning and Forgiving"
  },
  {
    "id": 100,
    "text": "And whoever emigrates for the cause of Allah will find on the earth many [alternative] locations and abundance. And whoever leaves his home as an emigrant to Allah and His Messenger and then death overtakes him - his reward has already become incumbent upon Allah. And Allah is ever Forgiving and Merciful"
  },
  {
    "id": 101,
    "text": "And when you travel throughout the land, there is no blame upon you for shortening the prayer, [especially] if you fear that those who disbelieve may disrupt [or attack] you. Indeed, the disbelievers are ever to you a clear enemy"
  },
  {
    "id": 102,
    "text": "And when you are among them and lead them in prayer, let a group of them stand [in prayer] with you and let them carry their arms. And when they have prostrated, let them be [in position] behind you and have the other group come forward which has not [yet] prayed and let them pray with you, taking precaution and carrying their arms. Those who disbelieve wish that you would neglect your weapons and your baggage so they could come down upon you in one [single] attack. But there is no blame upon you, if you are troubled by rain or are ill, for putting down your arms, but take precaution. Indeed, Allah has prepared for the disbelievers a humiliating punishment"
  },
  {
    "id": 103,
    "text": "And when you have completed the prayer, remember Allah standing, sitting, or [lying] on your sides. But when you become secure, re-establish [regular] prayer. Indeed, prayer has been decreed upon the believers a decree of specified times"
  },
  {
    "id": 104,
    "text": "And do not weaken in pursuit of the enemy. If you should be suffering - so are they suffering as you are suffering, but you expect from Allah that which they expect not. And Allah is ever Knowing and Wise"
  },
  {
    "id": 105,
    "text": "Indeed, We have revealed to you, [O Muhammad], the Book in truth so you may judge between the people by that which Allah has shown you. And do not be for the deceitful an advocate"
  },
  {
    "id": 106,
    "text": "And seek forgiveness of Allah. Indeed, Allah is ever Forgiving and Merciful"
  },
  {
    "id": 107,
    "text": "And do not argue on behalf of those who deceive themselves. Indeed, Allah loves not one who is a habitually sinful deceiver"
  },
  {
    "id": 108,
    "text": "They conceal [their evil intentions and deeds] from the people, but they cannot conceal [them] from Allah, and He is with them [in His knowledge] when they spend the night in such as He does not accept of speech. And ever is Allah, of what they do, encompassing"
  },
  {
    "id": 109,
    "text": "Here you are - those who argue on their behalf in [this] worldly life - but who will argue with Allah for them on the Day of Resurrection, or who will [then] be their representative"
  },
  {
    "id": 110,
    "text": "And whoever does a wrong or wrongs himself but then seeks forgiveness of Allah will find Allah Forgiving and Merciful"
  },
  {
    "id": 111,
    "text": "And whoever commits a sin only earns it against himself. And Allah is ever Knowing and Wise"
  },
  {
    "id": 112,
    "text": "But whoever earns an offense or a sin and then blames it on an innocent [person] has taken upon himself a slander and manifest sin"
  },
  {
    "id": 113,
    "text": "And if it was not for the favor of Allah upon you, [O Muhammad], and His mercy, a group of them would have determined to mislead you. But they do not mislead except themselves, and they will not harm you at all. And Allah has revealed to you the Book and wisdom and has taught you that which you did not know. And ever has the favor of Allah upon you been great"
  },
  {
    "id": 114,
    "text": "No good is there in much of their private conversation, except for those who enjoin charity or that which is right or conciliation between people. And whoever does that seeking means to the approval of Allah - then We are going to give him a great reward"
  },
  {
    "id": 115,
    "text": "And whoever opposes the Messenger after guidance has become clear to him and follows other than the way of the believers - We will give him what he has taken and drive him into Hell, and evil it is as a destination"
  },
  {
    "id": 116,
    "text": "Indeed, Allah does not forgive association with Him, but He forgives what is less than that for whom He wills. And he who associates others with Allah has certainly gone far astray"
  },
  {
    "id": 117,
    "text": "They call upon instead of Him none but female [deities], and they [actually] call upon none but a rebellious Satan"
  },
  {
    "id": 118,
    "text": "Whom Allah has cursed. For he had said, \"I will surely take from among Your servants a specific portion"
  },
  {
    "id": 119,
    "text": "And I will mislead them, and I will arouse in them [sinful] desires, and I will command them so they will slit the ears of cattle, and I will command them so they will change the creation of Allah.\" And whoever takes Satan as an ally instead of Allah has certainly sustained a clear loss"
  },
  {
    "id": 120,
    "text": "Satan promises them and arouses desire in them. But Satan does not promise them except delusion"
  },
  {
    "id": 121,
    "text": "The refuge of those will be Hell, and they will not find from it an escape"
  },
  {
    "id": 122,
    "text": "But the ones who believe and do righteous deeds - We will admit them to gardens beneath which rivers flow, wherein they will abide forever. [It is] the promise of Allah, [which is] truth, and who is more truthful than Allah in statement"
  },
  {
    "id": 123,
    "text": "Paradise is not [obtained] by your wishful thinking nor by that of the People of the Scripture. Whoever does a wrong will be recompensed for it, and he will not find besides Allah a protector or a helper"
  },
  {
    "id": 124,
    "text": "And whoever does righteous deeds, whether male or female, while being a believer - those will enter Paradise and will not be wronged, [even as much as] the speck on a date seed"
  },
  {
    "id": 125,
    "text": "And who is better in religion than one who submits himself to Allah while being a doer of good and follows the religion of Abraham, inclining toward truth? And Allah took Abraham as an intimate friend"
  },
  {
    "id": 126,
    "text": "And to Allah belongs whatever is in the heavens and whatever is on the earth. And ever is Allah, of all things, encompassing"
  },
  {
    "id": 127,
    "text": "And they request from you, [O Muhammad], a [legal] ruling concerning women. Say, \"Allah gives you a ruling about them and [about] what has been recited to you in the Book concerning the orphan girls to whom you do not give what is decreed for them - and [yet] you desire to marry them - and concerning the oppressed among children and that you maintain for orphans [their rights] in justice.\" And whatever you do of good - indeed, Allah is ever Knowing of it"
  },
  {
    "id": 128,
    "text": "And if a woman fears from her husband contempt or evasion, there is no sin upon them if they make terms of settlement between them - and settlement is best. And present in [human] souls is stinginess. But if you do good and fear Allah - then indeed Allah is ever, with what you do, Acquainted"
  },
  {
    "id": 129,
    "text": "And you will never be able to be equal [in feeling] between wives, even if you should strive [to do so]. So do not incline completely [toward one] and leave another hanging. And if you amend [your affairs] and fear Allah - then indeed, Allah is ever Forgiving and Merciful"
  },
  {
    "id": 130,
    "text": "But if they separate [by divorce], Allah will enrich each [of them] from His abundance. And ever is Allah Encompassing and Wise"
  },
  {
    "id": 131,
    "text": "And to Allah belongs whatever is in the heavens and whatever is on the earth. And We have instructed those who were given the Scripture before you and yourselves to fear Allah. But if you disbelieve - then to Allah belongs whatever is in the heavens and whatever is on the earth. And ever is Allah Free of need and Praiseworthy"
  },
  {
    "id": 132,
    "text": "And to Allah belongs whatever is in the heavens and whatever is on the earth. And sufficient is Allah as Disposer of affairs"
  },
  {
    "id": 133,
    "text": "If He wills, He can do away with you, O people, and bring others [in your place]. And ever is Allah competent to do that"
  },
  {
    "id": 134,
    "text": "Whoever desires the reward of this world - then with Allah is the reward of this world and the Hereafter. And ever is Allah Hearing and Seeing"
  },
  {
    "id": 135,
    "text": "O you who have believed, be persistently standing firm in justice, witnesses for Allah, even if it be against yourselves or parents and relatives. Whether one is rich or poor, Allah is more worthy of both. So follow not [personal] inclination, lest you not be just. And if you distort [your testimony] or refuse [to give it], then indeed Allah is ever, with what you do, Acquainted"
  },
  {
    "id": 136,
    "text": "O you who have believed, believe in Allah and His Messenger and the Book that He sent down upon His Messenger and the Scripture which He sent down before. And whoever disbelieves in Allah, His angels, His books, His messengers, and the Last Day has certainly gone far astray"
  },
  {
    "id": 137,
    "text": "Indeed, those who have believed then disbelieved, then believed, then disbelieved, and then increased in disbelief - never will Allah forgive them, nor will He guide them to a way"
  },
  {
    "id": 138,
    "text": "Give tidings to the hypocrites that there is for them a painful punishment"
  },
  {
    "id": 139,
    "text": "Those who take disbelievers as allies instead of the believers. Do they seek with them honor [through power]? But indeed, honor belongs to Allah entirely"
  },
  {
    "id": 140,
    "text": "And it has already come down to you in the Book that when you hear the verses of Allah [recited], they are denied [by them] and ridiculed; so do not sit with them until they enter into another conversation. Indeed, you would then be like them. Indeed Allah will gather the hypocrites and disbelievers in Hell all together"
  },
  {
    "id": 141,
    "text": "Those who wait [and watch] you. Then if you gain a victory from Allah, they say, \"Were we not with you?\" But if the disbelievers have a success, they say [to them], \"Did we not gain the advantage over you, but we protected you from the believers?\" Allah will judge between [all of] you on the Day of Resurrection, and never will Allah give the disbelievers over the believers a way [to overcome them]"
  },
  {
    "id": 142,
    "text": "Indeed, the hypocrites [think to] deceive Allah, but He is deceiving them. And when they stand for prayer, they stand lazily, showing [themselves to] the people and not remembering Allah except a little"
  },
  {
    "id": 143,
    "text": "Wavering between them, [belonging] neither to the believers nor to the disbelievers. And whoever Allah leaves astray - never will you find for him a way"
  },
  {
    "id": 144,
    "text": "O you who have believed, do not take the disbelievers as allies instead of the believers. Do you wish to give Allah against yourselves a clear case"
  },
  {
    "id": 145,
    "text": "Indeed, the hypocrites will be in the lowest depths of the Fire - and never will you find for them a helper"
  },
  {
    "id": 146,
    "text": "Except for those who repent, correct themselves, hold fast to Allah, and are sincere in their religion for Allah, for those will be with the believers. And Allah is going to give the believers a great reward"
  },
  {
    "id": 147,
    "text": "What would Allah do with your punishment if you are grateful and believe? And ever is Allah Appreciative and Knowing"
  },
  {
    "id": 148,
    "text": "Allah does not like the public mention of evil except by one who has been wronged. And ever is Allah Hearing and Knowing"
  },
  {
    "id": 149,
    "text": "If [instead] you show [some] good or conceal it or pardon an offense - indeed, Allah is ever Pardoning and Competent"
  },
  {
    "id": 150,
    "text": "Indeed, those who disbelieve in Allah and His messengers and wish to discriminate between Allah and His messengers and say, \"We believe in some and disbelieve in others,\" and wish to adopt a way in between"
  },
  {
    "id": 151,
    "text": "Those are the disbelievers, truly. And We have prepared for the disbelievers a humiliating punishment"
  },
  {
    "id": 152,
    "text": "But they who believe in Allah and His messengers and do not discriminate between any of them - to those He is going to give their rewards. And ever is Allah Forgiving and Merciful"
  },
  {
    "id": 153,
    "text": "The People of the Scripture ask you to bring down to them a book from the heaven. But they had asked of Moses [even] greater than that and said, \"Show us Allah outright,\" so the thunderbolt struck them for their wrongdoing. Then they took the calf [for worship] after clear evidences had come to them, and We pardoned that. And We gave Moses a clear authority"
  },
  {
    "id": 154,
    "text": "And We raised over them the mount for [refusal of] their covenant; and We said to them, \"Enter the gate bowing humbly\", and We said to them, \"Do not transgress on the sabbath\", and We took from them a solemn covenant"
  },
  {
    "id": 155,
    "text": "And [We cursed them] for their breaking of the covenant and their disbelief in the signs of Allah and their killing of the prophets without right and their saying, \"Our hearts are wrapped\". Rather, Allah has sealed them because of their disbelief, so they believe not, except for a few"
  },
  {
    "id": 156,
    "text": "And [We cursed them] for their disbelief and their saying against Mary a great slander"
  },
  {
    "id": 157,
    "text": "And [for] their saying, \"Indeed, we have killed the Messiah, Jesus, the son of Mary, the messenger of Allah.\" And they did not kill him, nor did they crucify him; but [another] was made to resemble him to them. And indeed, those who differ over it are in doubt about it. They have no knowledge of it except the following of assumption. And they did not kill him, for certain"
  },
  {
    "id": 158,
    "text": "Rather, Allah raised him to Himself. And ever is Allah Exalted in Might and Wise"
  },
  {
    "id": 159,
    "text": "And there is none from the People of the Scripture but that he will surely believe in Jesus before his death. And on the Day of Resurrection he will be against them a witness"
  },
  {
    "id": 160,
    "text": "For wrongdoing on the part of the Jews, We made unlawful for them [certain] good foods which had been lawful to them, and for their averting from the way of Allah many [people]"
  },
  {
    "id": 161,
    "text": "And [for] their taking of usury while they had been forbidden from it, and their consuming of the people's wealth unjustly. And we have prepared for the disbelievers among them a painful punishment"
  },
  {
    "id": 162,
    "text": "But those firm in knowledge among them and the believers believe in what has been revealed to you, [O Muhammad], and what was revealed before you. And the establishers of prayer [especially] and the givers of zakah and the believers in Allah and the Last Day - those We will give a great reward"
  },
  {
    "id": 163,
    "text": "Indeed, We have revealed to you, [O Muhammad], as We revealed to Noah and the prophets after him. And we revealed to Abraham, Ishmael, Isaac, Jacob, the Descendants, Jesus, Job, Jonah, Aaron, and Solomon, and to David We gave the book [of Psalms]"
  },
  {
    "id": 164,
    "text": "And [We sent] messengers about whom We have related [their stories] to you before and messengers about whom We have not related to you. And Allah spoke to Moses with [direct] speech"
  },
  {
    "id": 165,
    "text": "[We sent] messengers as bringers of good tidings and warners so that mankind will have no argument against Allah after the messengers. And ever is Allah Exalted in Might and Wise"
  },
  {
    "id": 166,
    "text": "But Allah bears witness to that which He has revealed to you. He has sent it down with His knowledge, and the angels bear witness [as well]. And sufficient is Allah as Witness"
  },
  {
    "id": 167,
    "text": "Indeed, those who disbelieve and avert [people] from the way of Allah have certainly gone far astray"
  },
  {
    "id": 168,
    "text": "Indeed, those who disbelieve and commit wrong [or injustice] - never will Allah forgive them, nor will He guide them to a path"
  },
  {
    "id": 169,
    "text": "Except the path of Hell; they will abide therein forever. And that, for Allah, is [always] easy"
  },
  {
    "id": 170,
    "text": "O Mankind, the Messenger has come to you with the truth from your Lord, so believe; it is better for you. But if you disbelieve - then indeed, to Allah belongs whatever is in the heavens and earth. And ever is Allah Knowing and Wise"
  },
  {
    "id": 171,
    "text": "O People of the Scripture, do not commit excess in your religion or say about Allah except the truth. The Messiah, Jesus, the son of Mary, was but a messenger of Allah and His word which He directed to Mary and a soul [created at a command] from Him. So believe in Allah and His messengers. And do not say, \"Three\"; desist - it is better for you. Indeed, Allah is but one God. Exalted is He above having a son. To Him belongs whatever is in the heavens and whatever is on the earth. And sufficient is Allah as Disposer of affairs"
  },
  {
    "id": 172,
    "text": "Never would the Messiah disdain to be a servant of Allah, nor would the angels near [to Him]. And whoever disdains His worship and is arrogant - He will gather them to Himself all together"
  },
  {
    "id": 173,
    "text": "And as for those who believed and did righteous deeds, He will give them in full their rewards and grant them extra from His bounty. But as for those who disdained and were arrogant, He will punish them with a painful punishment, and they will not find for themselves besides Allah any protector or helper"
  },
  {
    "id": 174,
    "text": "O mankind, there has come to you a conclusive proof from your Lord, and We have sent down to you a clear light"
  },
  {
    "id": 175,
    "text": "So those who believe in Allah and hold fast to Him - He will admit them to mercy from Himself and bounty and guide them to Himself on a straight path"
  },
  {
    "id": 176,
    "text": "They request from you a [legal] ruling. Say, \"Allah gives you a ruling concerning one having neither descendants nor ascendants [as heirs].\" If a man dies, leaving no child but [only] a sister, she will have half of what he left. And he inherits from her if she [dies and] has no child. But if there are two sisters [or more], they will have two-thirds of what he left. If there are both brothers and sisters, the male will have the share of two females. Allah makes clear to you [His law], lest you go astray. And Allah is Knowing of all things"
  }
]

export default en
