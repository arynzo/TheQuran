import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "The command of Allah is coming, so be not impatient for it. Exalted is He and high above what they associate with Him"
  },
  {
    "id": 2,
    "text": "He sends down the angels, with the inspiration of His command, upon whom He wills of His servants, [telling them], \"Warn that there is no deity except Me; so fear Me"
  },
  {
    "id": 3,
    "text": "He created the heavens and earth in truth. High is He above what they associate with Him"
  },
  {
    "id": 4,
    "text": "He created man from a sperm-drop; then at once, he is a clear adversary"
  },
  {
    "id": 5,
    "text": "And the grazing livestock He has created for you; in them is warmth and [numerous] benefits, and from them you eat"
  },
  {
    "id": 6,
    "text": "And for you in them is [the enjoyment of] beauty when you bring them in [for the evening] and when you send them out [to pasture]"
  },
  {
    "id": 7,
    "text": "And they carry your loads to a land you could not have reached except with difficulty to yourselves. Indeed, your Lord is Kind and Merciful"
  },
  {
    "id": 8,
    "text": "And [He created] the horses, mules and donkeys for you to ride and [as] adornment. And He creates that which you do not know"
  },
  {
    "id": 9,
    "text": "And upon Allah is the direction of the [right] way, and among the various paths are those deviating. And if He willed, He could have guided you all"
  },
  {
    "id": 10,
    "text": "It is He who sends down rain from the sky; from it is drink and from it is foliage in which you pasture [animals]"
  },
  {
    "id": 11,
    "text": "He causes to grow for you thereby the crops, olives, palm trees, grapevines, and from all the fruits. Indeed in that is a sign for a people who give thought"
  },
  {
    "id": 12,
    "text": "And He has subjected for you the night and day and the sun and moon, and the stars are subjected by His command. Indeed in that are signs for a people who reason"
  },
  {
    "id": 13,
    "text": "And [He has subjected] whatever He multiplied for you on the earth of varying colors. Indeed in that is a sign for a people who remember"
  },
  {
    "id": 14,
    "text": "And it is He who subjected the sea for you to eat from it tender meat and to extract from it ornaments which you wear. And you see the ships plowing through it, and [He subjected it] that you may seek of His bounty; and perhaps you will be grateful"
  },
  {
    "id": 15,
    "text": "And He has cast into the earth firmly set mountains, lest it shift with you, and [made] rivers and roads, that you may be guided"
  },
  {
    "id": 16,
    "text": "And landmarks. And by the stars they are [also] guided"
  },
  {
    "id": 17,
    "text": "Then is He who creates like one who does not create? So will you not be reminded"
  },
  {
    "id": 18,
    "text": "And if you should count the favors of Allah, you could not enumerate them. Indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 19,
    "text": "And Allah knows what you conceal and what you declare"
  },
  {
    "id": 20,
    "text": "And those they invoke other than Allah create nothing, and they [themselves] are created"
  },
  {
    "id": 21,
    "text": "They are, [in fact], dead, not alive, and they do not perceive when they will be resurrected"
  },
  {
    "id": 22,
    "text": "Your god is one God. But those who do not believe in the Hereafter - their hearts are disapproving, and they are arrogant"
  },
  {
    "id": 23,
    "text": "Assuredly, Allah knows what they conceal and what they declare. Indeed, He does not like the arrogant"
  },
  {
    "id": 24,
    "text": "And when it is said to them, \"What has your Lord sent down?\" They say, \"Legends of the former peoples"
  },
  {
    "id": 25,
    "text": "That they may bear their own burdens in full on the Day of Resurrection and some of the burdens of those whom they misguide without knowledge. Unquestionably, evil is that which they bear"
  },
  {
    "id": 26,
    "text": "Those before them had already plotted, but Allah came at their building from the foundations, so the roof fell upon them from above them, and the punishment came to them from where they did not perceive"
  },
  {
    "id": 27,
    "text": "Then on the Day of Resurrection He will disgrace them and say, \"Where are My 'partners' for whom you used to oppose [the believers]?\" Those who were given knowledge will say, \"Indeed disgrace, this Day, and evil are upon the disbelievers"
  },
  {
    "id": 28,
    "text": "The ones whom the angels take in death [while] wronging themselves, and [who] then offer submission, [saying], \"We were not doing any evil.\" But, yes! Indeed, Allah is Knowing of what you used to do"
  },
  {
    "id": 29,
    "text": "So enter the gates of Hell to abide eternally therein, and how wretched is the residence of the arrogant"
  },
  {
    "id": 30,
    "text": "And it will be said to those who feared Allah, \"What did your Lord send down?\" They will say, \"[That which is] good.\" For those who do good in this world is good; and the home of the Hereafter is better. And how excellent is the home of the righteous"
  },
  {
    "id": 31,
    "text": "Gardens of perpetual residence, which they will enter, beneath which rivers flow. They will have therein whatever they wish. Thus does Allah reward the righteous"
  },
  {
    "id": 32,
    "text": "The ones whom the angels take in death, [being] good and pure; [the angels] will say, \"Peace be upon you. Enter Paradise for what you used to do"
  },
  {
    "id": 33,
    "text": "Do the disbelievers await [anything] except that the angels should come to them or there comes the command of your Lord? Thus did those do before them. And Allah wronged them not, but they had been wronging themselves"
  },
  {
    "id": 34,
    "text": "So they were struck by the evil consequences of what they did and were enveloped by what they used to ridicule"
  },
  {
    "id": 35,
    "text": "And those who associate others with Allah say, \"If Allah had willed, we would not have worshipped anything other than Him, neither we nor our fathers, nor would we have forbidden anything through other than Him.\" Thus did those do before them. So is there upon the messengers except [the duty of] clear notification"
  },
  {
    "id": 36,
    "text": "And We certainly sent into every nation a messenger, [saying], \"Worship Allah and avoid Taghut.\" And among them were those whom Allah guided, and among them were those upon whom error was [deservedly] decreed. So proceed through the earth and observe how was the end of the deniers"
  },
  {
    "id": 37,
    "text": "[Even] if you should strive for their guidance, [O Muhammad], indeed, Allah does not guide those He sends astray, and they will have no helpers"
  },
  {
    "id": 38,
    "text": "And they swear by Allah their strongest oaths [that] Allah will not resurrect one who dies. But yes - [it is] a true promise [binding] upon Him, but most of the people do not know"
  },
  {
    "id": 39,
    "text": "[It is] so He will make clear to them [the truth of] that wherein they differ and so those who have disbelieved may know that they were liars"
  },
  {
    "id": 40,
    "text": "Indeed, Our word to a thing when We intend it is but that We say to it, \"Be,\" and it is"
  },
  {
    "id": 41,
    "text": "And those who emigrated for [the cause of] Allah after they had been wronged - We will surely settle them in this world in a good place; but the reward of the Hereafter is greater, if only they could know"
  },
  {
    "id": 42,
    "text": "[They are] those who endured patiently and upon their Lord relied"
  },
  {
    "id": 43,
    "text": "And We sent not before you except men to whom We revealed [Our message]. So ask the people of the message if you do not know"
  },
  {
    "id": 44,
    "text": "[We sent them] with clear proofs and written ordinances. And We revealed to you the message that you may make clear to the people what was sent down to them and that they might give thought"
  },
  {
    "id": 45,
    "text": "Then, do those who have planned evil deeds feel secure that Allah will not cause the earth to swallow them or that the punishment will not come upon them from where they do not perceive"
  },
  {
    "id": 46,
    "text": "Or that He would not seize them during their [usual] activity, and they could not cause failure"
  },
  {
    "id": 47,
    "text": "Or that He would not seize them gradually [in a state of dread]? But indeed, your Lord is Kind and Merciful"
  },
  {
    "id": 48,
    "text": "Have they not considered what things Allah has created? Their shadows incline to the right and to the left, prostrating to Allah, while they are humble"
  },
  {
    "id": 49,
    "text": "And to Allah prostrates whatever is in the heavens and whatever is on the earth of creatures, and the angels [as well], and they are not arrogant"
  },
  {
    "id": 50,
    "text": "They fear their Lord above them, and they do what they are commanded"
  },
  {
    "id": 51,
    "text": "And Allah has said, \"Do not take for yourselves two deities. He is but one God, so fear only Me"
  },
  {
    "id": 52,
    "text": "And to Him belongs whatever is in the heavens and the earth, and to Him is [due] worship constantly. Then is it other than Allah that you fear"
  },
  {
    "id": 53,
    "text": "And whatever you have of favor - it is from Allah. Then when adversity touches you, to Him you cry for help"
  },
  {
    "id": 54,
    "text": "Then when He removes the adversity from you, at once a party of you associates others with their Lord"
  },
  {
    "id": 55,
    "text": "So they will deny what We have given them. Then enjoy yourselves, for you are going to know"
  },
  {
    "id": 56,
    "text": "And they assign to what they do not know a portion of that which We have provided them. By Allah, you will surely be questioned about what you used to invent"
  },
  {
    "id": 57,
    "text": "And they attribute to Allah daughters - exalted is He - and for them is what they desire"
  },
  {
    "id": 58,
    "text": "And when one of them is informed of [the birth of] a female, his face becomes dark, and he suppresses grief"
  },
  {
    "id": 59,
    "text": "He hides himself from the people because of the ill of which he has been informed. Should he keep it in humiliation or bury it in the ground? Unquestionably, evil is what they decide"
  },
  {
    "id": 60,
    "text": "For those who do not believe in the Hereafter is the description of evil; and for Allah is the highest attribute. And He is Exalted in Might, the Wise"
  },
  {
    "id": 61,
    "text": "And if Allah were to impose blame on the people for their wrongdoing, He would not have left upon the earth any creature, but He defers them for a specified term. And when their term has come, they will not remain behind an hour, nor will they precede [it]"
  },
  {
    "id": 62,
    "text": "And they attribute to Allah that which they dislike, and their tongues assert the lie that they will have the best [from Him]. Assuredly, they will have the Fire, and they will be [therein] neglected"
  },
  {
    "id": 63,
    "text": "By Allah, We did certainly send [messengers] to nations before you, but Satan made their deeds attractive to them. And he is the disbelievers' ally today [as well], and they will have a painful punishment"
  },
  {
    "id": 64,
    "text": "And We have not revealed to you the Book, [O Muhammad], except for you to make clear to them that wherein they have differed and as guidance and mercy for a people who believe"
  },
  {
    "id": 65,
    "text": "And Allah has sent down rain from the sky and given life thereby to the earth after its lifelessness. Indeed in that is a sign for a people who listen"
  },
  {
    "id": 66,
    "text": "And indeed, for you in grazing livestock is a lesson. We give you drink from what is in their bellies - between excretion and blood - pure milk, palatable to drinkers"
  },
  {
    "id": 67,
    "text": "And from the fruits of the palm trees and grapevines you take intoxicant and good provision. Indeed in that is a sign for a people who reason"
  },
  {
    "id": 68,
    "text": "And your Lord inspired to the bee, \"Take for yourself among the mountains, houses, and among the trees and [in] that which they construct"
  },
  {
    "id": 69,
    "text": "Then eat from all the fruits and follow the ways of your Lord laid down [for you].\" There emerges from their bellies a drink, varying in colors, in which there is healing for people. Indeed in that is a sign for a people who give thought"
  },
  {
    "id": 70,
    "text": "And Allah created you; then He will take you in death. And among you is he who is reversed to the most decrepit [old] age so that he will not know, after [having had] knowledge, a thing. Indeed, Allah is Knowing and Competent"
  },
  {
    "id": 71,
    "text": "And Allah has favored some of you over others in provision. But those who were favored would not hand over their provision to those whom their right hands possess so they would be equal to them therein. Then is it the favor of Allah they reject"
  },
  {
    "id": 72,
    "text": "And Allah has made for you from yourselves mates and has made for you from your mates sons and grandchildren and has provided for you from the good things. Then in falsehood do they believe and in the favor of Allah they disbelieve"
  },
  {
    "id": 73,
    "text": "And they worship besides Allah that which does not possess for them [the power of] provision from the heavens and the earth at all, and [in fact], they are unable"
  },
  {
    "id": 74,
    "text": "So do not assert similarities to Allah. Indeed, Allah knows and you do not know"
  },
  {
    "id": 75,
    "text": "Allah presents an example: a slave [who is] owned and unable to do a thing and he to whom We have provided from Us good provision, so he spends from it secretly and publicly. Can they be equal? Praise to Allah! But most of them do not know"
  },
  {
    "id": 76,
    "text": "And Allah presents an example of two men, one of them dumb and unable to do a thing, while he is a burden to his guardian. Wherever he directs him, he brings no good. Is he equal to one who commands justice, while he is on a straight path"
  },
  {
    "id": 77,
    "text": "And to Allah belongs the unseen [aspects] of the heavens and the earth. And the command for the Hour is not but as a glance of the eye or even nearer. Indeed, Allah is over all things competent"
  },
  {
    "id": 78,
    "text": "And Allah has extracted you from the wombs of your mothers not knowing a thing, and He made for you hearing and vision and intellect that perhaps you would be grateful"
  },
  {
    "id": 79,
    "text": "Do they not see the birds controlled in the atmosphere of the sky? None holds them up except Allah. Indeed in that are signs for a people who believe"
  },
  {
    "id": 80,
    "text": "And Allah has made for you from your homes a place of rest and made for you from the hides of the animals tents which you find light on your day of travel and your day of encampment; and from their wool, fur and hair is furnishing and enjoyment for a time"
  },
  {
    "id": 81,
    "text": "And Allah has made for you, from that which He has created, shadows and has made for you from the mountains, shelters and has made for you garments which protect you from the heat and garments which protect you from your [enemy in] battle. Thus does He complete His favor upon you that you might submit [to Him]"
  },
  {
    "id": 82,
    "text": "But if they turn away, [O Muhammad] - then only upon you is [responsibility for] clear notification"
  },
  {
    "id": 83,
    "text": "They recognize the favor of Allah; then they deny it. And most of them are disbelievers"
  },
  {
    "id": 84,
    "text": "And [mention] the Day when We will resurrect from every nation a witness. Then it will not be permitted to the disbelievers [to apologize or make excuses], nor will they be asked to appease [Allah]"
  },
  {
    "id": 85,
    "text": "And when those who wronged see the punishment, it will not be lightened for them, nor will they be reprieved"
  },
  {
    "id": 86,
    "text": "And when those who associated others with Allah see their \"partners,\" they will say,\" Our Lord, these are our partners [to You] whom we used to invoke besides You.\" But they will throw at them the statement, \"Indeed, you are liars"
  },
  {
    "id": 87,
    "text": "And they will impart to Allah that Day [their] submission, and lost from them is what they used to invent"
  },
  {
    "id": 88,
    "text": "Those who disbelieved and averted [others] from the way of Allah - We will increase them in punishment over [their] punishment for what corruption they were causing"
  },
  {
    "id": 89,
    "text": "And [mention] the Day when We will resurrect among every nation a witness over them from themselves. And We will bring you, [O Muhammad], as a witness over your nation. And We have sent down to you the Book as clarification for all things and as guidance and mercy and good tidings for the Muslims"
  },
  {
    "id": 90,
    "text": "Indeed, Allah orders justice and good conduct and giving to relatives and forbids immorality and bad conduct and oppression. He admonishes you that perhaps you will be reminded"
  },
  {
    "id": 91,
    "text": "And fulfill the covenant of Allah when you have taken it, [O believers], and do not break oaths after their confirmation while you have made Allah, over you, a witness. Indeed, Allah knows what you do"
  },
  {
    "id": 92,
    "text": "And do not be like she who untwisted her spun thread after it was strong [by] taking your oaths as [means of] deceit between you because one community is more plentiful [in number or wealth] than another community. Allah only tries you thereby. And He will surely make clear to you on the Day of Resurrection that over which you used to differ"
  },
  {
    "id": 93,
    "text": "And if Allah had willed, He could have made you [of] one religion, but He causes to stray whom He wills and guides whom He wills. And you will surely be questioned about what you used to do"
  },
  {
    "id": 94,
    "text": "And do not take your oaths as [means of] deceit between you, lest a foot slip after it was [once] firm, and you would taste evil [in this world] for what [people] you diverted from the way of Allah, and you would have [in the Hereafter] a great punishment"
  },
  {
    "id": 95,
    "text": "And do not exchange the covenant of Allah for a small price. Indeed, what is with Allah is best for you, if only you could know"
  },
  {
    "id": 96,
    "text": "Whatever you have will end, but what Allah has is lasting. And We will surely give those who were patient their reward according to the best of what they used to do"
  },
  {
    "id": 97,
    "text": "Whoever does righteousness, whether male or female, while he is a believer - We will surely cause him to live a good life, and We will surely give them their reward [in the Hereafter] according to the best of what they used to do"
  },
  {
    "id": 98,
    "text": "So when you recite the Qur'an, [first] seek refuge in Allah from Satan, the expelled [from His mercy]"
  },
  {
    "id": 99,
    "text": "Indeed, there is for him no authority over those who have believed and rely upon their Lord"
  },
  {
    "id": 100,
    "text": "His authority is only over those who take him as an ally and those who through him associate others with Allah"
  },
  {
    "id": 101,
    "text": "And when We substitute a verse in place of a verse - and Allah is most knowing of what He sends down - they say, \"You, [O Muhammad], are but an inventor [of lies].\" But most of them do not know"
  },
  {
    "id": 102,
    "text": "Say, [O Muhammad], \"The Pure Spirit has brought it down from your Lord in truth to make firm those who believe and as guidance and good tidings to the Muslims"
  },
  {
    "id": 103,
    "text": "And We certainly know that they say, \"It is only a human being who teaches the Prophet.\" The tongue of the one they refer to is foreign, and this Qur'an is [in] a clear Arabic language"
  },
  {
    "id": 104,
    "text": "Indeed, those who do not believe in the verses of Allah - Allah will not guide them, and for them is a painful punishment"
  },
  {
    "id": 105,
    "text": "They only invent falsehood who do not believe in the verses of Allah, and it is those who are the liars"
  },
  {
    "id": 106,
    "text": "Whoever disbelieves in Allah after his belief... except for one who is forced [to renounce his religion] while his heart is secure in faith. But those who [willingly] open their breasts to disbelief, upon them is wrath from Allah, and for them is a great punishment"
  },
  {
    "id": 107,
    "text": "That is because they preferred the worldly life over the Hereafter and that Allah does not guide the disbelieving people"
  },
  {
    "id": 108,
    "text": "Those are the ones over whose hearts and hearing and vision Allah has sealed, and it is those who are the heedless"
  },
  {
    "id": 109,
    "text": "Assuredly, it is they, in the Hereafter, who will be the losers"
  },
  {
    "id": 110,
    "text": "Then, indeed your Lord, to those who emigrated after they had been compelled [to renounce their religion] and thereafter fought [for the cause of Allah] and were patient - indeed, your Lord, after that, is Forgiving and Merciful"
  },
  {
    "id": 111,
    "text": "On the Day when every soul will come disputing for itself, and every soul will be fully compensated for what it did, and they will not be wronged"
  },
  {
    "id": 112,
    "text": "And Allah presents an example: a city which was safe and secure, its provision coming to it in abundance from every location, but it denied the favors of Allah. So Allah made it taste the envelopment of hunger and fear for what they had been doing"
  },
  {
    "id": 113,
    "text": "And there had certainly come to them a Messenger from among themselves, but they denied him; so punishment overtook them while they were wrongdoers"
  },
  {
    "id": 114,
    "text": "Then eat of what Allah has provided for you [which is] lawful and good. And be grateful for the favor of Allah, if it is [indeed] Him that you worship"
  },
  {
    "id": 115,
    "text": "He has only forbidden to you dead animals, blood, the flesh of swine, and that which has been dedicated to other than Allah. But whoever is forced [by necessity], neither desiring [it] nor transgressing [its limit] - then indeed, Allah is Forgiving and Merciful"
  },
  {
    "id": 116,
    "text": "And do not say about what your tongues assert of untruth, \"This is lawful and this is unlawful,\" to invent falsehood about Allah. Indeed, those who invent falsehood about Allah will not succeed"
  },
  {
    "id": 117,
    "text": "[It is but] a brief enjoyment, and they will have a painful punishment"
  },
  {
    "id": 118,
    "text": "And to those who are Jews We have prohibited that which We related to you before. And We did not wrong them [thereby], but they were wronging themselves"
  },
  {
    "id": 119,
    "text": "Then, indeed your Lord, to those who have done wrong out of ignorance and then repent after that and correct themselves - indeed, your Lord, thereafter, is Forgiving and Merciful"
  },
  {
    "id": 120,
    "text": "Indeed, Abraham was a [comprehensive] leader, devoutly obedient to Allah, inclining toward truth, and he was not of those who associate others with Allah"
  },
  {
    "id": 121,
    "text": "[He was] grateful for His favors. Allah chose him and guided him to a straight path"
  },
  {
    "id": 122,
    "text": "And We gave him good in this world, and indeed, in the Hereafter he will be among the righteous"
  },
  {
    "id": 123,
    "text": "Then We revealed to you, [O Muhammad], to follow the religion of Abraham, inclining toward truth; and he was not of those who associate with Allah"
  },
  {
    "id": 124,
    "text": "The sabbath was only appointed for those who differed over it. And indeed, your Lord will judge between them on the Day of Resurrection concerning that over which they used to differ"
  },
  {
    "id": 125,
    "text": "Invite to the way of your Lord with wisdom and good instruction, and argue with them in a way that is best. Indeed, your Lord is most knowing of who has strayed from His way, and He is most knowing of who is [rightly] guided"
  },
  {
    "id": 126,
    "text": "And if you punish [an enemy, O believers], punish with an equivalent of that with which you were harmed. But if you are patient - it is better for those who are patient"
  },
  {
    "id": 127,
    "text": "And be patient, [O Muhammad], and your patience is not but through Allah. And do not grieve over them and do not be in distress over what they conspire"
  },
  {
    "id": 128,
    "text": "Indeed, Allah is with those who fear Him and those who are doers of good"
  }
]

export default en
