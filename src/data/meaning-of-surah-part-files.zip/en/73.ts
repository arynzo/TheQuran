import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "O you who wraps himself [in clothing]"
  },
  {
    "id": 2,
    "text": "Arise [to pray] the night, except for a little"
  },
  {
    "id": 3,
    "text": "Half of it - or subtract from it a little"
  },
  {
    "id": 4,
    "text": "Or add to it, and recite the Qur'an with measured recitation"
  },
  {
    "id": 5,
    "text": "Indeed, We will cast upon you a heavy word"
  },
  {
    "id": 6,
    "text": "Indeed, the hours of the night are more effective for concurrence [of heart and tongue] and more suitable for words"
  },
  {
    "id": 7,
    "text": "Indeed, for you by day is prolonged occupation"
  },
  {
    "id": 8,
    "text": "And remember the name of your Lord and devote yourself to Him with [complete] devotion"
  },
  {
    "id": 9,
    "text": "[He is] the Lord of the East and the West; there is no deity except Him, so take Him as Disposer of [your] affairs"
  },
  {
    "id": 10,
    "text": "And be patient over what they say and avoid them with gracious avoidance"
  },
  {
    "id": 11,
    "text": "And leave Me with [the matter of] the deniers, those of ease [in life], and allow them respite a little"
  },
  {
    "id": 12,
    "text": "Indeed, with Us [for them] are shackles and burning fire"
  },
  {
    "id": 13,
    "text": "And food that chokes and a painful punishment"
  },
  {
    "id": 14,
    "text": "On the Day the earth and the mountains will convulse and the mountains will become a heap of sand pouring down"
  },
  {
    "id": 15,
    "text": "Indeed, We have sent to you a Messenger as a witness upon you just as We sent to Pharaoh a messenger"
  },
  {
    "id": 16,
    "text": "But Pharaoh disobeyed the messenger, so We seized him with a ruinous seizure"
  },
  {
    "id": 17,
    "text": "Then how can you fear, if you disbelieve, a Day that will make the children white- haired"
  },
  {
    "id": 18,
    "text": "The heaven will break apart therefrom; ever is His promise fulfilled"
  },
  {
    "id": 19,
    "text": "Indeed, this is a reminder, so whoever wills may take to his Lord a way"
  },
  {
    "id": 20,
    "text": "Indeed, your Lord knows, [O Muhammad], that you stand [in prayer] almost two thirds of the night or half of it or a third of it, and [so do] a group of those with you. And Allah determines [the extent of] the night and the day. He has known that you [Muslims] will not be able to do it and has turned to you in forgiveness, so recite what is easy [for you] of the Qur'an. He has known that there will be among you those who are ill and others traveling throughout the land seeking [something] of the bounty of Allah and others fighting for the cause of Allah. So recite what is easy from it and establish prayer and give zakah and loan Allah a goodly loan. And whatever good you put forward for yourselves - you will find it with Allah. It is better and greater in reward. And seek forgiveness of Allah. Indeed, Allah is Forgiving and Merciful"
  }
]

export default en
