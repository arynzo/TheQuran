import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Blessed is He in whose hand is dominion, and He is over all things competent"
  },
  {
    "id": 2,
    "text": "[He] who created death and life to test you [as to] which of you is best in deed - and He is the Exalted in Might, the Forgiving"
  },
  {
    "id": 3,
    "text": "[And] who created seven heavens in layers. You do not see in the creation of the Most Merciful any inconsistency. So return [your] vision [to the sky]; do you see any breaks"
  },
  {
    "id": 4,
    "text": "Then return [your] vision twice again. [Your] vision will return to you humbled while it is fatigued"
  },
  {
    "id": 5,
    "text": "And We have certainly beautified the nearest heaven with stars and have made [from] them what is thrown at the devils and have prepared for them the punishment of the Blaze"
  },
  {
    "id": 6,
    "text": "And for those who disbelieved in their Lord is the punishment of Hell, and wretched is the destination"
  },
  {
    "id": 7,
    "text": "When they are thrown into it, they hear from it a [dreadful] inhaling while it boils up"
  },
  {
    "id": 8,
    "text": "It almost bursts with rage. Every time a company is thrown into it, its keepers ask them, \"Did there not come to you a warner"
  },
  {
    "id": 9,
    "text": "They will say,\" Yes, a warner had come to us, but we denied and said, 'Allah has not sent down anything. You are not but in great error"
  },
  {
    "id": 10,
    "text": "And they will say, \"If only we had been listening or reasoning, we would not be among the companions of the Blaze"
  },
  {
    "id": 11,
    "text": "And they will admit their sin, so [it is] alienation for the companions of the Blaze"
  },
  {
    "id": 12,
    "text": "Indeed, those who fear their Lord unseen will have forgiveness and great reward"
  },
  {
    "id": 13,
    "text": "And conceal your speech or publicize it; indeed, He is Knowing of that within the breasts"
  },
  {
    "id": 14,
    "text": "Does He who created not know, while He is the Subtle, the Acquainted"
  },
  {
    "id": 15,
    "text": "It is He who made the earth tame for you - so walk among its slopes and eat of His provision - and to Him is the resurrection"
  },
  {
    "id": 16,
    "text": "Do you feel secure that He who [holds authority] in the heaven would not cause the earth to swallow you and suddenly it would sway"
  },
  {
    "id": 17,
    "text": "Or do you feel secure that He who [holds authority] in the heaven would not send against you a storm of stones? Then you would know how [severe] was My warning"
  },
  {
    "id": 18,
    "text": "And already had those before them denied, and how [terrible] was My reproach"
  },
  {
    "id": 19,
    "text": "Do they not see the birds above them with wings outspread and [sometimes] folded in? None holds them [aloft] except the Most Merciful. Indeed He is, of all things, Seeing"
  },
  {
    "id": 20,
    "text": "Or who is it that could be an army for you to aid you other than the Most Merciful? The disbelievers are not but in delusion"
  },
  {
    "id": 21,
    "text": "Or who is it that could provide for you if He withheld His provision? But they have persisted in insolence and aversion"
  },
  {
    "id": 22,
    "text": "Then is one who walks fallen on his face better guided or one who walks erect on a straight path"
  },
  {
    "id": 23,
    "text": "Say, \"It is He who has produced you and made for you hearing and vision and hearts; little are you grateful"
  },
  {
    "id": 24,
    "text": "Say, \"It is He who has multiplied you throughout the earth, and to Him you will be gathered"
  },
  {
    "id": 25,
    "text": "And they say, \"When is this promise, if you should be truthful"
  },
  {
    "id": 26,
    "text": "Say, \"The knowledge is only with Allah, and I am only a clear warner"
  },
  {
    "id": 27,
    "text": "But when they see it approaching, the faces of those who disbelieve will be distressed, and it will be said, \"This is that for which you used to call"
  },
  {
    "id": 28,
    "text": "Say, [O Muhammad], \"Have you considered: whether Allah should cause my death and those with me or have mercy upon us, who can protect the disbelievers from a painful punishment"
  },
  {
    "id": 29,
    "text": "Say, \"He is the Most Merciful; we have believed in Him, and upon Him we have relied. And you will [come to] know who it is that is in clear error"
  },
  {
    "id": 30,
    "text": "Say, \"Have you considered: if your water was to become sunken [into the earth], then who could bring you flowing water"
  }
]

export default en
