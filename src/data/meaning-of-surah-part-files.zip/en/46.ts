import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Ha, Meem"
  },
  {
    "id": 2,
    "text": "The revelation of the Book is from Allah, the Exalted in Might, the Wise"
  },
  {
    "id": 3,
    "text": "We did not create the heavens and earth and what is between them except in truth and [for] a specified term. But those who disbelieve, from that of which they are warned, are turning away"
  },
  {
    "id": 4,
    "text": "Say, [O Muhammad], \"Have you considered that which you invoke besides Allah? Show me what they have created of the earth; or did they have partnership in [creation of] the heavens? Bring me a scripture [revealed] before this or a [remaining] trace of knowledge, if you should be truthful"
  },
  {
    "id": 5,
    "text": "And who is more astray than he who invokes besides Allah those who will not respond to him until the Day of Resurrection, and they, of their invocation, are unaware"
  },
  {
    "id": 6,
    "text": "And when the people are gathered [that Day], they [who were invoked] will be enemies to them, and they will be deniers of their worship"
  },
  {
    "id": 7,
    "text": "And when Our verses are recited to them as clear evidences, those who disbelieve say of the truth when it has come to them, \"This is obvious magic"
  },
  {
    "id": 8,
    "text": "Or do they say, \"He has invented it?\" Say, \"If I have invented it, you will not possess for me [the power of protection] from Allah at all. He is most knowing of that in which you are involved. Sufficient is He as Witness between me and you, and He is the Forgiving the Merciful"
  },
  {
    "id": 9,
    "text": "Say, \"I am not something original among the messengers, nor do I know what will be done with me or with you. I only follow that which is revealed to me, and I am not but a clear warner"
  },
  {
    "id": 10,
    "text": "Say, \"Have you considered: if the Qur'an was from Allah, and you disbelieved in it while a witness from the Children of Israel has testified to something similar and believed while you were arrogant...?\" Indeed, Allah does not guide the wrongdoing people"
  },
  {
    "id": 11,
    "text": "And those who disbelieve say of those who believe, \"If it had [truly] been good, they would not have preceded us to it.\" And when they are not guided by it, they will say, \"This is an ancient falsehood"
  },
  {
    "id": 12,
    "text": "And before it was the scripture of Moses to lead and as a mercy. And this is a confirming Book in an Arabic tongue to warn those who have wronged and as good tidings to the doers of good"
  },
  {
    "id": 13,
    "text": "Indeed, those who have said, \"Our Lord is Allah,\" and then remained on a right course - there will be no fear concerning them, nor will they grieve"
  },
  {
    "id": 14,
    "text": "Those are the companions of Paradise, abiding eternally therein as reward for what they used to do"
  },
  {
    "id": 15,
    "text": "And We have enjoined upon man, to his parents, good treatment. His mother carried him with hardship and gave birth to him with hardship, and his gestation and weaning [period] is thirty months. [He grows] until, when he reaches maturity and reaches [the age of] forty years, he says, \"My Lord, enable me to be grateful for Your favor which You have bestowed upon me and upon my parents and to work righteousness of which You will approve and make righteous for me my offspring. Indeed, I have repented to You, and indeed, I am of the Muslims"
  },
  {
    "id": 16,
    "text": "Those are the ones from whom We will accept the best of what they did and overlook their misdeeds, [their being] among the companions of Paradise. [That is] the promise of truth which they had been promised"
  },
  {
    "id": 17,
    "text": "But one who says to his parents, \"Uff to you; do you promise me that I will be brought forth [from the earth] when generations before me have already passed on [into oblivion]?\" while they call to Allah for help [and to their son], \"Woe to you! Believe! Indeed, the promise of Allah is truth.\" But he says, \"This is not but legends of the former people"
  },
  {
    "id": 18,
    "text": "Those are the ones upon whom the word has come into effect, [who will be] among nations which had passed on before them of jinn and men. Indeed, they [all] were losers"
  },
  {
    "id": 19,
    "text": "And for all there are degrees [of reward and punishment] for what they have done, and [it is] so that He may fully compensate them for their deeds, and they will not be wronged"
  },
  {
    "id": 20,
    "text": "And the Day those who disbelieved are exposed to the Fire [it will be said], \"You exhausted your pleasures during your worldly life and enjoyed them, so this Day you will be awarded the punishment of [extreme] humiliation because you were arrogant upon the earth without right and because you were defiantly disobedient"
  },
  {
    "id": 21,
    "text": "And mention, [O Muhammad], the brother of 'Aad, when he warned his people in the [region of] al-Ahqaf - and warners had already passed on before him and after him - [saying], \"Do not worship except Allah. Indeed, I fear for you the punishment of a terrible day"
  },
  {
    "id": 22,
    "text": "They said, \"Have you come to delude us away from our gods? Then bring us what you promise us, if you should be of the truthful"
  },
  {
    "id": 23,
    "text": "He said, \"Knowledge [of its time] is only with Allah, and I convey to you that with which I was sent; but I see you [to be] a people behaving ignorantly"
  },
  {
    "id": 24,
    "text": "And when they saw it as a cloud approaching their valleys, they said, \"This is a cloud bringing us rain!\" Rather, it is that for which you were impatient: a wind, within it a painful punishment"
  },
  {
    "id": 25,
    "text": "Destroying everything by command of its Lord. And they became so that nothing was seen [of them] except their dwellings. Thus do We recompense the criminal people"
  },
  {
    "id": 26,
    "text": "And We had certainly established them in such as We have not established you, and We made for them hearing and vision and hearts. But their hearing and vision and hearts availed them not from anything [of the punishment] when they were [continually] rejecting the signs of Allah; and they were enveloped by what they used to ridicule"
  },
  {
    "id": 27,
    "text": "And We have already destroyed what surrounds you of [those] cities, and We have diversified the signs [or verses] that perhaps they might return [from disbelief]"
  },
  {
    "id": 28,
    "text": "Then why did those they took besides Allah as deities by which to approach [Him] not aid them? But they had strayed from them. And that was their falsehood and what they were inventing"
  },
  {
    "id": 29,
    "text": "And [mention, O Muhammad], when We directed to you a few of the jinn, listening to the Qur'an. And when they attended it, they said, \"Listen quietly.\" And when it was concluded, they went back to their people as warners"
  },
  {
    "id": 30,
    "text": "They said, \"O our people, indeed we have heard a [recited] Book revealed after Moses confirming what was before it which guides to the truth and to a straight path"
  },
  {
    "id": 31,
    "text": "O our people, respond to the Messenger of Allah and believe in him; Allah will forgive for you your sins and protect you from a painful punishment"
  },
  {
    "id": 32,
    "text": "But he who does not respond to the Caller of Allah will not cause failure [to Him] upon earth, and he will not have besides Him any protectors. Those are in manifest error"
  },
  {
    "id": 33,
    "text": "Do they not see that Allah, who created the heavens and earth and did not fail in their creation, is able to give life to the dead? Yes. Indeed, He is over all things competent"
  },
  {
    "id": 34,
    "text": "And the Day those who disbelieved are exposed to the Fire [it will be said], \"Is this not the truth?\" They will say, \"Yes, by our Lord.\" He will say, \"Then taste the punishment because you used to disbelieve"
  },
  {
    "id": 35,
    "text": "So be patient, [O Muhammad], as were those of determination among the messengers and do not be impatient for them. It will be - on the Day they see that which they are promised - as though they had not remained [in the world] except an hour of a day. [This is] notification. And will [any] be destroyed except the defiantly disobedient people"
  }
]

export default en
