import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Indeed, We have given you, [O Muhammad], a clear conquest"
  },
  {
    "id": 2,
    "text": "That Allah may forgive for you what preceded of your sin and what will follow and complete His favor upon you and guide you to a straight path"
  },
  {
    "id": 3,
    "text": "And [that] Allah may aid you with a mighty victory"
  },
  {
    "id": 4,
    "text": "It is He who sent down tranquillity into the hearts of the believers that they would increase in faith along with their [present] faith. And to Allah belong the soldiers of the heavens and the earth, and ever is Allah Knowing and Wise"
  },
  {
    "id": 5,
    "text": "[And] that He may admit the believing men and the believing women to gardens beneath which rivers flow to abide therein eternally and remove from them their misdeeds - and ever is that, in the sight of Allah, a great attainment"
  },
  {
    "id": 6,
    "text": "And [that] He may punish the hypocrite men and hypocrite women, and the polytheist men and polytheist women - those who assume about Allah an assumption of evil nature. Upon them is a misfortune of evil nature; and Allah has become angry with them and has cursed them and prepared for them Hell, and evil it is as a destination"
  },
  {
    "id": 7,
    "text": "And to Allah belong the soldiers of the heavens and the earth. And ever is Allah Exalted in Might and Wise"
  },
  {
    "id": 8,
    "text": "Indeed, We have sent you as a witness and a bringer of good tidings and a warner"
  },
  {
    "id": 9,
    "text": "That you [people] may believe in Allah and His Messenger and honor him and respect the Prophet and exalt Allah morning and afternoon"
  },
  {
    "id": 10,
    "text": "Indeed, those who pledge allegiance to you, [O Muhammad] - they are actually pledging allegiance to Allah. The hand of Allah is over their hands. So he who breaks his word only breaks it to the detriment of himself. And he who fulfills that which he has promised Allah - He will give him a great reward"
  },
  {
    "id": 11,
    "text": "Those who remained behind of the bedouins will say to you, \"Our properties and our families occupied us, so ask forgiveness for us.\" They say with their tongues what is not within their hearts. Say, \"Then who could prevent Allah at all if He intended for you harm or intended for you benefit? Rather, ever is Allah, with what you do, Acquainted"
  },
  {
    "id": 12,
    "text": "But you thought that the Messenger and the believers would never return to their families, ever, and that was made pleasing in your hearts. And you assumed an assumption of evil and became a people ruined"
  },
  {
    "id": 13,
    "text": "And whoever has not believed in Allah and His Messenger - then indeed, We have prepared for the disbelievers a Blaze"
  },
  {
    "id": 14,
    "text": "And to Allah belongs the dominion of the heavens and the earth. He forgives whom He wills and punishes whom He wills. And ever is Allah Forgiving and Merciful"
  },
  {
    "id": 15,
    "text": "Those who remained behind will say when you set out toward the war booty to take it, \"Let us follow you.\" They wish to change the words of Allah. Say, \"Never will you follow us. Thus did Allah say before.\" So they will say, \"Rather, you envy us.\" But [in fact] they were not understanding except a little"
  },
  {
    "id": 16,
    "text": "Say to those who remained behind of the bedouins, \"You will be called to [face] a people of great military might; you may fight them, or they will submit. So if you obey, Allah will give you a good reward; but if you turn away as you turned away before, He will punish you with a painful punishment"
  },
  {
    "id": 17,
    "text": "There is not upon the blind any guilt or upon the lame any guilt or upon the ill any guilt [for remaining behind]. And whoever obeys Allah and His Messenger - He will admit him to gardens beneath which rivers flow; but whoever turns away - He will punish him with a painful punishment"
  },
  {
    "id": 18,
    "text": "Certainly was Allah pleased with the believers when they pledged allegiance to you, [O Muhammad], under the tree, and He knew what was in their hearts, so He sent down tranquillity upon them and rewarded them with an imminent conquest"
  },
  {
    "id": 19,
    "text": "And much war booty which they will take. And ever is Allah Exalted in Might and Wise"
  },
  {
    "id": 20,
    "text": "Allah has promised you much booty that you will take [in the future] and has hastened for you this [victory] and withheld the hands of people from you - that it may be a sign for the believers and [that] He may guide you to a straight path"
  },
  {
    "id": 21,
    "text": "And [He promises] other [victories] that you were [so far] unable to [realize] which Allah has already encompassed. And ever is Allah, over all things, competent"
  },
  {
    "id": 22,
    "text": "And if those [Makkans] who disbelieve had fought you, they would have turned their backs [in flight]. Then they would not find a protector or a helper"
  },
  {
    "id": 23,
    "text": "[This is] the established way of Allah which has occurred before. And never will you find in the way of Allah any change"
  },
  {
    "id": 24,
    "text": "And it is He who withheld their hands from you and your hands from them within [the area of] Makkah after He caused you to overcome them. And ever is Allah of what you do, Seeing"
  },
  {
    "id": 25,
    "text": "They are the ones who disbelieved and obstructed you from al-Masjid al-Haram while the offering was prevented from reaching its place of sacrifice. And if not for believing men and believing women whom you did not know - that you might trample them and there would befall you because of them dishonor without [your] knowledge - [you would have been permitted to enter Makkah]. [This was so] that Allah might admit to His mercy whom He willed. If they had been apart [from them], We would have punished those who disbelieved among them with painful punishment"
  },
  {
    "id": 26,
    "text": "When those who disbelieved had put into their hearts chauvinism - the chauvinism of the time of ignorance. But Allah sent down His tranquillity upon His Messenger and upon the believers and imposed upon them the word of righteousness, and they were more deserving of it and worthy of it. And ever is Allah, of all things, Knowing"
  },
  {
    "id": 27,
    "text": "Certainly has Allah showed to His Messenger the vision in truth. You will surely enter al-Masjid al-Haram, if Allah wills, in safety, with your heads shaved and [hair] shortened, not fearing [anyone]. He knew what you did not know and has arranged before that a conquest near [at hand]"
  },
  {
    "id": 28,
    "text": "It is He who sent His Messenger with guidance and the religion of truth to manifest it over all religion. And sufficient is Allah as Witness"
  },
  {
    "id": 29,
    "text": "Muhammad is the Messenger of Allah; and those with him are forceful against the disbelievers, merciful among themselves. You see them bowing and prostrating [in prayer], seeking bounty from Allah and [His] pleasure. Their mark is on their faces from the trace of prostration. That is their description in the Torah. And their description in the Gospel is as a plant which produces its offshoots and strengthens them so they grow firm and stand upon their stalks, delighting the sowers - so that Allah may enrage by them the disbelievers. Allah has promised those who believe and do righteous deeds among them forgiveness and a great reward"
  }
]

export default en
