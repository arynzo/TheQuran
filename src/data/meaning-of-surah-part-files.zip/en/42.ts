import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Ha, Meem"
  },
  {
    "id": 2,
    "text": "Ayn, Seen, Qaf"
  },
  {
    "id": 3,
    "text": "Thus has He revealed to you, [O Muhammad], and to those before you - Allah, the Exalted in Might, the Wise"
  },
  {
    "id": 4,
    "text": "To Him belongs whatever is in the heavens and whatever is in the earth, and He is the Most High, the Most Great"
  },
  {
    "id": 5,
    "text": "The heavens almost break from above them, and the angels exalt [Allah] with praise of their Lord and ask forgiveness for those on earth. Unquestionably, it is Allah who is the Forgiving, the Merciful"
  },
  {
    "id": 6,
    "text": "And those who take as allies other than Him - Allah is [yet] Guardian over them; and you, [O Muhammad], are not over them a manager"
  },
  {
    "id": 7,
    "text": "And thus We have revealed to you an Arabic Qur'an that you may warn the Mother of Cities [Makkah] and those around it and warn of the Day of Assembly, about which there is no doubt. A party will be in Paradise and a party in the Blaze"
  },
  {
    "id": 8,
    "text": "And if Allah willed, He could have made them [of] one religion, but He admits whom He wills into His mercy. And the wrongdoers have not any protector or helper"
  },
  {
    "id": 9,
    "text": "Or have they taken protectors [or allies] besides him? But Allah - He is the Protector, and He gives life to the dead, and He is over all things competent"
  },
  {
    "id": 10,
    "text": "And in anything over which you disagree - its ruling is [to be referred] to Allah. [Say], \"That is Allah, my Lord; upon Him I have relied, and to Him I turn back"
  },
  {
    "id": 11,
    "text": "[He is] Creator of the heavens and the earth. He has made for you from yourselves, mates, and among the cattle, mates; He multiplies you thereby. There is nothing like unto Him, and He is the Hearing, the Seeing"
  },
  {
    "id": 12,
    "text": "To Him belong the keys of the heavens and the earth. He extends provision for whom He wills and restricts [it]. Indeed He is, of all things, Knowing"
  },
  {
    "id": 13,
    "text": "He has ordained for you of religion what He enjoined upon Noah and that which We have revealed to you, [O Muhammad], and what We enjoined upon Abraham and Moses and Jesus - to establish the religion and not be divided therein. Difficult for those who associate others with Allah is that to which you invite them. Allah chooses for Himself whom He wills and guides to Himself whoever turns back [to Him]"
  },
  {
    "id": 14,
    "text": "And they did not become divided until after knowledge had come to them - out of jealous animosity between themselves. And if not for a word that preceded from your Lord [postponing the penalty] until a specified time, it would have been concluded between them. And indeed, those who were granted inheritance of the Scripture after them are, concerning it, in disquieting doubt"
  },
  {
    "id": 15,
    "text": "So to that [religion of Allah] invite, [O Muhammad], and remain on a right course as you are commanded and do not follow their inclinations but say, \"I have believed in what Allah has revealed of the Qur'an, and I have been commanded to do justice among you. Allah is our Lord and your Lord. For us are our deeds, and for you your deeds. There is no [need for] argument between us and you. Allah will bring us together, and to Him is the [final] destination"
  },
  {
    "id": 16,
    "text": "And those who argue concerning Allah after He has been responded to - their argument is invalid with their Lord, and upon them is [His] wrath, and for them is a severe punishment"
  },
  {
    "id": 17,
    "text": "It is Allah who has sent down the Book in truth and [also] the balance. And what will make you perceive? Perhaps the Hour is near"
  },
  {
    "id": 18,
    "text": "Those who do not believe in it are impatient for it, but those who believe are fearful of it and know that it is the truth. Unquestionably, those who dispute concerning the Hour are in extreme error"
  },
  {
    "id": 19,
    "text": "Allah is Subtle with His servants; He gives provisions to whom He wills. And He is the Powerful, the Exalted in Might"
  },
  {
    "id": 20,
    "text": "Whoever desires the harvest of the Hereafter - We increase for him in his harvest. And whoever desires the harvest of this world - We give him thereof, but there is not for him in the Hereafter any share"
  },
  {
    "id": 21,
    "text": "Or have they other deities who have ordained for them a religion to which Allah has not consented? But if not for the decisive word, it would have been concluded between them. And indeed, the wrongdoers will have a painful punishment"
  },
  {
    "id": 22,
    "text": "You will see the wrongdoers fearful of what they have earned, and it will [certainly] befall them. And those who have believed and done righteous deeds will be in lush regions of the gardens [in Paradise] having whatever they will in the presence of their Lord. That is what is the great bounty"
  },
  {
    "id": 23,
    "text": "It is that of which Allah gives good tidings to His servants who believe and do righteous deeds. Say, [O Muhammad], \"I do not ask you for this message any payment [but] only good will through kinship.\" And whoever commits a good deed - We will increase for him good therein. Indeed, Allah is Forgiving and Appreciative"
  },
  {
    "id": 24,
    "text": "Or do they say, \"He has invented about Allah a lie\"? But if Allah willed, He could seal over your heart. And Allah eliminates falsehood and establishes the truth by His words. Indeed, He is Knowing of that within the breasts"
  },
  {
    "id": 25,
    "text": "And it is He who accepts repentance from his servants and pardons misdeeds, and He knows what you do"
  },
  {
    "id": 26,
    "text": "And He answers [the supplication of] those who have believed and done righteous deeds and increases [for] them from His bounty. But the disbelievers will have a severe punishment"
  },
  {
    "id": 27,
    "text": "And if Allah had extended [excessively] provision for His servants, they would have committed tyranny throughout the earth. But He sends [it] down in an amount which He wills. Indeed He is, of His servants, Acquainted and Seeing"
  },
  {
    "id": 28,
    "text": "And it is He who sends down the rain after they had despaired and spreads His mercy. And He is the Protector, the Praiseworthy"
  },
  {
    "id": 29,
    "text": "And of his signs is the creation of the heavens and earth and what He has dispersed throughout them of creatures. And He, for gathering them when He wills, is competent"
  },
  {
    "id": 30,
    "text": "And whatever strikes you of disaster - it is for what your hands have earned; but He pardons much"
  },
  {
    "id": 31,
    "text": "And you will not cause failure [to Allah] upon the earth. And you have not besides Allah any protector or helper"
  },
  {
    "id": 32,
    "text": "And of His signs are the ships in the sea, like mountains"
  },
  {
    "id": 33,
    "text": "If He willed, He could still the wind, and they would remain motionless on its surface. Indeed in that are signs for everyone patient and grateful"
  },
  {
    "id": 34,
    "text": "Or He could destroy them for what they earned; but He pardons much"
  },
  {
    "id": 35,
    "text": "And [that is so] those who dispute concerning Our signs may know that for them there is no place of escape"
  },
  {
    "id": 36,
    "text": "So whatever thing you have been given - it is but [for] enjoyment of the worldly life. But what is with Allah is better and more lasting for those who have believed and upon their Lord rely"
  },
  {
    "id": 37,
    "text": "And those who avoid the major sins and immoralities, and when they are angry, they forgive"
  },
  {
    "id": 38,
    "text": "And those who have responded to their lord and established prayer and whose affair is [determined by] consultation among themselves, and from what We have provided them, they spend"
  },
  {
    "id": 39,
    "text": "And those who, when tyranny strikes them, they defend themselves"
  },
  {
    "id": 40,
    "text": "And the retribution for an evil act is an evil one like it, but whoever pardons and makes reconciliation - his reward is [due] from Allah. Indeed, He does not like wrongdoers"
  },
  {
    "id": 41,
    "text": "And whoever avenges himself after having been wronged - those have not upon them any cause [for blame]"
  },
  {
    "id": 42,
    "text": "The cause is only against the ones who wrong the people and tyrannize upon the earth without right. Those will have a painful punishment"
  },
  {
    "id": 43,
    "text": "And whoever is patient and forgives - indeed, that is of the matters [requiring] determination"
  },
  {
    "id": 44,
    "text": "And he whom Allah sends astray - for him there is no protector beyond Him. And you will see the wrongdoers, when they see the punishment, saying, \"Is there for return [to the former world] any way"
  },
  {
    "id": 45,
    "text": "And you will see them being exposed to the Fire, humbled from humiliation, looking from [behind] a covert glance. And those who had believed will say, \"Indeed, the [true] losers are the ones who lost themselves and their families on the Day of Resurrection. Unquestionably, the wrongdoers are in an enduring punishment"
  },
  {
    "id": 46,
    "text": "And there will not be for them any allies to aid them other than Allah. And whoever Allah sends astray - for him there is no way"
  },
  {
    "id": 47,
    "text": "Respond to your Lord before a Day comes from Allah of which there is no repelling. No refuge will you have that day, nor for you will there be any denial"
  },
  {
    "id": 48,
    "text": "But if they turn away - then We have not sent you, [O Muhammad], over them as a guardian; upon you is only [the duty of] notification. And indeed, when We let man taste mercy from us, he rejoices in it; but if evil afflicts him for what his hands have put forth, then indeed, man is ungrateful"
  },
  {
    "id": 49,
    "text": "To Allah belongs the dominion of the heavens and the earth; He creates what he wills. He gives to whom He wills female [children], and He gives to whom He wills males"
  },
  {
    "id": 50,
    "text": "Or He makes them [both] males and females, and He renders whom He wills barren. Indeed, He is Knowing and Competent"
  },
  {
    "id": 51,
    "text": "And it is not for any human being that Allah should speak to him except by revelation or from behind a partition or that He sends a messenger to reveal, by His permission, what He wills. Indeed, He is Most High and Wise"
  },
  {
    "id": 52,
    "text": "And thus We have revealed to you an inspiration of Our command. You did not know what is the Book or [what is] faith, but We have made it a light by which We guide whom We will of Our servants. And indeed, [O Muhammad], you guide to a straight path"
  },
  {
    "id": 53,
    "text": "The path of Allah, to whom belongs whatever is in the heavens and whatever is on the earth. Unquestionably, to Allah do [all] matters evolve"
  }
]

export default en
