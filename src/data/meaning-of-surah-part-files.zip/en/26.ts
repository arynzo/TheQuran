import type { meanType } from "./type"

const en: meanType[] = [
  {
    "id": 1,
    "text": "Ta, Seen, Meem"
  },
  {
    "id": 2,
    "text": "These are the verses of the clear Book"
  },
  {
    "id": 3,
    "text": "Perhaps, [O Muhammad], you would kill yourself with grief that they will not be believers"
  },
  {
    "id": 4,
    "text": "If We willed, We could send down to them from the sky a sign for which their necks would remain humbled"
  },
  {
    "id": 5,
    "text": "And no revelation comes to them anew from the Most Merciful except that they turn away from it"
  },
  {
    "id": 6,
    "text": "For they have already denied, but there will come to them the news of that which they used to ridicule"
  },
  {
    "id": 7,
    "text": "Did they not look at the earth - how much We have produced therein from every noble kind"
  },
  {
    "id": 8,
    "text": "Indeed in that is a sign, but most of them were not to be believers"
  },
  {
    "id": 9,
    "text": "And indeed, your Lord - He is the Exalted in Might, the Merciful"
  },
  {
    "id": 10,
    "text": "And [mention] when your Lord called Moses, [saying], \"Go to the wrongdoing people"
  },
  {
    "id": 11,
    "text": "The people of Pharaoh. Will they not fear Allah"
  },
  {
    "id": 12,
    "text": "He said, \"My Lord, indeed I fear that they will deny me"
  },
  {
    "id": 13,
    "text": "And that my breast will tighten and my tongue will not be fluent, so send for Aaron"
  },
  {
    "id": 14,
    "text": "And they have upon me a [claim due to] sin, so I fear that they will kill me"
  },
  {
    "id": 15,
    "text": "[Allah] said, \"No. Go both of you with Our signs; indeed, We are with you, listening"
  },
  {
    "id": 16,
    "text": "Go to Pharaoh and say, 'We are the messengers of the Lord of the worlds"
  },
  {
    "id": 17,
    "text": "[Commanded to say], \"Send with us the Children of Israel"
  },
  {
    "id": 18,
    "text": "[Pharaoh] said, \"Did we not raise you among us as a child, and you remained among us for years of your life"
  },
  {
    "id": 19,
    "text": "And [then] you did your deed which you did, and you were of the ungrateful"
  },
  {
    "id": 20,
    "text": "[Moses] said, \"I did it, then, while I was of those astray"
  },
  {
    "id": 21,
    "text": "So I fled from you when I feared you. Then my Lord granted me wisdom and prophethood and appointed me [as one] of the messengers"
  },
  {
    "id": 22,
    "text": "And is this a favor of which you remind me - that you have enslaved the Children of Israel"
  },
  {
    "id": 23,
    "text": "Said Pharaoh, \"And what is the Lord of the worlds"
  },
  {
    "id": 24,
    "text": "[Moses] said, \"The Lord of the heavens and earth and that between them, if you should be convinced"
  },
  {
    "id": 25,
    "text": "[Pharaoh] said to those around him, \"Do you not hear"
  },
  {
    "id": 26,
    "text": "[Moses] said, \"Your Lord and the Lord of your first forefathers"
  },
  {
    "id": 27,
    "text": "[Pharaoh] said, \"Indeed, your 'messenger' who has been sent to you is mad"
  },
  {
    "id": 28,
    "text": "[Moses] said, \"Lord of the east and the west and that between them, if you were to reason"
  },
  {
    "id": 29,
    "text": "[Pharaoh] said, \"If you take a god other than me, I will surely place you among those imprisoned"
  },
  {
    "id": 30,
    "text": "[Moses] said, \"Even if I brought you proof manifest"
  },
  {
    "id": 31,
    "text": "[Pharaoh] said, \"Then bring it, if you should be of the truthful"
  },
  {
    "id": 32,
    "text": "So [Moses] threw his staff, and suddenly it was a serpent manifest"
  },
  {
    "id": 33,
    "text": "And he drew out his hand; thereupon it was white for the observers"
  },
  {
    "id": 34,
    "text": "[Pharaoh] said to the eminent ones around him, \"Indeed, this is a learned magician"
  },
  {
    "id": 35,
    "text": "He wants to drive you out of your land by his magic, so what do you advise"
  },
  {
    "id": 36,
    "text": "They said, \"Postpone [the matter of] him and his brother and send among the cities gatherers"
  },
  {
    "id": 37,
    "text": "Who will bring you every learned, skilled magician"
  },
  {
    "id": 38,
    "text": "So the magicians were assembled for the appointment of a well-known day"
  },
  {
    "id": 39,
    "text": "And it was said to the people, \"Will you congregate"
  },
  {
    "id": 40,
    "text": "That we might follow the magicians if they are the predominant"
  },
  {
    "id": 41,
    "text": "And when the magicians arrived, they said to Pharaoh, \"Is there indeed for us a reward if we are the predominant"
  },
  {
    "id": 42,
    "text": "He said, \"Yes, and indeed, you will then be of those near [to me]"
  },
  {
    "id": 43,
    "text": "Moses said to them, \"Throw whatever you will throw"
  },
  {
    "id": 44,
    "text": "So they threw their ropes and their staffs and said, \"By the might of Pharaoh, indeed it is we who are predominant"
  },
  {
    "id": 45,
    "text": "Then Moses threw his staff, and at once it devoured what they falsified"
  },
  {
    "id": 46,
    "text": "So the magicians fell down in prostration [to Allah]"
  },
  {
    "id": 47,
    "text": "They said, \"We have believed in the Lord of the worlds"
  },
  {
    "id": 48,
    "text": "The Lord of Moses and Aaron"
  },
  {
    "id": 49,
    "text": "[Pharaoh] said, \"You believed Moses before I gave you permission. Indeed, he is your leader who has taught you magic, but you are going to know. I will surely cut off your hands and your feet on opposite sides, and I will surely crucify you all"
  },
  {
    "id": 50,
    "text": "They said, \"No harm. Indeed, to our Lord we will return"
  },
  {
    "id": 51,
    "text": "Indeed, we aspire that our Lord will forgive us our sins because we were the first of the believers"
  },
  {
    "id": 52,
    "text": "And We inspired to Moses, \"Travel by night with My servants; indeed, you will be pursued"
  },
  {
    "id": 53,
    "text": "Then Pharaoh sent among the cities gatherers"
  },
  {
    "id": 54,
    "text": "[And said], \"Indeed, those are but a small band"
  },
  {
    "id": 55,
    "text": "And indeed, they are enraging us"
  },
  {
    "id": 56,
    "text": "And indeed, we are a cautious society"
  },
  {
    "id": 57,
    "text": "So We removed them from gardens and springs"
  },
  {
    "id": 58,
    "text": "And treasures and honorable station"
  },
  {
    "id": 59,
    "text": "Thus. And We caused to inherit it the Children of Israel"
  },
  {
    "id": 60,
    "text": "So they pursued them at sunrise"
  },
  {
    "id": 61,
    "text": "And when the two companies saw one another, the companions of Moses said, \"Indeed, we are to be overtaken"
  },
  {
    "id": 62,
    "text": "[Moses] said, \"No! Indeed, with me is my Lord; He will guide me"
  },
  {
    "id": 63,
    "text": "Then We inspired to Moses, \"Strike with your staff the sea,\" and it parted, and each portion was like a great towering mountain"
  },
  {
    "id": 64,
    "text": "And We advanced thereto the pursuers"
  },
  {
    "id": 65,
    "text": "And We saved Moses and those with him, all together"
  },
  {
    "id": 66,
    "text": "Then We drowned the others"
  },
  {
    "id": 67,
    "text": "Indeed in that is a sign, but most of them were not to be believers"
  },
  {
    "id": 68,
    "text": "And indeed, your Lord - He is the Exalted in Might, the Merciful"
  },
  {
    "id": 69,
    "text": "And recite to them the news of Abraham"
  },
  {
    "id": 70,
    "text": "When he said to his father and his people, \"What do you worship"
  },
  {
    "id": 71,
    "text": "They said, \"We worship idols and remain to them devoted"
  },
  {
    "id": 72,
    "text": "He said, \"Do they hear you when you supplicate"
  },
  {
    "id": 73,
    "text": "Or do they benefit you, or do they harm"
  },
  {
    "id": 74,
    "text": "They said, \"But we found our fathers doing thus"
  },
  {
    "id": 75,
    "text": "He said, \"Then do you see what you have been worshipping"
  },
  {
    "id": 76,
    "text": "You and your ancient forefathers"
  },
  {
    "id": 77,
    "text": "Indeed, they are enemies to me, except the Lord of the worlds"
  },
  {
    "id": 78,
    "text": "Who created me, and He [it is who] guides me"
  },
  {
    "id": 79,
    "text": "And it is He who feeds me and gives me drink"
  },
  {
    "id": 80,
    "text": "And when I am ill, it is He who cures me"
  },
  {
    "id": 81,
    "text": "And who will cause me to die and then bring me to life"
  },
  {
    "id": 82,
    "text": "And who I aspire that He will forgive me my sin on the Day of Recompense"
  },
  {
    "id": 83,
    "text": "[And he said], \"My Lord, grant me authority and join me with the righteous"
  },
  {
    "id": 84,
    "text": "And grant me a reputation of honor among later generations"
  },
  {
    "id": 85,
    "text": "And place me among the inheritors of the Garden of Pleasure"
  },
  {
    "id": 86,
    "text": "And forgive my father. Indeed, he has been of those astray"
  },
  {
    "id": 87,
    "text": "And do not disgrace me on the Day they are [all] resurrected"
  },
  {
    "id": 88,
    "text": "The Day when there will not benefit [anyone] wealth or children"
  },
  {
    "id": 89,
    "text": "But only one who comes to Allah with a sound heart"
  },
  {
    "id": 90,
    "text": "And Paradise will be brought near [that Day] to the righteous"
  },
  {
    "id": 91,
    "text": "And Hellfire will be brought forth for the deviators"
  },
  {
    "id": 92,
    "text": "And it will be said to them, \"Where are those you used to worship"
  },
  {
    "id": 93,
    "text": "Other than Allah? Can they help you or help themselves"
  },
  {
    "id": 94,
    "text": "So they will be overturned into Hellfire, they and the deviators"
  },
  {
    "id": 95,
    "text": "And the soldiers of Iblees, all together"
  },
  {
    "id": 96,
    "text": "They will say while they dispute therein"
  },
  {
    "id": 97,
    "text": "By Allah, we were indeed in manifest error"
  },
  {
    "id": 98,
    "text": "When we equated you with the Lord of the worlds"
  },
  {
    "id": 99,
    "text": "And no one misguided us except the criminals"
  },
  {
    "id": 100,
    "text": "So now we have no intercessors"
  },
  {
    "id": 101,
    "text": "And not a devoted friend"
  },
  {
    "id": 102,
    "text": "Then if we only had a return [to the world] and could be of the believers"
  },
  {
    "id": 103,
    "text": "Indeed in that is a sign, but most of them were not to be believers"
  },
  {
    "id": 104,
    "text": "And indeed, your Lord - He is the Exalted in Might, the Merciful"
  },
  {
    "id": 105,
    "text": "The people of Noah denied the messengers"
  },
  {
    "id": 106,
    "text": "When their brother Noah said to them, \"Will you not fear Allah"
  },
  {
    "id": 107,
    "text": "Indeed, I am to you a trustworthy messenger"
  },
  {
    "id": 108,
    "text": "So fear Allah and obey me"
  },
  {
    "id": 109,
    "text": "And I do not ask you for it any payment. My payment is only from the Lord of the worlds"
  },
  {
    "id": 110,
    "text": "So fear Allah and obey me"
  },
  {
    "id": 111,
    "text": "They said, \"Should we believe you while you are followed by the lowest [class of people]"
  },
  {
    "id": 112,
    "text": "He said, \"And what is my knowledge of what they used to do"
  },
  {
    "id": 113,
    "text": "Their account is only upon my Lord, if you [could] perceive"
  },
  {
    "id": 114,
    "text": "And I am not one to drive away the believers"
  },
  {
    "id": 115,
    "text": "I am only a clear warner"
  },
  {
    "id": 116,
    "text": "They said, \"If you do not desist, O Noah, you will surely be of those who are stoned"
  },
  {
    "id": 117,
    "text": "He said, \"My Lord, indeed my people have denied me"
  },
  {
    "id": 118,
    "text": "Then judge between me and them with decisive judgement and save me and those with me of the believers"
  },
  {
    "id": 119,
    "text": "So We saved him and those with him in the laden ship"
  },
  {
    "id": 120,
    "text": "Then We drowned thereafter the remaining ones"
  },
  {
    "id": 121,
    "text": "Indeed in that is a sign, but most of them were not to be believers"
  },
  {
    "id": 122,
    "text": "And indeed, your Lord - He is the Exalted in Might, the Merciful"
  },
  {
    "id": 123,
    "text": "Aad denied the messengers"
  },
  {
    "id": 124,
    "text": "When their brother Hud said to them, \"Will you not fear Allah"
  },
  {
    "id": 125,
    "text": "Indeed, I am to you a trustworthy messenger"
  },
  {
    "id": 126,
    "text": "So fear Allah and obey me"
  },
  {
    "id": 127,
    "text": "And I do not ask you for it any payment. My payment is only from the Lord of the worlds"
  },
  {
    "id": 128,
    "text": "Do you construct on every elevation a sign, amusing yourselves"
  },
  {
    "id": 129,
    "text": "And take for yourselves palaces and fortresses that you might abide eternally"
  },
  {
    "id": 130,
    "text": "And when you strike, you strike as tyrants"
  },
  {
    "id": 131,
    "text": "So fear Allah and obey me"
  },
  {
    "id": 132,
    "text": "And fear He who provided you with that which you know"
  },
  {
    "id": 133,
    "text": "Provided you with grazing livestock and children"
  },
  {
    "id": 134,
    "text": "And gardens and springs"
  },
  {
    "id": 135,
    "text": "Indeed, I fear for you the punishment of a terrible day"
  },
  {
    "id": 136,
    "text": "They said, \"It is all the same to us whether you advise or are not of the advisors"
  },
  {
    "id": 137,
    "text": "This is not but the custom of the former peoples"
  },
  {
    "id": 138,
    "text": "And we are not to be punished"
  },
  {
    "id": 139,
    "text": "And they denied him, so We destroyed them. Indeed in that is a sign, but most of them were not to be believers"
  },
  {
    "id": 140,
    "text": "And indeed, your Lord - He is the Exalted in Might, the Merciful"
  },
  {
    "id": 141,
    "text": "Thamud denied the messengers"
  },
  {
    "id": 142,
    "text": "When their brother Salih said to them, \"Will you not fear Allah"
  },
  {
    "id": 143,
    "text": "Indeed, I am to you a trustworthy messenger"
  },
  {
    "id": 144,
    "text": "So fear Allah and obey me"
  },
  {
    "id": 145,
    "text": "And I do not ask you for it any payment. My payment is only from the Lord of the worlds"
  },
  {
    "id": 146,
    "text": "Will you be left in what is here, secure [from death]"
  },
  {
    "id": 147,
    "text": "Within gardens and springs"
  },
  {
    "id": 148,
    "text": "And fields of crops and palm trees with softened fruit"
  },
  {
    "id": 149,
    "text": "And you carve out of the mountains, homes, with skill"
  },
  {
    "id": 150,
    "text": "So fear Allah and obey me"
  },
  {
    "id": 151,
    "text": "And do not obey the order of the transgressors"
  },
  {
    "id": 152,
    "text": "Who cause corruption in the land and do not amend"
  },
  {
    "id": 153,
    "text": "They said, \"You are only of those affected by magic"
  },
  {
    "id": 154,
    "text": "You are but a man like ourselves, so bring a sign, if you should be of the truthful"
  },
  {
    "id": 155,
    "text": "He said, \"This is a she-camel. For her is a [time of] drink, and for you is a [time of] drink, [each] on a known day"
  },
  {
    "id": 156,
    "text": "And do not touch her with harm, lest you be seized by the punishment of a terrible day"
  },
  {
    "id": 157,
    "text": "But they hamstrung her and so became regretful"
  },
  {
    "id": 158,
    "text": "And the punishment seized them. Indeed in that is a sign, but most of them were not to be believers"
  },
  {
    "id": 159,
    "text": "And indeed, your Lord - He is the Exalted in Might, the Merciful"
  },
  {
    "id": 160,
    "text": "The people of Lot denied the messengers"
  },
  {
    "id": 161,
    "text": "When their brother Lot said to them, \"Will you not fear Allah"
  },
  {
    "id": 162,
    "text": "Indeed, I am to you a trustworthy messenger"
  },
  {
    "id": 163,
    "text": "So fear Allah and obey me"
  },
  {
    "id": 164,
    "text": "And I do not ask you for it any payment. My payment is only from the Lord of the worlds"
  },
  {
    "id": 165,
    "text": "Do you approach males among the worlds"
  },
  {
    "id": 166,
    "text": "And leave what your Lord has created for you as mates? But you are a people transgressing"
  },
  {
    "id": 167,
    "text": "They said, \"If you do not desist, O Lot, you will surely be of those evicted"
  },
  {
    "id": 168,
    "text": "He said, \"Indeed, I am, toward your deed, of those who detest [it]"
  },
  {
    "id": 169,
    "text": "My Lord, save me and my family from [the consequence of] what they do"
  },
  {
    "id": 170,
    "text": "So We saved him and his family, all"
  },
  {
    "id": 171,
    "text": "Except an old woman among those who remained behind"
  },
  {
    "id": 172,
    "text": "Then We destroyed the others"
  },
  {
    "id": 173,
    "text": "And We rained upon them a rain [of stones], and evil was the rain of those who were warned"
  },
  {
    "id": 174,
    "text": "Indeed in that is a sign, but most of them were not to be believers"
  },
  {
    "id": 175,
    "text": "And indeed, your Lord - He is the Exalted in Might, the Merciful"
  },
  {
    "id": 176,
    "text": "The companions of the thicket denied the messengers"
  },
  {
    "id": 177,
    "text": "When Shu'ayb said to them, \"Will you not fear Allah"
  },
  {
    "id": 178,
    "text": "Indeed, I am to you a trustworthy messenger"
  },
  {
    "id": 179,
    "text": "So fear Allah and obey me"
  },
  {
    "id": 180,
    "text": "And I do not ask you for it any payment. My payment is only from the Lord of the worlds"
  },
  {
    "id": 181,
    "text": "Give full measure and do not be of those who cause loss"
  },
  {
    "id": 182,
    "text": "And weigh with an even balance"
  },
  {
    "id": 183,
    "text": "And do not deprive people of their due and do not commit abuse on earth, spreading corruption"
  },
  {
    "id": 184,
    "text": "And fear He who created you and the former creation"
  },
  {
    "id": 185,
    "text": "They said, \"You are only of those affected by magic"
  },
  {
    "id": 186,
    "text": "You are but a man like ourselves, and indeed, we think you are among the liars"
  },
  {
    "id": 187,
    "text": "So cause to fall upon us fragments of the sky, if you should be of the truthful"
  },
  {
    "id": 188,
    "text": "He said, \"My Lord is most knowing of what you do"
  },
  {
    "id": 189,
    "text": "And they denied him, so the punishment of the day of the black cloud seized them. Indeed, it was the punishment of a terrible day"
  },
  {
    "id": 190,
    "text": "Indeed in that is a sign, but most of them were not to be believers"
  },
  {
    "id": 191,
    "text": "And indeed, your Lord - He is the Exalted in Might, the Merciful"
  },
  {
    "id": 192,
    "text": "And indeed, the Qur'an is the revelation of the Lord of the worlds"
  },
  {
    "id": 193,
    "text": "The Trustworthy Spirit has brought it down"
  },
  {
    "id": 194,
    "text": "Upon your heart, [O Muhammad] - that you may be of the warners"
  },
  {
    "id": 195,
    "text": "In a clear Arabic language"
  },
  {
    "id": 196,
    "text": "And indeed, it is [mentioned] in the scriptures of former peoples"
  },
  {
    "id": 197,
    "text": "And has it not been a sign to them that it is recognized by the scholars of the Children of Israel"
  },
  {
    "id": 198,
    "text": "And even if We had revealed it to one among the foreigners"
  },
  {
    "id": 199,
    "text": "And he had recited it to them [perfectly], they would [still] not have been believers in it"
  },
  {
    "id": 200,
    "text": "Thus have We inserted disbelief into the hearts of the criminals"
  },
  {
    "id": 201,
    "text": "They will not believe in it until they see the painful punishment"
  },
  {
    "id": 202,
    "text": "And it will come to them suddenly while they perceive [it] not"
  },
  {
    "id": 203,
    "text": "And they will say, \"May we be reprieved"
  },
  {
    "id": 204,
    "text": "So for Our punishment are they impatient"
  },
  {
    "id": 205,
    "text": "Then have you considered if We gave them enjoyment for years"
  },
  {
    "id": 206,
    "text": "And then there came to them that which they were promised"
  },
  {
    "id": 207,
    "text": "They would not be availed by the enjoyment with which they were provided"
  },
  {
    "id": 208,
    "text": "And We did not destroy any city except that it had warners"
  },
  {
    "id": 209,
    "text": "As a reminder; and never have We been unjust"
  },
  {
    "id": 210,
    "text": "And the devils have not brought the revelation down"
  },
  {
    "id": 211,
    "text": "It is not allowable for them, nor would they be able"
  },
  {
    "id": 212,
    "text": "Indeed they, from [its] hearing, are removed"
  },
  {
    "id": 213,
    "text": "So do not invoke with Allah another deity and [thus] be among the punished"
  },
  {
    "id": 214,
    "text": "And warn, [O Muhammad], your closest kindred"
  },
  {
    "id": 215,
    "text": "And lower your wing to those who follow you of the believers"
  },
  {
    "id": 216,
    "text": "And if they disobey you, then say, \"Indeed, I am disassociated from what you are doing"
  },
  {
    "id": 217,
    "text": "And rely upon the Exalted in Might, the Merciful"
  },
  {
    "id": 218,
    "text": "Who sees you when you arise"
  },
  {
    "id": 219,
    "text": "And your movement among those who prostrate"
  },
  {
    "id": 220,
    "text": "Indeed, He is the Hearing, the Knowing"
  },
  {
    "id": 221,
    "text": "Shall I inform you upon whom the devils descend"
  },
  {
    "id": 222,
    "text": "They descend upon every sinful liar"
  },
  {
    "id": 223,
    "text": "They pass on what is heard, and most of them are liars"
  },
  {
    "id": 224,
    "text": "And the poets - [only] the deviators follow them"
  },
  {
    "id": 225,
    "text": "Do you not see that in every valley they roam"
  },
  {
    "id": 226,
    "text": "And that they say what they do not do"
  },
  {
    "id": 227,
    "text": "Except those [poets] who believe and do righteous deeds and remember Allah often and defend [the Muslims] after they were wronged. And those who have wronged are going to know to what [kind of] return they will be returned"
  }
]

export default en
